using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT5
{
    public partial class BT_Congtru : Form
    {
        public BT_Congtru()
        {
            InitializeComponent();
        }

        private void btnCong_Click(object sender, EventArgs e)
        {
            int intso1,intso2;
            intso1=Convert.ToInt32(txtso1.Text);
            intso2=Convert.ToInt32(txtso2.Text);
            int t=0;
            t= intso1+intso2;
            txtkq.Text=t.ToString();
            

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTru_Click(object sender, EventArgs e)
        {
            int intso1, intso2;
            intso1 = Convert.ToInt32(txtso1.Text);
            intso2 = Convert.ToInt32(txtso2.Text);
            int t = 0;
            t = intso1 - intso2;
            txtkq.Text = t.ToString();
        }

        private void txtso2_TextChanged(object sender, EventArgs e)
        {
            if (txtso1.Text !=""&& txtso2.Text != "")
            {
                btnCong.Enabled = true;
                btnTru.Enabled = Enabled;
            }
        }

        
    }
}