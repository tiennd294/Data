public class CmdLineArgExample {

    public static void Main(string[] args) {
    
        foreach (string s in args) {
            System.Console.WriteLine(s);
        }
        
        System.Console.WriteLine(System.Environment.CommandLine);
        foreach (string s in System.Environment.GetCommandLineArgs()) {
            System.Console.WriteLine(s);
        }

		System.Console.Read();
    }
}