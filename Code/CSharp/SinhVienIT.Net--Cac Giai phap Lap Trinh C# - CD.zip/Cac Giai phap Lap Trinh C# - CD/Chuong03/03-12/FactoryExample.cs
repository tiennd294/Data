using System;
using System.Reflection;

public interface IPlugin {
    string Description { get; set; }
    void Start();
    void Stop();
}

public abstract class AbstractPlugin : IPlugin {

    private string description = "";

    public string Description { 
        get { return description; }
        set { description = value; }
    }

    public abstract void Start();
    public abstract void Stop();
}

public class SimplePlugin : AbstractPlugin {

    public override void Start() {
        Console.WriteLine(Description  + ": Starting...");
    }

    public override void Stop() {
        Console.WriteLine(Description + ": Stopping...");
    }
}

public sealed class PluginFactory {

    public static IPlugin CreatePlugin(string assembly, 
        string pluginName, string description) {

        Type type = Type.GetType(pluginName + ", " + assembly);

        ConstructorInfo cInfo = type.GetConstructor(Type.EmptyTypes);

        IPlugin plugin = (IPlugin)cInfo.Invoke(null);

        plugin.Description = description;

        return plugin;
    }
}