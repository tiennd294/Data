# Changelog

## 1.0.6 - 2017-02-14

- [feature] Add parameter localeId to filter currencyFormat.

- [fix] Fix retrieve the default value in currencyFormatService.getLanguageByCode.

## 1.0.5 - 2017-01-26

- [fix] Fixed fraction size for IDR.

- [fix] Updated grapheme for PEN.

- [fix] Removed grapheme for CHF.

- [fix] Fixed fraction size for BYN.

## 1.0.4 - 2016-09-08

- [feature] Add formatting numeral string: decimal, thousands.

## 1.0.3 - 2016-06-30

- [feature] Add symbol template for new Belarussian Ruble (BYN).

- [fix] Fixed some names of currencies.

## 1.0.2 - 2016-05-19

- [fix] Fix symbol template for Yuan Renminbi (CNY).

## 1.0.1 - 2016-02-12

- [feature] Added Turkish Lira grapheme.
