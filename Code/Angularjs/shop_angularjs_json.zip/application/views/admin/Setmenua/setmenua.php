<script type='text/javascript'>
    $(function(){
        $('.asetlink').click(function(){
            $(".atextdata1").val($( ".asetlink option:selected" ).val())
            $(".atextdata1").attr("readonly", true);
            $(".atextdata5").val('1');
        
        });
        $('.esetlink').click(function(){
            $(".etextdata1").val($( ".esetlink option:selected" ).val())
        
        });
        $('.atextdata34').click(function(){
            $("#aimgdemo").attr('src',$( ".atextdata34 option:selected" ).val());
            $(".atextdata3").val($( ".atextdata34 option:selected" ).text());
            

            
        
        });
        $('.etextdata23').click(function(){
            $("#eimgdemo").attr('src',$( ".etextdata23 option:selected" ).val());
        	$(".etextdata2").val($( ".etextdata23 option:selected" ).text());
        });
    });
</script> 
<?php
        $this->load->view('admin/accessdata/template/messenger');
?>
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                        <div class='table-action'>
                            <a href='#' class='btnadd tip-top' data-original-title='Add'><i class='icon-plus'></i> Thêm mới</a>
                        </div>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã ID</th>  
                                    <th>Tên menu</th>  
                                    <th>Items</th>  
                                    <th>Trạng thái</th>  
                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                $i=0;
                                foreach ($tblsetmenua as $row):
                                    $i++;
                            ?>
                                <tr class='gradeU  items_'>
                                    <td><?php echo $row->Idset; ?></td>
                                    <td><?php echo $row->Name; ?></td>
                                    <td><?php echo $row->Icon; ?></td>
                                    <td><?php echo $row->Startus; ?></td>
                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Thêm mới</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='<?php echo admin_url();?>/setmenua/Add'>

							<div class='control-group'>
									<label class='control-label'>Get Link</label>
									<div class='controls '>
									     <select name='asetlink' id='asetlink' class="asetlink">
 									         <?php
 									         		$CI = &get_instance();
													$CI->load->database();
											        $conn = @mysqli_connect($CI->db->hostname,$CI->db->username,$CI->db->password, $CI->db->database) or die ('Lỗi kết nối');
												  	$sele=mysqli_query($conn, "SHOW TABLES FROM ".$CI->db->database);
										            while($row=mysqli_fetch_row($sele))
										            {
										            	?>
										            		<option value="<?php echo $row[0]; ?>"><?php echo $row[0]; ?></option>
										            	<?php
										              	
										            }
 									         ?>
 									        
									     </select>
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Items</label>
									<div class='controls '>
									     <select name='atextdata34' id='atextdata34' class="atextdata34">
									     	<option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/book.png">book</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/cabinet.png">cabinet</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/client.png">client</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/dashboard.png">dashboard</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/database.png">database</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/download.png">download</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/graph.png">graph</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/home.png">home</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/lock.png">lock</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/mail.png">mail</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/pdf.png">pdf</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/people.png">people</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/piechart.png">piechart</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/search.png">search</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/shopping-bag.png">shopping-bag</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/survey.png">survey</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/tag.png">tag</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/user.png">user</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/wallet.png">wallet</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/web.png">web</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/calendar.png">calendar</option>
									     </select>
									</div>
								</div>
								<div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                    <input name='atextdata3' type='text' class='atextdata3' value="book" readonly />
                                </div>
								
								<div class='control-group'>
									
									<div class='controls'>
										<img id="aimgdemo" class="aimgdemo" src="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/book.png" name=edit-save/>
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mã ID :</label>
									<div class='controls'>
										<input  name='atextdata1' type='text' class='span20 atextdata1' placeholder='Mã ID' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Tên menu :</label>
									<div class='controls'>
										<input  name='atextdata2' type='text' class='span20 atextdata2' placeholder='Tên menu' />
									</div>
								</div>

								

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='atextdata4' class='atextdata4 atextdata4cb' />On/Off</label>
									</div>
								</div>
								
								<div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                    <input name='atextdata5' type='text' class='atextdata5' value="" readonly />
                                </div>
									<div class='form-actions'   align='center'>
									<button id='btnadd' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	<div class='frmedit' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-pencil'></i>
									</span>
									<h5>Cập nhật</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form3' class='form-horizontal' name='form3' method='post' action='<?php echo admin_url();?>/setmenua/Edit'>
								<div class='control-group'>
										<label class='control-label'>Mã ID :</label>
										<div class='controls'><input id='etextid' name='etextid' type='text' class='span20 etextid'/></div>
								</div>
								
								<div class='control-group'>
									<label class='control-label'>Items</label>
									<div class='controls '>
									     <select name='etextdata23' id='etextdata23' class="etextdata23">
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/book.png">book</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/cabinet.png">cabinet</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/client.png">client</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/dashboard.png">dashboard</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/database.png">database</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/download.png">download</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/graph.png">graph</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/home.png">home</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/lock.png">lock</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/mail.png">mail</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/pdf.png">pdf</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/people.png">people</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/piechart.png">piechart</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/search.png">search</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/shopping-bag.png">shopping-bag</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/survey.png">survey</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/tag.png">tag</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/user.png">user</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/wallet.png">wallet</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/web.png">web</option>
 									         <option value="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/calendar.png">calendar</option>
									     </select>
									</div>
								</div>
								<div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                    <input name='etextdata2' type='text' class='etextdata2' value='book' readonly />
                                </div>
								<div class='control-group'>
									
									<div class='controls'>
										<img id="eimgdemo" class="eimgdemo" src="<?php echo public_url();?>/admin/accessdata/template/img/icons/32/book.png" name=edit-save/>
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Tên menu :</label>
									<div class='controls'>
										<input  name='etextdata1' type='text' class='span20 etextdata1' placeholder='Tên menu' />
									</div>
								</div>

								
								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='etextdata3' class='etextdata3 etextdata3cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnedit' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>







	<div class='frmdelete' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-trash'></i>
									</span>
									<h5>Xóa</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form2' class='form-horizontal' name='form2' method='post' action='<?php echo admin_url();?>/setmenua/Delete'>
								<div class='controls'>                                   <label id='Label2' class='control-label'> Bạn có chắc chắn muốn xóa không?</label>                               </div>                               <div class='control-group' style='padding-left:5px; padding-top:5px;'>                                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:13px;height:13px;overflow:auto;'>                                        <div class='control-group'>                                               <label class='control-label'>ID dstaikhoan:</label>                                           <div class='controls'>                                               <input id='textid' class='textid' name='textid' type='text' class='span20' />                                           </div>                                       </div>                                   </div>                               </div>								<div class='form-actions  txtc'   align='center'>
									<button id='btndelete' class='btn btnyes btn-success'>Có</button>
									<button id='btnhuy'  class='btn btn-success btncancel' style='margin-left:10px'> Không</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
