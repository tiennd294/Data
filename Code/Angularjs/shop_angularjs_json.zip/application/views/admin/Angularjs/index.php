<div id='datatable' class='container-fluid'>

    <!-- Bai_1 -->
<!-- <input type="text" name="demo" ng-model='message'>
<div>{{name}}</div>
<div> 10 + 20 = {{10+20}}</div> -->
<!-- End_Bai_1 -->


<!-- _Bai_2 -->

<!-- End_Bai_2 -->



<!-- <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/> -->


{{msg}}<!-- {{tongtrang}} -->
<div class='row-fluid'>
    <div class='span12'>
        <div class='widget-box'>
            <div class='widget-title'>
                <span class="txt_search">Search:</span>
                <span class='icon'><i class='icon-th'></i></span>
                <input ng-model="search" value='' placeholder='Key' class='span3 key_search'/>
                <div class='table-action divbtnadd'><!-- <a href="#_add_items" data-toggle="modal" class="btn btn-warning">Add</a>  -->
                    <a href='#_add_items' class='_btnadd tip-top' data-toggle="modal" ><i class='icon-plus'></i> Thêm mới</a>
                </div>
                
            </div>
            <div class='widget-content nopadding' style='overflow: auto;'>
                <table class='table table-bordered'>
                    <thead>
                        <tr>
                            <th>Id</th>  
                            <th ng-click="sort('id')">Id Angularjs
                                <span class="glyphicon sort-icon" ng-show="sortKey=='id'" ng-class="{'glyphicon-chevron-up':reverse,'glyphicon-chevron-down':!reverse}"></span>
                            </th>  
                            <th ng-click="sort('name')">Tên Angularjs</th>  
                            <th ng-click="sort('phone')">Phone</th>  
                            <th ng-click="sort('email')">Email   </th>  
                            <th ng-click="sort('address')">Address     </th>  
                            <th ng-click="sort('startus')">Trạng thái</th>  
                            <th>Quản lý</th>
                        </tr>
                        <tr>
                            <th></th>  
                            <th>
                                <input ng-model="search_id" value='' placeholder='Key' class='span20 key_search'/>
                            </th>  
                            <th><input ng-model="search_name" value='' placeholder='Key' class='span20 key_search'/></th>  
                            <th><input ng-model="search_email" value='' placeholder='Key' class='span20 key_search'/></th>  
                            <th><input ng-model="search_phone" value='' placeholder='Key' class='span20 key_search'/></th>  
                            <th><input ng-model="search_address" value='' placeholder='Key' class='span20 key_search'/></th>  
                            <th><input ng-model="search_startus" value='' placeholder='Key' class='span20 key_search'/></th>  
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id='fbody'>

                        <tr class='gradeU items_' dir-paginate="data in tbl_angularjs|orderBy:sortKey:reverse| filter:search|filter:search_id |filter:search_name |filter:search_email |filter:search_phone |filter:search_address |filter:search_startus | itemsPerPage:3" id='{{data.id}}'>
                            <td>{{$index+1}}</td>
                            <td>{{data.id}}</td>
                            <td>{{data.name}}</td>
                            <td>{{data.phone}}</td>
                            <td>{{data.email}}</td>
                            <td>{{data.address}}</td>
                            <td>{{data.startus}}</td>
                            <td style='text-align: center;'>
                                <a href='#_edit_items' data-toggle="modal" ng-click="select_data(data)"  class='btn btn-mini tip-top btn-primary'>Sửa</a> 
                                <a href='#_delete_items' data-toggle="modal"  ng-click="select_data(data)" class='btn btn-mini tip-top btndelete btn-danger''>Xóa</a> 
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div><!-- <div id='pagination' class='' style='text-align: center;'></div><div id="paginations" class="pagination-sm"></div> -->
        <div class="pagination" style="float: right;">
            <dir-pagination-controls
            max-size="5"
            direction-links="true"
            boundary-links="true" >
        </dir-pagination-controls>
    </div>
</div>
</div>
</div>
<script type="text/javascript">

</script>
<!-- http://jsfiddle.net/SAWsA/1754/ -->



<div class="widget-content2"> 
    <div id="_add_items" class="modal hide" aria-hidden="true" style="display: none;">
        <div class="modal-header">
            <button data-dismiss="modal" ng-click="load_tbl_data()" class="close" type="button">×</button>
            <h3>Thêm mới</h3>
        </div>
        <div class="modal-body">
            <form id='frm_add' method="post" action="">
                <div class="control-group">
                    <label class="control-label">Tên Angularjs :</label>
                    <div class="controls"><input type="text" class="span20" ng-model="tbl_data.name" name="name_test" placeholder="Tên Angularjs" required="true"></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Phone :</label>
                    <div class="controls"><input type="text" class="span20" ng-model="tbl_data.phone" placeholder="Phone" required="true"></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Email  :</label>
                    <div class="controls"><input type="text" class="span20" ng-model="tbl_data.email" placeholder="Email  " required="true"></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Address :</label>
                    <div class="controls"><textarea name="address" class="span20 ckeditor2" ng-model="tbl_data.address"  placeholder="textarea (span20)" ></textarea></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Trạng thái :</label>

                    <div class="controls"><label><input type="checkbox" ng-model="tbl_data.startus" name="startus" class="">On / Off</label></div>
                    
                    
                </div>
            </form>    

        </div>
        <div class="modal-footer"> <a data-dismiss="modal" class="btn btn-primary" href="" type="submit" ng-click="insert_data(tbl_data)">Save</a> <a data-dismiss="modal" class="btn" href="#" ng-click="load_tbl_data()">Cancel</a> </div>
    </div>
</div>



<div class="widget-content2"> 
    <div id="_edit_items" class="modal hide" aria-hidden="true" style="display: none;">
        <form id='frm_update' method="post" action="">
            <div class="modal-header">
                <button data-dismiss="modal" ng-click="load_tbl_data()" class="close" type="button">×</button>
                <h3>Updated</h3>
            </div>
            <div class="modal-body">

                <div class="control-group">
                    <label class="control-label">Tên Angularjs :</label>
                    <div class="controls"><input type="text" class="span20" ng-model="data_angularjs.name" name="name_test" placeholder="Tên Angularjs" required></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Phone :</label>
                    <div class="controls"><input type="text" class="span20" ng-model="data_angularjs.phone" placeholder="Phone" required=""></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Email  :</label>
                    <div class="controls"><input type="text" class="span20" ng-model="data_angularjs.email" placeholder="Email  " required=""></div>
                </div>
                <div class="control-group">
                    <label class="control-label">Address :</label>
                    <textarea name="address" class="span20 ckeditor2" ng-model="data_angularjs.address"></textarea>
                    <!-- <div class="controls"><input type="text" class="span20" ng-model="data_angularjs.address" placeholder="Address" required="true"></div> -->
                </div>
                <div class="control-group">
                    <label class="control-label">Trạng thái :</label>
                    <div class="controls"><label><input type="checkbox" ng-model="data_angularjs.startus" name="startus" class="">On / Off</label></div>
                </div><!-- {{datajson.username}}22 -->
                <div class="control-group">
                    <label class="control-label">phan quyen :</label>
                    <div class="__permissions" ng-repeat="permission in permissions">
                        <input type="text" name="s" ng-model="permission.name_permissions"> 
                        <input type="text" name="a" ng-model="permission.link_permissions"> 
                        <a class="unlinka" ng-click="_delete_permissions(permission)" href="">Delete</a>
                    </div>
                    <div class="_add_permissions"><a ng-click="_add_permissions()" href="#" class="unlinka">Add</a></div>
                </div>

               <!-- <ul>
                   <li ng-repeat="datajs in permissions">{{datajs.name_permissions}}</li>
               </ul> -->

            </div>
            <div class="modal-footer"> 
                <a data-dismiss="modal" class="btn btn-primary" href="" type="submit" ng-click="updated_data(data_angularjs)">Save</a> 
                <a data-dismiss="modal" class="btn" href="#" ng-click="load_tbl_data()">Cancel</a> 
            </div>
        </form>
    </div>
</div>



<div class="widget-content2"> 
    <div id="_delete_items" class="modal hide" aria-hidden="true" style="display: none;">
        <div class="modal-header">
            <button data-dismiss="modal" ng-click="load_tbl_data()" class="close" type="button">×</button>
            <h3>Deleted</h3>
        </div>
        <div class="modal-body">
            <form id='frm_delete' method="post" action="">
                <div class="control-group">
                    <label class="control-label">Bạn có muốn xóa toàn bộ thông tin về <b>{{data_angularjs.name}}</b> không?</label>
                    <div class="controls"><!-- <input type="text" aria-hidden="true" style="display:none;" class="span20" ng-model="data_angularjs.id" required="true"> --></div>
                </div>
            </form>    

        </div>
        <div class="modal-footer"> <a data-dismiss="modal" class="btn btn-primary" href="" type="submit" ng-click="deleted_data(data_angularjs)">Delete</a> <a data-dismiss="modal" class="btn" href="#" ng-click="load_tbl_data()">Cancel</a> </div>
    </div>
</div>


