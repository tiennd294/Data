using System;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic;

public class BeepTest
{

	[DllImport("kernel32.dll")]
	private static extern bool Beep(int freq, int dur);
	
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	private static void Main(string[] args)
	{
		Console.WriteLine("Win32 API beep test.");
		Beep(440, 100);
		Console.ReadLine();			

		Console.WriteLine("VB beep test.");
		Interaction.Beep();
		Console.ReadLine();			
	}
}