using System;
using System.IO;
using System.Security.Cryptography;

public class SymmetricEncryptionExample {

    public static void Main(string[] args) {
        
        byte[] key;
        byte[] iv;
        
        using(SymmetricAlgorithm alg = SymmetricAlgorithm.Create("3DES")){
            
            key = alg.Key;
            iv = alg.IV;
        }
        
        EncryptFile(args[0], "encrypted"+args[0], (byte[])key.Clone(), 
            (byte[])iv.Clone());
        
        DecryptFile("encrypted"+args[0], "decrypted"+args[0], key, iv);
    }

    private static void EncryptFile(string srcFileName, 
        string destFileName, byte[] key, byte[] iv) {
        
        Stream srcFile = 
          new FileStream(srcFileName, FileMode.Open, FileAccess.Read);
        Stream destFile = 
          new FileStream(destFileName, FileMode.Create, FileAccess.Write);
            
        using(SymmetricAlgorithm alg = SymmetricAlgorithm.Create("3DES")){

            alg.Key = key;
            alg.IV = iv;

            CryptoStream cryptoStream = new CryptoStream(srcFile, 
                                            alg.CreateEncryptor(),
                                            CryptoStreamMode.Read);

            int bufferLength;
            byte[] buffer = new byte[1024];
            
            do {
                bufferLength = cryptoStream.Read(buffer, 0, 1024);
                destFile.Write(buffer, 0, bufferLength);
            } while (bufferLength > 0);
            
            destFile.Flush();
            Array.Clear(key,0,key.Length);
            Array.Clear(iv,0,iv.Length);
            cryptoStream.Clear();                        
            cryptoStream.Close();
            srcFile.Close();
            destFile.Close();
        }
    }
    
    private static void DecryptFile(string srcFileName, 
        string destFileName, byte[] key, byte[] iv) {

        Stream srcFile = 
          new FileStream(srcFileName, FileMode.Open, FileAccess.Read);
        Stream destFile = 
          new FileStream(destFileName, FileMode.Create, FileAccess.Write);
            
        using(SymmetricAlgorithm alg = SymmetricAlgorithm.Create("3DES")){

            alg.Key = key;
            alg.IV = iv;
            
            CryptoStream cryptoStream = new CryptoStream(destFile, 
                                        alg.CreateDecryptor(), 
                                        CryptoStreamMode.Write);

            int bufferLength;
            byte[] buffer = new byte[1024];
            
            do {
                bufferLength = srcFile.Read(buffer, 0, 1024);
                cryptoStream.Write(buffer, 0, bufferLength);
            } while (bufferLength > 0);
            
            cryptoStream.FlushFinalBlock();
            Array.Clear(key,0,key.Length);
            Array.Clear(iv,0,iv.Length);
            cryptoStream.Clear();                        
            cryptoStream.Close();
            srcFile.Close();
            destFile.Close();
        }
    }
}