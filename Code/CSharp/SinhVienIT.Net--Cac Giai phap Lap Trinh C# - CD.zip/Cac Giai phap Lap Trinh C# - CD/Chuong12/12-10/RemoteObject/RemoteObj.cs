using System;
using System.Timers;

namespace RemoteObject
{
	public delegate void TaskCompleted(object sender, TaskCompleteEventArgs e);

	public class RemoteObject : MarshalByRefObject 
	{
	
		public event TaskCompleted TaskComplete;

		private Timer tmr = new Timer();

		public void StartTask() 
		{

			tmr.Interval = 10000;
			tmr.Elapsed += new ElapsedEventHandler(tmrCallback);
			tmr.Start();
		}

		private void tmrCallback(object sender, ElapsedEventArgs e) 
		{

			tmr.Enabled = false;
			if (TaskComplete != null) 
			{
				TaskComplete(this, 
					new TaskCompleteEventArgs("Task completed on server"));
			}
		}

		public override object InitializeLifetimeService() 
		{
			return null;
		}
	}

	[Serializable()] 
	public class TaskCompleteEventArgs : EventArgs 
	{

		public string Result;

		public TaskCompleteEventArgs(string result) 
		{
			this.Result = result;
		}
	}
}
namespace EventListener
{
	public class EventListener : MarshalByRefObject 
	{
		public event RemoteObject.TaskCompleted TaskComplete;

		public void OnTaskComplete(object sender, 
			RemoteObject.TaskCompleteEventArgs e) 
		{
			TaskComplete(sender, e);
		}

		public override object InitializeLifetimeService() 
		{
			return null;
		}
	}

}
