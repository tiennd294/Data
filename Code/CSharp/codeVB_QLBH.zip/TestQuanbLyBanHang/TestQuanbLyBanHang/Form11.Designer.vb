Namespace TestQuanbLyBanHang
	Partial Class Form11
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.button2 = New System.Windows.Forms.Button()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label2 = New System.Windows.Forms.Label()
			Me.button1 = New System.Windows.Forms.Button()
			Me.comboBox1 = New System.Windows.Forms.ComboBox()
			Me.label1 = New System.Windows.Forms.Label()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' button2
			' 
			Me.button2.Location = New System.Drawing.Point(356, 263)
			Me.button2.Name = "button2"
			Me.button2.Size = New System.Drawing.Size(65, 32)
			Me.button2.TabIndex = 13
			Me.button2.Text = "Tro Ve"
			Me.button2.UseVisualStyleBackColor = True
			AddHandler Me.button2.Click, New System.EventHandler(Me.button2_Click)
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(24, 55)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(410, 202)
			Me.dataGridView1.TabIndex = 12
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(376, 22)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(45, 20)
			Me.textBox1.TabIndex = 11
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(272, 25)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(94, 13)
			Me.label2.TabIndex = 10
			Me.label2.Text = "Tong So Hoa Don"
			' 
			' button1
			' 
			Me.button1.Location = New System.Drawing.Point(221, 20)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(45, 23)
			Me.button1.TabIndex = 9
			Me.button1.Text = "OK"
			Me.button1.UseVisualStyleBackColor = True
			AddHandler Me.button1.Click, New System.EventHandler(Me.button1_Click)
			' 
			' comboBox1
			' 
			Me.comboBox1.FormattingEnabled = True
			Me.comboBox1.Location = New System.Drawing.Point(108, 22)
			Me.comboBox1.Name = "comboBox1"
			Me.comboBox1.Size = New System.Drawing.Size(107, 21)
			Me.comboBox1.TabIndex = 8
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(7, 26)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(95, 13)
			Me.label1.TabIndex = 7
			Me.label1.Text = "Chon Khach Hang"
			' 
			' Form11
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(460, 311)
			Me.Controls.Add(Me.button2)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.textBox1)
			Me.Controls.Add(Me.label2)
			Me.Controls.Add(Me.button1)
			Me.Controls.Add(Me.comboBox1)
			Me.Controls.Add(Me.label1)
			Me.Name = "Form11"
			Me.Text = "Quan Ly Hoa Don Theo Khach Hang"
			Me.Load += New System.EventHandler(Me.Form11_Load)
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private button2 As System.Windows.Forms.Button
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private textBox1 As System.Windows.Forms.TextBox
		Private label2 As System.Windows.Forms.Label
		Private button1 As System.Windows.Forms.Button
		Private comboBox1 As System.Windows.Forms.ComboBox
		Private label1 As System.Windows.Forms.Label
	End Class
End Namespace
