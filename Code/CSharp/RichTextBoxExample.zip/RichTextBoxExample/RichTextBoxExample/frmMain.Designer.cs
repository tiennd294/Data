﻿namespace RichTextBoxExample
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbRecordSet = new System.Windows.Forms.GroupBox();
            this.gvRecords = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Content = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbValue = new System.Windows.Forms.GroupBox();
            this.rtxtValue = new System.Windows.Forms.RichTextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.tblMain = new System.Windows.Forms.TableLayoutPanel();
            this.pnlButton = new System.Windows.Forms.Panel();
            this.gbRecordSet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvRecords)).BeginInit();
            this.gbValue.SuspendLayout();
            this.tblMain.SuspendLayout();
            this.pnlButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbRecordSet
            // 
            this.gbRecordSet.Controls.Add(this.gvRecords);
            this.gbRecordSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbRecordSet.Location = new System.Drawing.Point(3, 3);
            this.gbRecordSet.Name = "gbRecordSet";
            this.gbRecordSet.Size = new System.Drawing.Size(842, 226);
            this.gbRecordSet.TabIndex = 0;
            this.gbRecordSet.TabStop = false;
            this.gbRecordSet.Text = "Records";
            // 
            // gvRecords
            // 
            this.gvRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvRecords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Content});
            this.gvRecords.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvRecords.Location = new System.Drawing.Point(3, 16);
            this.gvRecords.MultiSelect = false;
            this.gvRecords.Name = "gvRecords";
            this.gvRecords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gvRecords.Size = new System.Drawing.Size(836, 207);
            this.gvRecords.TabIndex = 0;
            this.gvRecords.SelectionChanged += new System.EventHandler(this.gvRecords_SelectionChanged);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Content
            // 
            this.Content.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Content.DataPropertyName = "Content";
            this.Content.HeaderText = "Content";
            this.Content.Name = "Content";
            this.Content.ReadOnly = true;
            this.Content.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // gbValue
            // 
            this.gbValue.Controls.Add(this.rtxtValue);
            this.gbValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbValue.Location = new System.Drawing.Point(3, 235);
            this.gbValue.Name = "gbValue";
            this.gbValue.Size = new System.Drawing.Size(842, 226);
            this.gbValue.TabIndex = 0;
            this.gbValue.TabStop = false;
            this.gbValue.Text = "Value";
            // 
            // rtxtValue
            // 
            this.rtxtValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtxtValue.Location = new System.Drawing.Point(3, 16);
            this.rtxtValue.Name = "rtxtValue";
            this.rtxtValue.Size = new System.Drawing.Size(836, 207);
            this.rtxtValue.TabIndex = 0;
            this.rtxtValue.Text = "";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(85, 6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Location = new System.Drawing.Point(166, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnNew
            // 
            this.btnNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNew.Location = new System.Drawing.Point(4, 6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 3;
            this.btnNew.Text = "New";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // tblMain
            // 
            this.tblMain.ColumnCount = 1;
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblMain.Controls.Add(this.pnlButton, 0, 2);
            this.tblMain.Controls.Add(this.gbRecordSet, 0, 0);
            this.tblMain.Controls.Add(this.gbValue, 0, 1);
            this.tblMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblMain.Location = new System.Drawing.Point(0, 0);
            this.tblMain.Name = "tblMain";
            this.tblMain.RowCount = 3;
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tblMain.Size = new System.Drawing.Size(848, 499);
            this.tblMain.TabIndex = 4;
            // 
            // pnlButton
            // 
            this.pnlButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlButton.Controls.Add(this.btnDelete);
            this.pnlButton.Controls.Add(this.btnSave);
            this.pnlButton.Controls.Add(this.btnNew);
            this.pnlButton.Location = new System.Drawing.Point(601, 467);
            this.pnlButton.Name = "pnlButton";
            this.pnlButton.Size = new System.Drawing.Size(244, 29);
            this.pnlButton.TabIndex = 5;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 499);
            this.Controls.Add(this.tblMain);
            this.Name = "frmMain";
            this.Text = "RichTextBox Example";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.gbRecordSet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvRecords)).EndInit();
            this.gbValue.ResumeLayout(false);
            this.tblMain.ResumeLayout(false);
            this.pnlButton.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbRecordSet;
        private System.Windows.Forms.DataGridView gvRecords;
        private System.Windows.Forms.GroupBox gbValue;
        private System.Windows.Forms.RichTextBox rtxtValue;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.TableLayoutPanel tblMain;
        private System.Windows.Forms.Panel pnlButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Content;
    }
}

