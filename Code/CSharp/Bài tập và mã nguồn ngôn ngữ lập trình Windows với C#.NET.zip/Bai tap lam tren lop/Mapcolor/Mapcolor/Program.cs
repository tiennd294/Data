using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Mapcolor
{
    class Program
    {
        
        static void Main(string[] args)
        {
            ArrayList Arr = new ArrayList();
            Class_Map C_m = new Class_Map();
            C_m.ReadFromFile("pham.txt", Arr);
            for (int i = 0; i < Arr.Count; i++)
            {
                Console.WriteLine(Arr[i].ToString());
            }
        }
    }
}
