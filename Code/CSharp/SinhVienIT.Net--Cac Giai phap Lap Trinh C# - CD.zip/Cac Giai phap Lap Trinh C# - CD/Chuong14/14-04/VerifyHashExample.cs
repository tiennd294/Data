using System;
using System.Text;
using System.Security.Cryptography;

public class VerifyHashExample {

    public static void Main(string[] args) {
    
        using (HashAlgorithm hashAlg = HashAlgorithm.Create(args[0])) {

            byte[] plainttext = Encoding.Default.GetBytes(args[1]);
                
            byte[] hash = hashAlg.ComputeHash(plainttext);

            Console.WriteLine("Hex hash verified = {0}", VerifyHexHash(hash, args[2]));
            Console.WriteLine("Base64 hash verified = {0}", VerifyB64Hash(hash, args[2]));
        }
    
        Console.ReadLine();
    }
    
    private static bool VerifyHexHash(byte[] hash, string oldHashString) {
        
        System.Text.StringBuilder newHashString = 
            new System.Text.StringBuilder(hash.Length);
        
        foreach (byte b in hash) {
            newHashString.AppendFormat("{0:X2}", b);
        }
        
        return (oldHashString == newHashString.ToString());
    }

    private static bool VerifyB64Hash(byte[] hash, string oldHashString) {
        
        string newHashString = System.Convert.ToBase64String(hash); 
        
        return (oldHashString == newHashString);
    }
    
    private static bool VerifyByteHash(byte[] hash, byte[] oldHash) {
        
        if (hash == null || oldHash == null || 
            hash.Length != oldHash.Length) return false;
            
        for (int count = 0; count < hash.Length; count++) {
            if (hash[count] != oldHash[count]) return false;
        }
    
        return true;
    }
}