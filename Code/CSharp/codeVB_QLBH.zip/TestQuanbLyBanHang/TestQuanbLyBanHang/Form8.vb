Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports System.IO

Namespace TestQuanbLyBanHang
	Public Partial Class Form8
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Public Them2 As Boolean
		Public filename As String
		Public filename2 As String
		Public Sub loaddata2()
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM SanPham", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				'(dataGridView1.Columns["Hinh"] as DataGridViewImageCell).DataSource = dt;
				' Đưa dữ liệu lên DataGridView
				dataGridView1.DataSource = dt
				' Thay đổi độ rộng cột
				dataGridView1.AutoResizeColumns()
				' Xóa trống các đối tượng trong Panel
				Me.textBox1.ResetText()
				Me.textBox2.ResetText()
				Me.textBox3.ResetText()
				Me.textBox4.ResetText()
				' Không cho thao tác trên các nút Lưu / Hủy
				Me.btnLuu.Enabled = False
				Me.btnHuyBo.Enabled = False
				'this.panel.Enabled = false;
				' Cho thao tác trên các nút Thêm / Sửa / Xóa /Thoát
				Me.btnThem.Enabled = True
				Me.btnSua.Enabled = True
				Me.btnXoa.Enabled = True
				Me.btnTroVe.Enabled = True

				' Không cho thao tác trên Panel

				Me.groupBox1.Enabled = False
			Catch
			End Try
		End Sub

		Private Sub btnReLoad_Click(sender As Object, e As EventArgs)
			loaddata2()
		End Sub

		Private Sub Form8_Load(sender As Object, e As EventArgs)
			loaddata2()
		End Sub

		Private Sub btnThem_Click(sender As Object, e As EventArgs)
			' Kich hoạt biến Them
			Them2 = True
			' Xóa trống các đối tượng trong Panel
			Me.textBox1.ResetText()
			Me.textBox2.ResetText()
			Me.textBox3.ResetText()
			Me.textBox4.ResetText()
			' Cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = True
			Me.btnHuyBo.Enabled = True
			Me.groupBox1.Enabled = True
			' Không cho thao tác trên các nút Thêm / Xóa / Thoát
			Me.btnThem.Enabled = False
			Me.btnSua.Enabled = False
			Me.btnXoa.Enabled = False
			Me.btnTroVe.Enabled = False
			' Đưa con trỏ đến TextField txtThanhPho
			Me.textBox1.Focus()
		End Sub

		Private Sub btnSua_Click(sender As Object, e As EventArgs)
			Try
				Them2 = False
				' Cho phép thao tác trên Panel this.panel.Enabled = true;
				' Thứ tự dòng hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Chuyển thông tin lên panel 
				Me.textBox1.Text = dataGridView1.Rows(r).Cells(0).Value.ToString()
				Me.textBox2.Text = dataGridView1.Rows(r).Cells(1).Value.ToString()
				Me.textBox3.Text = dataGridView1.Rows(r).Cells(2).Value.ToString()
				Me.textBox4.Text = dataGridView1.Rows(r).Cells(3).Value.ToString()
				' Cho thao tác trên các nút Lưu / Hủy / Panel
				Me.btnLuu.Enabled = True
				Me.btnHuyBo.Enabled = True
				Me.groupBox1.Enabled = True
				' Không cho thao tác trên các nút Thêm / Xóa / Thoát
				Me.btnThem.Enabled = False
				Me.btnSua.Enabled = False
				Me.btnXoa.Enabled = False
				Me.btnTroVe.Enabled = False
				' Đưa con trỏ đến TextField txtMaKH
				Me.textBox1.Focus()
			Catch
			End Try
		End Sub

		Private Sub btnLuu_Click(sender As Object, e As EventArgs)
			Dim cmd As New SqlCommand()
			Dim kn As New ketnoi()
			kn.ket_noi()
			cmd.Connection = kn.con
			Dim imgdata As Byte()
			imgdata = File.ReadAllBytes(pictureBox1.ImageLocation)
			If Them2 Then
				Try
					' Thực hiện lệnh


					cmd.CommandType = CommandType.Text
					' Lệnh Insert InTo
					cmd.CommandText = System.[String].Concat("Insert Into SanPham(MaSP, TenSP, DonViTinh, DonGia, Hinh) Values(" & "'" & Me.textBox1.Text.ToString() & "','" & Me.textBox2.Text.ToString() & "','" & Me.textBox3.Text.ToString() & "','" & Me.textBox4.Text.ToString() & "', @Hinh)")
					cmd.Parameters.Add("@Hinh", SqlDbType.Image).Value = imgdata
					cmd.CommandType = CommandType.Text

					cmd.ExecuteNonQuery()

					loaddata2()

					MessageBox.Show("Đã thêm xong!")
				Catch generatedExceptionName As SqlException
					MessageBox.Show("Không thêm được. Lỗi rồi!")
				End Try
			End If
			If Not Them2 Then
				' Thực hiện lệnh

				cmd.CommandType = CommandType.Text
				' Thứ tự dòng hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' MaKH hiện hành 
				Dim str As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Câu lệnh SQL
				cmd.CommandText = System.[String].Concat("Update SanPham Set TenSP='" & Me.textBox2.Text.ToString() & "',DonViTinh='" & Me.textBox3.Text.ToString() & "', DonGia='" & Me.textBox4.Text.ToString() & "', Hinh=@Hinh  Where MaSP='" & str & "'")
				' Cập nhật
				cmd.Parameters.Add("@Hinh", SqlDbType.Image).Value = imgdata
				cmd.CommandType = CommandType.Text
				cmd.ExecuteNonQuery()
				' Load lại dữ liệu trên DataGridView
				loaddata2()
				' Thông báo
				MessageBox.Show("Đã sửa xong!")
			End If
			' Đóng kết nối
			kn.con.Close()
		End Sub

		Private Sub btnHuyBo_Click(sender As Object, e As EventArgs)
			Me.btnThem.Enabled = True
			Me.btnSua.Enabled = True
			Me.btnXoa.Enabled = True
			Me.btnTroVe.Enabled = True
			' Không cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = False
			Me.btnHuyBo.Enabled = False
			Me.groupBox1.Enabled = False
		End Sub

		Private Sub btnXoa_Click(sender As Object, e As EventArgs)
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con
				cmd.CommandType = CommandType.Text
				' Lấy thứ tự record hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Lấy MaKH của record hiện hành 
				Dim str As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Viết câu lệnh SQL
				cmd.CommandText = System.[String].Concat("Delete From SanPham Where MaSP='" & str & "'")
				cmd.CommandType = CommandType.Text
				' Thực hiện câu lệnh SQL
				cmd.ExecuteNonQuery()
				' Cập nhật lại DataGridView
				loaddata2()
				' Thông báo

				MessageBox.Show("Đã xóa xong!")
			Catch
			End Try
		End Sub

		Private Sub btnTroVe_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		Private Sub button1_Click(sender As Object, e As EventArgs)
			Dim dlg As New OpenFileDialog()
			dlg.Filter = "All File (*.*)|*.*|JPG Files(*.JPG)|*.JPG | GIF Files(*.GIF)|*.GIF"
			If dlg.ShowDialog(Me) = DialogResult.OK Then
				pictureBox1.ImageLocation = dlg.FileName
				filename = dlg.FileName
				label5.Text = filename.Split("\"C).Last()
				filename2 = label5.Text
			End If
		End Sub

		Private Sub dataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs)
			If e.RowIndex >= 0 AndAlso e.RowIndex < dataGridView1.Rows.Count Then
				Dim row As DataGridViewRow = dataGridView1.Rows(e.RowIndex)
				'pictureBox2.Image = row.Cells[4].Value.GetType() ;
				Dim data = DirectCast(row.Cells(4).Value, [Byte]())
				Dim stream = New MemoryStream(data)

				pictureBox2.Image = Image.FromStream(stream)
			End If
		End Sub
	End Class
End Namespace
