<?php 

?>

<div class="container">
		<div class="sixteen columns">
			
			<div id="pageName">
				<div class="name_tag">
					<p>
						Tin tức sự kiện
					</p>
					<div class="shapLeft"></div>
					<div class="shapRight"></div>
				</div>
			</div><!--end pageName-->

		</div>
	</div><!-- container -->



	<!-- strat the main content area -->
	
	<div class="container">

		<div class="eleven columns">
<?php 
foreach ($tblnews as $row):  
?>
			<article>
				<div class="blogImg">

		       		<div class="pagers center">
						<a class="prev blog_slide_prev" href="#prev">Prev</a>
						<a class="nxt blog_slide_nxt" href="#nxt">Next</a>
					</div>

		        	<ul class="cycle-slideshow"
					data-cycle-fx="tileBlind"
			        data-cycle-timeout=0
			        data-cycle-slides="> li"
			        data-cycle-prev="div.pagers a.blog_slide_prev"
			        data-cycle-next="div.pagers a.blog_slide_nxt"
			        >

		        		<li><a href="<?php echo base_url().'defaults/Blogpost/'.$row->Idn; ?>"><img src="<?php echo base_url().$row->Images; ?>"  style="height:300px;" alt="blog image"></a></li>

		        	</ul>
				</div><!--end blogImg-->

				<div class="blogDesc clearfix">
					<div class="blogLeft clearfix">
						<h6><span><?php echo substr( trim($row->Createdate),  8, 2); ?></span><br><?php echo substr( $row->Createdate,  5, 2); ?>, <?php echo substr( $row->Createdate,  0, 4); ?></h6>
						<ul>
							
							<li>Người đăng: <?php echo $row->Createby; ?></li>
							<li>Lươt xem: <a href="#">113 Times</a></li>
						</ul>
					</div><!--end blog left-->

					<div class="blogRight">
						<h5>
							<a href="<?php echo base_url().'defaults/Blogpost/'.$row->Idn; ?>"><?php echo $row->Name; ?></a>
						</h5>
						<p>
							<?php echo $row->Discription; ?>
						</p>
					</div><!--end blogText-->
				</div><!--end blogDesc-->

			</article><!--end article-->
<?php
endforeach;
    
?>

			

			

			
		</div><!--end eleven-->


<?php
    $this->load->view('site/access/template/blog_right');
?>


	</div><!--end container-->
	<!-- end the main content area -->
