using System.Security;

[assembly:AllowPartiallyTrustedCallers]
public class AllowPartiallyTrustedCallersExample {

    [System.Security.Permissions.PermissionSetAttribute(System.Security.Permissions.SecurityAction.LinkDemand, Name="FullTrust")]
    public void SomeMethod() {
    }

    public static void Main() {
    }
}