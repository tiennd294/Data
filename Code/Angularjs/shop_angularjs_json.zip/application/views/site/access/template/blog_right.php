<aside class="five columns">

			<div class="blogSearch clearfix">
				<form method="get" action="#">
					<label>
						<input class="input_tool_tip" type="text" name="search" placeholder="Tìm kiếm bài viết">
					</label>
					<div class="submit">
						<input class="unlinka" onclick="__test()" type="submit" name="submit">
					</div>
				</form>
			</div><!--end blogSearch-->

			<div class="blog_category clearfix">
				<div class="box_head">
					<h3>Danh mục</h3>
				</div><!--end box_head -->
				<ul>
				<?php
					$i=1;
					foreach ($tblcategory as $row):  
				    	if ($i%2!=0) {
				    		
				    	
				?>
						
							<li><a href="<?php echo base_url().'defaults/Blogct/'.$row->Idc; ?>"><?php echo $row->Name; ?></a></li>
						
						
						
<?php
						
						}
						$i++;
					endforeach;
?>
				</ul>

				<ul>
				<?php
					$i=1;
					foreach ($tblcategory as $row):  
				    	if ($i%2==0) {
				    		
				    	
				?>
						
							<li><a href="<?php echo base_url().'defaults/Blogct/'.$row->Idc; ?>"><?php echo $row->Name; ?></a></li>
							
<?php
						
						}
						$i++;
					endforeach;
?>
				</ul>


			</div><!--end blogArchive-->

<?php /* 


			<div class="blogTab">
				<div id="tabs">

					<ul class="tabNav">
						<li><a class="currentTab" href="#recent">Recent</a></li>
						<li><a href="#puplar">Puplar</a></li>
						<li><a href="#comment">Comments</a></li>
						<div class="clear"></div>
					</ul>

					<div id="tabContentOuter">

						<div id="recent" class="tabContent">
							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>16 October, 2012</span>
								</div>
							</div>

							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>16 October, 2012</span>
								</div>
							</div>

							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>16 October, 2012</span>
								</div>
							</div>
							<div class="clear"></div>
						</div><!--end recent-->


						<div id="puplar" class="tabContent">
							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>8 September, 2012</span>
								</div>
							</div>

							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>18 September, 2012</span>
								</div>
							</div>

							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>16 September, 2012</span>
								</div>
							</div>
							<div class="clear"></div>
						</div><!--end puplar-->


						<div id="comment" class="tabContent">
							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>15 May, 2012</span>
								</div>
							</div>

							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>9 Januury, 2012</span>
								</div>
							</div>

							<div>
								<img src="images/photos/thumbnail.jpg" alt="">
								<div>
									<a href="#">
									<p>consectetur adipiscing elit. Curabitur eu risus lorem</p>
									</a>
									<span>11 June, 2012</span>
								</div>
							</div>
							<div class="clear"></div>
						</div><!--end comment-->

					</div><!--end tabContentOuter-->

				</div><!--end tabs-->
			</div><!--end blogTab-->

			<div class="blogArchive">
				<div class="box_head">
					<h3>Archive</h3>
				</div><!--end box_head -->
				<ul>
					<li><a href="#">December...<span>13</span></a></li>
					<li><a href="#">Noveber...<span>22</span></a></li>
					<li><a href="#">October...<span>20</span></a></li>
					<li><a href="#">July...<span>5</span></a></li>
					<li><a href="#">June...<span>9</span></a></li>
					<li><a href="#">May...<span>16</span></a></li>
					<li><a href="#">September...<span>18</span></a></li>
					<li><a href="#">January...<span>18</span></a></li>
				</ul>
			</div><!--end blogArchive-->


			<div class="ads">
				<h6>Addvertise Here</h6>
			</div><!--end ads-->
 */ ?>
		</aside><!--end aside five-->