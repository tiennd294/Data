Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class Form4
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub
		Public Them As Boolean
		Public Sub loaddata()
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM ThanhPho", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				' Đưa dữ liệu lên DataGridView
				dataGridView1.DataSource = dt
				' Thay đổi độ rộng cột
				dataGridView1.AutoResizeColumns()
				' Xóa trống các đối tượng trong Panel
				Me.textBox1.ResetText()
				Me.textBox2.ResetText()
				' Không cho thao tác trên các nút Lưu / Hủy
				Me.btnLuu.Enabled = False
				Me.btnHuyBo.Enabled = False
				'this.panel.Enabled = false;
				' Cho thao tác trên các nút Thêm / Sửa / Xóa /Thoát
				Me.btnThem.Enabled = True
				Me.btnSua.Enabled = True
				Me.btnXoa.Enabled = True
				Me.btnTroVe.Enabled = True

				Me.groupBox1.Enabled = False
			Catch
			End Try
		End Sub
		Private Sub Form4_Load(sender As Object, e As EventArgs)
			loaddata()
		End Sub

		Private Sub Form4_FormClosing(sender As Object, e As FormClosingEventArgs)
			Dim dt As New DataTable()
			dt.Dispose()
			dt = Nothing
			Dim kn As New ketnoi()
			kn.con = Nothing
		End Sub

		Private Sub btnReLoad_Click(sender As Object, e As EventArgs)
			loaddata()
		End Sub

		Private Sub btnTroVe_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		Private Sub btnThem_Click(sender As Object, e As EventArgs)
			' Kich hoạt biến Them
			Them = True
			' Xóa trống các đối tượng trong Panel
			Me.textBox1.ResetText()
			Me.textBox2.ResetText()
			' Cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = True
			Me.btnHuyBo.Enabled = True
			Me.groupBox1.Enabled = True
			' Không cho thao tác trên các nút Thêm / Xóa / Thoát
			Me.btnThem.Enabled = False
			Me.btnSua.Enabled = False
			Me.btnXoa.Enabled = False
			Me.btnTroVe.Enabled = False
			' Đưa con trỏ đến TextField txtThanhPho
			Me.textBox1.Focus()

		End Sub

		Private Sub btnSua_Click(sender As Object, e As EventArgs)
			Them = False
			' Cho phép thao tác trên Panel this.panel.Enabled = true;
			' Thứ tự dòng hiện hành
			Dim r As Integer = dataGridView1.CurrentCell.RowIndex
			' Chuyển thông tin lên panel 
			Me.textBox1.Text = dataGridView1.Rows(r).Cells(0).Value.ToString()
			Me.textBox2.Text = dataGridView1.Rows(r).Cells(1).Value.ToString()
			' Cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = True
			Me.btnHuyBo.Enabled = True
			Me.groupBox1.Enabled = True
			' Không cho thao tác trên các nút Thêm / Xóa / Thoát
			Me.btnThem.Enabled = False
			Me.btnSua.Enabled = False
			Me.btnXoa.Enabled = False
			Me.btnTroVe.Enabled = False
			' Đưa con trỏ đến TextField txtMaKH
			Me.textBox1.Focus()

		End Sub

		Private Sub btnXoa_Click(sender As Object, e As EventArgs)
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con
				cmd.CommandType = CommandType.Text
				' Lấy thứ tự record hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Lấy MaKH của record hiện hành 
				Dim strTHANHPHO As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Viết câu lệnh SQL
				cmd.CommandText = System.[String].Concat("Delete From ThanhPho Where ThanhPho='" & strTHANHPHO & "'")
				cmd.CommandType = CommandType.Text
				' Thực hiện câu lệnh SQL
				cmd.ExecuteNonQuery()
				' Cập nhật lại DataGridView
				loaddata()
				' Thông báo

				MessageBox.Show("Đã xóa xong!")
			Catch
			End Try
		End Sub

		Private Sub btnHuyBo_Click(sender As Object, e As EventArgs)
			' Xóa trống các đối tượng trong Panel this.txtThanhPho.ResetText(); this.txtTenThanhPho.ResetText();
			' Cho thao tác trên các nút Thêm / Sửa / Xóa / Thoát
			Me.btnThem.Enabled = True
			Me.btnSua.Enabled = True
			Me.btnXoa.Enabled = True
			Me.btnTroVe.Enabled = True
			' Không cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = False
			Me.btnHuyBo.Enabled = False
			Me.groupBox1.Enabled = False

		End Sub

		Private Sub btnLuu_Click(sender As Object, e As EventArgs)
			Dim cmd As New SqlCommand()
			Dim kn As New ketnoi()
			kn.ket_noi()
			cmd.Connection = kn.con
			If Them Then
				Try
					' Thực hiện lệnh

					cmd.CommandType = CommandType.Text
					' Lệnh Insert InTo
					cmd.CommandText = System.[String].Concat("Insert Into ThanhPho Values(" & "'" & Me.textBox1.Text.ToString() & "','" & Me.textBox2.Text.ToString() & "')")
					cmd.CommandType = CommandType.Text
					cmd.ExecuteNonQuery()
					' Load lại dữ liệu trên DataGridView
					loaddata()
					' Thông báo
					MessageBox.Show("Đã thêm xong!")
				Catch generatedExceptionName As SqlException
					MessageBox.Show("Không thêm được. Lỗi rồi!")
				End Try
			End If
			If Not Them Then
				' Thực hiện lệnh

				cmd.CommandType = CommandType.Text
				' Thứ tự dòng hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' MaKH hiện hành 
				Dim strTHANHPHO As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Câu lệnh SQL
				cmd.CommandText = System.[String].Concat("Update ThanhPho Set TenThanhPho='" & Me.textBox1.Text.ToString() & "' Where ThanhPho='" & strTHANHPHO & "'")
				' Cập nhật
				cmd.CommandType = CommandType.Text
				cmd.ExecuteNonQuery()
				' Load lại dữ liệu trên DataGridView
				loaddata()
				' Thông báo
				MessageBox.Show("Đã sửa xong!")
			End If
			' Đóng kết nối
			kn.con.Close()


		End Sub
	End Class
End Namespace
