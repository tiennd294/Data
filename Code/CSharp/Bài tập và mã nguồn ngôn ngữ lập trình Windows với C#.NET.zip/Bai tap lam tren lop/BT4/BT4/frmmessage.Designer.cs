namespace BT4
{
    partial class frmmessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panname = new System.Windows.Forms.Panel();
            this.txtmessage = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblmessage1 = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.grpcolor = new System.Windows.Forms.GroupBox();
            this.grpstyle = new System.Windows.Forms.GroupBox();
            this.lblmessage = new System.Windows.Forms.Label();
            this.piccd = new System.Windows.Forms.PictureBox();
            this.btndisplay = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnprint = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.radred = new System.Windows.Forms.RadioButton();
            this.radgreen = new System.Windows.Forms.RadioButton();
            this.radblue = new System.Windows.Forms.RadioButton();
            this.radblack = new System.Windows.Forms.RadioButton();
            this.chkbold = new System.Windows.Forms.CheckBox();
            this.chkitalic = new System.Windows.Forms.CheckBox();
            this.chkunderline = new System.Windows.Forms.CheckBox();
            this.panname.SuspendLayout();
            this.grpcolor.SuspendLayout();
            this.grpstyle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piccd)).BeginInit();
            this.SuspendLayout();
            // 
            // panname
            // 
            this.panname.Controls.Add(this.txtmessage);
            this.panname.Controls.Add(this.txtname);
            this.panname.Controls.Add(this.lblmessage1);
            this.panname.Controls.Add(this.lblname);
            this.panname.Location = new System.Drawing.Point(28, 12);
            this.panname.Name = "panname";
            this.panname.Size = new System.Drawing.Size(350, 92);
            this.panname.TabIndex = 0;
            // 
            // txtmessage
            // 
            this.txtmessage.Location = new System.Drawing.Point(126, 51);
            this.txtmessage.Name = "txtmessage";
            this.txtmessage.Size = new System.Drawing.Size(203, 20);
            this.txtmessage.TabIndex = 1;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(126, 14);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(203, 20);
            this.txtname.TabIndex = 1;
            // 
            // lblmessage1
            // 
            this.lblmessage1.AutoSize = true;
            this.lblmessage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmessage1.Location = new System.Drawing.Point(17, 54);
            this.lblmessage1.Name = "lblmessage1";
            this.lblmessage1.Size = new System.Drawing.Size(65, 17);
            this.lblmessage1.TabIndex = 0;
            this.lblmessage1.Text = "Message";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(17, 17);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(77, 17);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Your name";
            // 
            // grpcolor
            // 
            this.grpcolor.Controls.Add(this.radblack);
            this.grpcolor.Controls.Add(this.radblue);
            this.grpcolor.Controls.Add(this.radgreen);
            this.grpcolor.Controls.Add(this.radred);
            this.grpcolor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpcolor.Location = new System.Drawing.Point(28, 129);
            this.grpcolor.Name = "grpcolor";
            this.grpcolor.Size = new System.Drawing.Size(165, 144);
            this.grpcolor.TabIndex = 1;
            this.grpcolor.TabStop = false;
            this.grpcolor.Text = "Color";
            // 
            // grpstyle
            // 
            this.grpstyle.Controls.Add(this.chkunderline);
            this.grpstyle.Controls.Add(this.chkitalic);
            this.grpstyle.Controls.Add(this.chkbold);
            this.grpstyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpstyle.Location = new System.Drawing.Point(214, 129);
            this.grpstyle.Name = "grpstyle";
            this.grpstyle.Size = new System.Drawing.Size(165, 144);
            this.grpstyle.TabIndex = 1;
            this.grpstyle.TabStop = false;
            this.grpstyle.Text = "Style";
            // 
            // lblmessage
            // 
            this.lblmessage.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblmessage.Location = new System.Drawing.Point(151, 304);
            this.lblmessage.Name = "lblmessage";
            this.lblmessage.Size = new System.Drawing.Size(108, 107);
            this.lblmessage.TabIndex = 2;
            // 
            // piccd
            // 
            this.piccd.Location = new System.Drawing.Point(25, 304);
            this.piccd.Name = "piccd";
            this.piccd.Size = new System.Drawing.Size(100, 107);
            this.piccd.TabIndex = 3;
            this.piccd.TabStop = false;
            // 
            // btndisplay
            // 
            this.btndisplay.Location = new System.Drawing.Point(278, 293);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(97, 23);
            this.btndisplay.TabIndex = 4;
            this.btndisplay.Text = "&Display";
            this.btndisplay.UseVisualStyleBackColor = true;
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(278, 325);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(97, 23);
            this.btnclear.TabIndex = 4;
            this.btnclear.Text = "&Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            // 
            // btnprint
            // 
            this.btnprint.Location = new System.Drawing.Point(278, 361);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(97, 23);
            this.btnprint.TabIndex = 4;
            this.btnprint.Text = "&Print";
            this.btnprint.UseVisualStyleBackColor = true;
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(278, 393);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(97, 23);
            this.btnexit.TabIndex = 4;
            this.btnexit.Text = "&Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            // 
            // radred
            // 
            this.radred.AutoSize = true;
            this.radred.Location = new System.Drawing.Point(20, 29);
            this.radred.Name = "radred";
            this.radred.Size = new System.Drawing.Size(52, 21);
            this.radred.TabIndex = 0;
            this.radred.TabStop = true;
            this.radred.Text = "&Red";
            this.radred.UseVisualStyleBackColor = true;
            // 
            // radgreen
            // 
            this.radgreen.AutoSize = true;
            this.radgreen.Location = new System.Drawing.Point(20, 54);
            this.radgreen.Name = "radgreen";
            this.radgreen.Size = new System.Drawing.Size(66, 21);
            this.radgreen.TabIndex = 0;
            this.radgreen.TabStop = true;
            this.radgreen.Text = "&Green";
            this.radgreen.UseVisualStyleBackColor = true;
            // 
            // radblue
            // 
            this.radblue.AutoSize = true;
            this.radblue.Location = new System.Drawing.Point(20, 81);
            this.radblue.Name = "radblue";
            this.radblue.Size = new System.Drawing.Size(54, 21);
            this.radblue.TabIndex = 0;
            this.radblue.TabStop = true;
            this.radblue.Text = "&Blue";
            this.radblue.UseVisualStyleBackColor = true;
            // 
            // radblack
            // 
            this.radblack.AutoSize = true;
            this.radblack.Location = new System.Drawing.Point(20, 106);
            this.radblack.Name = "radblack";
            this.radblack.Size = new System.Drawing.Size(60, 21);
            this.radblack.TabIndex = 0;
            this.radblack.TabStop = true;
            this.radblack.Text = "B&lack";
            this.radblack.UseVisualStyleBackColor = true;
            // 
            // chkbold
            // 
            this.chkbold.AutoSize = true;
            this.chkbold.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbold.Location = new System.Drawing.Point(31, 30);
            this.chkbold.Name = "chkbold";
            this.chkbold.Size = new System.Drawing.Size(59, 21);
            this.chkbold.TabIndex = 0;
            this.chkbold.Text = "B&old";
            this.chkbold.UseVisualStyleBackColor = true;
            // 
            // chkitalic
            // 
            this.chkitalic.AutoSize = true;
            this.chkitalic.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkitalic.Location = new System.Drawing.Point(31, 68);
            this.chkitalic.Name = "chkitalic";
            this.chkitalic.Size = new System.Drawing.Size(55, 21);
            this.chkitalic.TabIndex = 0;
            this.chkitalic.Text = "&Italic";
            this.chkitalic.UseVisualStyleBackColor = true;
            // 
            // chkunderline
            // 
            this.chkunderline.AutoSize = true;
            this.chkunderline.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkunderline.Location = new System.Drawing.Point(31, 106);
            this.chkunderline.Name = "chkunderline";
            this.chkunderline.Size = new System.Drawing.Size(88, 21);
            this.chkunderline.TabIndex = 0;
            this.chkunderline.Text = "&Underline";
            this.chkunderline.UseVisualStyleBackColor = true;
            // 
            // frmmessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 438);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnprint);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btndisplay);
            this.Controls.Add(this.piccd);
            this.Controls.Add(this.lblmessage);
            this.Controls.Add(this.grpstyle);
            this.Controls.Add(this.grpcolor);
            this.Controls.Add(this.panname);
            this.Name = "frmmessage";
            this.Text = "Message Formater";
            this.panname.ResumeLayout(false);
            this.panname.PerformLayout();
            this.grpcolor.ResumeLayout(false);
            this.grpcolor.PerformLayout();
            this.grpstyle.ResumeLayout(false);
            this.grpstyle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piccd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panname;
        private System.Windows.Forms.TextBox txtmessage;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblmessage1;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.GroupBox grpcolor;
        private System.Windows.Forms.GroupBox grpstyle;
        private System.Windows.Forms.Label lblmessage;
        private System.Windows.Forms.PictureBox piccd;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnprint;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.RadioButton radblack;
        private System.Windows.Forms.RadioButton radblue;
        private System.Windows.Forms.RadioButton radgreen;
        private System.Windows.Forms.RadioButton radred;
        private System.Windows.Forms.CheckBox chkunderline;
        private System.Windows.Forms.CheckBox chkitalic;
        private System.Windows.Forms.CheckBox chkbold;
    }
}

