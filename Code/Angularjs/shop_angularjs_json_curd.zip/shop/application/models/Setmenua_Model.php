<?php
Class Setmenua_Model extends MY_Model
{
    var $table = 'setmenua';
    var $key = 'Idset';
}