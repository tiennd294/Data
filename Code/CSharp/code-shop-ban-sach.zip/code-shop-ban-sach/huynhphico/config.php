<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES.,JSC. All rights reserved
 * @Createdate Thu, 16 Jun 2011 13:11:08 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) )
{
    die( 'Stop!!!' );
}

$db_config['dbhost'] = "localhost";
$db_config['dbport'] = "";
$db_config['dbname'] = "lexuandu_01";
$db_config['dbuname'] = "lexuandu_01";
$db_config['dbpass'] = "kkk123";
$db_config['prefix'] = "nv3";

$global_config['sitekey'] = "3d85937d33b6a8cf07498f957b7444c3";// Do not change sitekey!

?>