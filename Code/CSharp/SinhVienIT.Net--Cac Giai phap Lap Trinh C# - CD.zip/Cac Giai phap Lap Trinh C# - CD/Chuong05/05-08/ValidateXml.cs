using System;
using System.Xml;
using System.Xml.Schema;

public class ValidateXml
{
	[STAThread]
	private static void Main()
	{
		ConsoleValidator consoleValidator = new ConsoleValidator();
		Console.WriteLine("Validating ProductCatalog.xml.");
		
        bool success = consoleValidator.ValidateXml("ProductCatalog.xml", "ProductCatalog.xsd");
		if (!success)
		{
			Console.WriteLine("Validation failed.");
		}
		else
		{
			Console.WriteLine("Validation succeeded.");
		}

		Console.ReadLine();
		Console.WriteLine("Validating ProductCatalog_Invalid.xml.");
		success = consoleValidator.ValidateXml("ProductCatalog_Invalid.xml", "ProductCatalog.xsd");
		if (!success)
		{
			Console.WriteLine("Validation failed.");
		}
		else
		{
			Console.WriteLine("Validation succeeded.");
		}

		Console.ReadLine();
	}
}

public class ConsoleValidator
{
	private bool failed;

	public bool Failed
	{
		get {return failed;}
	}

	public bool ValidateXml(string xmlFilename, string schemaFilename)
	{
		XmlTextReader r = new XmlTextReader(xmlFilename);
		XmlValidatingReader validator = new XmlValidatingReader(r);
		validator.ValidationType = ValidationType.Schema;
					
		XmlSchemaCollection schemas = new XmlSchemaCollection();
		schemas.Add(null, schemaFilename);
		validator.Schemas.Add(schemas);
		
		validator.ValidationEventHandler += new ValidationEventHandler(ValidationEventHandler);
        
		failed = false;
		try
		{
			while (validator.Read())
			{}
		}
		catch (XmlException err)
		{
			Console.WriteLine("A critical XML error has occurred.");
			Console.WriteLine(err.Message);
			failed = true;
		}
		finally
		{
			validator.Close();
		}

		return !failed;
	}

	private void ValidationEventHandler(object sender, ValidationEventArgs args)
	{
		failed = true;

		Console.WriteLine("Validation error: " + args.Message);
		Console.WriteLine();
	}

}