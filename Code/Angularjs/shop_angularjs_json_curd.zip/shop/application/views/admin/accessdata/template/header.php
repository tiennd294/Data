
<!DOCTYPE html>
<html lang="vi" ng-app="My_Module">

<head>  
    <title>Administrator</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php
      $this->load->view('admin/accessdata/template/load_jquery');
      $this->load->view('admin/accessdata/template/load_scripts');
      
    ?>
<script type="text/javascript">
$(document).ready(function () {
    $('.unlinka').click(function(e) { return false; }); 
    })
  function __test()
  {
    alert('Chức năng đang được xây dựng!');
  }
</script>  
</head>

<body ng-controller="My_Controller">

        <div id="header">
  
        </div>
        <!--close-Header-part--> 
        <!--top-Header-menu-->
        
        <form id="logout" name="logout" method="post" action="">
            <div id="user-nav" class="navbar navbar-inverse">
                <ul class="nav">
                    <li class="" ><a title="" class="unlinka" onclick="__test()" href="#"><i class="icon icon-user"></i> <span class="text">Profile</span></a></li>
                        <li class=""><a title="" class="unlinka" onclick="__test()" href="#"><i class="icon icon-home2"></i> <span class="text">Website</span></a></li>
                        <li class="unlinka dropdown" onclick="__test()" id="menu-messages"><a href="#" data-toggle="dropdown" data-target="#menu-messages" class="dropdown-toggle"><i class="icon icon-envelope"></i> <span class="text">Messages</span> <span class="label label-important">5</span> <b class="caret"></b></a>
                          
                        </li>
                    <li class=""><a title="" class="unlinka dropdown" onclick="__test()" href=""><i class="icon icon-cog"></i> <span class="text">Settings</span></a></li>
                    <li class=""><a href="<?php echo admin_url('users/logout');?>" onclick="$(this).closest('form').submit()" ><i class="icon icon-share-alt"></i> 
                  Logout</a></li>
                </ul>
            </div>
        </form>
  <?php /*      
  <form id="logout" name="logout" method="post" action="">
        <div id="user-nav" class="navbar navbar-inverse">
          <ul class="nav">
            
            <li class=""><a onclick="$(this).closest('form').submit()" ><i class="icon icon-share-alt"></i> 
                  <input name="logout" type="hidden" value="ok" />Logout
                    </a>
            </li>
          </ul>
        </div>
 </form>*/
 ?>
        <!--close-top-Header-menu-->
        
         
         
      <?php
        $this->load->view('admin/accessdata/template/category',$tblmenu);
      ?>


        

        
        
<div id="content">
     <div id="content-header">
        <div id="breadcrumb"> <a class="" href="<?php echo admin_url().'/'; ?>"  title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Quản lý hệ thống</a> </div>
        
      </div>
      
       
       
       <h2 style="margin-left: 5%; column-rule: blanchedalmond;"> <br/></h2>
       <?php 
       
       /*$testfck='';
       if((!isset($_SESSION["testck"])) || ($_SESSION["testck"]==""))
       echo 'null';
       else
       {
        $testfck=$_SESSION["testck"];
        echo($testfck);
       }*/
       
        ?>

       