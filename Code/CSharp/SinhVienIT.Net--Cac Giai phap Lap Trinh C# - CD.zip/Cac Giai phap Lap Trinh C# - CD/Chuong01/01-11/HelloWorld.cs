using System;
using System.Reflection;

[assembly:AssemblyKeyFile(@"..\..\MyPublicKey.snk")]

[assembly:AssemblyCulture("")]
[assembly:AssemblyVersion("1.2.3.4")]
[assembly:AssemblyDelaySign(true)]

public class HelloWorld {

    public static void Main() {
    
        Console.WriteLine("Hello, world");

		System.Console.Read();
    }
}
