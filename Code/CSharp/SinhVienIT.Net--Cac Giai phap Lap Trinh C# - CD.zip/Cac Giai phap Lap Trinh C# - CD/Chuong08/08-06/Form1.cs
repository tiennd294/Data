using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class ScreenCapture : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button cmdCapture;
	private System.Windows.Forms.Panel panel1;
	private System.Windows.Forms.PictureBox pictureBox1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ScreenCapture()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.cmdCapture = new System.Windows.Forms.Button();
		this.panel1 = new System.Windows.Forms.Panel();
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.panel1.SuspendLayout();
		this.SuspendLayout();
		// 
		// cmdCapture
		// 
		this.cmdCapture.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.cmdCapture.Location = new System.Drawing.Point(196, 256);
		this.cmdCapture.Name = "cmdCapture";
		this.cmdCapture.Size = new System.Drawing.Size(84, 24);
		this.cmdCapture.TabIndex = 1;
		this.cmdCapture.Text = "Capture";
		this.cmdCapture.Click += new System.EventHandler(this.cmdCapture_Click);
		// 
		// panel1
		// 
		this.panel1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.panel1.AutoScroll = true;
		this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				this.pictureBox1});
		this.panel1.Location = new System.Drawing.Point(12, 13);
		this.panel1.Name = "panel1";
		this.panel1.Size = new System.Drawing.Size(268, 235);
		this.panel1.TabIndex = 2;
		// 
		// pictureBox1
		// 
		this.pictureBox1.BackColor = System.Drawing.Color.White;
		this.pictureBox1.Location = new System.Drawing.Point(-4, -8);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(480, 400);
		this.pictureBox1.TabIndex = 0;
		this.pictureBox1.TabStop = false;
		// 
		// ScreenCapture
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 290);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.panel1,
																		this.cmdCapture});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "ScreenCapture";
		this.Text = "Screen Capture";
		this.panel1.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new ScreenCapture());
	}

	private void cmdCapture_Click(object sender, System.EventArgs e)
	{
		pictureBox1.Image = DesktopCapture.Capture();
		pictureBox1.Size = pictureBox1.Image.Size;
	}
}

public class DesktopCapture
{
	[DllImport("user32.dll")]
	private extern static IntPtr GetDesktopWindow();

	[DllImport("user32.dll")]
	private extern static IntPtr GetDC(IntPtr windowHandle);

	[DllImport("gdi32.dll")]
	private extern static IntPtr GetCurrentObject(IntPtr hdc,
		ushort objectType);

	[DllImport("user32.dll")]
	private extern static void ReleaseDC( IntPtr hdc );

	const int OBJ_BITMAP = 7;
	
	public static Bitmap Capture()
	{
		IntPtr desktopWindow = GetDesktopWindow();
		IntPtr desktopDC = GetDC( desktopWindow );

		IntPtr desktopBitmap = GetCurrentObject(desktopDC, OBJ_BITMAP);
		
		Bitmap desktopImage = Image.FromHbitmap( desktopBitmap );
		
		ReleaseDC(desktopDC);
		return desktopImage;
	}
}