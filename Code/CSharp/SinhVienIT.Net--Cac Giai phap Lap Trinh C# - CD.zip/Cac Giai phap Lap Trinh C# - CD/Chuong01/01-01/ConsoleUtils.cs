using System;

public class ConsoleUtils {
    
    public static string ReadString(string msg) {
        
        Console.Write(msg);
        return System.Console.ReadLine();
    }
    
    public static void WriteString(string msg) {
        
        System.Console.WriteLine(msg);
    }
    
    public static void Main() {

        string name = ReadString("Please enter your name : ");
        
        WriteString("Welcome to Microsoft .NET Framework, " + name);
    }
}
        
        