using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace System
{
    public partial class frmSystem : Form
    {
        public frmSystem()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        decimal mdecsumdollar,mdecweight;
        private void btnitem_Click(object sender, EventArgs e)
        {
            decimal decsum, decquantity, decprice,decweight;
            decquantity = Convert.ToDecimal(txtquantity.Text);
            decprice = Convert.ToDecimal(txtprice.Text);
            decsum = decquantity * decprice+mdecsumdollar;
            txtdollar.Text = "$" + decsum.ToString();
            mdecsumdollar += decsum;
            decweight=Convert.ToDecimal(txtweight.Text);
            mdecweight += decweight;
            grpcustomer.Enabled = false;
            txtdescription.Text = null;
            txtquantity.Text = null;
            txtweight.Text = null;
            txtprice.Text = null;
            btnupdate.Enabled = true;
        }
        const decimal mdecshipping=0.25m, mdectax=0.08m;
        private void btnupdate_Click(object sender, EventArgs e)
        {
            decimal decsales,decshipping,decdue,dechandling;
            if (txtstate.Text.ToUpper() == "CA")
                decsales = mdectax * mdecsumdollar;
            else
                decsales = 0;
            decshipping = mdecweight * mdecshipping;
            if (mdecweight < 10)
                dechandling = decshipping + 1;
            else if
                (mdecweight <= 100)
                dechandling = decshipping + 3;
            else
                dechandling = decshipping + 5;
            decdue = decsales + dechandling + mdecsumdollar;
            txtsales.Text = decsales.ToString();
            txtshipping.Text = dechandling.ToString();
            txtdue.Text = decdue.ToString();
            btnoder.Enabled = true;
        }
    }
}