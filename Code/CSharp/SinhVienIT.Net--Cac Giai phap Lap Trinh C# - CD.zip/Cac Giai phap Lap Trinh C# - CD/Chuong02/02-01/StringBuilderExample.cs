using System;

public class StringBuilderExample {

    public static string ReverseString(string str) {
            
        if (str == null || str.Length == 1) {        
            return str;
        }
            
        System.Text.StringBuilder revStr = 
            new System.Text.StringBuilder(str.Length);

        for (int count = str.Length-1; count > -1; count--) {           
            revStr.Append(str[count]);
        }

        return revStr.ToString();
    }

    public static void Main(string[] args) {

        foreach (string s in args) {

            Console.WriteLine(ReverseString(s));
        }

		Console.ReadLine();
    }
}