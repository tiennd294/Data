using System;
using System.IO;

public class TestTypeExample {

    public static bool IsType(object obj, string type) {

        Type t = Type.GetType(type, true, true);

        return t == obj.GetType() || obj.GetType().IsSubclassOf(t);
    }

    public static void Main() {

        Object someObject = 
            new StringReader("This is a StringReader");

        if (typeof(System.IO.StringReader) == someObject.GetType()) {

            Console.WriteLine("typeof: someObject is a StringReader");
        }

        if (someObject is System.IO.TextReader) {

            Console.WriteLine("is: someObject is a TextReader or a derived class");
        }

        if (IsType(someObject, "System.IO.TextReader")) {

            Console.WriteLine("GetType: someObject is a TextReader");
        }

        StringReader reader = someObject as System.IO.StringReader;
        if (reader != null) {

            Console.WriteLine("as: someObject is a StringReader");
        }

		Console.ReadLine();
    }
}
