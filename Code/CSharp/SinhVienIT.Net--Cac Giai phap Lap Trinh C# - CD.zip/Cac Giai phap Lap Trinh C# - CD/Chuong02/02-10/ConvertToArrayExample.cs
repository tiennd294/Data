using System.Collections;

public class ConvertToArrayExample {

    public static void Main() {

        ArrayList list = new ArrayList(5);
        list.Add("Phuong");
        list.Add("Phong");
        list.Add("Nam");
        list.Add("Tam");
        list.Add("Nhan");

        string[] array1 = new string[5];
        list.CopyTo(array1,0);        

        object[] array2 = list.ToArray();

        string[] array3 = 
            (string[])list.ToArray(System.Type.GetType("System.String"));

        foreach (string s in array1) { System.Console.WriteLine(s);}
        foreach (string s in array2) { System.Console.WriteLine(s);}
        foreach (string s in array3) { System.Console.WriteLine(s);}

		System.Console.ReadLine();
    }
}
