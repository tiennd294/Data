using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT20
{
    public partial class frmqlcahoc : Form
    {
        public frmqlcahoc()
        {
            InitializeComponent();
        }

        private void btnthoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            lstnhom1.Text = null;
            lstnhom1.Text = null;
        }
    }
}