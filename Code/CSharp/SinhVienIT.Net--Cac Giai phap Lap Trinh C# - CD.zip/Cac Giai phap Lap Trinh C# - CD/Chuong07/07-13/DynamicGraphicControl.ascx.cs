using System;
using System.Web;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Drawing.Drawing2D;

/// <summary>
///	Summary description for DynamicGraphicControl.
/// </summary>
public class DynamicGraphicControl : System.Web.UI.UserControl
{

	private string imageText = "";
	public string ImageText
	{
		get
		{
			return imageText;
		}
		set
		{
			imageText = value;
		}
	}

	private Font textFont;
	public Font TextFont
	{
		get
		{
			return textFont;
		}
		set
		{
			textFont = value;
		}
	}

	private Size imageSize;
	public Size ImageSize
	{
		get
		{
			return imageSize;
		}
		set
		{
			imageSize = value;
		}
	}

	private Color foreColor;
	public Color ForeColor
	{
		get
		{
			return foreColor;
		}
		set
		{
			foreColor = value;
		}
	}

	private Color backColor;
	public Color BackColor
	{
		get
		{
			return backColor;
		}
		set
		{
			backColor = value;
		}
	}

	private Color borderColor;
	public Color BorderColor
	{
		get
		{
			return borderColor;
		}
		set
		{
			borderColor = value;
		}
	}

	private void Page_Load(object sender, System.EventArgs e)
	{
		if (ImageText == "")
			return;

		Bitmap bitmap = new Bitmap(ImageSize.Width, ImageSize.Height);

		Graphics graphics = Graphics.FromImage(bitmap);

		graphics.Clear(BorderColor);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;

		graphics.FillRectangle(new SolidBrush(BackColor), 5, 5, 
			ImageSize.Width - 10, ImageSize.Height - 10);

		StringFormat stringFormat = new StringFormat();
		stringFormat.Alignment = StringAlignment.Center;
		stringFormat.LineAlignment = StringAlignment.Center;

		graphics.DrawString(ImageText, TextFont, new SolidBrush(ForeColor), 
   			new Rectangle(0, 0, ImageSize.Width, ImageSize.Height), 
  			stringFormat);

		bitmap.Save(Response.OutputStream, 
			System.Drawing.Imaging.ImageFormat.Gif);

		graphics.Dispose();
		bitmap.Dispose();
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	///		Required method for Designer support - do not modify
	///		the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.Load += new System.EventHandler(this.Page_Load);
	}
	#endregion
}