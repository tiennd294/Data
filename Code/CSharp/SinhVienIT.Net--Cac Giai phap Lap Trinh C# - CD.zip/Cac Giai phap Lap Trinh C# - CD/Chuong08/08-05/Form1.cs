using System;
using System.Windows.Forms;
using System.Drawing;

public class PictureScroll : System.Windows.Forms.Form
{
	private System.Windows.Forms.PictureBox pictureBox1;
	private System.Windows.Forms.Panel panel1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public PictureScroll()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.panel1 = new System.Windows.Forms.Panel();
		this.panel1.SuspendLayout();
		this.SuspendLayout();
		// 
		// pictureBox1
		// 
		this.pictureBox1.BackColor = System.Drawing.Color.White;
		this.pictureBox1.Location = new System.Drawing.Point(-4, -8);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(480, 400);
		this.pictureBox1.TabIndex = 0;
		this.pictureBox1.TabStop = false;
		// 
		// panel1
		// 
		this.panel1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.panel1.AutoScroll = true;
		this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				this.pictureBox1});
		this.panel1.Location = new System.Drawing.Point(12, 12);
		this.panel1.Name = "panel1";
		this.panel1.Size = new System.Drawing.Size(268, 240);
		this.panel1.TabIndex = 1;
		// 
		// PictureScroll
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.panel1});
		this.Name = "PictureScroll";
		this.Text = "Picture Scroll";
		this.Load += new System.EventHandler(this.PictureScroll_Load);
		this.panel1.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new PictureScroll());
	}

	private void PictureScroll_Load(object sender, System.EventArgs e)
	{
		string text = "The quick brown fox jumps over the lazy dog.";
		Font font = new Font("Tahoma", 20);
	
		Bitmap b = new Bitmap(600, 600);
		Graphics g = Graphics.FromImage(b);
		g.FillRectangle(Brushes.White, new Rectangle(0, 0, b.Width, b.Height));
		
		for (int i=0; i < 10; i++)
		{
			g.DrawString(text, font, Brushes.Black, 50, 50 + i*60);
		}

		pictureBox1.BackgroundImage = b;
		pictureBox1.Size = b.Size;
	}
}