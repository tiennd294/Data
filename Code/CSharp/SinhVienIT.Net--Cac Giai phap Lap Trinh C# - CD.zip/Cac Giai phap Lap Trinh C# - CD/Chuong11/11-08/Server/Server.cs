using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using SharedComponent;


public class TcpServerTest
{
	private static void Main()
	{
		TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 
			8000);
        
		Console.WriteLine("About to initialize port.");
		listener.Start();
        Console.WriteLine("Listening for a connection...");
        
		try
		{
			TcpClient client = listener.AcceptTcpClient();
			Console.WriteLine("Connection accepted.");
            
			NetworkStream stream = client.GetStream();
			
			BinaryWriter w = new BinaryWriter(stream);
            
			BinaryReader r = new BinaryReader(stream);
            
			if (r.ReadString() == ClientMessages.RequestConnect)
			{
				w.Write(ServerMessages.AcknowledgeOK);
				Console.WriteLine("Connection completed.");
                
				while (r.ReadString() != ClientMessages.Disconnect)
				{}
				
				Console.WriteLine();
				Console.WriteLine("Disconnect request received.");
				w.Write(ServerMessages.Disconnect);
			}
			else
			{
				Console.WriteLine("Could not complete connection.");
			}
			
			client.Close();
			Console.WriteLine("Connection closed.");
			
			listener.Stop();
			Console.WriteLine("Listener stopped.");
		}
		catch (Exception err)
		{
			Console.WriteLine(err.ToString());
		}
    
		Console.ReadLine();
	}
}