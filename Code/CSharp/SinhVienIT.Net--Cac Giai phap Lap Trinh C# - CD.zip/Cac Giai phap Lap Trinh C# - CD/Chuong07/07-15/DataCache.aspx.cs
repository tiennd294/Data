using System;
using System.Data;
using System.Web;
using System.Configuration;
using System.Diagnostics;
using System.Web.Caching;
using System.Data.SqlClient;


/// <summary>
/// Summary description for DataCache.
/// </summary>
public class DataCache : System.Web.UI.Page
{

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.cmdGetData.Click += new System.EventHandler(this.cmdGetData_Click);
		

	}
	#endregion

	protected System.Web.UI.WebControls.DataGrid DataGrid1;
	protected System.Web.UI.WebControls.Label lblInfo;
	protected System.Web.UI.WebControls.Button cmdGetData;


	private void cmdGetData_Click(object sender, System.EventArgs e)
	{
		CustomerDatabase custDB = new CustomerDatabase();
		DataGrid1.DataSource = custDB.GetCustomers();
		DataGrid1.DataBind();		
	}

}

public class CustomerDatabase
{
	private string connectionString;

	private Cache cache = HttpContext.Current.Cache;

	public CustomerDatabase()
	{
		connectionString = ConfigurationSettings.AppSettings["NorthwindCon"];
	}

	public DataSet GetCustomers()
	{
		DataSet customersDS;

		if (cache["Customers"] == null)
		{
			customersDS = GetCustomersFromDatabase();
            
			cache.Insert("Customers", customersDS, null,
				DateTime.MaxValue, TimeSpan.FromSeconds(60));

			Debug.WriteLine("DataSet created from data source.");
		}
		else
		{
			Debug.WriteLine("DataSet retrieved from cache.");
            
			customersDS = (DataSet)cache["Customers"];
		}
			
		return customersDS;
	}

	private DataSet GetCustomersFromDatabase()
	{
		DataSet customersDS = new DataSet();
            
		SqlConnection con = new SqlConnection(connectionString);
		SqlCommand cmd = new SqlCommand("SELECT * FROM Customers", con);

		SqlDataAdapter adapter = new SqlDataAdapter(cmd);
		try
		{
			con.Open();
			adapter.Fill(customersDS, "Customers");
		}
		catch
		{
			customersDS = null;
		}
		finally
		{
			con.Close();
		}

		return customersDS;
	}

}