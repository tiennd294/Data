/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
    var linkurl='/shop/public/admin/accessdata/template/js/ckfinder';
    config.filebrowserBrowseUrl = linkurl+'/ckfinder.html';
    config.filebrowserImageBrowseUrl = linkurl+'/ckfinder.html?Type=Images';
    config.filebrowserFlashBrowseUrl = linkurl+'/ckfinder.html?Type=Flash';
    config.filebrowserUploadUrl = linkurl+'/core/connector/aspx/connector.aspx?command=QuickUpload&type=Files';
    config.filebrowserImageUploadUrl = linkurl+'/core/connector/aspx/connector.aspx?command=QuickUpload&type=Images';
    config.filebrowserFlashUploadUrl = linkurl+'/core/connector/aspx/connector.aspx?command=QuickUpload&type=Flash';
};
