<?php
Class Products_Cart_Model extends MY_Model
{
    var $table = 'products_cart';
    var $key = 'Idct';
}