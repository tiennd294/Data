<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_order_ok extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Products_Cart_Model');
        $this->load->model('User_Model');
    }

    public function Index()
    {
        $input = array();
        $tblpurchase_order=$this->Products_Cart_Model->get_list($input);
        $tblmenu=$this->Products_Cart_Model->loadmenu();

        $tbluser = $this->db->query("SELECT DISTINCT products_cart.Product_code,products_cart.Startus,products_cart.Createby,`user`.Email,`user`.`Name`,`user`.Phone,`user`.Address FROM products_cart,`user` WHERE products_cart.Createby=`user`.Email ORDER BY products_cart.Createdate DESC");
        
        $data = array(
            'urldata' => 'admin/Products_Cart/purchase_order_ok',
            'tblpurchase_order' => $tblpurchase_order,
            'tbluser' => $tbluser,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

   

    public function Purchase_order()
    {
        if($this->input->post('Product_code')){
            $tg=$this->input->post('Startus');
            if ($this->input->post('Startus')=='on') {
                $tg='';
            }
            else $tg='on';

            $this->db->query("UPDATE products_cart SET products_cart.Startus='".$tg."' WHERE products_cart.Product_code='".$this->input->post('Product_code')."'");

        
        }
    }
   
}