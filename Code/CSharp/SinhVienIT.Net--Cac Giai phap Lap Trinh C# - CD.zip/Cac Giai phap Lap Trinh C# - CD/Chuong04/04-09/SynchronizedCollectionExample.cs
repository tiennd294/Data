using System.Collections;
using System.Collections.Specialized;

public class SynchronizedCollectionExample {

    public static void Main() {

        Hashtable hUnsync = new Hashtable();

        Hashtable hSync = Hashtable.Synchronized(hUnsync);

        NameValueCollection nvCollection = new NameValueCollection();

        lock (((ICollection)nvCollection).SyncRoot) {

            // ...
        }
    }
}
