using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;

public class PrintPreview : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public PrintPreview()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.cmdPreview = new System.Windows.Forms.Button();
		this.printPreviewControl = new System.Windows.Forms.PrintPreviewControl();
		this.lstZoom = new System.Windows.Forms.ListBox();
		this.label1 = new System.Windows.Forms.Label();
		this.cmdShowDialog = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// cmdPreview
		// 
		this.cmdPreview.Location = new System.Drawing.Point(347, 256);
		this.cmdPreview.Name = "cmdPreview";
		this.cmdPreview.Size = new System.Drawing.Size(100, 30);
		this.cmdPreview.TabIndex = 1;
		this.cmdPreview.Text = "Refresh";
		this.cmdPreview.Click += new System.EventHandler(this.cmdPreview_Click);
		// 
		// printPreviewControl
		// 
		this.printPreviewControl.AutoZoom = false;
		this.printPreviewControl.Location = new System.Drawing.Point(12, 16);
		this.printPreviewControl.Name = "printPreviewControl";
		this.printPreviewControl.Size = new System.Drawing.Size(316, 312);
		this.printPreviewControl.TabIndex = 2;
		this.printPreviewControl.Zoom = 0.3;
		// 
		// lstZoom
		// 
		this.lstZoom.Location = new System.Drawing.Point(344, 44);
		this.lstZoom.Name = "lstZoom";
		this.lstZoom.Size = new System.Drawing.Size(104, 199);
		this.lstZoom.TabIndex = 3;
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(344, 20);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(88, 20);
		this.label1.TabIndex = 4;
		this.label1.Text = "Zoom:";
		// 
		// cmdShowDialog
		// 
		this.cmdShowDialog.Location = new System.Drawing.Point(348, 296);
		this.cmdShowDialog.Name = "cmdShowDialog";
		this.cmdShowDialog.Size = new System.Drawing.Size(100, 30);
		this.cmdShowDialog.TabIndex = 5;
		this.cmdShowDialog.Text = "Show Dialog";
		this.cmdShowDialog.Click += new System.EventHandler(this.button1_Click);
		// 
		// PrintPreview
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(464, 342);
		this.Controls.Add(this.cmdShowDialog);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.lstZoom);
		this.Controls.Add(this.printPreviewControl);
		this.Controls.Add(this.cmdPreview);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "PrintPreview";
		this.Text = "Print preview";
		this.Load += new System.EventHandler(this.PrintPreview_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new PrintPreview());
	}

	
	private void Doc_PrintPage(object sender, PrintPageEventArgs e)
	{
		TextDocument doc = (TextDocument)sender;
        
		Font font = new Font("Arial", 10);
		float lineHeight = font.GetHeight(e.Graphics);
		
		float x = e.MarginBounds.Left;
		float y = e.MarginBounds.Top;
		
		doc.PageNumber += 1;
		
		while ((y + lineHeight) < e.MarginBounds.Bottom &&
			doc.Offset <= doc.Text.GetUpperBound(0))
		{
			e.Graphics.DrawString(doc.Text[doc.Offset], font, 
				Brushes.Black, x, y);

			doc.Offset += 1;
			
			y += lineHeight;
		}
        
		if (doc.Offset < doc.Text.GetUpperBound(0))
		{
			e.HasMorePages = true;
		}
		else
		{
			doc.Offset = 0;
		}
	}

	private System.Windows.Forms.Button cmdPreview;
	private System.Windows.Forms.PrintPreviewControl printPreviewControl;
	private System.Windows.Forms.ListBox lstZoom;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Button cmdShowDialog;

	private PrintDocument doc;

	private void PrintPreview_Load(object sender, System.EventArgs e)
	{
		for (int i=1; i <= 10; i++)
		{
			lstZoom.Items.Add((i * 10).ToString());
		}

		string[] printText = new string[100];
		for (int i=0; i < 100; i++)
		{
			printText[i] = i.ToString();
			printText[i] += ": The quick brown fox jumps over the lazy dog.";
		}

		doc = new TextDocument(printText);
		doc.PrintPage += new PrintPageEventHandler(this.Doc_PrintPage);

		lstZoom.Text = "100";
		printPreviewControl.Zoom = 1;
		printPreviewControl.Document = doc;
		printPreviewControl.Rows = 2;
	}

	private void cmdPreview_Click(object sender, System.EventArgs e)
	{
		printPreviewControl.Zoom = Single.Parse(lstZoom.Text) / 100;

		printPreviewControl.Document = doc;

		printPreviewControl.Rows = 2;
	}

	private void button1_Click(object sender, System.EventArgs e)
	{
		PrintPreviewDialog dlgPreview = new PrintPreviewDialog();
		dlgPreview.Document = doc;
		dlgPreview.Show();
	}


}

public class TextDocument : PrintDocument
{
	private string[] text;
	private int pageNumber;
	private int offset;

	public string[] Text
	{
		get {return text;}
		set {text = value;}
	}

	public int PageNumber
	{
		get {return pageNumber;}
		set {pageNumber = value;}
	}

	public int Offset
	{
		get {return offset;}
		set {offset = value;}
	}

	public TextDocument(string[] text)
	{
		this.Text = text;
	}
}