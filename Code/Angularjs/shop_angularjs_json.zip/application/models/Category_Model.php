<?php
Class Category_Model extends MY_Model
{
    var $table = 'category';
    var $key = 'Idc';
}

