using System;
using System.Reflection;
using System.Collections;
using System.Collections.Specialized;

public interface IPlugin {
    void Start();
    void Stop();
}

public class SimplePlugin : IPlugin {

    public void Start() {
        Console.WriteLine(AppDomain.CurrentDomain.FriendlyName + 
            ": SimplePlugin starting...");
    }

    public void Stop() {
        Console.WriteLine(AppDomain.CurrentDomain.FriendlyName + 
            ": SimplePlugin stopping...");
    }
}

public class PluginManager : MarshalByRefObject {

    private ListDictionary plugins = new ListDictionary();

    public PluginManager() {}

    public PluginManager(ListDictionary pluginList) {

        foreach (string plugin in pluginList.Keys) {

            this.LoadPlugin((string)pluginList[plugin], plugin);
        }
    }

    public bool LoadPlugin(string assemblyName, string pluginName) {

        try {

            Assembly assembly = Assembly.Load(assemblyName);

            IPlugin plugin = 
                (IPlugin)assembly.CreateInstance(pluginName, true);

            if (plugin != null) {

                plugins[pluginName] = plugin;

                return true;

            } else {
                return false;
            }
        } catch {
            return false;
        }
    }

    public void StartPlugin(string plugin) {

        ((IPlugin)plugins[plugin]).Start();
    }

    public void StopPlugin(string plugin) {

        ((IPlugin)plugins[plugin]).Stop();
    }

    public ArrayList GetPluginList() {

        return new ArrayList(plugins.Keys);
    }
}

public class CreateInstanceExample {

    public static void Main() {

        AppDomain domain1 = AppDomain.CreateDomain("NewAppDomain1");

        PluginManager manager1 = 
            (PluginManager)domain1.CreateInstanceAndUnwrap(
            "CreateInstanceExample", "PluginManager");

        manager1.LoadPlugin("CreateInstanceExample", "SimplePlugin");

        manager1.StartPlugin("SimplePlugin");
        manager1.StopPlugin("SimplePlugin");

        AppDomain domain2 = AppDomain.CreateDomain("NewAppDomain2");

        ListDictionary pluginList = new ListDictionary();
        pluginList["SimplePlugin"] = "CreateInstanceExample";

        PluginManager manager2 = 
            (PluginManager)domain1.CreateInstanceAndUnwrap(
            "CreateInstanceExample", "PluginManager", true, 0,
            null, new object[] {pluginList}, null, null, null);

        Console.WriteLine("Plugins in NewAppDomain2:");
        foreach (string s in manager2.GetPluginList()) {
            Console.WriteLine(" - " + s);
        }

        Console.ReadLine();
    }
}
