$(document).ready(function () {
    $('.unlinka').click(function(e) { return false; }); 
    var body = $('body');
    var frmadd = $('.frmadd');
    var frmedit = $('.frmedit');
    var frmdelete = $('.frmdelete');
    var datatable = $('#datatable');
    var maxcolumn=0;
    var id;
    $('.btnadd').click(function (e) {
        e.preventDefault();
        var numCols = $("thead").find('tr')[0].cells.length;
        maxcolumn=numCols;
        //body.css({ 'overflow': 'hidden' });
        datatable.hide(500);
        frmadd.fadeIn(500);
        $(".textfocus").focus();
        $(".Infomation").html("");


    });


    $(".btnedit").click(function (e) {
        var numCols = $("#fbody").find('tr')[0].cells.length;
        maxcolumn=numCols;
        var $td = $(this).closest('tr').children('td');
        for(var i=1;i<numCols-1;i++)
        {

            if($(".etextdata"+i+"cb").length>0){
                if($td.eq(i).text()=='on'){
                    $(".etextdata"+i+"cb").parent().addClass('checked');
                    $(".etextdata"+i+"cb").prop('checked',true);
                }
            }else
            if($(".etextdata"+i).length>0)
                $(".etextdata"+i).val($td.eq(i).text().replace(' 00:00:00',''));
        }
        var etextid = $td.eq(0).text(); $(".etextid").val(etextid);
        $('.etextid').attr("readonly", true);

        e.preventDefault();
        //body.css({ 'overflow': 'hidden' });
        datatable.hide(500);
        frmedit.fadeIn(500);
        $(".textfocus").focus();
        $(".Infomation").html("");
        
        
         /*if($(".etextdata"+i+"ck").length>0){
                //CKEDITOR.instances['etextdata'+i+'ck'].setData($td.eq(i).html());
               // $("textarea[name=etextdata"+i+"ck]").val(CKEDITOR.instances['etextdata'+i+'ck'].getData());
                //var TextArea = $("[name=etextdata"+i+"ck]").val();
                //alert(TextArea.replace("<div class='longtextt' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>").replace("<i class='setlongtext'></i></div>",""));
                //CKEDITOR.instances['etextdata'+i+'ck'].setData(TextArea.replace("<div class='longtextt' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>").replace("<i class='setlongtext'></i></div>",""));
                
            }*/

        });

    $(".btndelete").click(function (e) {
        var $td = $(this).closest('tr').children('td');
        var makhoa = $td.eq(0).text();
        $(".textid").val(makhoa);
        
        e.preventDefault();
        //body.css({ 'overflow': 'hidden' });
        datatable.hide(500);
        frmdelete.fadeIn(500);
        //$(".Infomation").html("");
        $('.textid').attr("readonly", true);
    });

    $('.btn-back').click(function (e) {
        e.preventDefault();
        body.css({ 'overflow': 'visible' });
        frmadd.fadeOut(500);
        frmedit.fadeOut(500);
        datatable.show(500);
        
    });

    $('.btncancel').click(function (e) {
        e.preventDefault();
        body.css({ 'overflow': 'visible' });
        frmdelete.fadeOut(500);
        datatable.show(500);
        
        

    });
    
    //ajax____________________________________________________________________________________________________
    
    
    // Add DATA


    
    $('#form1').submit(function(){
        return false;
    });

    $('#btnadd').click(function(e){

        for(var i=1;i<maxcolumn-1;i++)
        {
            if($(".atextdata"+i+"ck").length>0){
                $("textarea[name=atextdata"+i+"ck]").val(CKEDITOR.instances['atextdata'+i+'ck'].getData());
                var TextArea = $("[name=atextdata"+i+"ck]").val();
                $(".atextdata"+i).val(TextArea);
            }

        }

        $.post(		
          $('#form1').attr('action'),
          $('#form1').serializeArray(),
          function(result){
             $('#result').html(result);
         }
         );
        e.preventDefault();
        body.css({ 'overflow': 'visible' });
        frmadd.fadeOut(500);
        $('#msSuccess').fadeIn(300);

            /*$.ajax({
                         url : $('#form1').attr('action'),
                         type : "post",
                         dateType:"text",
                         data : $('#form1').serializeArray(),
                         success : function (result)
                         {
                              $('#result').html(result);
                         }
                     });*/

                 });
    
    
    
    // Delete data
    
    $('#form2').submit(function(){
    	return false;
    });

    $('#btndelete').click(function(e){
       $.post(		
          $('#form2').attr('action'),
          $('#form2').serializeArray(),
          function(result){
             $('#result').html(result);
         }
         );

       e.preventDefault();
       body.css({ 'overflow': 'visible' });
       frmdelete.fadeOut(500);
       $('#msSuccess').fadeIn(300);
   });


        // Edit data
        $('#form3').submit(function(){
           return false;
       });

        $('#btnedit').click(function(e){

            var numCols = $("#fbody").find('tr')[0].cells.length;
            for(var i=1;i<numCols-1;i++)
            {
                if($(".etextdata"+i+"ck").length>0){
                    $("textarea[name=etextdata"+i+"ck]").val(CKEDITOR.instances['etextdata'+i+'ck'].getData());
                    var TextArea = $("[name=etextdata"+i+"ck]").val();
                    $(".etextdata"+i).val(TextArea);
                }
                
            }
            $.post(		
              $('#form3').attr('action'),
              $('#form3').serializeArray(),
              function(result){
                 $('#result').html(result);
             }
             );
            
            e.preventDefault();
            body.css({ 'overflow': 'visible' });
            frmedit.fadeOut(500);
            //datatable.show(500);
            $('#msSuccess').fadeIn(300);
        });
        
        function getdateconvert(datetime){
            var ngay='';
            var thang='';
            var nam='';
            nam = datetime.slice(0, 4);
            thang = datetime.slice(5, 7);
            ngay = datetime.slice(8, 10);
            var newdate=ngay+'-'+thang+'-'+nam;
            return newdate;
        }
        
        

    });



/*var My_app = angular.module("My_Module",[]);
My_app.controller("My_Controller", My_Controller);

function My_Controller($scope){
    $scope.message = 'demo angularjs';
}*/

angular.module("My_Module", []).controller("My_Controller", function($scope, $http) {

    $scope.load_tbl_data = function(){
        $http.get("Angularjs/Load_data")
        .success(function(response) {
            $scope.tbl_angularjs = response;
        });
    };
    $scope.load_tbl_data();

    $scope.insert_data=function($getdata){
        var data = $getdata;
        
        $http.post("Angularjs/Add", data).success(function(){
            $scope.msg="Insert_ok";
            $scope.load_tbl_data();
        })
    };

    $scope.select_data = function($data){
        $scope.data_angularjs = $data;
        //$scope.tongtrang = response.length;
        /*if ($data.address != '') {
            $scope.datajson = JSON.parse($data.address);
        }*/
    };

    $scope.updated_data = function($getdata){
        var data = $getdata;
        $http.post("Angularjs/Update", data).success(function(){
            $scope.msg="Update_ok";
            $scope.load_tbl_data();
        })
    };



    $scope.deleted_data =function($getdata){
        var data = $getdata;
        $http.post("Angularjs/Delete", data).success(function(){
            $scope.msg="Delete_ok";
            $scope.load_tbl_data();
        })
    };

    $scope.sort = function(keyname){
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }
});





 /*$scope.pagination = function($totalrow, callback){
        var totalPages = Math.ceil($totalrow / home_config.page_size);
        $('#paginations').twbsPagination({
            totalPages: totalPages,
            visiblePages: 10,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                $scope.load_tbl_data();
            }
        });
    };*/
    /*$scope.datajson = [{
            "username" : "admin",
            "email" : "admin@gmail.com",
            "website" : "admin.net",
            "title" : "Học lập trình với JSON"
        }];*/