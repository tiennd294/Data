using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace bai_tap_ven_nha
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        congtru ct1;
        congtru ct2;
        private void btncong_Click(object sender, EventArgs e)
        {
            int ts = Convert.ToInt32(txttuso.Text);
            int ms = Convert.ToInt32(txtmauso.Text);
            ct1 = new congtru(ts,ms);
            int ts1 = Convert.ToInt32(txttuso1.Text);
            int ms2 = Convert.ToInt32(txtmauso2.Text);
            ct2 = new congtru(ts1, ms2);
            txtkq.Text = ct1.cong(ct2).ToString();
            
        }

        private void btntru_Click(object sender, EventArgs e)
        {
            int ts = Convert.ToInt32(txttuso.Text);
            int ms = Convert.ToInt32(txtmauso.Text);
            ct1 = new congtru(ts, ms);
            int ts1 = Convert.ToInt32(txttuso1.Text);
            int ms2 = Convert.ToInt32(txtmauso2.Text);
            ct2 = new congtru(ts1, ms2);
            txtkq.Text = ct1.tru(ct2).ToString();
            
        }

        private void btnrutgon_Click(object sender, EventArgs e)
        {
            txtkq.Text = "";
            txttuso.Text="";
            txtmauso.Text="";
            txtmauso2.Text = "";
            txttuso1.Text = "";
        }
        private void btnthoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}