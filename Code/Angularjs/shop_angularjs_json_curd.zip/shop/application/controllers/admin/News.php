<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('News_Model');
        $this->load->model('Category_Model');
    }

    public function Index()
    {
        $input = array();
        $tblnews=$this->News_Model->get_list($input);
        $tblmenu=$this->News_Model->loadmenu();
        $tblcategory=$this->Category_Model->get_list($input);
        $data = array(
            'urldata' => 'admin/News/news',
            'tblnews' => $tblnews,
            'tblcategory' => $tblcategory,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

    

    public function Add()
    {
        $Images=str_replace(base_url(), '', $this->input->post('atextdata3'));
        $data = array(
            'Name' => $this->input->post('atextdata1'),
            'Discription' => $this->input->post('atextdata2'),
            'Images' => $Images,
            'Idc' => $this->input->post('atextdata4'),
            'Detail' => $this->input->post('atextdata5'),
            'Startus' => $this->input->post('atextdata6'),
            'Createby' => $this->session->userdata('Administrator'),
            'Createdate' => date("Y/m/d H:i:s")

        );
       $this->News_Model->create($data);
    }


    public function Edit()
    {
        $Images=str_replace(base_url(), '', $this->input->post('etextdata3'));
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Discription' => $this->input->post('etextdata2'),
            'Images' => $Images,
            'Idc' => $this->input->post('etextdata4'),
            'Detail' => $this->input->post('etextdata5'),
            'Startus' => $this->input->post('etextdata6'),
            'Modifyby' => $this->session->userdata('Administrator'),
            'Modifydate' => date("Y/m/d H:i:s")
        );
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->News_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->News_Model->delete($Id);
       
        }
    }

    
}