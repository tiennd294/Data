using System;
using System.IO;

public class CopyDir
{
	private static void Main(string[] args)
	{
		if (args.Length < 2)
		{
			Console.WriteLine("usage:   CopyDir [sourcePath] [destinationPath]");
			return;
		}

		DirectoryInfo sourceDir = new DirectoryInfo(args[0]);
		DirectoryInfo destinationDir = new DirectoryInfo(args[1]);

		FileSystemUtil.CopyDirectory(sourceDir, destinationDir);
		
		Console.WriteLine("Copy complete.");
		Console.ReadLine();
	}
}

public class FileSystemUtil 
{

	public static void CopyDirectory(DirectoryInfo source,
		DirectoryInfo destination) 
	{

		if (!destination.Exists) 
		{
			destination.Create();
		}

		FileInfo[] files = source.GetFiles();
		foreach (FileInfo file in files) 
		{

			file.CopyTo(Path.Combine(destination.FullName, file.Name));
		}

		DirectoryInfo[] dirs = source.GetDirectories();
		foreach (DirectoryInfo dir in dirs) 
		{

			string destinationDir = Path.Combine(destination.FullName, dir.Name);

			CopyDirectory(dir, new DirectoryInfo(destinationDir));
		}
	}
}