using System;
using System.Security.Policy;
using System.Security.Cryptography.X509Certificates;

public class AppDomainEvidenceExample {

    public static void Main() {
    
        AppDomain appDom1 = CreateAppDomain("Litware", "litware.cer");
        AppDomain appDom2 = CreateAppDomain("Fabrikam", "fabrikam.cer");
        
        // ...
    }

    private static AppDomain CreateAppDomain(string name, string certFile){
        
        X509Certificate cert = 
            X509Certificate.CreateFromCertFile(certFile);
        
        Publisher publisherEvidence = new Publisher(cert);

        Evidence evidence = new Evidence();

        evidence.AddHost(publisherEvidence);

        return AppDomain.CreateDomain(name, evidence);
    }
}