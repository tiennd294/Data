Namespace TestQuanbLyBanHang
	Partial Class Form2
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.button1 = New System.Windows.Forms.Button()
			Me.button2 = New System.Windows.Forms.Button()
			Me.groupBox1.SuspendLayout()
			Me.SuspendLayout()
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me.textBox2)
			Me.groupBox1.Controls.Add(Me.textBox1)
			Me.groupBox1.Controls.Add(Me.label2)
			Me.groupBox1.Controls.Add(Me.label1)
			Me.groupBox1.Location = New System.Drawing.Point(36, 38)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(329, 100)
			Me.groupBox1.TabIndex = 0
			Me.groupBox1.TabStop = False
			Me.groupBox1.Text = "Thong Tin Dang Nhap"
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(130, 63)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.PasswordChar = "*"C
			Me.textBox2.Size = New System.Drawing.Size(168, 20)
			Me.textBox2.TabIndex = 3
			AddHandler Me.textBox2.KeyDown, New System.Windows.Forms.KeyEventHandler(Me.textBox2_KeyDown)
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(130, 28)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(168, 20)
			Me.textBox1.TabIndex = 2
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(23, 66)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(53, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Mat Khau"
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(23, 31)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(86, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Ten Nguoi Dung"
			' 
			' button1
			' 
			Me.button1.Location = New System.Drawing.Point(82, 168)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(91, 35)
			Me.button1.TabIndex = 1
			Me.button1.Text = "Dang Nhap"
			Me.button1.UseVisualStyleBackColor = True
			AddHandler Me.button1.Click, New System.EventHandler(Me.button1_Click)
			' 
			' button2
			' 
			Me.button2.Location = New System.Drawing.Point(217, 168)
			Me.button2.Name = "button2"
			Me.button2.Size = New System.Drawing.Size(91, 35)
			Me.button2.TabIndex = 2
			Me.button2.Text = "Thoat"
			Me.button2.UseVisualStyleBackColor = True
			AddHandler Me.button2.Click, New System.EventHandler(Me.button2_Click)
			' 
			' Form2
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(404, 228)
			Me.Controls.Add(Me.button2)
			Me.Controls.Add(Me.button1)
			Me.Controls.Add(Me.groupBox1)
			Me.Name = "Form2"
			Me.Text = "Form2"
			Me.Load += New System.EventHandler(Me.Form2_Load)
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private groupBox1 As System.Windows.Forms.GroupBox
		Private textBox2 As System.Windows.Forms.TextBox
		Private textBox1 As System.Windows.Forms.TextBox
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private button1 As System.Windows.Forms.Button
		Private button2 As System.Windows.Forms.Button
	End Class
End Namespace
