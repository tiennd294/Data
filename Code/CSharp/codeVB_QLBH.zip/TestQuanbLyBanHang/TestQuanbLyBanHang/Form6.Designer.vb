Namespace TestQuanbLyBanHang
	Partial Class Form6
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.comboBox2 = New System.Windows.Forms.ComboBox()
			Me.comboBox1 = New System.Windows.Forms.ComboBox()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label5 = New System.Windows.Forms.Label()
			Me.label4 = New System.Windows.Forms.Label()
			Me.label3 = New System.Windows.Forms.Label()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.btnReLoad = New System.Windows.Forms.Button()
			Me.btnThem = New System.Windows.Forms.Button()
			Me.btnSua = New System.Windows.Forms.Button()
			Me.btnLuu = New System.Windows.Forms.Button()
			Me.btnHuyBo = New System.Windows.Forms.Button()
			Me.btnXoa = New System.Windows.Forms.Button()
			Me.btnTroVe = New System.Windows.Forms.Button()
			Me.maskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
			Me.maskedTextBox2 = New System.Windows.Forms.MaskedTextBox()
			Me.groupBox1.SuspendLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me.maskedTextBox2)
			Me.groupBox1.Controls.Add(Me.maskedTextBox1)
			Me.groupBox1.Controls.Add(Me.comboBox2)
			Me.groupBox1.Controls.Add(Me.comboBox1)
			Me.groupBox1.Controls.Add(Me.textBox1)
			Me.groupBox1.Controls.Add(Me.label5)
			Me.groupBox1.Controls.Add(Me.label4)
			Me.groupBox1.Controls.Add(Me.label3)
			Me.groupBox1.Controls.Add(Me.label2)
			Me.groupBox1.Controls.Add(Me.label1)
			Me.groupBox1.Location = New System.Drawing.Point(20, 12)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(662, 106)
			Me.groupBox1.TabIndex = 0
			Me.groupBox1.TabStop = False
			' 
			' comboBox2
			' 
			Me.comboBox2.FormattingEnabled = True
			Me.comboBox2.Location = New System.Drawing.Point(123, 73)
			Me.comboBox2.Name = "comboBox2"
			Me.comboBox2.Size = New System.Drawing.Size(161, 21)
			Me.comboBox2.TabIndex = 9
			' 
			' comboBox1
			' 
			Me.comboBox1.FormattingEnabled = True
			Me.comboBox1.Location = New System.Drawing.Point(123, 48)
			Me.comboBox1.Name = "comboBox1"
			Me.comboBox1.Size = New System.Drawing.Size(232, 21)
			Me.comboBox1.TabIndex = 8
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(123, 21)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(133, 20)
			Me.textBox1.TabIndex = 5
			' 
			' label5
			' 
			Me.label5.AutoSize = True
			Me.label5.Location = New System.Drawing.Point(391, 51)
			Me.label5.Name = "label5"
			Me.label5.Size = New System.Drawing.Size(111, 13)
			Me.label5.TabIndex = 4
			Me.label5.Text = "Ngay Lap Nhan Hang"
			' 
			' label4
			' 
			Me.label4.AutoSize = True
			Me.label4.Location = New System.Drawing.Point(391, 24)
			Me.label4.Name = "label4"
			Me.label4.Size = New System.Drawing.Size(99, 13)
			Me.label4.TabIndex = 3
			Me.label4.Text = "Ngay Lap Hoa Don"
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Location = New System.Drawing.Point(20, 76)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(75, 13)
			Me.label3.TabIndex = 2
			Me.label3.Text = "Ma Nhan Vien"
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(20, 51)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(85, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Ma Khach Hang"
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(20, 24)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(68, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Ma Hoa Don"
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(20, 127)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(661, 241)
			Me.dataGridView1.TabIndex = 1
			' 
			' btnReLoad
			' 
			Me.btnReLoad.Location = New System.Drawing.Point(30, 382)
			Me.btnReLoad.Name = "btnReLoad"
			Me.btnReLoad.Size = New System.Drawing.Size(68, 25)
			Me.btnReLoad.TabIndex = 2
			Me.btnReLoad.Text = "ReLoad"
			Me.btnReLoad.UseVisualStyleBackColor = True
			AddHandler Me.btnReLoad.Click, New System.EventHandler(Me.btnReLoad_Click)
			' 
			' btnThem
			' 
			Me.btnThem.Location = New System.Drawing.Point(120, 382)
			Me.btnThem.Name = "btnThem"
			Me.btnThem.Size = New System.Drawing.Size(68, 25)
			Me.btnThem.TabIndex = 3
			Me.btnThem.Text = "Them"
			Me.btnThem.UseVisualStyleBackColor = True
			AddHandler Me.btnThem.Click, New System.EventHandler(Me.btnThem_Click)
			' 
			' btnSua
			' 
			Me.btnSua.Location = New System.Drawing.Point(219, 382)
			Me.btnSua.Name = "btnSua"
			Me.btnSua.Size = New System.Drawing.Size(68, 25)
			Me.btnSua.TabIndex = 4
			Me.btnSua.Text = "Sua"
			Me.btnSua.UseVisualStyleBackColor = True
			AddHandler Me.btnSua.Click, New System.EventHandler(Me.btnSua_Click)
			' 
			' btnLuu
			' 
			Me.btnLuu.Location = New System.Drawing.Point(316, 382)
			Me.btnLuu.Name = "btnLuu"
			Me.btnLuu.Size = New System.Drawing.Size(68, 25)
			Me.btnLuu.TabIndex = 5
			Me.btnLuu.Text = "Luu"
			Me.btnLuu.UseVisualStyleBackColor = True
			AddHandler Me.btnLuu.Click, New System.EventHandler(Me.btnLuu_Click)
			' 
			' btnHuyBo
			' 
			Me.btnHuyBo.Location = New System.Drawing.Point(414, 382)
			Me.btnHuyBo.Name = "btnHuyBo"
			Me.btnHuyBo.Size = New System.Drawing.Size(68, 25)
			Me.btnHuyBo.TabIndex = 6
			Me.btnHuyBo.Text = "Huy Bo"
			Me.btnHuyBo.UseVisualStyleBackColor = True
			AddHandler Me.btnHuyBo.Click, New System.EventHandler(Me.btnHuyBo_Click)
			' 
			' btnXoa
			' 
			Me.btnXoa.Location = New System.Drawing.Point(514, 382)
			Me.btnXoa.Name = "btnXoa"
			Me.btnXoa.Size = New System.Drawing.Size(68, 25)
			Me.btnXoa.TabIndex = 7
			Me.btnXoa.Text = "Xoa"
			Me.btnXoa.UseVisualStyleBackColor = True
			AddHandler Me.btnXoa.Click, New System.EventHandler(Me.btnXoa_Click)
			' 
			' btnTroVe
			' 
			Me.btnTroVe.Location = New System.Drawing.Point(613, 382)
			Me.btnTroVe.Name = "btnTroVe"
			Me.btnTroVe.Size = New System.Drawing.Size(68, 25)
			Me.btnTroVe.TabIndex = 8
			Me.btnTroVe.Text = "Tro Ve"
			Me.btnTroVe.UseVisualStyleBackColor = True
			AddHandler Me.btnTroVe.Click, New System.EventHandler(Me.btnTroVe_Click)
			' 
			' maskedTextBox1
			' 
			Me.maskedTextBox1.Location = New System.Drawing.Point(517, 21)
			Me.maskedTextBox1.Mask = "00/00/0000"
			Me.maskedTextBox1.Name = "maskedTextBox1"
			Me.maskedTextBox1.Size = New System.Drawing.Size(131, 20)
			Me.maskedTextBox1.TabIndex = 10
			Me.maskedTextBox1.ValidatingType = GetType(System.DateTime)
			' 
			' maskedTextBox2
			' 
			Me.maskedTextBox2.Location = New System.Drawing.Point(517, 48)
			Me.maskedTextBox2.Mask = "00/00/0000"
			Me.maskedTextBox2.Name = "maskedTextBox2"
			Me.maskedTextBox2.Size = New System.Drawing.Size(131, 20)
			Me.maskedTextBox2.TabIndex = 11
			Me.maskedTextBox2.ValidatingType = GetType(System.DateTime)
			' 
			' Form6
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(705, 436)
			Me.Controls.Add(Me.btnTroVe)
			Me.Controls.Add(Me.btnXoa)
			Me.Controls.Add(Me.btnHuyBo)
			Me.Controls.Add(Me.btnLuu)
			Me.Controls.Add(Me.btnSua)
			Me.Controls.Add(Me.btnThem)
			Me.Controls.Add(Me.btnReLoad)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.groupBox1)
			Me.Name = "Form6"
			Me.Text = "Quan Ly Danh Muc Hoa Don"
			Me.Load += New System.EventHandler(Me.Form6_Load)
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private groupBox1 As System.Windows.Forms.GroupBox
		Private textBox1 As System.Windows.Forms.TextBox
		Private label5 As System.Windows.Forms.Label
		Private label4 As System.Windows.Forms.Label
		Private label3 As System.Windows.Forms.Label
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private btnReLoad As System.Windows.Forms.Button
		Private btnThem As System.Windows.Forms.Button
		Private btnSua As System.Windows.Forms.Button
		Private btnLuu As System.Windows.Forms.Button
		Private btnHuyBo As System.Windows.Forms.Button
		Private btnXoa As System.Windows.Forms.Button
		Private btnTroVe As System.Windows.Forms.Button
		Private comboBox2 As System.Windows.Forms.ComboBox
		Private comboBox1 As System.Windows.Forms.ComboBox
		Private maskedTextBox2 As System.Windows.Forms.MaskedTextBox
		Private maskedTextBox1 As System.Windows.Forms.MaskedTextBox
	End Class
End Namespace
