<script type='text/javascript'>
    $(function(){
    $('#atextdata4Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#atextdata4').val(fileUrl);
            $('#atextdata4').attr('readonly', true);
        };
        ckfinder.popup();
    });

    $('#aitextdata1Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#aitextdata1').val(fileUrl);
            $('#aitextdata1').attr('readonly', true);
        };
        ckfinder.popup();
    });
    $('#aitextdata2Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#aitextdata2').val(fileUrl);
            $('#aitextdata2').attr('readonly', true);
        };
        ckfinder.popup();
    });
    $('#aitextdata3Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#aitextdata3').val(fileUrl);
            $('#aitextdata3').attr('readonly', true);
        };
        ckfinder.popup();
    });




    $('#etextdata4Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#etextdata4').val(fileUrl);
            $('#etextdata4').attr('readonly', true);
        };
        ckfinder.popup();
    });


    $('#eitextdata1Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#eitextdata1').val(fileUrl);
            $('#eitextdata1').attr('readonly', true);
        };
        ckfinder.popup();
    });
    $('#eitextdata2Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#eitextdata2').val(fileUrl);
            $('#eitextdata2').attr('readonly', true);
        };
        ckfinder.popup();
    });
    $('#eitextdata3Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#eitextdata3').val(fileUrl);
            $('#eitextdata3').attr('readonly', true);
        };
        ckfinder.popup();
    });


    });

	

     function fetch_select(val)
	{
		var loading = $('.reloadadd');
        var Successfuly = $('.as1'); 
        Successfuly.fadeOut(300);
        loading.fadeIn(500);
	   $.ajax({
	     type: 'post',
	     url: '<?php echo admin_url();?>/products/loadcategory',
	     data: {
	       get_Parentid:val
	     },
	     success: function (response) {
	       document.getElementById("atextdata10").innerHTML=response; 
	       loading.fadeOut(300);
	       Successfuly.fadeIn(500);
	     }
	   });
	}

	function fetch_select2(val)
	{
		var loading = $('.reloadedit');
        var Successfuly = $('.es1');
        Successfuly.fadeOut(300);
        loading.fadeIn(500); 

	   $.ajax({
	     type: 'post',
	     url: '<?php echo admin_url();?>/products/loadcategory',
	     data: {
	       get_Parentid:val
	     },
	     success: function (response) {
	       document.getElementById("etextdata10").innerHTML=response; 
	       loading.fadeOut(300);
	       Successfuly.fadeIn(500);
	     }
	   });
	}
</script> 
<?php
        $this->load->view('admin/accessdata/template/messenger');
?>
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                        <div class='table-action'>
                            <a href='#' class='btnadd tip-top' data-original-title='Add'><i class='icon-plus'></i> Thêm mới</a>
                        </div>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã ID</th>  
                                    <th>Tên sản phẩm</th>  
                                    <th>Mã sản phẩm</th>  

                                    <th>Mô tả</th>  
                                    <th>Hình ảnh</th>  
                                    <th>Giá khuyến mại</th>  
                                    <th>Giá bán</th>  
                                    <th>Giá nhập</th>  
                                    <th>VAT</th>  
                                    <th>Số lượng</th>  
                                    <th>Danh mục</th>  
                                    <th>Nội dung</th>  
                                    <th>Bảo hành</th>  
                                    <th>Ngày giảm giá</th>  

                                    <th>Trạng thái</th>  






                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                
                                foreach ($tblproducts as $row):
                                    
                            ?>
                                <tr class='gradeU items_' id='<?php echo $row->Idp; ?>'>
                                    <td><?php echo $row->Idp; ?></td>
                                    <td><?php echo $row->Name; ?></td>
                                    <td><?php echo $row->Code; ?></td>

                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Discription; ?></div></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Images; ?></div></td>
                                    <td><?php echo $row->Promotion; ?></td>
                                    <td><?php echo $row->Price; ?></td>
                                    <td><?php echo $row->Cost; ?></td>
                                    <td><?php echo $row->IncludeVAT; ?></td>
                                    <td><?php echo $row->Quantity; ?></td>
                                    <td><?php echo $row->Idc; ?></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Detail; ?></div></td>
                                    <td><?php echo $row->Warranty; ?></td>
                                    <td><?php echo str_replace(' 00:00:00','', $row->Tophot); ?></td>

                                    <td><?php echo $row->Startus; ?></td>


                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Thêm mới</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='<?php echo admin_url();?>/products/Add'>


								<div class='control-group'>
									<label class='control-label'>Danh mục :</label>

									<div class='controls '>
									     <select name='atextdatac' id='atextdatac'  onchange="fetch_select(this.value);">
									     	
                                                <?php
                                                 foreach ($tblcategory as $row):
                                        		  	
                                        		  	
                                                ?>
                                                    <option  value='<?php echo $row->Idc; ?>'><?php echo $row->Name; ?></option>
                                                <?php
                                                	
                                                endforeach;
                                                ?>
									     </select><i class='icon-ok Successfuly as1' style='display: none;'></i>
									</div>
									<div style=' margin-left: 20%;padding-bottom: 5px;margin-top: 0px;padding-right: 60%;'><i class='reload reloadadd' style='display: none; margin-right: 0px;padding-bottom: 5px;margin-top: 10px;padding-right: 108px;'></i></div>

									
								</div>

								<div class='control-group'>
									<label class='control-label'>Danh mục con :</label>
									<div class='controls '>
									     <select name='atextdata10' id='atextdata10'>
                                                 <option>Chọn danh mục :</option>
									     </select><i class='icon-ok Successfuly as2' style='display: none;'></i>
									</div>

								</div>
								<div class='control-group'>
									<label class='control-label'>Tên sản phẩm :</label>
									<div class='controls'>
										<input  name='atextdata1' type='text' class='span20 atextdata1' placeholder='Tên sản phẩm' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mã sản phẩm :</label>
									<div class='controls'>
										<input  name='atextdata2' type='text' class='span20 atextdata2' placeholder='Mã sản phẩm' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mô tả :</label>
									<div class='controls'>
										<textarea  name='atextdata3' class='span20  atextdata3 ' placeholder=' Mô tả' rows='5' ></textarea>
									</div>
								</div>

									<div class='control-group'>
										<label class='control-label'>Ảnh đại diện :</label>
										<div class='controls'>
                                            <input id='atextdata4'  name='atextdata4' type='text' class='span3 atextdata4' placeholder='Hình ảnh' readonly />
                                            <button id='atextdata4Brows' class='atextdata4Brows'>...</button>
										</div>
									</div>
									
									<div class='control-group'>
										<label class='control-label'>Ảnh chi tiết :</label>
										<div class='controls'>
                                            <input id='aitextdata1'  name='aitextdata1' type='text' class='span3 aitextdata1' placeholder='Hình ảnh' readonly/>
                                            <button id='aitextdata1Brows' class='aitextdata1Brows'>...</button>
										</div>
									</div>
									<div class='control-group'>
										<label class='control-label'>Ảnh chi tiết :</label>
										<div class='controls'>
                                            <input id='aitextdata2'  name='aitextdata2' type='text' class='span3 aitextdata2' placeholder='Hình ảnh' readonly />
                                            <button id='aitextdata2Brows' class='aitextdata2Brows'>...</button>
										</div>
									</div>
									<div class='control-group'>
										<label class='control-label'>Ảnh chi tiết :</label>
										<div class='controls'>
                                            <input id='aitextdata3'  name='aitextdata3' type='text' class='span3 aitextdata3' placeholder='Hình ảnh' readonly />
                                            <button id='aitextdata3Brows' class='aitextdata3Brows'>...</button>
										</div>
									</div>
								
								<div class='control-group'>
									<label class='control-label'>Giá khuyến mại :</label>
									<div class='controls'>
										<input  name='atextdata5' type='text' class='span20 atextdata5' placeholder='Giá khuyến mại' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Giá bán :</label>
									<div class='controls'>
										<input  name='atextdata6' type='text' class='span20 atextdata6' placeholder='Giá bán' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Giá nhập :</label>
									<div class='controls'>
										<input  name='atextdata7' type='text' class='span20 atextdata7' placeholder='Giá nhập' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>VAT :</label>
									<div class='controls'>
										<input  name='atextdata8' type='text' class='span20 atextdata8' placeholder='VAT' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Số lượng :</label>
									<div class='controls'>
										<input  name='atextdata9' type='text' class='span20 atextdata9' placeholder='Số lượng' />
									</div>
								</div>

								

								<div class='control-group'>
									<label class='control-label'>Nội dung :</label>
									<div class='controls'>
									</div>
								</div>

								<div class='control-group' style='margin-right: 1.5%; '>
										<textarea  name='atextdata11ck' class='span20 atextdata11ck ckeditor' rows='5' ></textarea>
                                        <div class='setingck' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>
                                        <input  name='atextdata11' type='text' class='span20 atextdata11' placeholder='data' />
                                        </div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Bảo hành :</label>
									<div class='controls'>
										<input  name='atextdata12' type='text' class='span20 atextdata12' placeholder='Bảo hành' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Ngày giảm giá :</label>
									<div class='controls'>
										<input  name='atextdata13' type='text' class='span20 atextdata13' placeholder='Ngày giảm giá' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='atextdata14' class='atextdata14 atextdata14cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnadd' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	<div class='frmedit' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-pencil'></i>
									</span>
									<h5>Cập nhật</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form3' class='form-horizontal' name='form3' method='post' action='<?php echo admin_url();?>/products/Edit'>
								<div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
								<div class='control-group'>
										<label class='control-label'>Mã ID :</label>
										<div class='controls'><input id='etextid' name='etextid' type='text' class='span20 etextid'/></div>
								</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Danh mục :</label>
									<div class='controls '>
									     <select name='etextdatac' id='etextdatac'  onchange="fetch_select2(this.value);">
                                                <?php
                                                foreach ($tblcategory as $row):
                                        		  	
                                                ?>
                                                    <option value="<?php echo $row->Idc; ?>"><?php echo $row->Name; ?></option>
                                                <?php
                                                		endforeach;
                                                ?>
									     </select><i class='icon-ok Successfuly es1' style='display: none;'></i>
									</div>
									<div style=' margin-left: 20%;padding-bottom: 5px;margin-top: 0px;padding-right: 60%;'><i class='reload reloadedit' style='display: none; margin-right: 0px;padding-bottom: 5px;margin-top: 10px;padding-right: 108px;'></i></div>

								</div>

								<div class='control-group'>
									<label class='control-label'>Danh mục con:</label>
									<div class='controls '>
									     <select name='etextdata10' id='etextdata10'>
                                                <option>Chọn danh mục :</option>
									     </select>
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Tên sản phẩm :</label>
									<div class='controls'>
										<input  name='etextdata1' type='text' class='span20 etextdata1' placeholder='Tên sản phẩm' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mã sản phẩm :</label>
									<div class='controls'>
										<input  name='etextdata2' type='text' class='span20 etextdata2' placeholder='Mã sản phẩm' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mô tả :</label>
									<div class='controls'>
										<textarea  name='etextdata3' class='span20  etextdata3 ' placeholder=' Mô tả' rows='5' ></textarea>
									</div>
								</div>

									<div class='control-group'>
										<label class='control-label'>Ảnh đại diện :</label>
										<div class='controls'>
                                            <input id='etextdata4'  name='etextdata4' type='text' class='span3 etextdata4' placeholder='Hình ảnh' readonly />
                                            <button id='etextdata4Brows' class='etextdata4Brows'>...</button>
										</div>
									</div>


									<div class='control-group'>
										<label class='control-label'>Ảnh chi tiết :</label>
										<div class='controls'>
                                            <input id='eitextdata1'  name='eitextdata1' type='text' class='span3 eitextdata1' placeholder='Hình ảnh' readonly />
                                            <button id='eitextdata1Brows' class='eitextdata1Brows'>...</button>
										</div>
									</div>
									<div class='control-group'>
										<label class='control-label'>Ảnh chi tiết :</label>
										<div class='controls'>
                                            <input id='eitextdata2'  name='eitextdata2' type='text' class='span3 eitextdata2' placeholder='Hình ảnh' readonly />
                                            <button id='eitextdata2Brows' class='eitextdata2Brows'>...</button>
										</div>
									</div>
									<div class='control-group'>
										<label class='control-label'>Ảnh chi tiết :</label>
										<div class='controls'>
                                            <input id='eitextdata3'  name='eitextdata3' type='text' class='span3 eitextdata3' placeholder='Hình ảnh' readonly />
                                            <button id='eitextdata3Brows' class='eitextdata3Brows'>...</button>
										</div>
									</div>

								<div class='control-group'>
									<label class='control-label'>Giá khuyến mại :</label>
									<div class='controls'>
										<input  name='etextdata5' type='text' class='span20 etextdata5' placeholder='Giá khuyến mại' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Giá bán :</label>
									<div class='controls'>
										<input  name='etextdata6' type='text' class='span20 etextdata6' placeholder='Giá bán' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Giá nhập :</label>
									<div class='controls'>
										<input  name='etextdata7' type='text' class='span20 etextdata7' placeholder='Giá nhập' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>VAT :</label>
									<div class='controls'>
										<input  name='etextdata8' type='text' class='span20 etextdata8' placeholder='VAT' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Số lượng :</label>
									<div class='controls'>
										<input  name='etextdata9' type='text' class='span20 etextdata9' placeholder='Số lượng' />
									</div>
								</div>

								

								<div class='control-group'>
									<label class='control-label'>Nội dung :</label>
									<div class='controls'>
									</div>
								</div>

								<div class='control-group' style='margin-right: 1.5%; '>
										<textarea  name='etextdata11ck' class='span20 etextdata11ck ckeditor' rows='5' ></textarea>
                                        <div class='setingck' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>
                                        <input  name='etextdata11' type='text' class='span20 etextdata11' placeholder='data' />
                                        </div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Bảo hành :</label>
									<div class='controls'>
										<input  name='etextdata12' type='text' class='span20 etextdata12' placeholder='Bảo hành' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Ngày giảm giá :</label>
									<div class='controls'>
										<input  name='etextdata13' type='text' class='span20 etextdata13' placeholder='Ngày giảm giá' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='etextdata14' class='etextdata14 etextdata14cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnedit' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>







	<div class='frmdelete' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-trash'></i>
									</span>
									<h5>Xóa</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form2' class='form-horizontal' name='form2' method='post' action='<?php echo admin_url();?>/products/Delete'>
								<div class='controls'>                                   <label id='Label2' class='control-label'> Bạn có chắc chắn muốn xóa không?</label>                               </div>                               <div class='control-group' style='padding-left:5px; padding-top:5px;'>                                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:13px;height:13px;overflow:auto;'>                                        <div class='control-group'>                                               <label class='control-label'>ID dstaikhoan:</label>                                           <div class='controls'>                                               <input id='textid' class='textid' name='textid' type='text' class='span20' />                                           </div>                                       </div>                                   </div>                               </div>								<div class='form-actions  txtc'   align='center'>
									<button id='btndelete' class='btn btnyes btn-success'>Có</button>
									<button id='btnhuy'  class='btn btn-success btncancel' style='margin-left:10px'> Không</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
