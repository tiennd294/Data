Namespace TestQuanbLyBanHang
	Partial Class Form10
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.label1 = New System.Windows.Forms.Label()
			Me.comboBox1 = New System.Windows.Forms.ComboBox()
			Me.button1 = New System.Windows.Forms.Button()
			Me.label2 = New System.Windows.Forms.Label()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.button2 = New System.Windows.Forms.Button()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(12, 29)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(84, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Chon thanh Pho"
			' 
			' comboBox1
			' 
			Me.comboBox1.FormattingEnabled = True
			Me.comboBox1.Location = New System.Drawing.Point(102, 26)
			Me.comboBox1.Name = "comboBox1"
			Me.comboBox1.Size = New System.Drawing.Size(107, 21)
			Me.comboBox1.TabIndex = 1
			' 
			' button1
			' 
			Me.button1.Location = New System.Drawing.Point(215, 24)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(45, 23)
			Me.button1.TabIndex = 2
			Me.button1.Text = "OK"
			Me.button1.UseVisualStyleBackColor = True
			AddHandler Me.button1.Click, New System.EventHandler(Me.button1_Click)
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(266, 29)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(111, 13)
			Me.label2.TabIndex = 3
			Me.label2.Text = "Tong So Khach Hang"
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(383, 26)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(45, 20)
			Me.textBox1.TabIndex = 4
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(18, 59)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(410, 202)
			Me.dataGridView1.TabIndex = 5
			' 
			' button2
			' 
			Me.button2.Location = New System.Drawing.Point(350, 267)
			Me.button2.Name = "button2"
			Me.button2.Size = New System.Drawing.Size(65, 32)
			Me.button2.TabIndex = 6
			Me.button2.Text = "Tro Ve"
			Me.button2.UseVisualStyleBackColor = True
			AddHandler Me.button2.Click, New System.EventHandler(Me.button2_Click)
			' 
			' Form10
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(446, 309)
			Me.Controls.Add(Me.button2)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.textBox1)
			Me.Controls.Add(Me.label2)
			Me.Controls.Add(Me.button1)
			Me.Controls.Add(Me.comboBox1)
			Me.Controls.Add(Me.label1)
			Me.Name = "Form10"
			Me.Text = "Quan Ly Khach Hang Theo Thanh Pho"
			Me.Load += New System.EventHandler(Me.Form10_Load)
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private label1 As System.Windows.Forms.Label
		Private comboBox1 As System.Windows.Forms.ComboBox
		Private button1 As System.Windows.Forms.Button
		Private label2 As System.Windows.Forms.Label
		Private textBox1 As System.Windows.Forms.TextBox
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private button2 As System.Windows.Forms.Button
	End Class
End Namespace
