using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT_Pheptoan
{
    public partial class frmPhepToan : Form
    {
        public frmPhepToan()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btncong_Click(object sender, EventArgs e)
        {
            int intSo1, intSo2;
            intSo1 = Convert.ToInt32(txtSo1.Text);
            intSo2 = Convert.ToInt32(txtSo2.Text);
            int t = 0;
            t = intSo1 + intSo2; 
            txtKetQua.Text = t.ToString();
        }

        private void btntru_Click(object sender, EventArgs e)
        {
            int intSo1, intSo2;
            intSo1 = Convert.ToInt32(txtSo1.Text);
            intSo2 = Convert.ToInt32(txtSo2.Text);
            int t = 0;
            t = intSo1 - intSo2;
            txtKetQua.Text = t.ToString();
        }

        private void btnnhan_Click(object sender, EventArgs e)
        {
            int intSo1, intSo2;
            intSo1 = Convert.ToInt32(txtSo1.Text);
            intSo2 = Convert.ToInt32(txtSo2.Text);
            int t = 0;
            t = intSo1 * intSo2;
            txtKetQua.Text = t.ToString();
        }

        private void txtSo2_TextChanged(object sender, EventArgs e)
        {
            if (txtSo1.Text != "" && txtSo2.Text != "")
            {
                btncong.Enabled = true;
                btntru.Enabled = true;
            }
        }
    }
}