using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT19
{
    public partial class frmbtlistbox : Form
    {
        public frmbtlistbox()
        {
            InitializeComponent();
        }

        private void btnketthuc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btncapnhat_Click(object sender, EventArgs e)
        {
            lstso.Items.Add(txtso.Text);
            txtso.Text = null;
        }
    }
}