<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Productsima extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Productsima_Model');
    }

    public function Index()
    {
        $input = array();
        $tblimg=$this->Productsima_Model->get_list($input);
        $tblmenu=$this->Productsima_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Productsima/productsima',
            'tblimg' => $tblimg,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

    
    public function Add()
    {
        $data = array(
            'Urllink' => str_replace(base_url(), '', $this->input->post('atextdata1')),
            'Idp' => $this->input->post('atextdata2')
        );
        $this->Productsima_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Urllink' => str_replace(base_url(), '', $this->input->post('etextdata1')),
            'Idp' => $this->input->post('etextdata2')
        );
        if($this->input->post('etextid')){
            $Id = $this->input->post('etextid');
            $this->Productsima_Model->update($Id,$data);
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Productsima_Model->delete($Id);
        }
    }
}