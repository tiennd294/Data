using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PhieuTienDien
{
    public partial class frmPhieutiendien : Form
    {
        public frmPhieutiendien()
        {
            InitializeComponent();
        }

        private void btnthoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btntinh_Click(object sender, EventArgs e)
        {
            int intsocu, intsomoi, inttien,dinhmuc=50,dongia1=5000,dongia2=7000,inttieuthu;
            intsocu = Convert.ToInt32(txtsocu.Text);
            intsomoi = Convert.ToInt32(txtsomoi.Text);
            inttieuthu = intsomoi - intsocu;
            if (inttieuthu <= dinhmuc)
            {
                txtdg.Text = dongia1.ToString();
                inttien = dongia1 * inttieuthu;
            }
            else
            {
                txtdg.Text = dongia2.ToString();
                inttien = dongia1 * inttieuthu + (inttieuthu - dinhmuc) * dongia2;
            }
            txttien.Text = inttien.ToString();
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            txtten.Text = null;
            txtsocu.Text = null;
            txtsomoi.Text = null;
            txtdg.Text = null;
            txttien.Text = null;
            btntinh.Enabled = false;
            btnxoa.Enabled = false;
        }

        private void txtsomoi_TextChanged(object sender, EventArgs e)
        {
            if (txtten.Text != "" && txtsocu.Text != "" && txtsomoi.Text != "")
            {
                btntinh.Enabled = true;
                btnxoa.Enabled = true;
            }
        }
    }
}