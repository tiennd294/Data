using System;
using System.Runtime.InteropServices;

public class QuickRelease
{
	private static void Main()
	{
		ADODB.Connection con = new ADODB.Connection();
		string connectionString = "Provider=SQLOLEDB.1;Data Source=localhost;" +
			"Initial Catalog=Northwind;Integrated Security=SSPI";
		con.Open(connectionString, null, null, 0);

		object recordsAffected;
		ADODB.Recordset rs = con.Execute("SELECT * From Customers",
			out recordsAffected, 0);

		while (rs.EOF != true)
		{
			Console.WriteLine(rs.Fields["CustomerID"].Value);
			rs.MoveNext();
		}

		Console.ReadLine();

		Marshal.ReleaseComObject(rs);
		Marshal.ReleaseComObject(con);
	}
}