using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Soap;

public class SoapSerializationExample {

    public static void Main() {
        
        ArrayList people = new ArrayList();
        people.Add("Phuong");
        people.Add("Phong");                    
        people.Add("Nam");

        FileStream str = File.Create("people.xml");
        SoapFormatter sf = new SoapFormatter();
        sf.Serialize(str, people);
        str.Close();
        
        str = File.OpenRead("people.xml");
        sf = new SoapFormatter();
        people = (ArrayList)sf.Deserialize(str);
        str.Close();
        
        foreach (string s in people) {
            
            System.Console.WriteLine(s);
        }

		System.Console.ReadLine();
    }   
}