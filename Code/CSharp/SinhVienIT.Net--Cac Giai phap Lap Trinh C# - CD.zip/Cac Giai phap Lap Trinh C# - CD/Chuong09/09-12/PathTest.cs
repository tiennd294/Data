using System;
using System.IO;

public class PathTest
{
	private	static void Main()
	{
		string filename = @"..\System\MyFile.txt";
		Console.WriteLine(Path.GetFileName(filename));

		filename = @"..\..\myfile.txt";
		string fullPath = @"c:\Temp";
		filename = Path.GetFileName(filename);
		Console.WriteLine(Path.Combine(fullPath, filename));

		Console.ReadLine();
	}
}