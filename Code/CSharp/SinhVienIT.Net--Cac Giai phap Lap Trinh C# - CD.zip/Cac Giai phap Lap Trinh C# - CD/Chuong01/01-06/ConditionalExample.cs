#define win2000
#define release
#undef  win98

using System;

public class ConditionalExample {

    [System.Diagnostics.Conditional("DEBUG")]
    public static void DumpState() {
    
        System.Console.WriteLine("Dump some state...");
    }
    
    public static void Main() {
    
        string platformName;
    
        #if winXP
			platformName = "Microsoft Windows XP";
        #elif win2000
			platformName = "Microsoft Windows 2000";
        #elif winNT
            platformName = "Microsoft Windows NT";
        #elif win98     
            platformName = "Microsoft Windows 98";
        #else
            platformName = "Unknown";
        #endif

        Console.WriteLine(platformName);

        DumpState();

		System.Console.Read();
    }
}
