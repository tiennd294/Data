using System;
using System.Drawing;
using System.Windows.Forms;

public class SimpleEditForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.MainMenu mainMenu1;
	private System.Windows.Forms.MenuItem mnuOpen;
	private System.Windows.Forms.MenuItem mnuSave;
	private System.Windows.Forms.MenuItem mnuExit;
	private System.Windows.Forms.MenuItem menuItem6;
	private System.Windows.Forms.RichTextBox rtDoc;
	private System.Windows.Forms.MenuItem mnuFile;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SimpleEditForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.rtDoc = new System.Windows.Forms.RichTextBox();
		this.mainMenu1 = new System.Windows.Forms.MainMenu();
		this.mnuFile = new System.Windows.Forms.MenuItem();
		this.mnuOpen = new System.Windows.Forms.MenuItem();
		this.mnuSave = new System.Windows.Forms.MenuItem();
		this.menuItem6 = new System.Windows.Forms.MenuItem();
		this.mnuExit = new System.Windows.Forms.MenuItem();
		this.SuspendLayout();
		// 
		// rtDoc
		// 
		this.rtDoc.Enabled = false;
		this.rtDoc.Location = new System.Drawing.Point(8, 12);
		this.rtDoc.Name = "rtDoc";
		this.rtDoc.Size = new System.Drawing.Size(276, 244);
		this.rtDoc.TabIndex = 0;
		this.rtDoc.Text = "";
		// 
		// mainMenu1
		// 
		this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuFile});
		// 
		// mnuFile
		// 
		this.mnuFile.Index = 0;
		this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				this.mnuOpen,
																				this.mnuSave,
																				this.menuItem6,
																				this.mnuExit});
		this.mnuFile.Text = "File";
		// 
		// mnuOpen
		// 
		this.mnuOpen.Index = 0;
		this.mnuOpen.Text = "Open";
		this.mnuOpen.Click += new System.EventHandler(this.mnuOpen_Click);
		// 
		// mnuSave
		// 
		this.mnuSave.Index = 1;
		this.mnuSave.Text = "Save";
		this.mnuSave.Click += new System.EventHandler(this.mnuSave_Click);
		// 
		// menuItem6
		// 
		this.menuItem6.Index = 2;
		this.menuItem6.Text = "-";
		// 
		// mnuExit
		// 
		this.mnuExit.Index = 3;
		this.mnuExit.Text = "Exit";
		this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
		// 
		// SimpleEditForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.Add(this.rtDoc);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Menu = this.mainMenu1;
		this.Name = "SimpleEditForm";
		this.Text = "Edit";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new SimpleEditForm());
	}

	private void mnuExit_Click(object sender, System.EventArgs e)
	{
		this.Close();
	}

	private void mnuOpen_Click(object sender, System.EventArgs e)
	{
		//FolderBrowserDialog dlg = new FolderBrowserDialog();
		//dlg.ShowNewFolderButton = false;
		//dlg.ShowDialog();
		OpenFileDialog dlg = new OpenFileDialog();
		dlg.Filter = "Rich Text Files (*.rtf)|*.RTF|" +
			"All files (*.*)|*.*";
		dlg.CheckFileExists = true;
		dlg.InitialDirectory = Application.StartupPath;
		
		if (dlg.ShowDialog() == DialogResult.OK)
		{
			rtDoc.LoadFile(dlg.FileName);
			rtDoc.Enabled = true;
		}
	}

	private void mnuSave_Click(object sender, System.EventArgs e)
	{
		SaveFileDialog dlg = new SaveFileDialog();
		dlg.Filter = "RichText Files (*.rtf)|*.RTF|Text Files (*.txt)|*.TXT" +
			"|All files (*.*)|*.*";
		dlg.CheckFileExists = true;
		dlg.InitialDirectory = Application.StartupPath;

		if (dlg.ShowDialog() == DialogResult.OK)
		{
			rtDoc.SaveFile(dlg.FileName);
		}
	
	}
}