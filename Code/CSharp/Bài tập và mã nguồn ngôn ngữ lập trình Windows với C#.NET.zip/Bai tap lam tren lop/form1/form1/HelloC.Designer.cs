namespace form1
{
    partial class HelloC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picC = new System.Windows.Forms.PictureBox();
            this.lblHelloC = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picC)).BeginInit();
            this.SuspendLayout();
            // 
            // picC
            // 
            this.picC.Image = global::form1.Properties.Resources.Tulips;
            this.picC.Location = new System.Drawing.Point(-2, 82);
            this.picC.Name = "picC";
            this.picC.Size = new System.Drawing.Size(684, 464);
            this.picC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picC.TabIndex = 1;
            this.picC.TabStop = false;
            // 
            // lblHelloC
            // 
            this.lblHelloC.Font = new System.Drawing.Font("Pristina", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelloC.ForeColor = System.Drawing.Color.Blue;
            this.lblHelloC.Location = new System.Drawing.Point(1, -1);
            this.lblHelloC.Name = "lblHelloC";
            this.lblHelloC.Size = new System.Drawing.Size(681, 80);
            this.lblHelloC.TabIndex = 0;
            this.lblHelloC.Text = "Welcom C# ...!";
            this.lblHelloC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHelloC.Click += new System.EventHandler(this.label1_Click);
            // 
            // HelloC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 547);
            this.Controls.Add(this.picC);
            this.Controls.Add(this.lblHelloC);
            this.Name = "HelloC";
            this.Text = "Baitap1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblHelloC;
        private System.Windows.Forms.PictureBox picC;
    }
}

