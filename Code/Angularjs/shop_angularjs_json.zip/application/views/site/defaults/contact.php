<?php 
foreach ($tblcontact as $row):  
?>

<script type='text/javascript'>

	$( ".Add_contact" ).prop( "disabled", true );
    function Add_contact()
    {
    	//alert($(".Email").val());
    	var loading = $('.loading');
    	var btnct = $('.Add_contact');
    	var successfuly = $('.successfuly');
    	successfuly.hide(200);     
    	btnct.hide(500);
    	loading.fadeIn(500);
        var data={
            Name:$(".Name").val(),
            Phone:$(".Phone").val(),
            Email:$(".Email").val(),
            Address:$(".Address").val(),
            Content:$(".Content").val()
        };

        $(".Name").val(''),
        $(".Phone").val(''),
        $(".Email").val(''),
        $(".Address").val(''),
        $(".Content").val('')

               
                    $.ajax({
                       type: 'post',
                       url: '<?php echo base_url();?>defaults/AddContact',
                       data: data,
                       success: function (response) {  
                       	if (response=='true') {
                       		 loading.hide(500);
	        				successfuly.fadeIn(500);
	        				btnct.fadeIn(500);
	        				$(".Name").focus();
                       	};
                       
                       }
                     });
                    
    }

</script> 


<div class="container">
		<div class="sixteen columns">
			
			<div id="pageName">
				<div class="name_tag">
					<p>
						Liên hệ
					</p>
					<div class="shapLeft"></div>
					<div class="shapRight"></div>
				</div>
			</div><!--end pageName-->

		</div>
	</div><!-- container -->



	<!-- strat the main content area -->
	
	<div class="container">
		<div class="sixteen columns">

			<div class="eleven columns alpha">
				<div id="googleMap">
						<?php echo $row->Addressmap; ?>
					</div><!--end googleMap-->
			</div><!--end eleven-->

			<div class="five columns omega">
				<div class="blocked_info">
					<div>
						<h4><?php echo $row->Name; ?></h4>
						<p>
							<?php echo $row->Content; ?>
						</p>
					</div>

					
				</div><!--end blocked_info-->
			</div><!--end five-->
		</div><!--end sixteen-->

		<div class="sixteen columns">

			<div class="eleven columns alpha">
				<div id="contact_form">
					<div class="box_head">
						<h3>Yêu cầu</h3>
					</div><!--end box_head -->

					<form action="#">

						<div class="five columns alpha">
							<input type="text" name="Name" class="Name" value="" placeholder="Nhập họ tên">

							<input type="text" name="Phone" class="Phone" value="" placeholder="Nhập số điện thoại">

							<input type="text" name="Email" class="Email" value="" placeholder=" Nhập Email">

							<input type="text" name="Address" class="Address" value="" placeholder="Nhập địa chỉ">
						</div><!--end five-->

						<div class="six columns omega">
							<textarea name="Content" class="Content" placeholder="Nội dung tin nhắn....."></textarea>
						</div><!--end six-->
					</form><!--end form-->
						<div class="submitForm">
							<button class="red_btn Add_contact" id="Add_contact" onclick="Add_contact();" >Gửi ngay</button>
							<div class="clear"></div>
						</div><!--end submitForm-->

					

				</div><!--end contact_form-->
			</div><!--end eleven-->

			


			<div class="five columns omega">
				<div id="contact_info">
					<ul>
						<li class="contact_address">
							<h6>Địa chỉ</h6>
							<p><?php echo $row->Address; ?></p>
						</li>
						<li class="contact_email">
							<h6>Email</h6>
							<p><?php echo $row->Email; ?></p>
						</li>
						<li class="contact_phone">
							<h6>Số đi động</h6>
							<p><?php echo $row->Phone; ?></p>
						</li>
						
					</ul>
				</div><!--end contact_info-->
			</div><!--end five-->

		</div><!--end sixteen-->


			<div id="loading" class="sixteen columns loading" style="width:98%;display: none;">
				<div id="tagLine" class="clearfix">
					<div class="twelve columns">
						<br>
						<i class='reload2'></i> Vui lòng chờ trong giây lát....
						<br><br>
					</div>
					<div class="three columns">
						<br><br>
					</div>
				
				</div><!--end tagLine-->
			</div>

		<div id="successfuly" class="sixteen columns successfuly" style="width:98%;display: none;">
			<section id="tagLine" class="clearfix">
				<div class="twelve columns">
					<h5>
						Gửi tin nhắn thành công!<br>
						<small>Chúng tôi sẽ giải đáp yêu cầu của bạn trong thời gian sớm nhất.</small>
					</h5>
				</div>
				<div class="three columns">
					<a class="red_btn" href="#">Cửa hàng</a>
				</div>
				
			</section><!--end tagLine-->
		</div><!--end sixteen-->


	</div><!--end container-->
	<!-- end the main content area -->
<?php endforeach; ?>