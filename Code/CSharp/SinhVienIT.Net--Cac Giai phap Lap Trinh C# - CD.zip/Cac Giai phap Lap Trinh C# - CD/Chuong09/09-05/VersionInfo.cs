using System;
using System.Diagnostics;

public class VersionInfo
{
	private static void Main(string[] args)
	{
		if (args.Length == 0)
		{
			Console.WriteLine("Please supply a filename.");
			return;
		}

        FileVersionInfo info = FileVersionInfo.GetVersionInfo(args[0]);

        Console.WriteLine("Checking File: " + info.FileName);
        Console.WriteLine("Product Name: " + info.ProductName);
        Console.WriteLine("Product Version: " + info.ProductVersion);
        Console.WriteLine("Company Name: " + info.CompanyName);
        Console.WriteLine("File Version: " + info.FileVersion);
        Console.WriteLine("File Description: " + info.FileDescription);
        Console.WriteLine("Original Filename: " + info.OriginalFilename);
        Console.WriteLine("Legal Copyright: " + info.LegalCopyright);
        Console.WriteLine("InternalName: " + info.InternalName);
        Console.WriteLine("IsDebug: " + info.IsDebug);
        Console.WriteLine("IsPatched: " + info.IsPatched);
        Console.WriteLine("IsPreRelease: " + info.IsPreRelease);
        Console.WriteLine("IsPrivateBuild: " + info.IsPrivateBuild);
        Console.WriteLine("IsSpecialBuild: " + info.IsSpecialBuild);
    
		Console.ReadLine();

	}
}