<?php

$this->load->view('site/access/template/header');
$this->load->view($urldata);



$this->load->view('site/access/template/footer');
?>