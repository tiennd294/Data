using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT2
{
    public partial class frmweather : Form
    {
        public frmweather()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radcloudy_CheckedChanged(object sender, EventArgs e)
        {
            piccloudy.Visible = true;
            picrainy.Visible = false;
            picsnowy.Visible = false;
            picsunny.Visible = false;
        }

        private void radrainy_CheckedChanged(object sender, EventArgs e)
        {
            piccloudy.Visible = false;
            picrainy.Visible = true;
            picsnowy.Visible = false;
            picsunny.Visible = false;
        }

        private void radsnowy_CheckedChanged(object sender, EventArgs e)
        {
            piccloudy.Visible = false;
            picrainy.Visible = false;
            picsnowy.Visible = true;
            picsunny.Visible = false;
        }

        private void radsunny_CheckedChanged(object sender, EventArgs e)
        {
            piccloudy.Visible = false;
            picrainy.Visible = false;
            picsnowy.Visible = false;
            picsunny.Visible = true;
        }
    }
}