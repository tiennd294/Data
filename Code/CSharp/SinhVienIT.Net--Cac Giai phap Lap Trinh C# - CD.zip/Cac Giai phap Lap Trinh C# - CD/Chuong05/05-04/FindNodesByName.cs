using System;
using System.Xml;

public class FindNodesByName
{
	[STAThread]
	private static void Main()
	{
		XmlDocument doc = new XmlDocument();
        doc.Load("ProductCatalog.xml");

		XmlNodeList prices = doc.GetElementsByTagName("productPrice");
		
	/*	XmlNode product = doc.GetElementsByTagName("products")[0];
		XmlNode price = ((XmlElement)product).GetElementsByTagName("productPrice")[0];
		Console.WriteLine("Price is " + price.InnerText);
    */
        
		decimal totalPrice = 0;
        foreach (XmlNode price in prices)
		{
			totalPrice += Decimal.Parse(price.ChildNodes[0].Value);
		}
		
		Console.WriteLine("Total catalog value: " + totalPrice.ToString());	
        Console.ReadLine();
	}
}