using System;
using System.IO;
using System.Security.Cryptography;

public class HashStreamExample {

    public static void Main(string[] args) {

        using (HashAlgorithm hashAlg = HashAlgorithm.Create(args[0])) {

            using (Stream file = new FileStream(args[1], FileMode.Open)) {
    
                byte[] hash = hashAlg.ComputeHash(file);
    
                Console.WriteLine(BitConverter.ToString(hash));
            }
        }

        Console.ReadLine();
    }
}
