
  <div class="container">
    <div class="sixteen columns">
      
      <div id="slide_outer">
        <div class="mainslide">

          <div class="pagers center">
            <a class="prev slide_prev" href="#prev">Prev</a>
            <a class="nxt slide_nxt" href="#nxt">Next</a>
          </div>

          <ul class="cycle-slideshow clearfix" 
              data-cycle-fx="scrollHorz"
              data-cycle-timeout="2000"
              data-cycle-slides="> li"
              data-cycle-pause-on-hover="true"
              data-cycle-prev="div.pagers a.slide_prev"
              data-cycle-next="div.pagers a.slide_nxt"
              >

<?php

           
            foreach ($tbnslide as $row):
              if($row->Classify==1 &&  $row->Startus='on'){
?>
            <li class="clearfix" >
              <div class="slide_img">
                <img src="<?php echo base_url().$row->Images;?>" alt="" style="width:350px;height:250px;">
              </div>
              <div class="flex-caption">
                <h5><span><?php echo $row->Name;?></span></h5>
                <p>
                  <?php echo $row->Detail;?>  
                </p>
               
                <a href="<?php echo $row->Links;?>"><span>Xem </span><span class="shadow">chi tiết ...</span></a>
              </div>
            </li>
<?php
              }
            endforeach;
?>
           


          </ul>
        </div>
        <div class="shadow_left"></div>
        <div class="shadow_right"></div>
      </div>

    </div>
  </div><!-- container -->

