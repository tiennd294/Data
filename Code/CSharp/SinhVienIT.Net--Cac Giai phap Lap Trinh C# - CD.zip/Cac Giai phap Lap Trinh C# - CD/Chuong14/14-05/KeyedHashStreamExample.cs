using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

public class KeyedHashStreamExample {

    public static void Main(string[] args) {

        byte[] key = Encoding.Unicode.GetBytes(args[1]);
        
        using (HMACSHA1 hashAlg = new HMACSHA1(key)) {

            using (Stream file = new FileStream(args[0], FileMode.Open)) {
    
                byte[] hash = hashAlg.ComputeHash(file);
    
                Console.WriteLine(BitConverter.ToString(hash));
            }
        }

        Console.ReadLine();
    }
}
