Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class Form3
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub



		Private Sub Form3_Load(sender As Object, e As EventArgs)

			Try

				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con
				Dim da As SqlDataAdapter = Nothing


				Dim intDM As Integer = Convert.ToInt32(Me.Text)
				Select Case intDM
					Case 1
						lblDM.Text = "Danh Mục Thành Phố"
						da = New SqlDataAdapter("SELECT ThanhPho, TenThanhPho FROM ThanhPho", kn.con)
						Exit Select
					Case 2
						lblDM.Text = "Danh Mục Khách Hàng"
						da = New SqlDataAdapter("SELECT MaKH, TenCty FROM KhachHang", kn.con)
						Exit Select
					Case 3
						lblDM.Text = "Danh Mục Nhân Viên"
						da = New SqlDataAdapter("SELECT MaNV, Ho, Ten FROM NhanVien", kn.con)
						Exit Select
					Case 4
						lblDM.Text = "Danh Mục Sản Phẩm"
						da = New SqlDataAdapter("SELECT MaSP, TenSP, DonViTinh, DonGia FROM SanPham", kn.con)
						Exit Select
					Case 5
						lblDM.Text = "Danh Mục Hóa Đơn"
						da = New SqlDataAdapter("SELECT MaHD, MaKH, MaNV FROM HoaDon", kn.con)
						Exit Select
					Case 6
						lblDM.Text = "Danh Mục Chi Tiết Hóa Đơn"
						da = New SqlDataAdapter("SELECT * FROM ChiTietHoaDon", kn.con)
						Exit Select
					Case Else
						Exit Select
				End Select

				Dim ds As New DataSet()
				da.Fill(ds)
				Dim dt As New DataTable()

				dt.Clear()
				da.Fill(dt)

				dataGridView1.DataSource = dt
				dataGridView1.AutoResizeColumns()
			Catch generatedExceptionName As SqlException

				MessageBox.Show("Không lấy được nội dung trong table. Lỗi rồi!!!")
			End Try
		End Sub

		Private Sub button1_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub


	End Class
End Namespace
