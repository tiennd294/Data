<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class About extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('About_Model');
    }

    public function Index()
    {
        $input = array();
        $tblabout=$this->About_Model->get_list($input);
        $tblmenu=$this->About_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/About/about',
            'tblabout' => $tblabout,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

    public function Add()
    {
        $Images=str_replace(base_url(), '', $this->input->post('atextdata2'));
        $data = array(
            'Name' => $this->input->post('atextdata1'),
            'Images' => $Images,
            'Discription' => $this->input->post('atextdata3'),
            'Detail' => $this->input->post('atextdata4'),
            'Startus' => $this->input->post('atextdata5'),
            'Createby' => $this->session->userdata('Administrator'),
            'Createdate' => date("Y/m/d H:i:s")
        );
        $this->About_Model->create($data);
    }


    public function Edit()
    {
        $Images=str_replace(base_url(), '', $this->input->post('etextdata2'));
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Images' => $Images,
            'Discription' => $this->input->post('etextdata3'),
            'Detail' => $this->input->post('etextdata4'),
            'Startus' => $this->input->post('etextdata5'),
            'Modifyby' => $this->session->userdata('Administrator'),
            'Modifydate' => date("Y/m/d H:i:s")
        );

        if($this->input->post('etextid')){
            $Id = $this->input->post('etextid');
            $this->About_Model->update($Id,$data);
        }
        
    }


    public function Delete()
    {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->About_Model->delete($Id);
        }
    }
}