using System;
using System.Security.Cryptography;

public class SecureRandomNumberExample {

    public static void Main() {
    
        byte[] number = new byte[32];
        
        RandomNumberGenerator rng = RandomNumberGenerator.Create();
        
        rng.GetBytes(number);
        
        Console.WriteLine(BitConverter.ToString(number));

        Console.ReadLine();
    }
}