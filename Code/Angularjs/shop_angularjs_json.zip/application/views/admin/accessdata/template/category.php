<?php
if ($tblmenu!='') 
echo $tblmenu;
?>