namespace nhapso
{
    partial class Frmnhapso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnhapso = new System.Windows.Forms.TextBox();
            this.lblnhapso = new System.Windows.Forms.Label();
            this.btncapnhat = new System.Windows.Forms.Button();
            this.grplopA = new System.Windows.Forms.GroupBox();
            this.lstso = new System.Windows.Forms.ListBox();
            this.grpchucnang = new System.Windows.Forms.GroupBox();
            this.btnsole = new System.Windows.Forms.Button();
            this.btnsochan = new System.Windows.Forms.Button();
            this.btnbinhphuong = new System.Windows.Forms.Button();
            this.btntang = new System.Windows.Forms.Button();
            this.btnxoa2 = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btntong = new System.Windows.Forms.Button();
            this.btnthoat = new System.Windows.Forms.Button();
            this.grplopA.SuspendLayout();
            this.grpchucnang.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtnhapso
            // 
            this.txtnhapso.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnhapso.Location = new System.Drawing.Point(121, 28);
            this.txtnhapso.Name = "txtnhapso";
            this.txtnhapso.Size = new System.Drawing.Size(140, 23);
            this.txtnhapso.TabIndex = 0;
            // 
            // lblnhapso
            // 
            this.lblnhapso.AutoSize = true;
            this.lblnhapso.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnhapso.Location = new System.Drawing.Point(26, 31);
            this.lblnhapso.Name = "lblnhapso";
            this.lblnhapso.Size = new System.Drawing.Size(63, 17);
            this.lblnhapso.TabIndex = 1;
            this.lblnhapso.Text = "Nhap So";
            // 
            // btncapnhat
            // 
            this.btncapnhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncapnhat.Location = new System.Drawing.Point(290, 28);
            this.btncapnhat.Name = "btncapnhat";
            this.btncapnhat.Size = new System.Drawing.Size(109, 23);
            this.btncapnhat.TabIndex = 2;
            this.btncapnhat.Text = "Cap Nhat";
            this.btncapnhat.UseVisualStyleBackColor = true;
            this.btncapnhat.Click += new System.EventHandler(this.btncapnhat_Click);
            // 
            // grplopA
            // 
            this.grplopA.Controls.Add(this.lstso);
            this.grplopA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grplopA.Location = new System.Drawing.Point(12, 78);
            this.grplopA.Name = "grplopA";
            this.grplopA.Size = new System.Drawing.Size(200, 237);
            this.grplopA.TabIndex = 3;
            this.grplopA.TabStop = false;
            this.grplopA.Text = "Lop A";
            // 
            // lstso
            // 
            this.lstso.FormattingEnabled = true;
            this.lstso.ItemHeight = 16;
            this.lstso.Location = new System.Drawing.Point(17, 19);
            this.lstso.Name = "lstso";
            this.lstso.Size = new System.Drawing.Size(167, 196);
            this.lstso.TabIndex = 0;
            // 
            // grpchucnang
            // 
            this.grpchucnang.Controls.Add(this.btnsole);
            this.grpchucnang.Controls.Add(this.btnsochan);
            this.grpchucnang.Controls.Add(this.btnbinhphuong);
            this.grpchucnang.Controls.Add(this.btntang);
            this.grpchucnang.Controls.Add(this.btnxoa2);
            this.grpchucnang.Controls.Add(this.btnxoa);
            this.grpchucnang.Controls.Add(this.btntong);
            this.grpchucnang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpchucnang.Location = new System.Drawing.Point(218, 78);
            this.grpchucnang.Name = "grpchucnang";
            this.grpchucnang.Size = new System.Drawing.Size(183, 237);
            this.grpchucnang.TabIndex = 4;
            this.grpchucnang.TabStop = false;
            this.grpchucnang.Text = "Cac Chuc Nang";
            // 
            // btnsole
            // 
            this.btnsole.Location = new System.Drawing.Point(6, 199);
            this.btnsole.Name = "btnsole";
            this.btnsole.Size = new System.Drawing.Size(171, 23);
            this.btnsole.TabIndex = 2;
            this.btnsole.Text = "Chon so le";
            this.btnsole.UseVisualStyleBackColor = true;
            // 
            // btnsochan
            // 
            this.btnsochan.Location = new System.Drawing.Point(6, 170);
            this.btnsochan.Name = "btnsochan";
            this.btnsochan.Size = new System.Drawing.Size(171, 23);
            this.btnsochan.TabIndex = 2;
            this.btnsochan.Text = "Chon so chan";
            this.btnsochan.UseVisualStyleBackColor = true;
            // 
            // btnbinhphuong
            // 
            this.btnbinhphuong.Location = new System.Drawing.Point(6, 141);
            this.btnbinhphuong.Name = "btnbinhphuong";
            this.btnbinhphuong.Size = new System.Drawing.Size(171, 23);
            this.btnbinhphuong.TabIndex = 2;
            this.btnbinhphuong.Text = "Thay bang binh phuong";
            this.btnbinhphuong.UseVisualStyleBackColor = true;
            this.btnbinhphuong.Click += new System.EventHandler(this.btnbinhphuong_Click);
            // 
            // btntang
            // 
            this.btntang.Location = new System.Drawing.Point(6, 112);
            this.btntang.Name = "btntang";
            this.btntang.Size = new System.Drawing.Size(171, 23);
            this.btntang.TabIndex = 2;
            this.btntang.Text = "Tang moi phan tu len 2";
            this.btntang.UseVisualStyleBackColor = true;
            this.btntang.Click += new System.EventHandler(this.btntang_Click);
            // 
            // btnxoa2
            // 
            this.btnxoa2.Location = new System.Drawing.Point(6, 83);
            this.btnxoa2.Name = "btnxoa2";
            this.btnxoa2.Size = new System.Drawing.Size(171, 23);
            this.btnxoa2.TabIndex = 2;
            this.btnxoa2.Text = "Xoa phan tu dang chon";
            this.btnxoa2.UseVisualStyleBackColor = true;
            this.btnxoa2.Click += new System.EventHandler(this.btnxoa2_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(6, 54);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(171, 23);
            this.btnxoa.TabIndex = 2;
            this.btnxoa.Text = "Xoa phan tu dau va cuoi";
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btntong
            // 
            this.btntong.Location = new System.Drawing.Point(6, 25);
            this.btntong.Name = "btntong";
            this.btntong.Size = new System.Drawing.Size(171, 23);
            this.btntong.TabIndex = 2;
            this.btntong.Text = "Tong cua danh sach";
            this.btntong.UseVisualStyleBackColor = true;
            this.btntong.Click += new System.EventHandler(this.btntong_Click);
            // 
            // btnthoat
            // 
            this.btnthoat.Location = new System.Drawing.Point(12, 333);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(387, 34);
            this.btnthoat.TabIndex = 2;
            this.btnthoat.Text = "KET THUC";
            this.btnthoat.UseVisualStyleBackColor = true;
            this.btnthoat.Click += new System.EventHandler(this.btnthoat_Click);
            // 
            // Frmnhapso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 379);
            this.Controls.Add(this.grpchucnang);
            this.Controls.Add(this.grplopA);
            this.Controls.Add(this.btncapnhat);
            this.Controls.Add(this.btnthoat);
            this.Controls.Add(this.lblnhapso);
            this.Controls.Add(this.txtnhapso);
            this.Name = "Frmnhapso";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grplopA.ResumeLayout(false);
            this.grpchucnang.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnhapso;
        private System.Windows.Forms.Label lblnhapso;
        private System.Windows.Forms.Button btncapnhat;
        private System.Windows.Forms.GroupBox grplopA;
        private System.Windows.Forms.ListBox lstso;
        private System.Windows.Forms.GroupBox grpchucnang;
        private System.Windows.Forms.Button btnsole;
        private System.Windows.Forms.Button btnsochan;
        private System.Windows.Forms.Button btnbinhphuong;
        private System.Windows.Forms.Button btntang;
        private System.Windows.Forms.Button btnxoa2;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btntong;
        private System.Windows.Forms.Button btnthoat;
    }
}

