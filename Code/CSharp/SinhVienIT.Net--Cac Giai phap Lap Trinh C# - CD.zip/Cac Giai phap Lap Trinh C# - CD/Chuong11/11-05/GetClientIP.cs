using System;
using System.Net;

public class GetIPAddress
{
	private static void Main()
	{
		string hostName = Dns.GetHostName();

		string ipAddress = Dns.GetHostByName(hostName).AddressList[0].ToString();

		Console.WriteLine("Host name: " + hostName);
		Console.WriteLine("IP address: " + ipAddress);

		Console.ReadLine();
	}
}