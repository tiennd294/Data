<?php
Class Tbl_Angularjs_Model extends MY_Model
{
    var $table = 'tbl_angular';
    var $key = 'id';
}