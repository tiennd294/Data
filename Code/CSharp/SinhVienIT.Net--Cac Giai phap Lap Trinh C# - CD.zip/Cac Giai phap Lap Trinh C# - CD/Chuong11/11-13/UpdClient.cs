using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class UdpTest 
{
	private static int localPort;

	private static void Main() 
	{

		Console.Write("Connect to IP: ");
		string IP = Console.ReadLine();
		Console.Write("Connect to port: ");
		int port = Int32.Parse(Console.ReadLine());
		

		IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Parse(IP), 
			port);

		Console.Write("Local port for listening: ");
		localPort = Int32.Parse(Console.ReadLine());
		
		Console.WriteLine();

		Thread receiveThread = new Thread(
			new ThreadStart(ReceiveData));
		receiveThread.IsBackground = true;
		receiveThread.Start();

		UdpClient client = new UdpClient();

		try 
		{
			string text;
			do 
			{
				text = Console.ReadLine();

				if (text != "") 
				{

					byte[] data = Encoding.UTF8.GetBytes(text);

					client.Send(data, data.Length, remoteEndPoint);
				}
			} while (text != "");
		}
		catch (Exception err)
		{
			Console.WriteLine(err.ToString());
		}

		Console.ReadLine();
	}

	private static void ReceiveData() 
	{

		UdpClient client = new UdpClient(localPort);
		while (true) 
		{

			try 
			{
				IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, 0);
				byte[] data = client.Receive(ref anyIP);

				string text = Encoding.UTF8.GetString(data);

				Console.WriteLine(">> " + text);
			}
			catch (Exception err) 
			{
				Console.WriteLine(err.ToString());
			}
		}
	}
}