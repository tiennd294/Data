using System;
using System.Net;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

public class DownloadForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.PictureBox picBox;
	private System.Windows.Forms.TextBox textBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DownloadForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.picBox = new System.Windows.Forms.PictureBox();
		this.textBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// picBox
		// 
		this.picBox.Location = new System.Drawing.Point(15, 15);
		this.picBox.Name = "picBox";
		this.picBox.Size = new System.Drawing.Size(472, 128);
		this.picBox.TabIndex = 0;
		this.picBox.TabStop = false;
		// 
		// textBox
		// 
		this.textBox.Location = new System.Drawing.Point(15, 158);
		this.textBox.Multiline = true;
		this.textBox.Name = "textBox";
		this.textBox.ReadOnly = true;
		this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.textBox.Size = new System.Drawing.Size(468, 278);
		this.textBox.TabIndex = 1;
		this.textBox.Text = "";
		// 
		// DownloadForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(496, 449);
		this.Controls.Add(this.textBox);
		this.Controls.Add(this.picBox);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "DownloadForm";
		this.Text = "Download";
		this.Load += new System.EventHandler(this.DownloadForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new DownloadForm());
	}

	private void DownloadForm_Load(object sender, System.EventArgs e)
	{
		string picUri =
			"http://localhost/winXP.gif";
		string htmlUri =
			"http://localhost/iishelp/iis/misc/default.asp";

		WebRequest requestPic = WebRequest.Create(picUri);
		WebRequest requestHtml = WebRequest.Create(htmlUri);

		WebResponse responsePic = requestPic.GetResponse();
		WebResponse responseHtml = requestHtml.GetResponse();

		Image downloadedImage = Image.FromStream(responsePic.GetResponseStream());
		StreamReader r = new StreamReader(responseHtml.GetResponseStream());
        string htmlContent = r.ReadToEnd();
		r.Close();

		picBox.Image = downloadedImage;

		textBox.Text = htmlContent;
	}

}