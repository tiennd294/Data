using System;

namespace _15_08
{
	public class OptionalParameters
	{
		private static object n = Type.Missing;
		private static void Main()
		{
			Word.ApplicationClass app = new Word.ApplicationClass();
			app.DisplayAlerts = Word.WdAlertLevel.wdAlertsNone;
            
			Word.Document doc = app.Documents.Add(ref n, ref n, ref n, ref n);

			Console.WriteLine();
			Console.WriteLine("Creating new document.");
			Console.WriteLine();
			
			Word.Range range = doc.Paragraphs.Add(ref n).Range;
			range.InsertBefore("Test Document");
			string style = "Heading 1";
			object objStyle = style;
			range.set_Style(ref objStyle);
            
			range = doc.Paragraphs.Add(ref n).Range;
			range.InsertBefore("Line one.\nLine two.");
			range.Font.Bold = 1;

			doc.PrintPreview();
			app.Visible = true;

			Console.ReadLine();
		}
	}
}
