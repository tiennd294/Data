Namespace TestQuanbLyBanHang
	Partial Class Form13
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.label1 = New System.Windows.Forms.Label()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label3 = New System.Windows.Forms.Label()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.textBox3 = New System.Windows.Forms.TextBox()
			Me.button1 = New System.Windows.Forms.Button()
			Me.button2 = New System.Windows.Forms.Button()
			Me.SuspendLayout()
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(31, 28)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(98, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Nhap Mat Khau Cu"
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(31, 61)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(102, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Nhap Mat Khau Moi"
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Location = New System.Drawing.Point(31, 89)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(119, 13)
			Me.label3.TabIndex = 2
			Me.label3.Text = "Nhap Lai Mat Khau Moi"
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(167, 25)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.PasswordChar = "*"C
			Me.textBox1.Size = New System.Drawing.Size(161, 20)
			Me.textBox1.TabIndex = 3
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(167, 58)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.PasswordChar = "*"C
			Me.textBox2.Size = New System.Drawing.Size(161, 20)
			Me.textBox2.TabIndex = 4
			' 
			' textBox3
			' 
			Me.textBox3.Location = New System.Drawing.Point(167, 86)
			Me.textBox3.Name = "textBox3"
			Me.textBox3.PasswordChar = "*"C
			Me.textBox3.Size = New System.Drawing.Size(161, 20)
			Me.textBox3.TabIndex = 5
			' 
			' button1
			' 
			Me.button1.Location = New System.Drawing.Point(75, 129)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(75, 27)
			Me.button1.TabIndex = 6
			Me.button1.Text = "Thay Doi"
			Me.button1.UseVisualStyleBackColor = True
			AddHandler Me.button1.Click, New System.EventHandler(Me.button1_Click)
			' 
			' button2
			' 
			Me.button2.Location = New System.Drawing.Point(180, 129)
			Me.button2.Name = "button2"
			Me.button2.Size = New System.Drawing.Size(75, 27)
			Me.button2.TabIndex = 7
			Me.button2.Text = "Huy Bo"
			Me.button2.UseVisualStyleBackColor = True
			AddHandler Me.button2.Click, New System.EventHandler(Me.button2_Click)
			' 
			' Form13
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(341, 168)
			Me.Controls.Add(Me.button2)
			Me.Controls.Add(Me.button1)
			Me.Controls.Add(Me.textBox3)
			Me.Controls.Add(Me.textBox2)
			Me.Controls.Add(Me.textBox1)
			Me.Controls.Add(Me.label3)
			Me.Controls.Add(Me.label2)
			Me.Controls.Add(Me.label1)
			Me.Name = "Form13"
			Me.Text = "Thay Doi Mat Khau"
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private label1 As System.Windows.Forms.Label
		Private label2 As System.Windows.Forms.Label
		Private label3 As System.Windows.Forms.Label
		Private textBox1 As System.Windows.Forms.TextBox
		Private textBox2 As System.Windows.Forms.TextBox
		Private textBox3 As System.Windows.Forms.TextBox
		Private button1 As System.Windows.Forms.Button
		Private button2 As System.Windows.Forms.Button
	End Class
End Namespace
