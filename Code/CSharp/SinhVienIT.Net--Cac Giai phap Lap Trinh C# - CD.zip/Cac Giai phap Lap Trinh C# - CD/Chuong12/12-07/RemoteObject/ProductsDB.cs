using System;
using System.Data;
using System.Data.SqlClient;

namespace RemoteObject
{
	public class ProductsDB : MarshalByRefObject
	{
		private static string connectionString = "Data Source=localhost;" +
			"Initial Catalog=Northwind;Integrated Security=SSPI";

		public DataTable GetProducts() 
		{
			string SQL = "SELECT * FROM Products";

			SqlConnection con = new SqlConnection(connectionString);
			SqlCommand com = new SqlCommand(SQL, con);
			SqlDataAdapter adapter = new SqlDataAdapter(com);
			DataSet ds = new DataSet();

			try
			{
				con.Open();
				adapter.Fill(ds, "Products");
			}
			catch (Exception err)
			{
				Console.WriteLine(err.ToString());
			}
			finally
			{
				con.Close();
			}

			return ds.Tables[0];
		}

		public string GetHostLocation()
		{
			return AppDomain.CurrentDomain.FriendlyName;
		}
	}
}
