using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;

public class MultiPagePrint : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button cmdPrint;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MultiPagePrint()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.cmdPrint = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// cmdPrint
		// 
		this.cmdPrint.Location = new System.Drawing.Point(52, 56);
		this.cmdPrint.Name = "cmdPrint";
		this.cmdPrint.Size = new System.Drawing.Size(104, 32);
		this.cmdPrint.TabIndex = 1;
		this.cmdPrint.Text = "Print";
		this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
		// 
		// MultiPagePrint
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.cmdPrint});
		this.Name = "MultiPagePrint";
		this.Text = "Form1";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new MultiPagePrint());
	}

	private void cmdPrint_Click(object sender, System.EventArgs e)
	{
		string[] printText = new string[100];
		for (int i=0; i < 100; i++)
		{
			printText[i] = i.ToString();
			printText[i] += ": Thập Diện Mai Phục (House of Flying Daggers)";
		}

		PrintDocument doc = new TextDocument(printText);
		doc.PrintPage += new PrintPageEventHandler(this.Doc_PrintPage);

		PrintDialog dlgSettings = new PrintDialog();
		dlgSettings.Document = doc;

		if (dlgSettings.ShowDialog() == DialogResult.OK)
		{

			doc.Print();
		}
	}

	private void Doc_PrintPage(object sender, PrintPageEventArgs e)
	{
		TextDocument doc = (TextDocument)sender;
        
		Font font = new Font("Tahoma", 10);
		float lineHeight = font.GetHeight(e.Graphics);
		
		float x = e.MarginBounds.Left;
		float y = e.MarginBounds.Top;
		
		doc.PageNumber += 1;
		
		while ((y + lineHeight) < e.MarginBounds.Bottom &&
			doc.Offset <= doc.Text.GetUpperBound(0))
		{
			e.Graphics.DrawString(doc.Text[doc.Offset], font, 
				Brushes.Black, x, y);

			doc.Offset += 1;
			
			y += lineHeight;
		}
        
		if (doc.Offset < doc.Text.GetUpperBound(0))
		{
			e.HasMorePages = true;
		}
		else
		{
			doc.Offset = 0;
		}
	}
}

public class TextDocument : PrintDocument
{
	private string[] text;
	private int pageNumber;
	private int offset;

	public string[] Text
	{
		get {return text;}
		set {text = value;}
	}

	public int PageNumber
	{
		get {return pageNumber;}
		set {pageNumber = value;}
	}

	public int Offset
	{
		get {return offset;}
		set {offset = value;}
	}

	public TextDocument(string[] text)
	{
		this.Text = text;
	}
}