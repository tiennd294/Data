A Pen created at CodePen.io. You can find this one at http://codepen.io/KrisOlszewski/pen/Dnktj.

 Ripple effect inspired by Google Material Design