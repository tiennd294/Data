using System;
using System.IO;
using System.Windows.Forms;

public class FileWatcherTest
{
	private static void Main()
	{
		FileSystemWatcher watch = new FileSystemWatcher();
		watch.Path = Application.StartupPath;
		watch.Filter = "*.*";
		watch.IncludeSubdirectories = true;

		watch.Created += new FileSystemEventHandler(OnCreatedOrDeleted);        
		watch.Deleted += new FileSystemEventHandler(OnCreatedOrDeleted);
		watch.EnableRaisingEvents = true;

		Console.WriteLine("Press Enter to create a file.");
		Console.ReadLine();
		
		if (File.Exists("test.bin"))
		{
			File.Delete("test.bin");
		}

		FileStream fs = new FileStream("test.bin", FileMode.Create);
		fs.Close();

		Console.WriteLine("Press Enter to terminate the application.");
		Console.WriteLine();
		Console.ReadLine();
	}

	private static void OnCreatedOrDeleted(object sender, FileSystemEventArgs e) 
	{
		Console.WriteLine("\tNOTIFICATION: " + e.FullPath +
			"' was " + e.ChangeType.ToString());
		Console.WriteLine();
	}

}