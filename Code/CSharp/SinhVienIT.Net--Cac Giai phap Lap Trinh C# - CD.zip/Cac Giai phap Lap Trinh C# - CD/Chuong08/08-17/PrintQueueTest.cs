using System;
using System.Windows.Forms;
using System.Management;
using System.Collections;

public class PrintQueueTest : System.Windows.Forms.Form
{
	private System.Windows.Forms.ListBox lstJobs;
	private System.Windows.Forms.Button cmdRefresh;
	private System.Windows.Forms.TextBox txtJobInfo;
	private System.Windows.Forms.Button cmdPause;
	private System.Windows.Forms.Button cmdResume;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public PrintQueueTest()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.lstJobs = new System.Windows.Forms.ListBox();
		this.cmdRefresh = new System.Windows.Forms.Button();
		this.txtJobInfo = new System.Windows.Forms.TextBox();
		this.cmdPause = new System.Windows.Forms.Button();
		this.cmdResume = new System.Windows.Forms.Button();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// lstJobs
		// 
		this.lstJobs.Location = new System.Drawing.Point(12, 32);
		this.lstJobs.Name = "lstJobs";
		this.lstJobs.Size = new System.Drawing.Size(252, 95);
		this.lstJobs.TabIndex = 1;
		this.lstJobs.SelectedIndexChanged += new System.EventHandler(this.lstJobs_SelectedIndexChanged);
		// 
		// cmdRefresh
		// 
		this.cmdRefresh.Location = new System.Drawing.Point(288, 32);
		this.cmdRefresh.Name = "cmdRefresh";
		this.cmdRefresh.Size = new System.Drawing.Size(96, 24);
		this.cmdRefresh.TabIndex = 2;
		this.cmdRefresh.Text = "Refresh List";
		this.cmdRefresh.Click += new System.EventHandler(this.cmdRefresh_Click);
		// 
		// txtJobInfo
		// 
		this.txtJobInfo.Location = new System.Drawing.Point(12, 164);
		this.txtJobInfo.Multiline = true;
		this.txtJobInfo.Name = "txtJobInfo";
		this.txtJobInfo.ReadOnly = true;
		this.txtJobInfo.Size = new System.Drawing.Size(252, 108);
		this.txtJobInfo.TabIndex = 3;
		this.txtJobInfo.Text = "";
		// 
		// cmdPause
		// 
		this.cmdPause.Location = new System.Drawing.Point(288, 164);
		this.cmdPause.Name = "cmdPause";
		this.cmdPause.Size = new System.Drawing.Size(96, 24);
		this.cmdPause.TabIndex = 4;
		this.cmdPause.Text = "Pause";
		this.cmdPause.Click += new System.EventHandler(this.cmdPause_Click);
		// 
		// cmdResume
		// 
		this.cmdResume.Location = new System.Drawing.Point(288, 196);
		this.cmdResume.Name = "cmdResume";
		this.cmdResume.Size = new System.Drawing.Size(96, 24);
		this.cmdResume.TabIndex = 5;
		this.cmdResume.Text = "Resume";
		this.cmdResume.Click += new System.EventHandler(this.cmdResume_Click);
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(12, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(52, 16);
		this.label1.TabIndex = 6;
		this.label1.Text = "Jobs:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(12, 144);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(100, 16);
		this.label2.TabIndex = 7;
		this.label2.Text = "Selected Job:";
		// 
		// PrintQueueTest
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(408, 294);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.label2,
																		this.label1,
																		this.cmdResume,
																		this.cmdPause,
																		this.txtJobInfo,
																		this.cmdRefresh,
																		this.lstJobs});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "PrintQueueTest";
		this.Text = "Print Queue Test";
		this.Load += new System.EventHandler(this.PrintQueueTest_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new PrintQueueTest());
	}

	private void PrintQueueTest_Load(object sender, System.EventArgs e)
	{
		cmdRefresh_Click(null, null);
	}

	private void cmdRefresh_Click(object sender, System.EventArgs e)
	{
		string query = "SELECT * FROM Win32_PrintJob";
		ManagementObjectSearcher jobQuery = new ManagementObjectSearcher(query);
        ManagementObjectCollection jobs = jobQuery.Get();
		
		lstJobs.Items.Clear();
		txtJobInfo.Text = "";
		foreach (ManagementObject job in jobs)
		{
			lstJobs.Items.Add(job["JobID"]);
		}
	}

	private ManagementObject GetSelectedJob()
	{
		try
		{
			string query = "SELECT * FROM Win32_PrintJob " +
				"WHERE JobID='" + lstJobs.Text + "'";
			ManagementObjectSearcher jobQuery = new ManagementObjectSearcher(query);           
			ManagementObjectCollection jobs = jobQuery.Get();
			IEnumerator enumerator = jobs.GetEnumerator();
			enumerator.MoveNext();
			return (ManagementObject)enumerator.Current;
		}
		catch (InvalidOperationException)
		{
			return null;
		}
	}

	private void lstJobs_SelectedIndexChanged(object sender, System.EventArgs e)
	{
		ManagementObject job = GetSelectedJob();
		if (job == null)
		{
			txtJobInfo.Text = "";
			return;
		}
		
		string jobInfo = "Document: " + job["Document"].ToString();
		jobInfo += Environment.NewLine;
		jobInfo += "DriverName: " + job["DriverName"].ToString();
		jobInfo += Environment.NewLine;
		jobInfo += "Status: " + job["Status"].ToString();            
		jobInfo += Environment.NewLine;
		jobInfo += "Owner: " + job["Owner"].ToString();
		
		jobInfo += Environment.NewLine;
		jobInfo += "PagesPrinted: " +
			job["PagesPrinted"].ToString();
		jobInfo += Environment.NewLine;
		jobInfo += "TotalPages: " + job["TotalPages"].ToString();

		if (job["JobStatus"] != null)
		{
			txtJobInfo.Text += Environment.NewLine;
			txtJobInfo.Text += "JobStatus: " + job["JobStatus"].ToString();
		}
		if (job["StartTime"] != null)
		{
			jobInfo += Environment.NewLine;
			jobInfo += "StartTime: " + job["StartTime"].ToString();
		}
		
		txtJobInfo.Text = jobInfo;
	}

	private void cmdPause_Click(object sender, System.EventArgs e)
	{
		if (lstJobs.SelectedIndex == -1) return;
		ManagementObject job = GetSelectedJob();
		if (job == null) return;
    
        int returnValue = Int32.Parse(job.InvokeMethod("Pause", null).ToString());

		if (returnValue == 0)
		{
			MessageBox.Show("Successfully paused job.");
		}
		else
		{
			MessageBox.Show("Unrecognized return value when pausing job.");
		}
        
	}

	private void cmdResume_Click(object sender, System.EventArgs e)
	{
		if (lstJobs.SelectedIndex == -1) return;
		ManagementObject job = GetSelectedJob();
		if (job == null) return;
    
		if ((Int32.Parse(job["StatusMask"].ToString()) & 1) == 1)
		{
			int returnValue = Int32.Parse(job.InvokeMethod("Resume", null).ToString());

			if (returnValue == 0)
			{
				MessageBox.Show("Successfully resumed job.");
			}
			else if (returnValue == 5)
			{
				MessageBox.Show("Access denied.");
			}
			else
			{
				MessageBox.Show("Unrecognized return value when resuming job.");
			}
		}
	}
}