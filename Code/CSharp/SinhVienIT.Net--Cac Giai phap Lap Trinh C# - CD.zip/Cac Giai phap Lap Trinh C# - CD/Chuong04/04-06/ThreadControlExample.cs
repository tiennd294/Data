using System;
using System.Threading;

public class ThreadControlExample {

    private static void DisplayMessage() {

        while (true) {

            try {

                Console.WriteLine("{0} : Second thread running. Enter"
                    + " (S)uspend, (R)esume, (I)nterrupt, or (E)xit.",
                    DateTime.Now.ToString("HH:mm:ss.ffff"));

                Thread.Sleep(2000);

            } catch (ThreadInterruptedException) {

                Console.WriteLine("{0} : Second thread interrupted.",
                    DateTime.Now.ToString("HH:mm:ss.ffff"));

            } catch (ThreadAbortException abortEx) {

                Console.WriteLine("{0} : Second thread aborted ({1})",  
                    DateTime.Now.ToString("HH:mm:ss.ffff"),
                    abortEx.ExceptionState);

            }
        }
    }

    public static void Main() {

        Thread thread = new Thread(new ThreadStart(DisplayMessage));

        Console.WriteLine("{0} : Starting second thread.",  
            DateTime.Now.ToString("HH:mm:ss.ffff"));

        thread.Start();

        char command = ' ';

        do {

            string input = Console.ReadLine();
            if (input.Length > 0) command = input.ToUpper()[0];
            else command = ' ';

            switch (command) {

                case 'S':
                    Console.WriteLine("{0} : Suspending second thread.",
                        DateTime.Now.ToString("HH:mm:ss.ffff"));
                    thread.Suspend();
                    break;

                case 'R':
                    try { 
                        Console.WriteLine("{0} : Resuming second thread.",
                            DateTime.Now.ToString("HH:mm:ss.ffff"));
                        thread.Resume();
                    } catch (ThreadStateException) {
                        Console.WriteLine("{0} : Thread wasn't suspended.",
                            DateTime.Now.ToString("HH:mm:ss.ffff"));
                    }
                    break;

                case 'I':
                    Console.WriteLine("{0} : Interrupting second thread.",
                        DateTime.Now.ToString("HH:mm:ss.ffff"));
                    thread.Interrupt();
                    break;

                case 'E':
                    Console.WriteLine("{0} : Aborting second thread.",  
                        DateTime.Now.ToString("HH:mm:ss.ffff"));

                    thread.Abort("Terminating example.");

                    thread.Join();
                    break;
            }
        } while (command != 'E');

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}