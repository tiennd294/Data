<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Angularjs extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Tbl_Angularjs_Model');
        $this->load->model('Users_Model');
    }

    public function Index()
    {
        $input = array();
        $tblangularjs=$this->Tbl_Angularjs_Model->get_list($input);
        $tblmenu=$this->Tbl_Angularjs_Model->loadmenu();

        $data = array(
            'urldata' => 'admin/Angularjs/index',
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

    public function Load_data($page = 1, $page_size = 3)
    {
        $input = array();
        $tblangularjs = json_encode($this->Tbl_Angularjs_Model->get_list($input)) ;
        echo $tblangularjs;
    }

    public function Add()
    {
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);
        //$request = json_decode($data);
        $data = array(
            'name' => $request->name,
            'Phone' => $request->phone,
            'email' => $request->email,
            'address' => $request->address,
            'startus' => $request->startus
        );
        $this->Tbl_Angularjs_Model->create($data);
    }

    public function Update()
    {
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);

        $data = array(
            'name' => $request->name,
            'Phone' => $request->phone,
            'email' => $request->email,
            'address' => $request->address,
            'startus' => $request->startus
        );
        if (isset($request->id)) {
           $id = $request->id;
           $this->Tbl_Angularjs_Model->update($id,$data);
        }
        
    }

    public function Delete()
    {
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);
        if (isset($request->id)) {
           $id = $request->id;
           $this->Tbl_Angularjs_Model->delete($id);
        }
    }
}