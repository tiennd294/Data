<script type='text/javascript'>
    $(function(){
    $('#atextdata3Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#atextdata3').val(fileUrl.replace('/test/admin',''));
            $('#atextdata3').attr('readonly', true);
        };
        ckfinder.popup();
    })

    $('#etextdata3Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#etextdata3').val(fileUrl.replace('/test/admin',''));
            $('#etextdata3').attr('readonly', true);
        };
        ckfinder.popup();
    })

    });

   





</script> 
<?php
        $this->load->view('admin/accessdata/template/messenger');
?>

                          
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                        <div class='table-action'>
                            <a href='#' class='btnadd tip-top' data-original-title='Add'><i class='icon-plus'></i> Thêm mới</a>
                        </div>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã ID</th>  
                                    <th>Tên tin tức</th>  

                                    <th>Mô tả</th>  
                                    <th>Hình ảnh</th>  
                                    <th>Danh mục</th>  
                                    <th>Nội dung</th>  

                                    <th>Trạng thái</th>  
                                    <th>Create by</th> 
                                    <th>Modify by</th> 




                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                $i=0;
                                foreach ($tblnews as $row):
                                    $i++;
                            ?>
                                <tr class='gradeU items_' id='<?php echo $row->Idn; ?>'>
                                    <td><?php echo $row->Idn; ?></td>
                                    <td><?php echo $row->Name; ?></td>

                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Discription; ?></div></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Images; ?></div></td>
                                    <td><?php echo $row->Idc; ?></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Detail; ?></div></td>

                                    <td><?php echo $row->Startus; ?></td>
                                    <td><?php echo $row->Createby; ?></td>
                                    <td><?php echo $row->Modifyby; ?></td>




                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Thêm mới</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='<?php echo admin_url();?>/news/Add'>

								<div class='control-group'>
									<label class='control-label'>Danh mục</label>
									<div class='controls '>
									     <select name='atextdata4' id='atextdata4'>
                                                 <?php
                                                  foreach ($tblcategory as $row):
                                        		  	if ($row->Parentid==0 && $row->Level==2) {
                                        		  	
                                                ?>
                                                    <option  value='<?php echo $row->Idc; ?>'><?php echo $row->Name; ?></option>
                                                <?php
                                                	}
                                                  endforeach;
                                                ?>
									     </select>
									</div>
								</div>

								

								<div class='control-group'>
									<label class='control-label'>Tên tin tức :</label>
									<div class='controls'>
										<input  name='atextdata1' type='text' class='span20 atextdata1' placeholder='Tên tin tức' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mô tả :</label>
									<div class='controls'>
										<textarea  name='atextdata2' class='span20  atextdata2 ' placeholder=' Mô tả' rows='5' ></textarea>
									</div>
								</div>

									<div class='control-group'>
										<label class='control-label'>Hình ảnh :</label>
										<div class='controls'>
                                            <input id='atextdata3'  name='atextdata3' type='text' class='span3 atextdata3' placeholder='Hình ảnh' />
                                            <button id='atextdata3Brows' class='atextdata3Brows'>...</button>
										</div>
									</div>

								
                                

								<div class='control-group'>
									<label class='control-label'>Nội dung :</label>
									<div class='controls'>
									</div>
								</div>

								<div class='control-group' style='margin-right: 1.5%; '>
										<textarea  name='atextdata5ck' class='span20 atextdata5ck ckeditor' rows='5' ></textarea>
                                        <div class='setingck' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>
                                        <input  name='atextdata5' type='text' class='span20 atextdata5' placeholder='data' />
                                        </div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='atextdata6' class='atextdata6 atextdata6cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnadd' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	<div class='frmedit' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-pencil'></i>
									</span>
									<h5>Cập nhật</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form3' class='form-horizontal' name='form3' method='post' action='<?php echo admin_url();?>/news/Edit'>
								<div class='control-group'>
										<label class='control-label'>Mã ID :</label>
										<div class='controls'><input id='etextid' name='etextid' type='text' class='span20 etextid'/></div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Danh mục</label>
									<div class='controls '>
									     <select name='etextdata4' id='etextdata4'>
                                         
                                                <?php
                                                  foreach ($tblcategory as $row):
                                        		  		if ($row->Parentid==0 && $row->Level==2) {
                                                ?>
                                                    <option value="<?php echo $row->Idc; ?>"><?php echo $row->Name; ?></option>
                                                <?php
                                                		}
                                                  endforeach;
                                                ?>
									     </select>
									</div>
								</div>



								<div class='control-group'>
									<label class='control-label'>Tên tin tức :</label>
									<div class='controls'>
										<input  name='etextdata1' type='text' class='span20 etextdata1' placeholder='Tên tin tức' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mô tả :</label>
									<div class='controls'>
										<textarea  name='etextdata2' class='span20  etextdata2 ' placeholder=' Mô tả' rows='5' ></textarea>
									</div>
								</div>

									<div class='control-group'>
										<label class='control-label'>Hình ảnh :</label>
										<div class='controls'>
                                            <input id='etextdata3'  name='etextdata3' type='text' class='span3 etextdata3' placeholder='Hình ảnh' />
                                            <button id='etextdata3Brows' class='etextdata3Brows'>...</button>
										</div>
									</div>

								

								<div class='control-group'>
									<label class='control-label'>Nội dung :</label>
									<div class='controls'>
									</div>
								</div>

								<div class='control-group' style='margin-right: 1.5%; '>
										<textarea  name='etextdata5ck' class='span20 etextdata5ck ckeditor' rows='5' ></textarea>
                                        <div class='setingck' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>
                                        <input  name='etextdata5' type='text' class='span20 etextdata5' placeholder='data' />
                                        </div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='etextdata6' class='etextdata6 etextdata6cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnedit' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>







	<div class='frmdelete' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-trash'></i>
									</span>
									<h5>Xóa</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form2' class='form-horizontal' name='form2' method='post' action='<?php echo admin_url();?>/news/Delete'>
								<div class='controls'>                                   <label id='Label2' class='control-label'> Bạn có chắc chắn muốn xóa không?</label>                               </div>                               <div class='control-group' style='padding-left:5px; padding-top:5px;'>                                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:13px;height:13px;overflow:auto;'>                                        <div class='control-group'>                                               <label class='control-label'>ID dstaikhoan:</label>                                           <div class='controls'>                                               <input id='textid' class='textid' name='textid' type='text' class='span20' />                                           </div>                                       </div>                                   </div>                               </div>								<div class='form-actions  txtc'   align='center'>
									<button id='btndelete' class='btn btnyes btn-success'>Có</button>
									<button id='btnhuy'  class='btn btn-success btncancel' style='margin-left:10px'> Không</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
