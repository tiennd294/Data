using System;
using SQLDMO;

public class SQLDMOExample {

    public static void Main() {

        SQLDMO.Application app = new SQLDMO.Application();
        SQLDMO.NameList names = app.ListAvailableSQLServers();

        if (names.Count == 0) {

            Console.WriteLine("No SQL Servers visible on the network.");

        } else {

            Console.WriteLine("SQL Servers visible : " + names.Count);

            foreach (string name in names) {

                Console.WriteLine("  Name : " + name);
            }
        }

        Console.ReadLine();
    }
}
