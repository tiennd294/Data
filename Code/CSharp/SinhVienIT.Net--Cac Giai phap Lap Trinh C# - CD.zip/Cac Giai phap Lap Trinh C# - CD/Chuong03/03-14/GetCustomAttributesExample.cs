using System;

[Author("Bluewind Thai")]
[Author("Square Nguyen", Company = "Goldsoft Ltd.")]
public class GetCustomAttributesExample {

    public static void Main() {

        Type type = typeof(GetCustomAttributesExample);

        object[] attrs = 
            type.GetCustomAttributes(typeof(AuthorAttribute), true);

        foreach (AuthorAttribute a in attrs) {
            Console.WriteLine(a.Name + ", " + a.Company);
        }

        Console.ReadLine();
    }
}
