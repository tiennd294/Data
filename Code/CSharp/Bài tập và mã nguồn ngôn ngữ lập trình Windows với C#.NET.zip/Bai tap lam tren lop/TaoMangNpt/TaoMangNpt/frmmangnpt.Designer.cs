namespace TaoMangNpt
{
    partial class frmmangnpt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnhap = new System.Windows.Forms.Label();
            this.txtso = new System.Windows.Forms.TextBox();
            this.btnxuatmang = new System.Windows.Forms.Button();
            this.btnchan = new System.Windows.Forms.Button();
            this.btnle = new System.Windows.Forms.Button();
            this.btnsnt = new System.Windows.Forms.Button();
            this.btnsohh = new System.Windows.Forms.Button();
            this.btnthoat = new System.Windows.Forms.Button();
            this.lbldisplay = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblnhap
            // 
            this.lblnhap.AutoSize = true;
            this.lblnhap.Location = new System.Drawing.Point(21, 13);
            this.lblnhap.Name = "lblnhap";
            this.lblnhap.Size = new System.Drawing.Size(61, 13);
            this.lblnhap.TabIndex = 0;
            this.lblnhap.Text = "Nhap gia tri";
            // 
            // txtso
            // 
            this.txtso.Location = new System.Drawing.Point(94, 10);
            this.txtso.Name = "txtso";
            this.txtso.Size = new System.Drawing.Size(167, 20);
            this.txtso.TabIndex = 1;
            // 
            // btnxuatmang
            // 
            this.btnxuatmang.Location = new System.Drawing.Point(267, 8);
            this.btnxuatmang.Name = "btnxuatmang";
            this.btnxuatmang.Size = new System.Drawing.Size(75, 23);
            this.btnxuatmang.TabIndex = 2;
            this.btnxuatmang.Text = "Xuat";
            this.btnxuatmang.UseVisualStyleBackColor = true;
            // 
            // btnchan
            // 
            this.btnchan.Location = new System.Drawing.Point(24, 167);
            this.btnchan.Name = "btnchan";
            this.btnchan.Size = new System.Drawing.Size(75, 23);
            this.btnchan.TabIndex = 2;
            this.btnchan.Text = "Chan";
            this.btnchan.UseVisualStyleBackColor = true;
            // 
            // btnle
            // 
            this.btnle.Location = new System.Drawing.Point(105, 167);
            this.btnle.Name = "btnle";
            this.btnle.Size = new System.Drawing.Size(75, 23);
            this.btnle.TabIndex = 2;
            this.btnle.Text = "Le";
            this.btnle.UseVisualStyleBackColor = true;
            // 
            // btnsnt
            // 
            this.btnsnt.Location = new System.Drawing.Point(186, 167);
            this.btnsnt.Name = "btnsnt";
            this.btnsnt.Size = new System.Drawing.Size(75, 23);
            this.btnsnt.TabIndex = 2;
            this.btnsnt.Text = "So NT";
            this.btnsnt.UseVisualStyleBackColor = true;
            // 
            // btnsohh
            // 
            this.btnsohh.Location = new System.Drawing.Point(267, 167);
            this.btnsohh.Name = "btnsohh";
            this.btnsohh.Size = new System.Drawing.Size(75, 23);
            this.btnsohh.TabIndex = 2;
            this.btnsohh.Text = "So HH";
            this.btnsohh.UseVisualStyleBackColor = true;
            // 
            // btnthoat
            // 
            this.btnthoat.Location = new System.Drawing.Point(146, 196);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(75, 23);
            this.btnthoat.TabIndex = 2;
            this.btnthoat.Text = "Exit";
            this.btnthoat.UseVisualStyleBackColor = true;
            // 
            // lbldisplay
            // 
            this.lbldisplay.BackColor = System.Drawing.SystemColors.Desktop;
            this.lbldisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldisplay.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbldisplay.Location = new System.Drawing.Point(21, 48);
            this.lbldisplay.Name = "lbldisplay";
            this.lbldisplay.Size = new System.Drawing.Size(321, 106);
            this.lbldisplay.TabIndex = 3;
            this.lbldisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmmangnpt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 235);
            this.Controls.Add(this.lbldisplay);
            this.Controls.Add(this.btnsohh);
            this.Controls.Add(this.btnthoat);
            this.Controls.Add(this.btnsnt);
            this.Controls.Add(this.btnle);
            this.Controls.Add(this.btnchan);
            this.Controls.Add(this.btnxuatmang);
            this.Controls.Add(this.txtso);
            this.Controls.Add(this.lblnhap);
            this.Name = "frmmangnpt";
            this.Text = "Mang N phan tu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnhap;
        private System.Windows.Forms.TextBox txtso;
        private System.Windows.Forms.Button btnxuatmang;
        private System.Windows.Forms.Button btnchan;
        private System.Windows.Forms.Button btnle;
        private System.Windows.Forms.Button btnsnt;
        private System.Windows.Forms.Button btnsohh;
        private System.Windows.Forms.Button btnthoat;
        private System.Windows.Forms.Label lbldisplay;
    }
}

