using System;
using System.Web;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for TestState.
/// </summary>
public class TestState : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.Button cmdClear;
	protected System.Web.UI.WebControls.Button cmdStore;
	protected System.Web.UI.WebControls.Label lblData;
	protected System.Web.UI.WebControls.Button cmdGetData;
		
	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
		this.cmdGetData.Click += new System.EventHandler(this.cmdGetData_Click);
		this.cmdStore.Click += new System.EventHandler(this.cmdStore_Click);
		

	}
	#endregion

	private void cmdStore_Click(object sender, System.EventArgs e) {
	
		DateTime now = DateTime.Now;

		ViewState["TestData"] = now;

		Session["TestData"] = now;

		if (Request.Cookies["07-02"] == null) {
		
			HttpCookie cookie = new HttpCookie("07-02");

			cookie["TestData"] = now.ToString();
            
			Response.Cookies.Add(cookie);
		}
	}

	private void cmdGetData_Click(object sender, System.EventArgs e) {
	
		lblData.Text = "";

		if (ViewState["TestData"] != null) {
		
			DateTime data = (DateTime)ViewState["TestData"];
			lblData.Text += "<b>View state data:</b> " +
				data.ToString() + "<br>";
		}
		else {
		
			lblData.Text += "No view state data found.<br>";
		}

		if (Session["TestData"] != null) {
		
			DateTime data = (DateTime)Session["TestData"];
			lblData.Text += "<b>Session state data:</b> " +
				data.ToString() + "<br>";
		}
		else {
		
			lblData.Text += "No session data found.<br>";
		}

		HttpCookie cookie = Request.Cookies["07-02"];
		if (cookie != null) {
		
			string cookieData = (string)cookie["TestData"];
			lblData.Text += "<b>Cookie data:</b> " +
				cookieData + "<br>";
		}
		else {
		
			lblData.Text += "No cookie data found.<br>";
		}
	}

	private void cmdClear_Click(object sender, System.EventArgs e) {
	
		ViewState["TestData"] = null;
        Session["TestData"] = null;
		HttpCookie cookie = new HttpCookie("07-02");
		cookie.Expires = DateTime.Now.AddDays(-1);
		Response.Cookies.Add(cookie);
	}
}