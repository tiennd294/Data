using System;
using System.Text;
using System.Security.Cryptography;

public class KeyExchangeExample {

    public static void Main() {

        RSAParameters recipientsPublicKey;

        CspParameters cspParams = new CspParameters();
        cspParams.KeyContainerName = "MyKeys";
        
        using (RSACryptoServiceProvider rsaAlg = 
            new RSACryptoServiceProvider(cspParams)) {
            
            rsaAlg.PersistKeyInCsp = true;

            recipientsPublicKey = rsaAlg.ExportParameters(false);
        }
        
        using (SymmetricAlgorithm symAlg =
            SymmetricAlgorithm.Create("3DES")) {
        
            Console.WriteLine("Session Key at Source = {0}\n\r", 
                BitConverter.ToString(symAlg.Key));
            
            byte[] exchangeData = 
                FormatKeyExchange(symAlg.Key, recipientsPublicKey);
            
            Console.WriteLine("Exchange Data = {0}\n\r", 
                BitConverter.ToString(exchangeData));

            byte[] sessionKey = DeformatKeyExchange(exchangeData, cspParams);
            
            Console.WriteLine("Session Key at Destination = {0}\n\r", 
                BitConverter.ToString(sessionKey));

            Console.ReadLine();
        }
    }

    private static byte[] FormatKeyExchange(byte[] sessionKey, 
        RSAParameters rsaParams) {
        
        using (RSACryptoServiceProvider asymAlg = 
            new RSACryptoServiceProvider()) {
       
            asymAlg.ImportParameters(rsaParams);
            
            RSAOAEPKeyExchangeFormatter formatter   
                = new RSAOAEPKeyExchangeFormatter();
    
            formatter.SetKey(asymAlg);
    
            return formatter.CreateKeyExchange(sessionKey);
        }
    }

    private static byte[] DeformatKeyExchange(byte[] exchangeData, 
        CspParameters cspParams) {   
        
        using (RSACryptoServiceProvider asymAlg = 
            new RSACryptoServiceProvider(cspParams)) {
        
            RSAOAEPKeyExchangeDeformatter deformatter 
                = new RSAOAEPKeyExchangeDeformatter();
        
            deformatter.SetKey(asymAlg);

            return deformatter.DecryptKeyExchange(exchangeData);
        }
    }
}