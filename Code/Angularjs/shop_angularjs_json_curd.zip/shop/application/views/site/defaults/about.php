<?php 
foreach ($tblabout as $row):  
?>
<div class="container">

<div class="container">
		<div class="sixteen columns">
			
			<div id="pageName">
				<div class="name_tag">
					<p>
						Giới thiệu
					</p>
					<div class="shapLeft"></div>
					<div class="shapRight"></div>
				</div>
			</div><!--end pageName-->

		</div>
	</div><!-- container -->

		<div class="sixteen columns">
			<div class="box_head">
				<h3><?php echo $row->Name; ?></h3>
			</div><!--end box_head -->

			<div class="seven columns alpha">
				<div class="welcome_img">
					<img src="<?php echo base_url().$row->Images; ?>" alt="">
				</div>
			</div><!--end four-->

			<div class="nine columns omega">
				<div class="welcome_text" style="padding-right:15%;">
					<h2></h2>
					<p>
						<?php echo $row->Discription; ?>
					</p>
					
					
				</div>
			</div><!--end fourteen-->


			<div class="seven columns alpha item" style="width:97%;padding-top:5%;padding-left:5%;padding-right:20%;">
				<div class="welcome_text" style="padding-right:10%;">
					
					<p>
						<?php echo $row->Detail; ?>
					</p>
				</div>
			</div>


		</div><!--end sixteen-->

		

		

	</div><!--end container-->
<?php endforeach; ?>