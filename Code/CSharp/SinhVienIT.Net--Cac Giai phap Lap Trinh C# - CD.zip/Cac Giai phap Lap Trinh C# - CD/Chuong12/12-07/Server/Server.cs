using System;
using System.Runtime.Remoting;

namespace Server
{
	public class Server
	{
		private static void Main()
		{
			RemotingConfiguration.Configure("Server.exe.config");

			Console.WriteLine("Press a key to shut down the server.");
			Console.ReadLine();
		}
	}
}
