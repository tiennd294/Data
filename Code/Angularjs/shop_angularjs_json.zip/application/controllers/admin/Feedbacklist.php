<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Feedbacklist extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Feedback_Model');
    }

    public function Index()
    {
        $input = array();
        $tblfeedback=$this->Feedback_Model->get_list($input);
        $tblmenu=$this->Feedback_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Feedback/feedbacklist',
            'tblfeedback' => $tblfeedback,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);

        
    }

    public function Update()
    {
        $tg=$this->input->post('Startus');
        if ($this->input->post('Startus')=='on') {
            $tg='';
        }
        else $tg='on';
        $data = array(
            'Startus' => $tg
        );
        if($this->input->post('Idf')){

            $Id = $this->input->post('Idf');
            $this->Feedback_Model->update($Id,$data);
        }
        
    }

}