using System;

class PlayAudio
{
	public static void Main(string[] args) 
	{ 
		string filename = args[0]; 

		QuartzTypeLib.FilgraphManager graphManager = 
			new QuartzTypeLib.FilgraphManager();
		QuartzTypeLib.IMediaControl mc =
  			(QuartzTypeLib.IMediaControl)graphManager;

		mc.RenderFile(filename);

		mc.Run();
		
		Console.WriteLine("Press Enter to continue."); 
		Console.ReadLine();

		mc.Stop();			
	}
}