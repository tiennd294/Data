<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Defaults extends MY_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('About_Model');
    }

	public function index()
	{
		$tblmenu=$this->About_Model->loadmenu();
		$tbldefaults=$this->About_Model->loadpagedefault();
		$data = array(
			'urldata' => 'admin/Defaults/Index',
			'tblmenu' => $tblmenu,
			'tbldefaults' => $tbldefaults
		);
		$this->load->view('admin/layout',$data);
		
	}
}
