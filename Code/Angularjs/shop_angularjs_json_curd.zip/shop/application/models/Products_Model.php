<?php
Class Products_Model extends MY_Model
{
    var $table = 'products';
    var $key = 'Idp';
}