<?php
Class User_Model extends MY_Model
{
    var $table = 'user';
    var $key = 'Email';
}