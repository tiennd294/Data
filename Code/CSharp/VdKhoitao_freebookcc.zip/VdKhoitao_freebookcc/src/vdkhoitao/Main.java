package VdKhoitao;
//import java.lang.*;
class Pair {

    int a;    // miền của lớp xác định các thành phần đối tượng
    int b;    // a – thành phần đầu tiên, b – thành phần thứ hai

 public Pair(int x, int y) {   // the constructor thiết lập giá trị của các thành phần
   a = x  ;             // dựa vào các giá trị làm đối số
   b = y;
 }

public Pair(int x) {          // constructor thiết lập giá trị của các thành phần
   a = b = x;           // (a và b) cùng bằng giá trị x
 }


 void set(Pair p)  {    // phương pháp này thiết lập giá trị của các thành phần
   a = p.a;             // dựa trên các thành phần của cặp cung cấp làm đối số
   b = p.b;
 }


public Pair add(Pair p) {             // phương pháp cộng hai cặp
   Pair result = new Pair(a, b);
   result.a += p.a+1;
   result.b += p.b;
   return result;
 }

                               // phương pháp in một cặp
 public void show(String s)  {
   System.out.println(s + " ( " + a + " , " + b + " )" );
 }

}

public class Main {

  public static void main(String[] args) {
    Pair pair1 = new Pair(1,5);
    Pair pair2 = new Pair(2,4);
    pair1.show("Pair 1 =");
    pair2.show("Pair 2 =");
    Pair pairSum = pair1.add(pair2);
    pairSum.show("Sum of pairs =");
    pair1.set(pair2);
    pair1.show("Pair 1 = ");

  }

}