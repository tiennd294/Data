using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Web.Services;
using System.EnterpriseServices;

public class TransactionTest : System.Web.Services.WebService
{
	public TransactionTest()
	{
		//CODEGEN: This call is required by the ASP.NET Web Services Designer
		InitializeComponent();
	}

	#region Component Designer generated code
	
	//Required by the Web Services Designer 
	private IContainer components = null;
			
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if(disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);		
	}
	
	#endregion

	private static string connectionString = "Data Source=localhost;" +
		"Initial Catalog=Northwind;user ID=sa";

	[WebMethod(TransactionOption=TransactionOption.RequiresNew)]
	public void FailedTransaction()
	{
		SqlConnection con = new SqlConnection(connectionString);

		SqlCommand cmd = new SqlCommand("DELETE * FROM Customers", con);

		con.Open();
		cmd.ExecuteNonQuery();
		    con.Close();

		DoSomething();
		
	}

	private void DoSomething()
	{
		ContextUtil.SetAbort();
	}

}