using System;

public class AccessEnvironmentExample {

    public static void Main() {

        Console.WriteLine("Command line : " + Environment.CommandLine);

        Console.WriteLine("OS PlatformID : " + 
            Environment.OSVersion.Platform);
        Console.WriteLine("OS Major Version : " + 
            Environment.OSVersion.Version.Major);
        Console.WriteLine("OS Minor Version : " + 
            Environment.OSVersion.Version.Minor);
        Console.WriteLine("CLR Version : " + Environment.Version);

        Console.WriteLine("User Name : " + Environment.UserName);
        Console.WriteLine("Domain Name : " + Environment.UserDomainName);
        Console.WriteLine("Machine name : " + Environment.MachineName);

        Console.WriteLine("Is interactive ? : " 
            + Environment.UserInteractive);
        Console.WriteLine("Shutting down ? : " 
            + Environment.HasShutdownStarted);
        Console.WriteLine("Ticks since startup : " 
            + Environment.TickCount);

        foreach (string s in Environment.GetLogicalDrives()) {
            Console.WriteLine("Logical drive : " + s);
        }

        Console.WriteLine("Current folder : " 
            + Environment.CurrentDirectory);
        Console.WriteLine("System folder : " 
            + Environment.SystemDirectory);

        foreach (Environment.SpecialFolder s in 
            Enum.GetValues(typeof(Environment.SpecialFolder))) {

            Console.WriteLine("{0} folder : {1}", 
                s, Environment.GetFolderPath(s));
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}
