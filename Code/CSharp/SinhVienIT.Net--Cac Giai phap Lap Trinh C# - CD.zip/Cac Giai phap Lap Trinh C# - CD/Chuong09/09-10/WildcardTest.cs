using System;
using System.IO;

public class WildcardTest
{
	private static void Main(string[] args)
	{
		if (args.Length < 2)
		{
			Console.WriteLine("USAGE:  WildcardTest [directory] [filterExpression]");
			return;
		}

		DirectoryInfo dir = new DirectoryInfo(args[0]);
		FileInfo[] files = dir.GetFiles(args[1]);
        
		foreach (FileInfo file in files)
		{
			Console.Write("Name: " + file.Name + "  ");
			Console.WriteLine("Size: " + file.Length.ToString());
		}

		Console.ReadLine();
	}
}