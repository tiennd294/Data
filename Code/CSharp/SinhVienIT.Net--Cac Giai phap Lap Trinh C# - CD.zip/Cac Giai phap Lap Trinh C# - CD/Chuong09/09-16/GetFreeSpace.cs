using System;
using System.Runtime.InteropServices;

public class GetFreeSpace
{
	[DllImport("kernel32.dll", EntryPoint="GetDiskFreeSpaceExA" )]
	private static extern long GetDiskFreeSpaceEx(
        string lpDirectoryName, out long lpFreeBytesAvailableToCaller, 
		out long lpTotalNumberOfBytes, out long lpTotalNumberOfFreeBytes);

	private static void Main()
	{
		long result, total , free, available;
        
		result = GetDiskFreeSpaceEx("c:", out available, out total, out free);

        if (result != 0)
		{
			Console.WriteLine("Total Bytes: {0:N}", total);
			Console.WriteLine("Free Bytes: {0:N}", free);
			Console.WriteLine("Available Bytes: {0:N}", available);
		}

		Console.ReadLine();
	}
}