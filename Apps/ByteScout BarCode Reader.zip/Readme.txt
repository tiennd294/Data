ByteScout BarCode Reader
Freeware
Copyright (C) 2007-2017 ByteScout


1. HOW TO USE

Bytescout BarCode Reader reads barcodes from images (JPG, TIFF, PNG, GIF image files) and PDF files 

The software is based on Bytescout BarCode Reader SDK for software developers (see http://bytescout.com/bytescoutbarcodereadersdk.html for more information)

Reads linear barcodes: Code 39, Code 128, EAN-13, UPCE, UPCA, GS1, GS1 Databar, Codabar, Interleaved 2 of 5, Postnet and others!
Reads 2D barcodes: QR Code, Datamatrix, Aztec, PDF417, MICR, PDF 417, MicroPDF, Code 16K, Codablock F, MaxiCode


2. SYSTEM REQUIREMENTS

MS Windows XP/Vista/7/8/8.1 (including x64 versions)
 

3. INSTALLATION

To install the program, run setup program then follow the instructions of the installation program.


4. THE DISTRIBUTION STATUS OF THE PROGRAM

Bytescout BarCode Reader is freely distributable.


5. HOW TO CONTACT US

ByteScout
www.bytescout.com