
<script type='text/javascript'>

    

</script> 

<?php
	$this->load->view('site/access/template/slideheader');
foreach ($tblproduct as $rowp): 
?>
<div class="productsp">
<div class="container">
<div class="eleven columns" style="width:98%;">
			<article>
				<div class="blogDesc clearfix">

				<br/><br/><br/>
				<div style="width:100%;height:auto;" >
					<div class="blogLeft clearfix" style="width:50%;">
						
						<div id='wrapper'>
						
							<div id='body'>
								<div id="bigPic">
									<img src="<?php echo base_url().$rowp->Images; ?>" alt="" 	/>
									<?php 
										foreach ($tbnimage as $rowi): 
                                        	echo "<img src='".base_url().$rowi->Urllink."'alt=''/>";
                                        endforeach;
									?>
									
								</div>
								
								
								<ul id="thumbs">
								<li class='active' rel='1'><img src="<?php echo base_url().$rowp->Images; ?>" alt="" /></li>
									<?php 
									$i=1;
										foreach ($tbnimage as $rowi2): 
                                        	$i++;
                                        	if ($i>1) {
                                        		echo "<li rel='".$i."'><img src='".base_url().$rowi2->Urllink."' alt='' /></li>";
                                        	}
                                        	//else echo "<li class='active' rel='".$i."'><img src=".$rowi2->Urllink." alt='' /></li>";
                                        	
                                        endforeach;
									?>
								</ul>
							
							</div>
							
						</div>
					</div>


					<div class="blogRight" style="width:40%;margin-bottom: 10%;">
						<h5>
							<?php echo $rowp->Name; ?> 
						</h5>
						
							
						
						<?php 
							if ($rowp->Promotion>0) {
								echo "Giá bán :<strong><span style='color:#FF0000'><span style='font-size:26px'>".str_replace('.00', '', $rowp->Promotion)."</span>.đ</span></strong>";
								echo "  Giá hãng :<strong><span class='sale_offer' style='color:#000000'><span style='font-size:20px'><del>".str_replace('.00', '', $rowp->Price)."</del></span>.đ</span></strong>";
							}
							else {
								echo "Giá bán :<strong><span style='color:#FF0000'><span style='font-size:26px'>".str_replace('.00', '', $rowp->Price)."</span>.đ</span></strong>";
							}
						?>
						<br/><br/>
						Mã hàng :<?php echo $rowp->Code; ?>   |  Tình trạng : <?php if($rowp->Startus=='on') echo "Còn hàng";else echo "Hết hàng";; ?>   |  Bảo hành :<?php echo $rowp->Warranty; ?>
						<br/><?php echo $rowp->Discription; ?>
						<br/><a class="red_btn unlinka"  onclick="Set_cart('<?php echo $rowp->Idp; ?>','<?php echo $rowp->Name; ?>','<?php echo $rowp->Code; ?>','<?php if($rowp->Promotion>0) echo $rowp->Promotion;else echo $rowp->Price; ?>','<?php echo base_url().$rowp->Images; ?>')"  href="#">Mua ngay</a>
					</div>
				</div>
				
				</div><!--end blogDesc-->

			</article><!--end article-->


		</div>
</div>

<div class="container">
<div class="eleven columns" style="width:98%;">

			<article>
				<div class="blogDesc clearfix" style="">

					<div class="blogLeft clearfix" style="padding-top: 5%;margin-top: 5%;margin-bottom: 10%;">
						<h6><span><?php echo substr( trim($rowp->Createdate),  8, 2); ?></span><br><?php echo substr( $rowp->Createdate,  5, 2); ?>, <?php echo substr( $rowp->Createdate,  0, 4); ?></h6>
						<ul>
							<li>Người đăng: <?php echo $rowp->Createby; ?></li>
							<li>Lươt xem: <a href="#">113 Times</a></li>
						</ul>

					</div><!--end blog left-->

					<div class="blogRight item" style="padding-top: 5%;margin-top: 5%;margin-bottom: 10%;">
						<?php echo $rowp->Detail; ?>
					</div><!--end blogText-->
				</div><!--end blogDesc-->

			</article><!--end article-->

		</div>
</div>
<br/>
<br/>
<br/>
</div>


<?php
	endforeach;
	$this->load->view('site/defaults/cart');
?>	