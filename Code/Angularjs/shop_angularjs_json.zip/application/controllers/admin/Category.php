<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends MY_Controller
{
     public function __construct()
    {
        parent::__construct();
        $this->load->model('Category_Model');
    }

    public function Index()
    {
        $input = array();
        $tblcetagory=$this->Category_Model->get_list($input);
        $tblmenu=$this->Category_Model->loadmenu();
        $category=$this->loadcategory();
        $data = array(
            'urldata' => 'admin/Category/category',
            'tblcetagory' => $tblcetagory,
            'category' => $category,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

    public function Add()
    {

         $data = array(
            'Classify' => $this->input->post('Classify'),
            'Name' => $this->input->post('Name'),
            'Display' => $this->input->post('Display'),
            'Startus' => $this->input->post('Startus'),
            'Parentid' => $this->input->post('Parentid'),
            'Linkurl' => $this->input->post('Linkurl'),
            'Createby' =>  $this->session->userdata('Administrator'),
            'Createdate' => date("Y/m/d H:i:s")
        );
        $this->Category_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Name' => $this->input->post('Name'),
            'Display' => $this->input->post('Display'),
            'Startus' => $this->input->post('Startus'),
            'Linkurl' => $this->input->post('Linkurl'),
            'Modifyby' =>   $this->session->userdata('Administrator'),
            'Modifydate' => date("Y/m/d H:i:s")

        );
        

        if($this->input->post('Idc')){
        
            $Id = $this->input->post('Idc');
            if($this->Category_Model->update($Id,$data))
                echo "true";
            else echo "false";
        }
        
    }


   public function Delete()
   {
        
        if($this->input->post('Idc')){
            $Id  = $this->input->post('Idc');
            if($this->Category_Model->delete($Id))
                echo "true";
            else echo "false";
       
        }
    }

    public function testmenu($Id)
    {
        $input = array();
        $input['where'] = array('Parentid' => $Id);
        
        if($this->Category_Model->get_total($input)<=0)
        {
            return "__No";
        }
        else return "__Yes";
    }

    public function Recursive($Id)
    {
        $data='';
        $input = array();
        $input['where'] = array('Parentid' => $Id);
        $input['order'] = array('Display','asc');
        $tblcatagory=$this->Category_Model->get_list($input);
        foreach ($tblcatagory as $row):
            $data .= "<div class='widget-title items".$row->Idc."'>";
            $data .= "              <a href='.add".$row->Idc."' data-toggle='collapse'>";
            $data .= "              <span class='icon'><i class='icon-plus addc'></i></span>";
            $data .= "              </a>";
            $data .= "              <a href='.category".$row->Idc."' id='".$row->Idc."' data-toggle='collapse'>";
            if ($row->Startus=='on') {
                $data .= "              <span class='icon'><i class='itemstartusok".$row->Idc." icon-ok'></i></span>";
            }
            else
                $data .= "              <span class='icon'><i class='itemstartuslock".$row->Idc." icon-lock'></i></span>";
            $data .= "              <h5>".$row->Name."</h5>";
            $data .= "              </a>";
            $data .= "              <a href='.addnew".$row->Idc."' data-toggle='collapse'>";
            $data .= "              <span class='icon'><i class='icon-plus'></i></span>";
            $data .= "              </a>";
            $data .= "              <a href='.edit".$row->Idc."' data-toggle='collapse'>";
            $data .= "                    <span class='icon'><i class='icon-pencil'></i></span>";
            $data .= "              </a>";
            $data .= "              <a href='.delete".$row->Idc."' data-toggle='collapse'>";
            $data .= "                    <span class='icon'><i class='icon-trash'></i></span>";
            $data .= "              </a>";
            $data .= "         </div>";
            $data .= "         <div class='collapse items".$row->Idc." add".$row->Idc."'>";
            $data .= "              <div class='widget-content'>";
            $data .= "                    <h5>Thêm danh mục cùng hạng mục :</h5>";
            $data .= "                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>";
            $data .= "                    <label class='control-label'>Classify :</label>";
            $data .= "                          <input  name='aClassify".$row->Idc."' type='text' class='span5 aClassify".$row->Idc."' placeholder='Classify'  value='".$row->Classify."' readonly />";
            $data .= "                          <label class='control-label'>Parent id :</label>";
            $data .= "                          <input name='aParentid".$row->Idc."' type='text' class='span5 aParentid".$row->Idc."' placeholder='Parent id' value='".$row->Parentid."' readonly />";
            $data .= "                    </div>";
            $data .= "                          <label class='control-label'>Tên danh mục :</label>";
            $data .= "                          <input name='aName".$row->Idc."' type='text' class='span5 aName".$row->Idc."' placeholder='Tên danh mục' />";
            $data .= "                          <label class='control-label'>Link :</label>";
            $data .= "                          <input name='aLinkurl".$row->Idc."' type='text' class='span5 aLinkurl".$row->Idc."' placeholder='Link' />";
            $data .= "                          <label class='control-label'>Thứ tự :</label>";
            $data .= "                          <input name='aDisplay".$row->Idc."' type='text' class='span5 aDisplay".$row->Idc."' placeholder='Thứ tự' />";
            $data .= "                          <div class='control-group'>";
            $data .= "                              <label class='control-label'>Trạng thái</label>";
            $data .= "                              <div class='controls '>";
            $data .= "                                  <select name='aStartus".$row->Idc."' class='aStartus".$row->Idc." atextdata3cb'  id='aStartus".$row->Idc."'>";
            $data .= "                                      <option value='on'>Show</option>";
            $data .= "                                      <option value=''>Hide</option>";
            $data .= "                                  </select>";
            $data .= "                              </div>";
            $data .= "                          </div>";
            $data .= "                          <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='AddCategory(".$row->Idc.")'>Save</button>";
            $data .= "                          <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "                    </div>";
            $data .= "               </div>";
            $data .= "               <div class='collapse items".$row->Idc." addnew".$row->Idc."'>";
            $data .= "                    <div class='widget-content'>";
            $data .= "                    <h5>Thêm danh mục trong hạng mục :</h5>";
            $data .= "                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>";
            $data .= "                          <label class='control-label'>Classify :</label>";
            $data .= "                          <input  name='a2Classify".$row->Idc."' type='text' class='span5 a2Classify".$row->Idc."' placeholder='Classify'  value='".$row->Classify."'  readonly/>";
            $data .= "                          <label class='control-label'>Parent id :</label>";
            $data .= "                          <input  name='a2Parentid".$row->Idc."' type='text' class='span5 a2Parentid".$row->Idc."' placeholder='Mã danh mục'  value='".$row->Idc."' readonly />";
            $data .= "                    </div>";
            $data .= "                          <label class='control-label'>Tên danh mục :</label>";
            $data .= "                          <input  name='a2Name".$row->Idc."' type='text' class='span5 a2Name".$row->Idc."' placeholder='Tên danh mục' />";
            $data .= "                          <label class='control-label'>Link :</label>";
            $data .= "                          <input  name='a2Linkurl".$row->Idc."' type='text' class='span5 a2Linkurl".$row->Idc."' placeholder='Link' />";
            $data .= "                          <label class='control-label'>Thứ tự :</label>";
            $data .= "                          <input  name='addtextthutu".$row->Idc."' type='text' class='span5 addtextthutu".$row->Idc."' placeholder='Thứ tự' />";
            $data .= "                          <div class='control-group'>";
            $data .= "                              <label class='control-label'>Trạng thái</label>";
            $data .= "                              <div class='controls '>";
            $data .= "                                  <select  id='a2Startus".$row->Idc."' name='a2Startus".$row->Idc."' class='a2Startus".$row->Idc." atextdata3cb' >";
            $data .= "                                      <option value='on'>Show</option>";
            $data .= "                                      <option value=''>Hide</option>";
            $data .= "                                  </select>";
            $data .= "                              </div>";
            $data .= "                          </div>";
            $data .= "                    <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='Add2Category(".$row->Idc.")'>Save</button>";
            $data .= "                    <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "               </div>";
            $data .= "          </div>";
            $data .= "          <div class='collapse items".$row->Idc." edit".$row->Idc."'>";
            $data .= "               <div class='widget-content'>";
            $data .= "               <h5>Sửa danh mục :</h5>";
            $data .= "                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>";
            $data .= "                          <label class='control-label'>Mã danh mục :</label>";
            $data .= "                          <input  name='eIdc".$row->Idc."' type='text' class='span5 eIdc".$row->Idc."' placeholder='Mã danh mục'  value='".$row->Idc."' readonly/>";
            $data .= "                    </div>";
            $data .= "                          <label class='control-label'>Tên danh mục :</label>";
            $data .= "                          <input  name='eName".$row->Idc."' type='text' class='span5 eName".$row->Idc."' placeholder='Tên danh mục'  value='".$row->Name."' />";
            $data .= "                          <label class='control-label'>Link :</label>";
            $data .= "                          <input  name='eLinkurl".$row->Idc."' type='text' class='span5 eLinkurl".$row->Idc."' placeholder='Link'  value='".$row->Linkurl."' />";
            $data .= "                          <label class='control-label'>Thứ tự :</label>";
            $data .= "                          <input  name='eDisplay".$row->Idc."' type='text' class='span5 eDisplay".$row->Idc."' placeholder='Thứ tự'  value='".$row->Display."' />";
            $data .= "                    <div class='control-group'>";
            $data .= "                          <label class='control-label'>Trạng thái</label>";
            $data .= "                          <div class='controls '>";
            $data .= "                              <select  id='eStartus".$row->Idc."' name='eStartus".$row->Idc."' class='eStartus".$row->Idc." atextdata3cb'  >";
            $data .= "                                  <option value='on'>Show</option>";
            $data .= "                                  <option value=''>Hide</option>";
            $data .= "                              </select>";
            $data .= "                          </div>";
            $data .= "                    </div>";
            $data .= "                    <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='EditCategory(".$row->Idc.")'>Save</button>";
            $data .= "                    <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "                    <i class='icon-ok successfuly".$row->Idc."' style='display: none;'></i>";
            $data .= "                </div>";
            $data .= "           </div>";
            $data .= "           <div class='collapse items".$row->Idc." delete".$row->Idc."'>";
            $data .= "              <div class='widget-content'>";
            $data .= "                    <h5>Xóa danh mục :</h5>";
            $data .= "                    <label class='control-label'>Bạn có chắc chắn muốn xóa không?</label>";
            $data .= "                          <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>   ";
            $data .= "                          <input  name='dIdc".$row->Idc."' type='text' class='span5 dIdc".$row->Idc."' placeholder='id'  value='".$row->Idc."' readonly/>";
            $data .= "                          </div>";
            $data .= "                    <label class='control-label'></label>";
            $data .= "                    <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='DeleteCategory(".$row->Idc.")'>Delete</button>";
            $data .= "                    <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "                    </div>";
            $data .= "                    </div>";
            if ($this->testmenu($row->Idc)=='__Yes') {
                $data .= "<div class='collapse items".$row->Idc." category".$row->Idc."'>";
                $data .= "<div class='widget-content'>";
                $data .= "     <div class='widget-box collapsible'>";
                $data .= $this->Recursive($row->Idc);
                $data .= "     </div>";
                $data .= "</div>";
                $data .= "</div>";

            }
        endforeach;
        return $data;
    }

    public function loadcategory()
    {
        $data="";
        $data .= "<div class='container-fluid' >";
        $data .= "     <div class='row-fluid'>";
        $data .= "          <div class='span12'>";
        for ($i=1; $i <= 3 ; $i++) { 
            if ($i==1) {
                $data .= "<div class='widget-box collapsible'>";
                $data .= "    <div class='widget-title'>";
                $data .= "        <a href='.Products' id='1' data-toggle='collapse'>";
                $data .= "        <span class='icon'><i class='icon-star'></i></span>";
                $data .= "            <h5>Sản phẩm</h5>";
                $data .= "          </a></div>";
                $data .= "     <div class='collapse Products'>";
                $data .= "    <div class='widget-content'>";
                $data .= "        <div class='widget-box collapsible'>";
            }

            if ($i==2) {
                $data .= "<div class='widget-box collapsible'>";
                $data .= "    <div class='widget-title'>";
                $data .= "        <a href='.News' id='1' data-toggle='collapse'>";
                $data .= "        <span class='icon'><i class='icon-star'></i></span>";
                $data .= "            <h5>Tin tức</h5>";
                $data .= "          </a></div>";
                $data .= "     <div class='collapse News'>";
                $data .= "    <div class='widget-content'>";
                $data .= "        <div class='widget-box collapsible'>";
            }

            if ($i==3) {
                $data .= "<div class='widget-box collapsible'>";
                $data .= "    <div class='widget-title'>";
                $data .= "        <a href='.footer' id='1' data-toggle='collapse'>";
                $data .= "        <span class='icon'><i class='icon-star'></i></span>";
                $data .= "            <h5>Footer</h5>";
                $data .= "          </a></div>";
                $data .= "     <div class='collapse footer'>";
                $data .= "    <div class='widget-content'>";
                $data .= "        <div class='widget-box collapsible'>";
            }

            $input = array();
            $input['where'] = array(
                'Parentid' => 0,
                'Classify' => $i
            );
            $input['order'] = array('Display','asc');
            $tblcatagory=$this->Category_Model->get_list($input);

            foreach ($tblcatagory as $row):
            $data .= "<div class='widget-title items".$row->Idc."'>";
            $data .= "              <a href='.add".$row->Idc."' data-toggle='collapse'>";
            $data .= "              <span class='icon'><i class='icon-plus addc'></i></span>";
            $data .= "              </a>";
            $data .= "              <a href='.category".$row->Idc."' id='".$row->Idc."' data-toggle='collapse'>";
            if ($row->Startus=='on') {
                $data .= "              <span class='icon'><i class='itemstartusok".$row->Idc." icon-ok'></i></span>";
            }
            else
                $data .= "              <span class='icon'><i class='itemstartuslock".$row->Idc." icon-lock'></i></span>";
            $data .= "              <h5>".$row->Name."</h5>";
            $data .= "              </a>";
            $data .= "              <a href='.addnew".$row->Idc."' data-toggle='collapse'>";
            $data .= "              <span class='icon'><i class='icon-plus'></i></span>";
            $data .= "              </a>";
            $data .= "              <a href='.edit".$row->Idc."' data-toggle='collapse'>";
            $data .= "                    <span class='icon'><i class='icon-pencil'></i></span>";
            $data .= "              </a>";
            $data .= "              <a href='.delete".$row->Idc."' data-toggle='collapse'>";
            $data .= "                    <span class='icon'><i class='icon-trash'></i></span>";
            $data .= "              </a>";
            $data .= "         </div>";
            $data .= "         <div class='collapse items".$row->Idc." add".$row->Idc."'>";
            $data .= "              <div class='widget-content'>";
            $data .= "                    <h5>Thêm danh mục cùng hạng mục :</h5>";
            $data .= "                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>";
            $data .= "                    <label class='control-label'>Classify :</label>";
            $data .= "                          <input  name='aClassify".$row->Idc."' type='text' class='span5 aClassify".$row->Idc."' placeholder='Classify'  value='".$row->Classify."' readonly />";
            $data .= "                          <label class='control-label'>Parent id :</label>";
            $data .= "                          <input name='aParentid".$row->Idc."' type='text' class='span5 aParentid".$row->Idc."' placeholder='Parent id' value='".$row->Parentid."' readonly />";
            $data .= "                    </div>";
            $data .= "                          <label class='control-label'>Tên danh mục :</label>";
            $data .= "                          <input name='aName".$row->Idc."' type='text' class='span5 aName".$row->Idc."' placeholder='Tên danh mục' />";
            $data .= "                          <label class='control-label'>Link :</label>";
            $data .= "                          <input name='aLinkurl".$row->Idc."' type='text' class='span5 aLinkurl".$row->Idc."' placeholder='Link' />";
            $data .= "                          <label class='control-label'>Thứ tự :</label>";
            $data .= "                          <input name='aDisplay".$row->Idc."' type='text' class='span5 aDisplay".$row->Idc."' placeholder='Thứ tự' />";
            $data .= "                          <div class='control-group'>";
            $data .= "                              <label class='control-label'>Trạng thái</label>";
            $data .= "                              <div class='controls '>";
            $data .= "                                  <select name='aStartus".$row->Idc."' class='aStartus".$row->Idc." atextdata3cb'  id='aStartus".$row->Idc."'>";
            $data .= "                                      <option value='on'>Show</option>";
            $data .= "                                      <option value=''>Hide</option>";
            $data .= "                                  </select>";
            $data .= "                              </div>";
            $data .= "                          </div>";
            $data .= "                          <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='AddCategory(".$row->Idc.")'>Save</button>";
            $data .= "                          <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "                    </div>";
            $data .= "               </div>";
            $data .= "               <div class='collapse items".$row->Idc." addnew".$row->Idc."'>";
            $data .= "                    <div class='widget-content'>";
            $data .= "                    <h5>Thêm danh mục trong hạng mục :</h5>";
            $data .= "                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>";
            $data .= "                          <label class='control-label'>Classify :</label>";
            $data .= "                          <input  name='a2Classify".$row->Idc."' type='text' class='span5 a2Classify".$row->Idc."' placeholder='Classify'  value='".$row->Classify."'  readonly/>";
            $data .= "                          <label class='control-label'>Parent id :</label>";
            $data .= "                          <input  name='a2Parentid".$row->Idc."' type='text' class='span5 a2Parentid".$row->Idc."' placeholder='Mã danh mục'  value='".$row->Idc."' readonly />";
            $data .= "                    </div>";
            $data .= "                          <label class='control-label'>Tên danh mục :</label>";
            $data .= "                          <input  name='a2Name".$row->Idc."' type='text' class='span5 a2Name".$row->Idc."' placeholder='Tên danh mục' />";
            $data .= "                          <label class='control-label'>Link :</label>";
            $data .= "                          <input  name='a2Linkurl".$row->Idc."' type='text' class='span5 a2Linkurl".$row->Idc."' placeholder='Link' />";
            $data .= "                          <label class='control-label'>Thứ tự :</label>";
            $data .= "                          <input  name='addtextthutu".$row->Idc."' type='text' class='span5 addtextthutu".$row->Idc."' placeholder='Thứ tự' />";
            $data .= "                          <div class='control-group'>";
            $data .= "                              <label class='control-label'>Trạng thái</label>";
            $data .= "                              <div class='controls '>";
            $data .= "                                  <select  id='a2Startus".$row->Idc."' name='a2Startus".$row->Idc."' class='a2Startus".$row->Idc." atextdata3cb' >";
            $data .= "                                      <option value='on'>Show</option>";
            $data .= "                                      <option value=''>Hide</option>";
            $data .= "                                  </select>";
            $data .= "                              </div>";
            $data .= "                          </div>";
            $data .= "                    <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='Add2Category(".$row->Idc.")'>Save</button>";
            $data .= "                    <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "               </div>";
            $data .= "          </div>";
            $data .= "          <div class='collapse items".$row->Idc." edit".$row->Idc."'>";
            $data .= "               <div class='widget-content'>";
            $data .= "               <h5>Sửa danh mục :</h5>";
            $data .= "                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>";
            $data .= "                          <label class='control-label'>Mã danh mục :</label>";
            $data .= "                          <input  name='eIdc".$row->Idc."' type='text' class='span5 eIdc".$row->Idc."' placeholder='Mã danh mục'  value='".$row->Idc."' readonly/>";
            $data .= "                    </div>";
            $data .= "                          <label class='control-label'>Tên danh mục :</label>";
            $data .= "                          <input  name='eName".$row->Idc."' type='text' class='span5 eName".$row->Idc."' placeholder='Tên danh mục'  value='".$row->Name."' />";
            $data .= "                          <label class='control-label'>Link :</label>";
            $data .= "                          <input  name='eLinkurl".$row->Idc."' type='text' class='span5 eLinkurl".$row->Idc."' placeholder='Link'  value='".$row->Linkurl."' />";
            $data .= "                          <label class='control-label'>Thứ tự :</label>";
            $data .= "                          <input  name='eDisplay".$row->Idc."' type='text' class='span5 eDisplay".$row->Idc."' placeholder='Thứ tự'  value='".$row->Display."' />";
            $data .= "                    <div class='control-group'>";
            $data .= "                          <label class='control-label'>Trạng thái</label>";
            $data .= "                          <div class='controls '>";
            $data .= "                              <select  id='eStartus".$row->Idc."' name='eStartus".$row->Idc."' class='eStartus".$row->Idc." atextdata3cb'  >";
            $data .= "                                  <option value='on'>Show</option>";
            $data .= "                                  <option value=''>Hide</option>";
            $data .= "                              </select>";
            $data .= "                          </div>";
            $data .= "                    </div>";
            $data .= "                    <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='EditCategory(".$row->Idc.")'>Save</button>";
            $data .= "                    <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "                    <i class='icon-ok successfuly".$row->Idc."' style='display: none;'></i>";
            $data .= "                </div>";
            $data .= "           </div>";
            $data .= "           <div class='collapse items".$row->Idc." delete".$row->Idc."'>";
            $data .= "              <div class='widget-content'>";
            $data .= "                    <h5>Xóa danh mục :</h5>";
            $data .= "                    <label class='control-label'>Bạn có chắc chắn muốn xóa không?</label>";
            $data .= "                          <div style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>   ";
            $data .= "                          <input  name='dIdc".$row->Idc."' type='text' class='span5 dIdc".$row->Idc."' placeholder='id'  value='".$row->Idc."' readonly/>";
            $data .= "                          </div>";
            $data .= "                    <label class='control-label'></label>";
            $data .= "                    <button id='btnadd' class='btn btn-success btnadd".$row->Idc."'   onclick='DeleteCategory(".$row->Idc.")'>Delete</button>";
            $data .= "                    <i class='reload reload".$row->Idc."' style='display: none;'></i>";
            $data .= "                    </div>";
            $data .= "                    </div>";
            if ($this->testmenu($row->Idc)=='__Yes') {
                $data .= "<div class='collapse items".$row->Idc." category".$row->Idc."'>";
                $data .= "<div class='widget-content'>";
                $data .= "     <div class='widget-box collapsible'>";
                $data .= $this->Recursive($row->Idc);
                $data .= "     </div>";
                $data .= "</div>";
                $data .= "</div>";

            }
            endforeach;
            
                $data .= "</div></div></div></div>";
            
        }
        $data .="</div></div></div></div>";
        return $data;
    }


}