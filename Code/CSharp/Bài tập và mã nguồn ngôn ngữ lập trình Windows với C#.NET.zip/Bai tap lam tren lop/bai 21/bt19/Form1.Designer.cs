namespace bt19
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNhap = new System.Windows.Forms.TextBox();
            this.btnNhap = new System.Windows.Forms.Button();
            this.cboSo = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.aa = new System.Windows.Forms.GroupBox();
            this.lstUS = new System.Windows.Forms.ListBox();
            this.btnUoc = new System.Windows.Forms.Button();
            this.btnUocchan = new System.Windows.Forms.Button();
            this.btnSNT = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.aa.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNhap
            // 
            this.txtNhap.Location = new System.Drawing.Point(6, 19);
            this.txtNhap.Name = "txtNhap";
            this.txtNhap.Size = new System.Drawing.Size(113, 20);
            this.txtNhap.TabIndex = 0;
            this.txtNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnNhap
            // 
            this.btnNhap.Location = new System.Drawing.Point(134, 19);
            this.btnNhap.Name = "btnNhap";
            this.btnNhap.Size = new System.Drawing.Size(75, 23);
            this.btnNhap.TabIndex = 1;
            this.btnNhap.Text = "Cap nhat";
            this.btnNhap.UseVisualStyleBackColor = true;
            this.btnNhap.Click += new System.EventHandler(this.btnNhap_Click);
            // 
            // cboSo
            // 
            this.cboSo.FormattingEnabled = true;
            this.cboSo.Location = new System.Drawing.Point(6, 54);
            this.cboSo.Name = "cboSo";
            this.cboSo.Size = new System.Drawing.Size(203, 21);
            this.cboSo.TabIndex = 2;
            this.cboSo.SelectedIndexChanged += new System.EventHandler(this.cboSo_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtNhap);
            this.groupBox1.Controls.Add(this.cboSo);
            this.groupBox1.Controls.Add(this.btnNhap);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(222, 91);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Du lieu nhap";
            // 
            // aa
            // 
            this.aa.Controls.Add(this.lstUS);
            this.aa.Controls.Add(this.btnSNT);
            this.aa.Controls.Add(this.btnUocchan);
            this.aa.Controls.Add(this.btnUoc);
            this.aa.Location = new System.Drawing.Point(247, 8);
            this.aa.Name = "aa";
            this.aa.Size = new System.Drawing.Size(200, 249);
            this.aa.TabIndex = 3;
            this.aa.TabStop = false;
            this.aa.Text = "Chi tiet";
            // 
            // lstUS
            // 
            this.lstUS.FormattingEnabled = true;
            this.lstUS.Location = new System.Drawing.Point(6, 15);
            this.lstUS.Name = "lstUS";
            this.lstUS.Size = new System.Drawing.Size(188, 134);
            this.lstUS.TabIndex = 0;
            // 
            // btnUoc
            // 
            this.btnUoc.Location = new System.Drawing.Point(37, 155);
            this.btnUoc.Name = "btnUoc";
            this.btnUoc.Size = new System.Drawing.Size(130, 23);
            this.btnUoc.TabIndex = 1;
            this.btnUoc.Text = "Tong cac uoc";
            this.btnUoc.UseVisualStyleBackColor = true;
            this.btnUoc.Click += new System.EventHandler(this.btnUoc_Click);
            // 
            // btnUocchan
            // 
            this.btnUocchan.Location = new System.Drawing.Point(37, 184);
            this.btnUocchan.Name = "btnUocchan";
            this.btnUocchan.Size = new System.Drawing.Size(130, 23);
            this.btnUocchan.TabIndex = 1;
            this.btnUocchan.Text = "So luong Uoc So Chan";
            this.btnUocchan.UseVisualStyleBackColor = true;
            // 
            // btnSNT
            // 
            this.btnSNT.Location = new System.Drawing.Point(37, 213);
            this.btnSNT.Name = "btnSNT";
            this.btnSNT.Size = new System.Drawing.Size(130, 23);
            this.btnSNT.TabIndex = 1;
            this.btnSNT.Text = "Kiem tra So nguyen to";
            this.btnSNT.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 273);
            this.Controls.Add(this.aa);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.aa.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtNhap;
        private System.Windows.Forms.Button btnNhap;
        private System.Windows.Forms.ComboBox cboSo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox aa;
        private System.Windows.Forms.ListBox lstUS;
        private System.Windows.Forms.Button btnSNT;
        private System.Windows.Forms.Button btnUocchan;
        private System.Windows.Forms.Button btnUoc;

    }
}

