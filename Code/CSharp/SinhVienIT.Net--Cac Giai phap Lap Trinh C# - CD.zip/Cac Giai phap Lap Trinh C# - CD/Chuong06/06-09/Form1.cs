using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

public class AutoCompleteComboBoxTest : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AutoCompleteComboBoxTest()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		// 
		// AutoCompleteComboBoxTest
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(272, 106);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "AutoCompleteComboBoxTest";
		this.Text = "AutoComplete ComboBox Test";
		this.Load += new System.EventHandler(this.AutoCompleteComboBox_Load);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new AutoCompleteComboBoxTest());
	}

	private void AutoCompleteComboBox_Load(object sender, System.EventArgs e)
	{
		AutoCompleteComboBox combo = new AutoCompleteComboBox();
		combo.Location = new Point(10,10);
		this.Controls.Add(combo);

		FileStream fs = new FileStream("words.txt", FileMode.Open);
		using (StreamReader r = new StreamReader(fs))
		{
			while (r.Peek() > -1)
			{
				string word = r.ReadLine();
				combo.Items.Add(word);
			}
		}
	}
}

public class AutoCompleteComboBox : ComboBox
{
	private bool controlKey = false;

	protected override void OnKeyPress(System.Windows.Forms.KeyPressEventArgs e)
	{
		base.OnKeyPress(e);
		
		if (e.KeyChar == (int)Keys.Escape)
		{
			this.SelectedIndex = -1;
			this.Text = "";
			controlKey = true;
		}
		else if (Char.IsControl(e.KeyChar))
		{
			controlKey = true;
		}
		else
		{
			controlKey = false;
		}
	}

	protected override void OnTextChanged(System.EventArgs e)
	{
		base.OnTextChanged(e);

		if (this.Text != "" && !controlKey)
		{
			string matchText = this.Text;
			int match = this.FindString(matchText);
			
			if (match != -1)
			{
				this.SelectedIndex = match;
				
				this.SelectionStart = matchText.Length;
				this.SelectionLength = this.Text.Length - this.SelectionStart;
			}
		}
	}
}