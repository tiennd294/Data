using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using SharedComponent;

public class TcpServerTest
{
	private static void Main()
	{
		TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 
			8000); 
        
		Console.WriteLine("Server: About to initialize port.");
		listener.Start();
        Console.WriteLine("Server: Listening for a connection...");
        
		int clientNum = 0;
		while (true)
		{
			try 
			{
				TcpClient client = listener.AcceptTcpClient();
				Console.WriteLine("Server: Connection accepted.");

				clientNum++;
				ClientHandler handler = new ClientHandler(client, "Client " +
					clientNum.ToString());

				Thread handlerThread = 
					new Thread(new ThreadStart(handler.Start));
				handlerThread.IsBackground = true;
				handlerThread.Start();

			}
			catch (Exception err) 
			{
				Console.WriteLine(err.ToString());
			}
		}
	}
}

public class ClientHandler 
{

	private TcpClient client;
	private string ID;

	public ClientHandler(TcpClient client, string ID) 
	{

		this.client = client;
		this.ID = ID;
	}

	public void Start() 
	{

		NetworkStream stream = client.GetStream();

		BinaryWriter w = new BinaryWriter(stream);

		BinaryReader r = new BinaryReader(stream);

		if (r.ReadString() == ClientMessages.RequestConnect) 
		{

			w.Write(ServerMessages.AcknowledgeOK);
			Console.WriteLine(ID + ": Connection completed.");
			while (r.ReadString() != ClientMessages.Disconnect) {}

			Console.WriteLine(ID + ": Disconnect request received.");
			w.Write(ServerMessages.Disconnect);
		}
		else 
		{
			Console.WriteLine(ID + ": Could not complete connection.");
		}

		client.Close();
		Console.WriteLine(ID + ": Client connection closed.");

		Console.ReadLine();
	}
}
