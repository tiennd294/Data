using System;
using System.Runtime.Remoting;
using System.Reflection;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace Server
{
	public class Server
	{
		private static void Main()
		{
			RemotingConfiguration.Configure("Server.exe.config");

			TcpChannel channel = (TcpChannel)ChannelServices.RegisteredChannels[0];

			Assembly assembly = Assembly.LoadFrom("RemoteObject.dll");

			foreach (Type type in assembly.GetTypes())
			{
				if (type.IsSubclassOf(typeof(MarshalByRefObject)))
				{
					Console.WriteLine("Registering " + type.Name);
					RemotingConfiguration.RegisterWellKnownServiceType( 
						type, type.Name, WellKnownObjectMode.SingleCall);

					string[] urls = channel.GetUrlsForUri(type.Name);
					Console.WriteLine(urls[0]);
				}
			}			

			Console.WriteLine("Press a key to shut down the server.");
			Console.ReadLine();
		}
	}
}
