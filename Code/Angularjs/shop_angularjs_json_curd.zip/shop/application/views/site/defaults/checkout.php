
<?php
if (isset($carts)) {

?>
<script type='text/javascript'>
 	function Add_cart()
    {
      //alert($(".Email").val());
      var loading = $('.loading');
      var frmcart = $('.frmcart');
      var successfuly = $('.successfuly');  
      var delete_item = $('.delete_item');  
         
      frmcart.hide(500);
      loading.fadeIn(500);
        var data={
            Email:$(".Email").val(),
            Name:$(".Name").val(),
            Phone:$(".Phone").val(),
            Address:$(".Address").val(),
            Discription:$(".Discription").val()
        };

               
                    $.ajax({
                       type: 'post',
                       url: '<?php echo base_url();?>defaults/AddCart',
                       data: data,
                       dataType:'text',
                       success: function (response) {
                       	
                        $('.countitems').text(0);
                        delete_item.remove();
                        loading.hide(500);
                		successfuly.fadeIn(500);
                       }
                     });
                    
    }
   

</script> 



<div class="container">
		<div class="sixteen columns">
			
			<div id="pageName">
				<div class="name_tag">
					<p>
						Tiến hành đặt hàng
					</p>
					<div class="shapLeft"></div>
					<div class="shapRight"></div>
				</div>
			</div><!--end pageName-->

		</div>
	</div><!-- container -->



	<!-- strat the main content area -->
	
	<div class="container">
		<div class="sixteen columns">

			<div class="box_head">
				<h3>Đặt hàng</h3>
			</div><!--end box_head -->



			<div id="successfuly" class="sixteen columns successfuly" style="width:98%;display: none;">
				<div id="tagLine" class="clearfix">
					<div class="twelve columns">
						<h5>
							Đặt hàng thành công!<br>
							<small>Chúng tôi sẽ giao hàng cho bạn vào thời gian sớm nhất! </small>
						</h5>
					</div>
					<div class="three columns">
						<a class="red_btn" href="<?php  echo base_url();?>">Cửa hàng</a>
					</div>
				
				</div><!--end tagLine-->
			</div><!--end sixteen-->

			<div id="loading" class="sixteen columns loading" style="width:98%;display: none;">
				<div id="tagLine" class="clearfix">
					<div class="twelve columns">
						<br>
						<i class='reload2'></i> Vui lòng chờ trong giây lát....
						<br><br>
					</div>
					<div class="three columns">
						<br><br>
					</div>
				
				</div><!--end tagLine-->
			</div>

			<div id="frmcart" class="frmcart">
			<div class="checkout_outer">
				<h2>Bước 1 : <span>Đăng nhập</span></h2>
				<div class="checkout_content checkout_option clearfix" style="display:block">
					<div class="not_register">
						<h6>Đặt hàng mà không cần đăng ký</h6>
						<p>
						</p>
						<a class="gray_btn" href="#">Sang bước 2</a>
					</div>
					<form mehod="post" action="">
						<h6>Nếu Bạn đã có tài khoản , xin vui lòng Đăng nhập</h6>
						<label>
							<strong>E-Mail <em>*</em></strong>
							<input type="text" name="email" value="" placeholder="example@example.com">
						</label>
						<label>
							<strong>Mật khẩu <em>*</em></strong>
							<input type="text" name="password" value="" placeholder="**********">
						</label>
						<div class="submit">
							<input class="red_btn" type="submit" name="submit" value="Đăng nhập">
						</div>
					</form>
				</div><!--end checkout_content-->
			</div><!--end checkout_outer-->

			<form name="form1"  method="post" action="">
			<div class="checkout_outer">
				<h2>Bước 2 : <span>Thông tin về bạn</span></h2>
				<div class="checkout_content billing_account clearfix">
					
					<table>
						<tr>
							<td>
								<strong>Email (*) <em>*</em></strong>
							</td>
							<td class="input">
								<input type="text" name="Email" class="Email" value="" placeholder="Email">
							</td>
						</tr>
						<tr>
							<td>
								<strong>Họ tên (*) <em>*</em></strong>
							</td>
							<td class="input">
								<input type="text" name="Name" class="Name" value="" placeholder="Họ tên">
							</td>
						</tr>
						<tr>
							<td>
								<strong>Điện thoại di động (*) <em>*</em></strong>
							</td>
							<td class="input">
								<input type="text" name="Phone" class="Phone" value="" placeholder="Điện thoại di động">
							</td>
						</tr>
						<tr>
							<td>
								<strong>Địa chỉ (*) <em>*</em></strong>
							</td>
							<td class="input">
								<input type="text" name="Address" class="Address" value="" placeholder="Địa chỉ">
							</td>
						</tr>
						<tr>
							<td>
								<strong>Ghi chú</strong>
							</td>
							<td class="input">
								<textarea  name="Discription" class="Discription" value="" style="width: 310px; height: 160px;" placeholder="Vui lòng cho chúng tôi biết thời gian nhận hàng trong ngày hoặc ghi chú thêm ....."></textarea>
							</td>
						</tr>

						<tr>
							<td></td>
							<td>
							<a class="red_btn" href="#">Bước 3</a>
						</tr>
					</table>
					
				</div><!--end checkout_content-->
			</div><!--end checkout_outer-->

			<div class="checkout_outer">
				<h2>Bước 3 : <span>Đặt hàng</span></h2>
				<div class="checkout_content clearfix">

					<div class="" style="padding-left:20%;padding-right:5%;padding-top:10%;padding-bottom:15%;">
						<h6>THANH TOÁN TIỀN MẶT</h6>
						<p>- Trả tiền mặt chỉ áp dụng đối với những khu vực chúng tôi hỗ trợ giao nhận miễn phí (tham khảo thêm chính sách giao nhận) hoặc trả tiền mua hàng trực tiếp tại các Siêu thị thuộc hệ thống Mediamart.
						<br/>
							- Với phương thức thanh toán trực tiếp quý khách có thể đặt hàng trên Website hoặc đặt hàng qua điện thoại. Nhân viên chúng tôi sẽ tiến hành xuất hàng cho quý khách và xác nhận ngày giờ giao hàng với quý khách sau khi xuất hàng.
							<br/>
							- Quý khách có trách nhiệm thanh toán đầy đủ toàn bộ giá trị đơn hàng cho Nhân viên giao nhận hoặc Nhân viên bán hàng và chăm sóc khách hàng của chúng tôi ngay khi hoàn tất kiểm tra hàng hóa và nhận hóa đơn thanh toán. Quý khách thanh toán đúng số tiền trên hóa đơn đã ghi, nếu có bất cứ thắc mắc nào quý khách gọi lại cho chúng tôi để được thông tin cụ thể hơn.
				<br/>

						</p>
						<h6>Thanh toán trực tiếp bằng tiền mặt hoặc thẻ (Thẻ Visa, Thẻ tín dụng...):</h6>
						<p>
							- Sau khi mua hàng để thực hiện thanh toán, nhân viên thu ngân của chúng tôi sẽ hướng dẫn quí khách và hoàn tất các thủ tục tại quầy thu ngân.
							<br/>
							Chúng tôi sẽ không chịu trách nhiệm khi quý khách dùng thẻ của người khác để thanh toán. Ngay sau khi kiểm tra và nhận được báo "Có" từ Ngân hàng, chúng tôi sẽ tiến hành xuất hàng và giao hàng cho quý khách trong thời gian sớm nhất.

						</p><br/><br/>
						<a class="red_btn unlinka" id="add_cart" href="#"  onclick="Add_cart();" >Đặt hàng</a>
					</div>
					



				</div><!--end checkout_content-->
			</div><!--end checkout_outer-->
			</form>
			</div>
		</div><!--end sixteen-->
	</div><!--end container-->
	<!-- end the main content area -->
	<?php
}
else{
	?>
		

		<div style="padding-left:5%;padding-right:5%;padding-top:20%;padding-bottom:20%;">
			<p style="text-align: center;"><span style="color:#ff0066"><span style="font-size:172px">404</span></span></p>

			<p style="text-align: center;"><span style="color:#ff0066"><span style="font-size:72px">page not found!</span></span></p>
		</div>


	<?php
}
?>
