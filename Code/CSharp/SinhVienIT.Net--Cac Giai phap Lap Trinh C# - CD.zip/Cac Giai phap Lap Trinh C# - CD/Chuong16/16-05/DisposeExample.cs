using System;

public class DisposeExample : IDisposable {

    bool isDisposed = false;

    private IntPtr resourceHandle;

	public DisposeExample() {

        // resourceHandle = ...
	}

    ~DisposeExample() {

        Dispose(false);        
    }

    public void Dispose() {

        Dispose(true);

        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing) {

        if (!isDisposed) {

            if (disposing) {

                // ...
            }
        }

        isDisposed = true;
    }

    public void SomeMethod() {

        if (isDisposed) {

            throw new ObjectDisposedException("DisposeExample");
        }

        // ...
    }

    public static void Main() {

        using (DisposeExample d = new DisposeExample()) {

            // ...
        }
    }
}
