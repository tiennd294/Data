using System;
using System.Windows.Forms;
using System.IO;


public class TagPropertyExample : System.Windows.Forms.Form
{
	private System.Windows.Forms.ListView listView;
	private System.Windows.Forms.ImageList imageList;
	private System.ComponentModel.IContainer components;

	public TagPropertyExample()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TagPropertyExample));
		this.listView = new System.Windows.Forms.ListView();
		this.imageList = new System.Windows.Forms.ImageList(this.components);
		this.SuspendLayout();
		// 
		// listView
		// 
		this.listView.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.listView.LargeImageList = this.imageList;
		this.listView.Location = new System.Drawing.Point(4, 4);
		this.listView.MultiSelect = false;
		this.listView.Name = "listView";
		this.listView.Size = new System.Drawing.Size(280, 252);
		this.listView.TabIndex = 0;
		this.listView.ItemActivate += new System.EventHandler(this.listView_ItemActivate);
		// 
		// imageList
		// 
		this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
		this.imageList.ImageSize = new System.Drawing.Size(16, 16);
		this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
		this.imageList.TransparentColor = System.Drawing.Color.Transparent;
		// 
		// TagPropertyExample
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.listView});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "TagPropertyExample";
		this.Text = "Tag Property Example";
		this.Load += new System.EventHandler(this.TagPropertyExample_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new TagPropertyExample());
	}

	private void TagPropertyExample_Load(object sender, System.EventArgs e)
	{
		DirectoryInfo directory = new DirectoryInfo("C:\\");
		FileInfo[] files = directory.GetFiles();

		foreach (FileInfo file in files)
		{
			ListViewItem item = listView.Items.Add(file.Name);
			item.ImageIndex = 0;
			item.Tag = file;
		}
	}

	private void listView_ItemActivate(object sender, System.EventArgs e)
	{
		ListViewItem item = ((ListView)sender).SelectedItems[0];
		FileInfo file = (FileInfo)item.Tag;
		string info = file.FullName + " is " + file.Length + " bytes.";

		MessageBox.Show(info, "File Information");
	}
}