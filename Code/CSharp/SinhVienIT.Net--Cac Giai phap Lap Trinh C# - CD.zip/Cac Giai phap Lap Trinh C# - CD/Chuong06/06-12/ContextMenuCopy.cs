using System;
using System.Drawing;
using System.Windows.Forms;

public class ContextMenuCopy : System.Windows.Forms.Form
{
	internal System.Windows.Forms.MainMenu MainMenu1;
	internal System.Windows.Forms.MenuItem mnuFile;
	internal System.Windows.Forms.MenuItem MenuItem5;
	internal System.Windows.Forms.MenuItem MenuItem6;
	internal System.Windows.Forms.MenuItem MenuItem7;
	internal System.Windows.Forms.MenuItem MenuItem8;
	internal System.Windows.Forms.TextBox TextBox1;
	internal System.Windows.Forms.MenuItem mnuOpen;
	internal System.Windows.Forms.MenuItem mnuSave;
	internal System.Windows.Forms.MenuItem mnuClick;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ContextMenuCopy()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ContextMenuCopy));
		this.MainMenu1 = new System.Windows.Forms.MainMenu();
		this.mnuFile = new System.Windows.Forms.MenuItem();
		this.mnuOpen = new System.Windows.Forms.MenuItem();
		this.mnuSave = new System.Windows.Forms.MenuItem();
		this.mnuClick = new System.Windows.Forms.MenuItem();
		this.MenuItem5 = new System.Windows.Forms.MenuItem();
		this.MenuItem6 = new System.Windows.Forms.MenuItem();
		this.MenuItem7 = new System.Windows.Forms.MenuItem();
		this.MenuItem8 = new System.Windows.Forms.MenuItem();
		this.TextBox1 = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// MainMenu1
		// 
		this.MainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.mnuFile,
																				  this.MenuItem5});
		this.MainMenu1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("MainMenu1.RightToLeft")));
		// 
		// mnuFile
		// 
		this.mnuFile.Enabled = ((bool)(resources.GetObject("mnuFile.Enabled")));
		this.mnuFile.Index = 0;
		this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				this.mnuOpen,
																				this.mnuSave,
																				this.mnuClick});
		this.mnuFile.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mnuFile.Shortcut")));
		this.mnuFile.ShowShortcut = ((bool)(resources.GetObject("mnuFile.ShowShortcut")));
		this.mnuFile.Text = resources.GetString("mnuFile.Text");
		this.mnuFile.Visible = ((bool)(resources.GetObject("mnuFile.Visible")));
		// 
		// mnuOpen
		// 
		this.mnuOpen.Enabled = ((bool)(resources.GetObject("mnuOpen.Enabled")));
		this.mnuOpen.Index = 0;
		this.mnuOpen.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mnuOpen.Shortcut")));
		this.mnuOpen.ShowShortcut = ((bool)(resources.GetObject("mnuOpen.ShowShortcut")));
		this.mnuOpen.Text = resources.GetString("mnuOpen.Text");
		this.mnuOpen.Visible = ((bool)(resources.GetObject("mnuOpen.Visible")));
		this.mnuOpen.Click += new System.EventHandler(this.mnuOpen_Click);
		// 
		// mnuSave
		// 
		this.mnuSave.Enabled = ((bool)(resources.GetObject("mnuSave.Enabled")));
		this.mnuSave.Index = 1;
		this.mnuSave.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mnuSave.Shortcut")));
		this.mnuSave.ShowShortcut = ((bool)(resources.GetObject("mnuSave.ShowShortcut")));
		this.mnuSave.Text = resources.GetString("mnuSave.Text");
		this.mnuSave.Visible = ((bool)(resources.GetObject("mnuSave.Visible")));
		this.mnuSave.Click += new System.EventHandler(this.mnuSave_Click);
		// 
		// mnuClick
		// 
		this.mnuClick.Enabled = ((bool)(resources.GetObject("mnuClick.Enabled")));
		this.mnuClick.Index = 2;
		this.mnuClick.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("mnuClick.Shortcut")));
		this.mnuClick.ShowShortcut = ((bool)(resources.GetObject("mnuClick.ShowShortcut")));
		this.mnuClick.Text = resources.GetString("mnuClick.Text");
		this.mnuClick.Visible = ((bool)(resources.GetObject("mnuClick.Visible")));
		this.mnuClick.Click += new System.EventHandler(this.mnuClick_Click);
		// 
		// MenuItem5
		// 
		this.MenuItem5.Enabled = ((bool)(resources.GetObject("MenuItem5.Enabled")));
		this.MenuItem5.Index = 1;
		this.MenuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				  this.MenuItem6,
																				  this.MenuItem7,
																				  this.MenuItem8});
		this.MenuItem5.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("MenuItem5.Shortcut")));
		this.MenuItem5.ShowShortcut = ((bool)(resources.GetObject("MenuItem5.ShowShortcut")));
		this.MenuItem5.Text = resources.GetString("MenuItem5.Text");
		this.MenuItem5.Visible = ((bool)(resources.GetObject("MenuItem5.Visible")));
		// 
		// MenuItem6
		// 
		this.MenuItem6.Enabled = ((bool)(resources.GetObject("MenuItem6.Enabled")));
		this.MenuItem6.Index = 0;
		this.MenuItem6.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("MenuItem6.Shortcut")));
		this.MenuItem6.ShowShortcut = ((bool)(resources.GetObject("MenuItem6.ShowShortcut")));
		this.MenuItem6.Text = resources.GetString("MenuItem6.Text");
		this.MenuItem6.Visible = ((bool)(resources.GetObject("MenuItem6.Visible")));
		// 
		// MenuItem7
		// 
		this.MenuItem7.Enabled = ((bool)(resources.GetObject("MenuItem7.Enabled")));
		this.MenuItem7.Index = 1;
		this.MenuItem7.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("MenuItem7.Shortcut")));
		this.MenuItem7.ShowShortcut = ((bool)(resources.GetObject("MenuItem7.ShowShortcut")));
		this.MenuItem7.Text = resources.GetString("MenuItem7.Text");
		this.MenuItem7.Visible = ((bool)(resources.GetObject("MenuItem7.Visible")));
		// 
		// MenuItem8
		// 
		this.MenuItem8.Enabled = ((bool)(resources.GetObject("MenuItem8.Enabled")));
		this.MenuItem8.Index = 2;
		this.MenuItem8.Shortcut = ((System.Windows.Forms.Shortcut)(resources.GetObject("MenuItem8.Shortcut")));
		this.MenuItem8.ShowShortcut = ((bool)(resources.GetObject("MenuItem8.ShowShortcut")));
		this.MenuItem8.Text = resources.GetString("MenuItem8.Text");
		this.MenuItem8.Visible = ((bool)(resources.GetObject("MenuItem8.Visible")));
		// 
		// TextBox1
		// 
		this.TextBox1.AccessibleDescription = resources.GetString("TextBox1.AccessibleDescription");
		this.TextBox1.AccessibleName = resources.GetString("TextBox1.AccessibleName");
		this.TextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("TextBox1.Anchor")));
		this.TextBox1.AutoSize = ((bool)(resources.GetObject("TextBox1.AutoSize")));
		this.TextBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBox1.BackgroundImage")));
		this.TextBox1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("TextBox1.Dock")));
		this.TextBox1.Enabled = ((bool)(resources.GetObject("TextBox1.Enabled")));
		this.TextBox1.Font = ((System.Drawing.Font)(resources.GetObject("TextBox1.Font")));
		this.TextBox1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("TextBox1.ImeMode")));
		this.TextBox1.Location = ((System.Drawing.Point)(resources.GetObject("TextBox1.Location")));
		this.TextBox1.MaxLength = ((int)(resources.GetObject("TextBox1.MaxLength")));
		this.TextBox1.Multiline = ((bool)(resources.GetObject("TextBox1.Multiline")));
		this.TextBox1.Name = "TextBox1";
		this.TextBox1.PasswordChar = ((char)(resources.GetObject("TextBox1.PasswordChar")));
		this.TextBox1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("TextBox1.RightToLeft")));
		this.TextBox1.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("TextBox1.ScrollBars")));
		this.TextBox1.Size = ((System.Drawing.Size)(resources.GetObject("TextBox1.Size")));
		this.TextBox1.TabIndex = ((int)(resources.GetObject("TextBox1.TabIndex")));
		this.TextBox1.Text = resources.GetString("TextBox1.Text");
		this.TextBox1.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("TextBox1.TextAlign")));
		this.TextBox1.Visible = ((bool)(resources.GetObject("TextBox1.Visible")));
		this.TextBox1.WordWrap = ((bool)(resources.GetObject("TextBox1.WordWrap")));
		this.TextBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TextBox1_MouseDown);
		// 
		// ContextMenuCopy
		// 
		this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
		this.AccessibleName = resources.GetString("$this.AccessibleName");
		this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
		this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
		this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
		this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
		this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
		this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
		this.Controls.Add(this.TextBox1);
		this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
		this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
		this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
		this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
		this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
		this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
		this.Menu = this.MainMenu1;
		this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
		this.Name = "ContextMenuCopy";
		this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
		this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
		this.Text = resources.GetString("$this.Text");
		this.Load += new System.EventHandler(this.ContextMenuCopy_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new ContextMenuCopy());
	}

	private void ContextMenuCopy_Load(object sender, System.EventArgs e)
	{
		ContextMenu mnuContext = new ContextMenu();
		
		foreach (MenuItem mnuItem in mnuFile.MenuItems)
		{
			mnuContext.MenuItems.Add(mnuItem.CloneMenu());
		}

		TextBox1.ContextMenu = mnuContext;
	}

	private void TextBox1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			TextBox1.ContextMenu.Show(TextBox1, new Point(e.X, e.Y));
		}
	}

	private void mnuOpen_Click(object sender, System.EventArgs e)
	{
		MessageBox.Show("This is the event handler for Open.");
	}

	private void mnuSave_Click(object sender, System.EventArgs e)
	{
		MessageBox.Show("This is the event handler for Save.");
	}

	private void mnuClick_Click(object sender, System.EventArgs e)
	{
		MessageBox.Show("This is the event handler for Exit.");
	}
}