Namespace TestQuanbLyBanHang
	Partial Class Form5
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.textBox4 = New System.Windows.Forms.TextBox()
			Me.comboBox1 = New System.Windows.Forms.ComboBox()
			Me.textBox3 = New System.Windows.Forms.TextBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label5 = New System.Windows.Forms.Label()
			Me.label4 = New System.Windows.Forms.Label()
			Me.label3 = New System.Windows.Forms.Label()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.btnReLoad = New System.Windows.Forms.Button()
			Me.btnSua = New System.Windows.Forms.Button()
			Me.btnLuu = New System.Windows.Forms.Button()
			Me.btnHuyBo = New System.Windows.Forms.Button()
			Me.btnXoa = New System.Windows.Forms.Button()
			Me.btnTroVe = New System.Windows.Forms.Button()
			Me.btnThem = New System.Windows.Forms.Button()
			Me.groupBox1.SuspendLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me.textBox4)
			Me.groupBox1.Controls.Add(Me.comboBox1)
			Me.groupBox1.Controls.Add(Me.textBox3)
			Me.groupBox1.Controls.Add(Me.textBox2)
			Me.groupBox1.Controls.Add(Me.textBox1)
			Me.groupBox1.Controls.Add(Me.label5)
			Me.groupBox1.Controls.Add(Me.label4)
			Me.groupBox1.Controls.Add(Me.label3)
			Me.groupBox1.Controls.Add(Me.label2)
			Me.groupBox1.Controls.Add(Me.label1)
			Me.groupBox1.Location = New System.Drawing.Point(28, 4)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(528, 116)
			Me.groupBox1.TabIndex = 0
			Me.groupBox1.TabStop = False
			' 
			' textBox4
			' 
			Me.textBox4.Location = New System.Drawing.Point(391, 53)
			Me.textBox4.Name = "textBox4"
			Me.textBox4.Size = New System.Drawing.Size(121, 20)
			Me.textBox4.TabIndex = 9
			' 
			' comboBox1
			' 
			Me.comboBox1.FormattingEnabled = True
			Me.comboBox1.Location = New System.Drawing.Point(391, 26)
			Me.comboBox1.Name = "comboBox1"
			Me.comboBox1.Size = New System.Drawing.Size(121, 21)
			Me.comboBox1.TabIndex = 8
			AddHandler Me.comboBox1.SelectedIndexChanged, New System.EventHandler(Me.comboBox1_SelectedIndexChanged)
			' 
			' textBox3
			' 
			Me.textBox3.Location = New System.Drawing.Point(66, 83)
			Me.textBox3.Name = "textBox3"
			Me.textBox3.Size = New System.Drawing.Size(254, 20)
			Me.textBox3.TabIndex = 7
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(66, 53)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.Size = New System.Drawing.Size(254, 20)
			Me.textBox2.TabIndex = 6
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(66, 27)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(147, 20)
			Me.textBox1.TabIndex = 5
			' 
			' label5
			' 
			Me.label5.AutoSize = True
			Me.label5.Location = New System.Drawing.Point(326, 56)
			Me.label5.Name = "label5"
			Me.label5.Size = New System.Drawing.Size(59, 13)
			Me.label5.TabIndex = 4
			Me.label5.Text = "Dien Thoai"
			' 
			' label4
			' 
			Me.label4.AutoSize = True
			Me.label4.Location = New System.Drawing.Point(325, 30)
			Me.label4.Name = "label4"
			Me.label4.Size = New System.Drawing.Size(60, 13)
			Me.label4.TabIndex = 3
			Me.label4.Text = "Thanh Pho"
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Location = New System.Drawing.Point(13, 86)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(41, 13)
			Me.label3.TabIndex = 2
			Me.label3.Text = "Dia Chi"
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(6, 56)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(48, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Ten CTy"
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(6, 30)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(40, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Ma KH"
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(27, 137)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(529, 215)
			Me.dataGridView1.TabIndex = 1
			' 
			' btnReLoad
			' 
			Me.btnReLoad.Location = New System.Drawing.Point(27, 370)
			Me.btnReLoad.Name = "btnReLoad"
			Me.btnReLoad.Size = New System.Drawing.Size(70, 28)
			Me.btnReLoad.TabIndex = 2
			Me.btnReLoad.Text = "ReLoad"
			Me.btnReLoad.UseVisualStyleBackColor = True
			AddHandler Me.btnReLoad.Click, New System.EventHandler(Me.button1_Click)
			' 
			' btnSua
			' 
			Me.btnSua.Location = New System.Drawing.Point(182, 370)
			Me.btnSua.Name = "btnSua"
			Me.btnSua.Size = New System.Drawing.Size(70, 28)
			Me.btnSua.TabIndex = 4
			Me.btnSua.Text = "Sua"
			Me.btnSua.UseVisualStyleBackColor = True
			AddHandler Me.btnSua.Click, New System.EventHandler(Me.btnSua_Click)
			' 
			' btnLuu
			' 
			Me.btnLuu.Location = New System.Drawing.Point(258, 370)
			Me.btnLuu.Name = "btnLuu"
			Me.btnLuu.Size = New System.Drawing.Size(70, 28)
			Me.btnLuu.TabIndex = 5
			Me.btnLuu.Text = "Luu"
			Me.btnLuu.UseVisualStyleBackColor = True
			AddHandler Me.btnLuu.Click, New System.EventHandler(Me.btnLuu_Click)
			' 
			' btnHuyBo
			' 
			Me.btnHuyBo.Location = New System.Drawing.Point(334, 370)
			Me.btnHuyBo.Name = "btnHuyBo"
			Me.btnHuyBo.Size = New System.Drawing.Size(70, 28)
			Me.btnHuyBo.TabIndex = 6
			Me.btnHuyBo.Text = "Huy Bo"
			Me.btnHuyBo.UseVisualStyleBackColor = True
			AddHandler Me.btnHuyBo.Click, New System.EventHandler(Me.btnHuyBo_Click)
			' 
			' btnXoa
			' 
			Me.btnXoa.Location = New System.Drawing.Point(410, 370)
			Me.btnXoa.Name = "btnXoa"
			Me.btnXoa.Size = New System.Drawing.Size(70, 28)
			Me.btnXoa.TabIndex = 7
			Me.btnXoa.Text = "Xoa"
			Me.btnXoa.UseVisualStyleBackColor = True
			AddHandler Me.btnXoa.Click, New System.EventHandler(Me.btnXoa_Click)
			' 
			' btnTroVe
			' 
			Me.btnTroVe.Location = New System.Drawing.Point(486, 370)
			Me.btnTroVe.Name = "btnTroVe"
			Me.btnTroVe.Size = New System.Drawing.Size(70, 28)
			Me.btnTroVe.TabIndex = 8
			Me.btnTroVe.Text = "Tro Ve"
			Me.btnTroVe.UseVisualStyleBackColor = True
			AddHandler Me.btnTroVe.Click, New System.EventHandler(Me.btnTroVe_Click)
			' 
			' btnThem
			' 
			Me.btnThem.Image = Global.TestQuanbLyBanHang.Properties.Resources.add
			Me.btnThem.Location = New System.Drawing.Point(103, 370)
			Me.btnThem.Name = "btnThem"
			Me.btnThem.Size = New System.Drawing.Size(73, 28)
			Me.btnThem.TabIndex = 3
			Me.btnThem.UseVisualStyleBackColor = True
			AddHandler Me.btnThem.Click, New System.EventHandler(Me.btnThem_Click)
			' 
			' Form5
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(581, 419)
			Me.Controls.Add(Me.btnTroVe)
			Me.Controls.Add(Me.btnXoa)
			Me.Controls.Add(Me.btnHuyBo)
			Me.Controls.Add(Me.btnLuu)
			Me.Controls.Add(Me.btnSua)
			Me.Controls.Add(Me.btnThem)
			Me.Controls.Add(Me.btnReLoad)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.groupBox1)
			Me.Name = "Form5"
			Me.Text = "Form5"
			Me.Load += New System.EventHandler(Me.Form5_Load)
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private groupBox1 As System.Windows.Forms.GroupBox
		Private textBox4 As System.Windows.Forms.TextBox
		Private comboBox1 As System.Windows.Forms.ComboBox
		Private textBox3 As System.Windows.Forms.TextBox
		Private textBox2 As System.Windows.Forms.TextBox
		Private textBox1 As System.Windows.Forms.TextBox
		Private label5 As System.Windows.Forms.Label
		Private label4 As System.Windows.Forms.Label
		Private label3 As System.Windows.Forms.Label
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private btnReLoad As System.Windows.Forms.Button
		Private btnThem As System.Windows.Forms.Button
		Private btnSua As System.Windows.Forms.Button
		Private btnLuu As System.Windows.Forms.Button
		Private btnHuyBo As System.Windows.Forms.Button
		Private btnXoa As System.Windows.Forms.Button
		Private btnTroVe As System.Windows.Forms.Button
	End Class
End Namespace
