using System;
using System.Drawing;
using System.Windows.Forms;

public class Thumbnails : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public Thumbnails()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		// 
		// Thumbnails
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Name = "Thumbnails";
		this.Text = "Thumbnails";
		this.Load += new System.EventHandler(this.Thumbnails_Load);
		this.Paint += new System.Windows.Forms.PaintEventHandler(this.Thumbnails_Paint);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new Thumbnails());
	}

	Image thumbnail;

	private void Thumbnails_Load(object sender, System.EventArgs e)
	{
		Image img = Image.FromFile("test.jpg");

		int thumbnailWidth = 0, thumbnailHeight = 0;

		if (img.Width > img.Height)
		{
			thumbnailWidth = 50;
			thumbnailHeight = Convert.ToInt32(((50F / img.Width) * img.Height));
		}
		else
		{
			thumbnailHeight = 50;
			thumbnailWidth = Convert.ToInt32(((50F / img.Height) * img.Width));
		}

		thumbnail = img.GetThumbnailImage(thumbnailWidth, thumbnailHeight, null, IntPtr.Zero);
	}

	private void Thumbnails_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
	{
		e.Graphics.DrawImage(thumbnail, 10, 10);
	}
}