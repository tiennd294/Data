using System;

public class DateTimeExample
{
	public static void Main() {

        TimeSpan timespan1 = new TimeSpan(2,12,0,0);

        TimeSpan timespan2 = new TimeSpan(4,12,0,0);

        TimeSpan oneWeek = timespan1 + timespan2;

        DateTime now = DateTime.Now;

        DateTime past = now - oneWeek;

        DateTime future = now + oneWeek;

        Console.WriteLine("Now   : {0}", now);
        Console.WriteLine("Past  : {0}", past);
        Console.WriteLine("Future: {0}", future);

		Console.ReadLine();
	}
}
