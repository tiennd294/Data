using System;
using System.Windows.Forms;

public class WindowsXP : System.Windows.Forms.Form
{
	internal System.Windows.Forms.HScrollBar HScrollBar1;
	internal System.Windows.Forms.ProgressBar ProgressBar1;
	internal System.Windows.Forms.TrackBar TrackBar1;
	internal System.Windows.Forms.ComboBox ComboBox1;
	internal System.Windows.Forms.RadioButton RadioButton1;
	internal System.Windows.Forms.CheckBox CheckBox1;
	internal System.Windows.Forms.Button Button1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public WindowsXP()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.HScrollBar1 = new System.Windows.Forms.HScrollBar();
		this.ProgressBar1 = new System.Windows.Forms.ProgressBar();
		this.TrackBar1 = new System.Windows.Forms.TrackBar();
		this.ComboBox1 = new System.Windows.Forms.ComboBox();
		this.RadioButton1 = new System.Windows.Forms.RadioButton();
		this.CheckBox1 = new System.Windows.Forms.CheckBox();
		this.Button1 = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.TrackBar1)).BeginInit();
		this.SuspendLayout();
		// 
		// HScrollBar1
		// 
		this.HScrollBar1.Location = new System.Drawing.Point(12, 188);
		this.HScrollBar1.Name = "HScrollBar1";
		this.HScrollBar1.Size = new System.Drawing.Size(304, 20);
		this.HScrollBar1.TabIndex = 15;
		// 
		// ProgressBar1
		// 
		this.ProgressBar1.Location = new System.Drawing.Point(12, 228);
		this.ProgressBar1.Name = "ProgressBar1";
		this.ProgressBar1.Size = new System.Drawing.Size(304, 23);
		this.ProgressBar1.TabIndex = 14;
		this.ProgressBar1.Value = 30;
		// 
		// TrackBar1
		// 
		this.TrackBar1.Location = new System.Drawing.Point(12, 124);
		this.TrackBar1.Name = "TrackBar1";
		this.TrackBar1.Size = new System.Drawing.Size(304, 45);
		this.TrackBar1.TabIndex = 13;
		// 
		// ComboBox1
		// 
		this.ComboBox1.Location = new System.Drawing.Point(12, 80);
		this.ComboBox1.Name = "ComboBox1";
		this.ComboBox1.Size = new System.Drawing.Size(160, 21);
		this.ComboBox1.TabIndex = 12;
		this.ComboBox1.Text = "ComboBox1";
		// 
		// RadioButton1
		// 
		this.RadioButton1.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.RadioButton1.Location = new System.Drawing.Point(12, 44);
		this.RadioButton1.Name = "RadioButton1";
		this.RadioButton1.Size = new System.Drawing.Size(172, 16);
		this.RadioButton1.TabIndex = 11;
		this.RadioButton1.Text = "RadioButton1";
		// 
		// CheckBox1
		// 
		this.CheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.CheckBox1.Location = new System.Drawing.Point(12, 12);
		this.CheckBox1.Name = "CheckBox1";
		this.CheckBox1.Size = new System.Drawing.Size(160, 20);
		this.CheckBox1.TabIndex = 10;
		this.CheckBox1.Text = "CheckBox1";
		// 
		// Button1
		// 
		this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
		this.Button1.Location = new System.Drawing.Point(212, 16);
		this.Button1.Name = "Button1";
		this.Button1.Size = new System.Drawing.Size(104, 28);
		this.Button1.TabIndex = 9;
		this.Button1.Text = "Button1";
		// 
		// Form1
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(340, 270);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.HScrollBar1,
																		this.ProgressBar1,
																		this.TrackBar1,
																		this.ComboBox1,
																		this.RadioButton1,
																		this.CheckBox1,
																		this.Button1});
		this.Name = "Form1";
		this.Text = "Form1";
		((System.ComponentModel.ISupportInitialize)(this.TrackBar1)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.EnableVisualStyles();
		Application.Run(new WindowsXP());
	}
}
