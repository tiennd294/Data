using System;
using System.Diagnostics;

public class StartProcessExample {

    public static void Main () {

        ProcessStartInfo startInfo = new ProcessStartInfo();

        startInfo.FileName = "notepad.exe";
        startInfo.Arguments = "file.txt";
        startInfo.WorkingDirectory = @"C:\Temp";
        startInfo.WindowStyle = ProcessWindowStyle.Maximized;
        startInfo.ErrorDialog = true;

        using (Process process = new Process()) {

            process.StartInfo = startInfo;

            try {

                process.Start();

                Console.WriteLine("Waiting 30 seconds for process to" +
                    " finish.");
                process.WaitForExit(30000);

            } catch (Exception ex) {

                Console.WriteLine("Could not start process.");
                Console.WriteLine(ex);
            }
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}
