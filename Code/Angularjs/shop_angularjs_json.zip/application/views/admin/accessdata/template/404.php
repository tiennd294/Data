<!DOCTYPE html>
<html lang="en">
<head>
<title>Maruti Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/maruti-style.css" />
<link rel="stylesheet" href="css/maruti-media.css" class="skin-color" />
</head>
<body>


        <div id="header">
  
        </div>
        <!--close-Header-part--> 
        <!--top-Header-menu-->
        <div id="user-nav" class="navbar navbar-inverse">
          <ul class="nav">
            <li class="" ><a title="" href="#"><i class="icon icon-user"></i> <span class="text">Profile</span></a></li>
            <li class=""><a title="" href="#"><i class="icon icon-home2"></i> <span class="text">Website</span></a></li>
            <li class=""><a title="" href="login.html"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
          </ul>
        </div>
 
        <!--close-top-Header-menu-->
         
         
         
     


        

        
        
<div id="content">
     <div id="content-header">
        <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Tables</a> </div>
        
      </div>
      
       
       
       <h1>Tables</h1>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title">
             <span class="icon"><i class="icon-th"></i></span> 
            <div class="table-action">
               <a href="role-create.html"><i class="icon-plus"></i> Thêm</a>
            </div>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>Rendering engine</th>
                  <th>Browser</th>
                  <th>Platform(s)</th>
                  <th>Engine version</th>
                </tr>
              </thead>
              <tbody>
               
                <tr class="gradeX">
                  <td>Misc</td>

                  <td>Links</td>
                  <td>Text only</td>
                  <td class="center">-</td>
                </tr>
                <tr class="gradeX">
                  <td>Misc</td>
                  <td>Lynx</td>
                  <td>Text only</td>
                  <td class="center">-</td>
                </tr>
                <tr class="gradeC">
                  <td>Misc</td>
                  <td>IE Mobile</td>
                  <td>Windows Mobile 6</td>
                  <td class="center">-</td>
                </tr>
                <tr class="gradeC">
                  <td>Misc</td>
                  <td>PSP browser</td>
                  <td>PSP</td>
                  <td class="center">-</td>
                </tr>
                <tr class="gradeU">
                  <td>Other browsers</td>
                  <td>All others</td>
                  <td>-</td>
                  <td class="center">-</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
       

      </div>
    </div>
  </div>
  
  

  
  
</div>
<div class="row-fluid">
  <div id="footer" class="span12"> 2012 &copy; Marutii Admin. Brought to you by <a href="http://themedesigner.in/">Themedesigner.in</a> </div>
</div>
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/maruti.js"></script> 
<script src="js/maruti.tables.js"></script>
</body>
</html>



<style>

article,
aside,
details,
figcaption,
figure,
footer,
header,
hgroup,
nav,
section { display:block }
audio,
canvas,
video { display:inline-block; *display:inline;
*zoom:1
}
audio:not([controls]) { display:none }
html { font-size:100%; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100% }
a:focus { outline:thin dotted #333; outline:5px auto -webkit-focus-ring-color; outline-offset:-2px }
a:hover,
a:active { outline:0 }
sub,
sup { position:relative; font-size:75%; line-height:0; vertical-align:baseline }
sup { top:-0.5em }
sub { bottom:-0.25em }
img { width:auto\9; height:auto; max-width:100%; vertical-align:middle; border:0; -ms-interpolation-mode:bicubic }
#map_canvas img,
.google-maps img { max-width:none }
button,
input,
select,
textarea { margin:0; font-size:100%; vertical-align:middle }
button,
input {
*overflow:visible; line-height:normal }
button::-moz-focus-inner, input::-moz-focus-inner {
padding:0;
border:0
}
button,
html input[type="button"],
input[type="reset"],
input[type="submit"] { cursor:pointer; -webkit-appearance:button }
input[type="search"] { -webkit-box-sizing:content-box; -moz-box-sizing:content-box; box-sizing:content-box; -webkit-appearance:textfield }
input[type="search"]::-webkit-search-decoration, input[type="search"]::-webkit-search-cancel-button {
-webkit-appearance:none
}
textarea { overflow:auto; vertical-align:top }
.clearfix { *zoom:1
}
.clearfix:before,
.clearfix:after { display:table; line-height:0; content:"" }
.clearfix:after { clear:both }
.hide-text { font:0/0 a; color:transparent; text-shadow:none; background-color:transparent; border:0 }
.input-block-level { display:block; width:100%; min-height:30px; -webkit-box-sizing:border-box; -moz-box-sizing:border-box; box-sizing:border-box }
body { margin:0; font-family:Arial, sans-serif; font-size:13px; line-height:20px; color:#5F5F5F; background-color:#fff }
a { color:#666; text-decoration:none }
a:hover { color:#F77825; text-decoration:underline }
.img-rounded { -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px }
.img-polaroid { padding:4px; background-color:#fff; border:1px solid #ccc; border:1px solid rgba(0,0,0,0.2); -webkit-box-shadow:0 1px 3px rgba(0,0,0,0.1); -moz-box-shadow:0 1px 3px rgba(0,0,0,0.1); box-shadow:0 1px 3px rgba(0,0,0,0.1) }
.img-circle { -webkit-border-radius:500px; -moz-border-radius:500px; border-radius:500px }
.row { margin-left:-20px; *zoom:1
}
.row:before,
.row:after { display:table; line-height:0; content:"" }
.row:after { clear:both }
[class*="span"] {
float:left;
min-height:1px;
margin-left:20px
}
.container,
.navbar-static-top .container,
.navbar-fixed-top .container,
.navbar-fixed-bottom .container { width:940px }
.span12 { width:940px }
.span11 { width:860px }
.span10 { width:780px }
.span9 { width:700px }
.span8 { width:620px }
.span7 { width:540px }
.span6 { width:460px }
.span5 { width:380px }
.span4 { width:300px }
.span3 { width:220px }
.span2 { width:140px }
.span1 { width:60px }
.offset12 { margin-left:980px }
.offset11 { margin-left:900px }
.offset10 { margin-left:820px }
.offset9 { margin-left:740px }
.offset8 { margin-left:660px }
.offset7 { margin-left:580px }
.offset6 { margin-left:500px }
.offset5 { margin-left:420px }
.offset4 { margin-left:340px }
.offset3 { margin-left:260px }
.offset2 { margin-left:180px }
.offset1 { margin-left:100px }
.row-fluid { width:100%; *zoom:1
}
.row-fluid:before,
.row-fluid:after { display:table; line-height:0; content:"" }
.row-fluid:after { clear:both }
.row-fluid [class*="span"] { display:block; float:left; width:100%; min-height:30px; margin-left:2.127659574468085%; *margin-left:2.074468085106383%;
-webkit-box-sizing:border-box; -moz-box-sizing:border-box; box-sizing:border-box }
.row-fluid [class*="span"]:first-child { margin-left:0 }
.row-fluid .controls-row [class*="span"]+[class*="span"] {
margin-left:2.127659574468085%
}
.row-fluid .span12 { width:100%; *width:99.94680851063829%
}
.row-fluid .span11 { width:91.48936170212765%; *width:91.43617021276594%
}
.row-fluid .span10 { width:82.97872340425532%; *width:82.92553191489361%
}
.row-fluid .span9 { width:74.46808510638297%; *width:74.41489361702126%
}
.row-fluid .span8 { width:65.95744680851064%; *width:65.90425531914893%
}
.row-fluid .span7 { width:57.44680851063829%; *width:57.39361702127659%
}
.row-fluid .span6 { width:48.93617021276595%; *width:48.88297872340425%
}
.row-fluid .span5 { width:40.42553191489362%; *width:40.37234042553192%
}
.row-fluid .span4 { width:31.914893617021278%; *width:31.861702127659576%
}
.row-fluid .span3 { width:23.404255319148934%; *width:23.351063829787233%
}
.row-fluid .span2 { width:14.893617021276595%; *width:14.840425531914894%
}
.row-fluid .span1 { width:6.382978723404255%; *width:6.329787234042553%
}
.row-fluid .offset12 { margin-left:104.25531914893617%; *margin-left:104.14893617021275%
}
.row-fluid .offset12:first-child { margin-left:102.12765957446808%; *margin-left:102.02127659574467%
}
.row-fluid .offset11 { margin-left:95.74468085106382%; *margin-left:95.6382978723404%
}
.row-fluid .offset11:first-child { margin-left:93.61702127659574%; *margin-left:93.51063829787232%
}
.row-fluid .offset10 { margin-left:87.23404255319149%; *margin-left:87.12765957446807%
}
.row-fluid .offset10:first-child { margin-left:85.1063829787234%; *margin-left:84.99999999999999%
}
.row-fluid .offset9 { margin-left:78.72340425531914%; *margin-left:78.61702127659572%
}
.row-fluid .offset9:first-child { margin-left:76.59574468085106%; *margin-left:76.48936170212764%
}
.row-fluid .offset8 { margin-left:70.2127659574468%; *margin-left:70.10638297872339%
}
.row-fluid .offset8:first-child { margin-left:68.08510638297872%; *margin-left:67.9787234042553%
}
.row-fluid .offset7 { margin-left:61.70212765957446%; *margin-left:61.59574468085106%
}
.row-fluid .offset7:first-child { margin-left:59.574468085106375%; *margin-left:59.46808510638297%
}
.row-fluid .offset6 { margin-left:53.191489361702125%; *margin-left:53.085106382978715%
}
.row-fluid .offset6:first-child { margin-left:51.063829787234035%; *margin-left:50.95744680851063%
}
.row-fluid .offset5 { margin-left:44.68085106382979%; *margin-left:44.57446808510638%
}
.row-fluid .offset5:first-child { margin-left:42.5531914893617%; *margin-left:42.4468085106383%
}
.row-fluid .offset4 { margin-left:36.170212765957444%; *margin-left:36.06382978723405%
}
.row-fluid .offset4:first-child { margin-left:34.04255319148936%; *margin-left:33.93617021276596%
}
.row-fluid .offset3 { margin-left:27.659574468085104%; *margin-left:27.5531914893617%
}
.row-fluid .offset3:first-child { margin-left:25.53191489361702%; *margin-left:25.425531914893618%
}
.row-fluid .offset2 { margin-left:19.148936170212764%; *margin-left:19.04255319148936%
}
.row-fluid .offset2:first-child { margin-left:17.02127659574468%; *margin-left:16.914893617021278%
}
.row-fluid .offset1 { margin-left:10.638297872340425%; *margin-left:10.53191489361702%
}
.row-fluid .offset1:first-child { margin-left:8.51063829787234%; *margin-left:8.404255319148938%
}
[class*="span"].hide,
.row-fluid [class*="span"].hide { display:none }
[class*="span"].pull-right,
.row-fluid [class*="span"].pull-right { float:right }
.container { margin-right:auto; margin-left:auto; *zoom:1
}
.container:before,
.container:after { display:table; line-height:0; content:"" }
.container:after { clear:both }
.container-fluid { padding-right:20px; padding-left:20px; *zoom:1
}
.container-fluid:before,
.container-fluid:after { display:table; line-height:0; content:"" }
.container-fluid:after { clear:both }
p { margin:0 0 10px }
.lead { margin-bottom:20px; font-size:21px; font-weight:200; line-height:30px }
small { font-size:85% }
strong { font-weight:bold }
em { font-style:italic }
cite { font-style:normal }
.muted { color:#999 }
.text-warning { color:#c09853 }
a.text-warning:hover { color:#a47e3c }
.text-error { color:#b94a48 }
a.text-error:hover { color:#953b39 }
.text-info { color:#3a87ad }
a.text-info:hover { color:#2d6987 }
.text-success { color:#468847 }
a.text-success:hover { color:#356635 }
h1,
h2,
h3,
h4,
h5,
h6 { margin:10px 0; font-family:inherit; font-weight:bold; line-height:20px; color:inherit; text-rendering:optimizelegibility }
h1 small,
h2 small,
h3 small,
h4 small,
h5 small,
h6 small { font-weight:normal; line-height:1; color:#999 }
h1,
h2,
h3 { line-height:40px }
h1 { font-size:38.5px }
h2 { font-size:31.5px }
h3 { font-size:24.5px }
h4 { font-size:17.5px }
h5 { font-size:14px }
h6 { font-size:11.9px }
h1 small { font-size:24.5px }
h2 small { font-size:17.5px }
h3 small { font-size:14px }
h4 small { font-size:14px }
.page-header { padding-bottom:9px; margin:20px 0 30px; border-bottom:1px solid #eee }
ul,
ol { padding:0; margin:0 0 10px 25px }
ul ul,
ul ol,
ol ol,
ol ul { margin-bottom:0 }
li { line-height:20px }
ul.unstyled,
ol.unstyled { margin-left:0; list-style:none }
dl { margin-bottom:20px }
dt,
dd { line-height:20px }
dt { font-weight:bold }
dd { margin-left:10px }
.dl-horizontal { *zoom:1
}
.dl-horizontal:before,
.dl-horizontal:after { display:table; line-height:0; content:"" }
.dl-horizontal:after { clear:both }
.dl-horizontal dt { float:left; width:160px; overflow:hidden; clear:left; text-align:right; text-overflow:ellipsis; white-space:nowrap }
.dl-horizontal dd { margin-left:180px }
hr { margin:20px 0; border:0; border-top:1px solid #eee; border-bottom:1px solid #fff }
abbr[title],
abbr[data-original-title] { cursor:help; border-bottom:1px dotted #999 }
abbr.initialism { font-size:90%; text-transform:uppercase }
blockquote { padding:0 0 0 15px; margin:0 0 20px; border-left:5px solid #eee }
blockquote p { margin-bottom:0; font-size:16px; font-weight:300; line-height:25px }
blockquote small { display:block; line-height:20px; color:#999 }
blockquote small:before { content:'\2014 \00A0' }
blockquote.pull-right { float:right; padding-right:15px; padding-left:0; border-right:5px solid #eee; border-left:0 }
blockquote.pull-right p,
blockquote.pull-right small { text-align:right }
blockquote.pull-right small:before { content:'' }
blockquote.pull-right small:after { content:'\00A0 \2014' }
q:before,
q:after,
blockquote:before,
blockquote:after { content:"" }
address { display:block; margin-bottom:20px; font-style:normal; line-height:20px }
code,
pre { padding:0 3px 2px; font-family:Monaco, Menlo, Consolas, "Courier New", monospace; font-size:12px; color:#333; -webkit-border-radius:3px; -moz-border-radius:3px; border-radius:3px }
code { padding:2px 4px; color:#d14; background-color:#f7f7f9; border:1px solid #e1e1e8 }
pre { display:block; padding:9.5px; margin:0 0 10px; font-size:13px; line-height:20px; word-break:break-all; word-wrap:break-word; white-space:pre; white-space:pre-wrap; background-color:#f5f5f5; border:1px solid #ccc; border:1px solid rgba(0,0,0,0.15); -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px }
pre.prettyprint { margin-bottom:20px }
pre code { padding:0; color:inherit; background-color:transparent; border:0 }
.pre-scrollable { max-height:340px; overflow-y:scroll }
form { margin:0 0 20px }
fieldset { padding:0; margin:0; border:0 }
legend { display:block; width:100%; padding:0; margin-bottom:20px; font-size:21px; line-height:40px; color:#333; border:0; border-bottom:1px solid #e5e5e5 }
legend small { font-size:15px; color:#999 }
label,
input,
button,
select,
textarea { font-size:14px; font-weight:normal; line-height:20px }
input,
button,
select,
textarea { font-family:"Helvetica Neue", Helvetica, Arial, sans-serif }
label { display:block; margin-bottom:5px }
select,
textarea,
input[type="text"],
input[type="password"],
input[type="datetime"],
input[type="datetime-local"],
input[type="date"],
input[type="month"],
input[type="time"],
input[type="week"],
input[type="number"],
input[type="email"],
input[type="url"],
input[type="search"],
input[type="tel"],
input[type="color"],
.uneditable-input { display:inline-block; height:20px; padding:4px 6px; margin-bottom:10px; font-size:14px; line-height:20px; color:#555; vertical-align:middle;}
input,
textarea,
.uneditable-input { width:206px }
textarea { height:auto }
textarea,
input[type="text"],
input[type="password"],
input[type="datetime"],
input[type="datetime-local"],
input[type="date"],
input[type="month"],
input[type="time"],
input[type="week"],
input[type="number"],
input[type="email"],
input[type="url"],
input[type="search"],
input[type="tel"],
input[type="color"],
.uneditable-input { background-color:#fff; border:1px solid #ccc;  transition:border linear .2s, box-shadow linear .2s }
textarea:focus,
input[type="text"]:focus,
input[type="password"]:focus,
input[type="datetime"]:focus,
input[type="datetime-local"]:focus,
input[type="date"]:focus,
input[type="month"]:focus,
input[type="time"]:focus,
input[type="week"]:focus,
input[type="number"]:focus,
input[type="email"]:focus,
input[type="url"]:focus,
input[type="search"]:focus,
input[type="tel"]:focus,
input[type="color"]:focus,
.uneditable-input:focus { border-color:rgba(82,168,236,0.8); outline:0; outline:thin dotted \9;  }
input[type="radio"],
input[type="checkbox"] { margin:4px 0 0; margin-top:1px \9; *margin-top:0;
line-height:normal; cursor:pointer }
input[type="file"],
input[type="image"],
input[type="submit"],
input[type="reset"],
input[type="button"],
input[type="radio"],
input[type="checkbox"] { width:auto }
select,
input[type="file"] { height:30px; *margin-top:4px;
line-height:30px }
select { width:220px; background-color:#fff; border:1px solid #ccc }
select[multiple],
select[size] { height:auto }
select:focus,
input[type="file"]:focus,
input[type="radio"]:focus,
input[type="checkbox"]:focus { outline:thin dotted #333; outline:5px auto -webkit-focus-ring-color; outline-offset:-2px }
.uneditable-input,
.uneditable-textarea { color:#999; cursor:not-allowed; background-color:#fcfcfc; border-color:#ccc; -webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.025); -moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.025); box-shadow:inset 0 1px 2px rgba(0,0,0,0.025) }
.uneditable-input { overflow:hidden; white-space:nowrap }
.uneditable-textarea { width:auto; height:auto }
input:-moz-placeholder, textarea:-moz-placeholder {
color:#999
}
input:-ms-input-placeholder, textarea:-ms-input-placeholder {
color:#999
}
input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
color:#999
}
.radio,
.checkbox { min-height:20px; padding-left:20px }
.radio input[type="radio"],
.checkbox input[type="checkbox"] { float:left; margin-left:-20px }
.controls>.radio:first-child,
.controls>.checkbox:first-child { padding-top:5px }
.radio.inline,
.checkbox.inline { display:inline-block; padding-top:5px; margin-bottom:0; vertical-align:middle }
.radio.inline+.radio.inline,
.checkbox.inline+.checkbox.inline { margin-left:10px }
.input-mini { width:60px }
.input-small { width:90px }
.input-medium { width:150px }
.input-large { width:210px }
.input-xlarge { width:270px }
.input-xxlarge { width:530px }
input[class*="span"],
select[class*="span"],
textarea[class*="span"],
.uneditable-input[class*="span"],
.row-fluid input[class*="span"],
.row-fluid select[class*="span"],
.row-fluid textarea[class*="span"],
.row-fluid .uneditable-input[class*="span"] { float:none; margin-left:0 }
.input-append input[class*="span"],
.input-append .uneditable-input[class*="span"],
.input-prepend input[class*="span"],
.input-prepend .uneditable-input[class*="span"],
.row-fluid input[class*="span"],
.row-fluid select[class*="span"],
.row-fluid textarea[class*="span"],
.row-fluid .uneditable-input[class*="span"],
.row-fluid .input-prepend [class*="span"],
.row-fluid .input-append [class*="span"] { display:inline-block; margin-bottom:5px; }
input,
textarea,
.uneditable-input { margin-left:0 }
.controls-row [class*="span"]+[class*="span"] {
margin-left:20px
}
input.span12,
textarea.span12,
.uneditable-input.span12 { width:926px }
input.span11,
textarea.span11,
.uneditable-input.span11 { width:846px }
input.span10,
textarea.span10,
.uneditable-input.span10 { width:766px }
input.span9,
textarea.span9,
.uneditable-input.span9 { width:686px }
input.span8,
textarea.span8,
.uneditable-input.span8 { width:606px }
input.span7,
textarea.span7,
.uneditable-input.span7 { width:526px }
input.span6,
textarea.span6,
.uneditable-input.span6 { width:446px }
input.span5,
textarea.span5,
.uneditable-input.span5 { width:366px }
input.span4,
textarea.span4,
.uneditable-input.span4 { width:286px }
input.span3,
textarea.span3,
.uneditable-input.span3 { width:206px }
input.span2,
textarea.span2,
.uneditable-input.span2 { width:126px }
input.span1,
textarea.span1,
.uneditable-input.span1 { width:46px }
.controls-row { *zoom:1
}
.controls-row:before,
.controls-row:after { display:table; line-height:0; content:"" }
.controls-row:after { clear:both }
.controls-row [class*="span"],
.row-fluid .controls-row [class*="span"] { float:left }
.controls-row .checkbox[class*="span"],
.controls-row .radio[class*="span"] { padding-top:5px }
input[disabled],
select[disabled],
textarea[disabled],
input[readonly],
select[readonly],
textarea[readonly] { cursor:not-allowed; background-color:#eee }
input[type="radio"][disabled],
input[type="checkbox"][disabled],
input[type="radio"][readonly],
input[type="checkbox"][readonly] { background-color:transparent }
.control-group.warning>label,
.control-group.warning .help-block,
.control-group.warning .help-inline { color:#c09853 }
.control-group.warning .checkbox,
.control-group.warning .radio,
.control-group.warning input,
.control-group.warning select,
.control-group.warning textarea { color:#c09853 }
.control-group.warning input,
.control-group.warning select,
.control-group.warning textarea { border-color:#c09853; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); box-shadow:inset 0 1px 1px rgba(0,0,0,0.075) }
.control-group.warning input:focus,
.control-group.warning select:focus,
.control-group.warning textarea:focus { border-color:#a47e3c; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #dbc59e; -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #dbc59e; box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #dbc59e }
.control-group.warning .input-prepend .add-on,
.control-group.warning .input-append .add-on { color:#c09853; background-color:#fcf8e3; border-color:#c09853 }
.control-group.error>label,
.control-group.error .help-block,
.control-group.error .help-inline { color:#b94a48 }
.control-group.error .checkbox,
.control-group.error .radio,
.control-group.error input,
.control-group.error select,
.control-group.error textarea { color:#b94a48 }
.control-group.error input,
.control-group.error select,
.control-group.error textarea { border-color:#b94a48; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); box-shadow:inset 0 1px 1px rgba(0,0,0,0.075) }
.control-group.error input:focus,
.control-group.error select:focus,
.control-group.error textarea:focus { border-color:#953b39; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #d59392; -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #d59392; box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #d59392 }
.control-group.error .input-prepend .add-on,
.control-group.error .input-append .add-on { color:#b94a48; background-color:#f2dede; border-color:#b94a48 }
.control-group.success>label,
.control-group.success .help-block,
.control-group.success .help-inline { color:#468847 }
.control-group.success .checkbox,
.control-group.success .radio,
.control-group.success input,
.control-group.success select,
.control-group.success textarea { color:#468847 }
.control-group.success input,
.control-group.success select,
.control-group.success textarea { border-color:#468847; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); box-shadow:inset 0 1px 1px rgba(0,0,0,0.075) }
.control-group.success input:focus,
.control-group.success select:focus,
.control-group.success textarea:focus { border-color:#356635; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #7aba7b; -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #7aba7b; box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #7aba7b }
.control-group.success .input-prepend .add-on,
.control-group.success .input-append .add-on { color:#468847; background-color:#dff0d8; border-color:#468847 }
.control-group.info>label,
.control-group.info .help-block,
.control-group.info .help-inline { color:#3a87ad }
.control-group.info .checkbox,
.control-group.info .radio,
.control-group.info input,
.control-group.info select,
.control-group.info textarea { color:#3a87ad }
.control-group.info input,
.control-group.info select,
.control-group.info textarea { border-color:#3a87ad; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075); box-shadow:inset 0 1px 1px rgba(0,0,0,0.075) }
.control-group.info input:focus,
.control-group.info select:focus,
.control-group.info textarea:focus { border-color:#2d6987; -webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #7ab5d3; -moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #7ab5d3; box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0 0 6px #7ab5d3 }
.control-group.info .input-prepend .add-on,
.control-group.info .input-append .add-on { color:#3a87ad; background-color:#d9edf7; border-color:#3a87ad }
input:focus:required:invalid, textarea:focus:required:invalid, select:focus:required:invalid {
color:#b94a48;
border-color:#ee5f5b
}
input:focus:required:invalid:focus, textarea:focus:required:invalid:focus, select:focus:required:invalid:focus {
border-color:#e9322d;
-webkit-box-shadow:0 0 6px #f8b9b7;
-moz-box-shadow:0 0 6px #f8b9b7;
box-shadow:0 0 6px #f8b9b7
}
.form-actions { padding:19px 20px 20px; margin-top:20px; margin-bottom:20px; background-color:#f5f5f5; border-top:1px solid #e5e5e5; *zoom:1
}
.form-actions:before,
.form-actions:after { display:table; line-height:0; content:"" }
.form-actions:after { clear:both }
.help-block,
.help-inline { color:#595959 }
.help-block { display:block; margin-bottom:10px }
.help-inline { display:inline-block; *display:inline;
padding-left:5px; vertical-align:middle; *zoom:1
}
.input-append,
.input-prepend { margin-bottom:5px; font-size:0; white-space:nowrap }
.input-append input,
.input-prepend input,
.input-append select,
.input-prepend select,
.input-append .uneditable-input,
.input-prepend .uneditable-input,
.input-append .dropdown-menu,
.input-prepend .dropdown-menu { font-size:14px }
.input-append input,
.input-prepend input,
.input-append select,
.input-prepend select,
.input-append .uneditable-input,
.input-prepend .uneditable-input { position:relative; margin-bottom:0; *margin-left:0;
vertical-align:top; -webkit-border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; border-radius:0 4px 4px 0 }
.input-append input:focus,
.input-prepend input:focus,
.input-append select:focus,
.input-prepend select:focus,
.input-append .uneditable-input:focus,
.input-prepend .uneditable-input:focus { z-index:2 }
.input-append .add-on,
.input-prepend .add-on { display:inline-block; width:auto; height:20px; min-width:16px; padding:4px 5px; font-size:14px; font-weight:normal; line-height:20px; text-align:center; text-shadow:0 1px 0 #fff; background-color:#eee; border:1px solid #ccc }
.input-append .add-on,
.input-prepend .add-on,
.input-append .btn,
.input-prepend .btn { vertical-align:top; -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.input-append .active,
.input-prepend .active { background-color:#a9dba9; border-color:#46a546 }
.input-prepend .add-on,
.input-prepend .btn { margin-right:-1px }
.input-prepend .add-on:first-child,
.input-prepend .btn:first-child { -webkit-border-radius:4px 0 0 4px; -moz-border-radius:4px 0 0 4px; border-radius:4px 0 0 4px }
.input-append input,
.input-append select,
.input-append .uneditable-input { -webkit-border-radius:4px 0 0 4px; -moz-border-radius:4px 0 0 4px; border-radius:4px 0 0 4px }
.input-append input+.btn-group .btn,
.input-append select+.btn-group .btn,
.input-append .uneditable-input+.btn-group .btn { -webkit-border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; border-radius:0 4px 4px 0 }
.input-append .add-on,
.input-append .btn,
.input-append .btn-group { margin-left:-1px }
.input-append .add-on:last-child,
.input-append .btn:last-child { -webkit-border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; border-radius:0 4px 4px 0 }
.input-prepend.input-append input,
.input-prepend.input-append select,
.input-prepend.input-append .uneditable-input { -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.input-prepend.input-append input+.btn-group .btn,
.input-prepend.input-append select+.btn-group .btn,
.input-prepend.input-append .uneditable-input+.btn-group .btn { -webkit-border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; border-radius:0 4px 4px 0 }
.input-prepend.input-append .add-on:first-child,
.input-prepend.input-append .btn:first-child { margin-right:-1px; -webkit-border-radius:4px 0 0 4px; -moz-border-radius:4px 0 0 4px; border-radius:4px 0 0 4px }
.input-prepend.input-append .add-on:last-child,
.input-prepend.input-append .btn:last-child { margin-left:-1px; -webkit-border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; border-radius:0 4px 4px 0 }
.input-prepend.input-append .btn-group:first-child { margin-left:0 }
input.search-query { padding-right:14px; padding-right:4px \9; padding-left:14px; padding-left:4px \9; margin-bottom:0; -webkit-border-radius:15px; -moz-border-radius:15px; border-radius:15px }
.form-search .input-append .search-query,
.form-search .input-prepend .search-query { -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.form-search .input-append .search-query { -webkit-border-radius:14px 0 0 14px; -moz-border-radius:14px 0 0 14px; border-radius:14px 0 0 14px }
.form-search .input-append .btn { -webkit-border-radius:0 14px 14px 0; -moz-border-radius:0 14px 14px 0; border-radius:0 14px 14px 0 }
.form-search .input-prepend .search-query { -webkit-border-radius:0 14px 14px 0; -moz-border-radius:0 14px 14px 0; border-radius:0 14px 14px 0 }
.form-search .input-prepend .btn { -webkit-border-radius:14px 0 0 14px; -moz-border-radius:14px 0 0 14px; border-radius:14px 0 0 14px }
.form-search input,
.form-inline input,
.form-horizontal input,
.form-search textarea,
.form-inline textarea,
.form-horizontal textarea,
.form-search select,
.form-inline select,
.form-horizontal select,
.form-search .help-inline,
.form-inline .help-inline,
.form-horizontal .help-inline,
.form-search .uneditable-input,
.form-inline .uneditable-input,
.form-horizontal .uneditable-input,
.form-search .input-prepend,
.form-inline .input-prepend,
.form-horizontal .input-prepend,
.form-search .input-append,
.form-inline .input-append,
.form-horizontal .input-append { display:inline-block; *display:inline;
margin-bottom:0; vertical-align:middle; *zoom:1
}
.form-search .hide,
.form-inline .hide,
.form-horizontal .hide { display:none }
.form-search label,
.form-inline label,
.form-search .btn-group,
.form-inline .btn-group { display:inline-block }
.form-search .input-append,
.form-inline .input-append,
.form-search .input-prepend,
.form-inline .input-prepend { margin-bottom:0 }
.form-search .radio,
.form-search .checkbox,
.form-inline .radio,
.form-inline .checkbox { padding-left:0; margin-bottom:0; vertical-align:middle }
.form-search .radio input[type="radio"],
.form-search .checkbox input[type="checkbox"],
.form-inline .radio input[type="radio"],
.form-inline .checkbox input[type="checkbox"] { float:left; margin-right:3px; margin-left:0 }
.control-group { margin-bottom:10px }
legend+.control-group { margin-top:20px; -webkit-margin-top-collapse:separate }
.form-horizontal .control-group { margin-bottom:20px; *zoom:1
}
.form-horizontal .control-group:before,
.form-horizontal .control-group:after { display:table; line-height:0; content:"" }
.form-horizontal .control-group:after { clear:both }
.form-horizontal .control-label { float:left; width:160px; padding-top:5px; text-align:right }
.form-horizontal .controls {
*display:inline-block;
*padding-left:20px; margin-left:180px; *margin-left:0
}
.form-horizontal .controls:first-child { *padding-left:180px
}
.form-horizontal .help-block { margin-bottom:0 }
.form-horizontal input+.help-block,
.form-horizontal select+.help-block,
.form-horizontal textarea+.help-block { margin-top:10px }
.form-horizontal .form-actions { padding-left:20px }
table { max-width:100%; background-color:transparent; border-collapse:collapse; border-spacing:0 }
.table { width:100%; margin-bottom:20px }
.table th,
.table td { padding:8px; line-height:20px; text-align:left; vertical-align:top; border-top:1px solid #ddd }
.table th { font-weight:bold }
.table thead th { vertical-align:bottom }
.table caption+thead tr:first-child th,
.table caption+thead tr:first-child td,
.table colgroup+thead tr:first-child th,
.table colgroup+thead tr:first-child td,
.table thead:first-child tr:first-child th,
.table thead:first-child tr:first-child td { border-top:0 }
.table tbody+tbody { border-top:2px solid #ddd }
.table-condensed th,
.table-condensed td { padding:4px 5px }
.table-bordered { border:1px solid #ddd; border-collapse:separate; *border-collapse:collapse;
border-left:0; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px }
.table-bordered th,
.table-bordered td { border-left:1px solid #ddd }
.table-bordered caption+thead tr:first-child th,
.table-bordered caption+tbody tr:first-child th,
.table-bordered caption+tbody tr:first-child td,
.table-bordered colgroup+thead tr:first-child th,
.table-bordered colgroup+tbody tr:first-child th,
.table-bordered colgroup+tbody tr:first-child td,
.table-bordered thead:first-child tr:first-child th,
.table-bordered tbody:first-child tr:first-child th,
.table-bordered tbody:first-child tr:first-child td { border-top:0 }
.table-bordered thead:first-child tr:first-child th:first-child,
.table-bordered tbody:first-child tr:first-child td:first-child { -webkit-border-top-left-radius:4px; border-top-left-radius:4px; -moz-border-radius-topleft:4px }
.table-bordered thead:first-child tr:first-child th:last-child,
.table-bordered tbody:first-child tr:first-child td:last-child { -webkit-border-top-right-radius:4px; border-top-right-radius:4px; -moz-border-radius-topright:4px }
.table-bordered thead:last-child tr:last-child th:first-child,
.table-bordered tbody:last-child tr:last-child td:first-child,
.table-bordered tfoot:last-child tr:last-child td:first-child { -webkit-border-radius:0 0 0 4px; -moz-border-radius:0 0 0 4px; border-radius:0 0 0 4px; -webkit-border-bottom-left-radius:4px; border-bottom-left-radius:4px; -moz-border-radius-bottomleft:4px }
.table-bordered thead:last-child tr:last-child th:last-child,
.table-bordered tbody:last-child tr:last-child td:last-child,
.table-bordered tfoot:last-child tr:last-child td:last-child { -webkit-border-bottom-right-radius:4px; border-bottom-right-radius:4px; -moz-border-radius-bottomright:4px }
.table-bordered caption+thead tr:first-child th:first-child,
.table-bordered caption+tbody tr:first-child td:first-child,
.table-bordered colgroup+thead tr:first-child th:first-child,
.table-bordered colgroup+tbody tr:first-child td:first-child { -webkit-border-top-left-radius:4px; border-top-left-radius:4px; -moz-border-radius-topleft:4px }
.table-bordered caption+thead tr:first-child th:last-child,
.table-bordered caption+tbody tr:first-child td:last-child,
.table-bordered colgroup+thead tr:first-child th:last-child,
.table-bordered colgroup+tbody tr:first-child td:last-child { -webkit-border-top-right-radius:4px; border-top-right-radius:4px; -moz-border-radius-topright:4px }
.table-striped tbody tr:nth-child(odd) td,
.table-striped tbody tr:nth-child(odd) th { background-color:#f9f9f9 }
.table-hover tbody tr:hover td,
.table-hover tbody tr:hover th { background-color:#f5f5f5 }
table td[class*="span"],
table th[class*="span"],
.row-fluid table td[class*="span"],
.row-fluid table th[class*="span"] { display:table-cell; float:none; margin-left:0 }
.table td.span1,
.table th.span1 { float:none; width:44px; margin-left:0 }
.table td.span2,
.table th.span2 { float:none; width:124px; margin-left:0 }
.table td.span3,
.table th.span3 { float:none; width:204px; margin-left:0 }
.table td.span4,
.table th.span4 { float:none; width:284px; margin-left:0 }
.table td.span5,
.table th.span5 { float:none; width:364px; margin-left:0 }
.table td.span6,
.table th.span6 { float:none; width:444px; margin-left:0 }
.table td.span7,
.table th.span7 { float:none; width:524px; margin-left:0 }
.table td.span8,
.table th.span8 { float:none; width:604px; margin-left:0 }
.table td.span9,
.table th.span9 { float:none; width:684px; margin-left:0 }
.table td.span10,
.table th.span10 { float:none; width:764px; margin-left:0 }
.table td.span11,
.table th.span11 { float:none; width:844px; margin-left:0 }
.table td.span12,
.table th.span12 { float:none; width:924px; margin-left:0 }
.table tbody tr.success td { background-color:#dff0d8 }
.table tbody tr.error td { background-color:#f2dede }
.table tbody tr.warning td { background-color:#fcf8e3 }
.table tbody tr.info td { background-color:#d9edf7 }
.table-hover tbody tr.success:hover td { background-color:#d0e9c6 }
.table-hover tbody tr.error:hover td { background-color:#ebcccc }
.table-hover tbody tr.warning:hover td { background-color:#faf2cc }
.table-hover tbody tr.info:hover td { background-color:#c4e3f3 }
[class^="icon-"], [class*=" icon-"] {
display:inline-block;
width:14px;
height:14px;
margin-top:1px;
*margin-right:.3em;
line-height:14px;
vertical-align:text-top;
background-image:url("../img/glyphicons-halflings.png");
background-position:14px 14px;
background-repeat:no-repeat
}
.icon-white, .nav-pills>.active>a>[class^="icon-"], .nav-pills>.active>a>[class*=" icon-"], .nav-list>.active>a>[class^="icon-"], .nav-list>.active>a>[class*=" icon-"], .navbar-inverse .nav>.active>a>[class^="icon-"], .navbar-inverse .nav>.active>a>[class*=" icon-"], .dropdown-menu>li>a:hover>[class^="icon-"], .dropdown-menu>li>a:hover>[class*=" icon-"], .dropdown-menu>.active>a>[class^="icon-"], .dropdown-menu>.active>a>[class*=" icon-"], .dropdown-submenu:hover>a>[class^="icon-"], .dropdown-submenu:hover>a>[class*=" icon-"] {
background-image:url("../img/glyphicons-halflings-white.png")
}
.icon-glass { background-position:0 0 }
.icon-music { background-position:-24px 0 }
.icon-search { background-position:-48px 0 }
.icon-envelope { background-position:-72px 0 }
.icon-heart { background-position:-96px 0 }
.icon-star { background-position:-120px 0 }
.icon-star-empty { background-position:-144px 0 }
.icon-user { background-position:-168px 0 }
.icon-film { background-position:-192px 0 }
.icon-th-large { background-position:-216px 0 }
.icon-th { background-position:-240px 0 }
.icon-th-list { background-position:-264px 0 }
.icon-ok { background-position:-288px 0 }
.icon-remove { background-position:-312px 0 }
.icon-zoom-in { background-position:-336px 0 }
.icon-zoom-out { background-position:-360px 0 }
.icon-off { background-position:-384px 0 }
.icon-signal { background-position:-408px 0 }
.icon-cog { background-position:-432px 0 }
.icon-trash { background-position:-456px 0 }
.icon-home { background-position:0 -24px }.icon-home2 { background-position:0 -168px }
.icon-file { background-position:-24px -24px }
.icon-time { background-position:-48px -24px }
.icon-road { background-position:-72px -24px }
.icon-download-alt { background-position:-96px -24px }
.icon-download { background-position:-120px -24px }
.icon-upload { background-position:-144px -24px }
.icon-inbox { background-position:-168px -24px }
.icon-play-circle { background-position:-192px -24px }
.icon-repeat { background-position:-216px -24px }
.icon-refresh { background-position:-240px -24px }
.icon-list-alt { background-position:-264px -24px }
.icon-lock { background-position:-287px -24px }
.icon-flag { background-position:-312px -24px }
.icon-headphones { background-position:-336px -24px }
.icon-volume-off { background-position:-360px -24px }
.icon-volume-down { background-position:-384px -24px }
.icon-volume-up { background-position:-408px -24px }
.icon-qrcode { background-position:-432px -24px }
.icon-barcode { background-position:-456px -24px }
.icon-tag { background-position:0 -48px }
.icon-tags { background-position:-25px -48px }
.icon-book { background-position:-48px -48px }
.icon-bookmark { background-position:-72px -48px }
.icon-print { background-position:-96px -48px }
.icon-camera { background-position:-120px -48px }
.icon-font { background-position:-144px -48px }
.icon-bold { background-position:-167px -48px }
.icon-italic { background-position:-192px -48px }
.icon-text-height { background-position:-216px -48px }
.icon-text-width { background-position:-240px -48px }
.icon-align-left { background-position:-264px -48px }
.icon-align-center { background-position:-288px -48px }
.icon-align-right { background-position:-312px -48px }
.icon-align-justify { background-position:-336px -48px }
.icon-list { background-position:-360px -48px }
.icon-indent-left { background-position:-384px -48px }
.icon-indent-right { background-position:-408px -48px }
.icon-facetime-video { background-position:-432px -48px }
.icon-picture { background-position:-456px -48px }
.icon-pencil { background-position:0 -72px }
.icon-map-marker { background-position:-24px -72px }
.icon-adjust { background-position:-48px -72px }
.icon-tint { background-position:-72px -72px }
.icon-edit { background-position:-96px -72px }
.icon-share { background-position:-120px -72px }
.icon-check { background-position:-144px -72px }
.icon-move { background-position:-168px -72px }
.icon-step-backward { background-position:-192px -72px }
.icon-fast-backward { background-position:-216px -72px }
.icon-backward { background-position:-240px -72px }
.icon-play { background-position:-264px -72px }
.icon-pause { background-position:-288px -72px }
.icon-stop { background-position:-312px -72px }
.icon-forward { background-position:-336px -72px }
.icon-fast-forward { background-position:-360px -72px }
.icon-step-forward { background-position:-384px -72px }
.icon-eject { background-position:-408px -72px }
.icon-chevron-left { background-position:-432px -72px }
.icon-chevron-right { background-position:-456px -72px }
.icon-plus-sign { background-position:0 -96px }
.icon-minus-sign { background-position:-24px -96px }
.icon-remove-sign { background-position:-48px -96px }
.icon-ok-sign { background-position:-72px -96px }
.icon-question-sign { background-position:-96px -96px }
.icon-info-sign { background-position:-120px -96px }
.icon-screenshot { background-position:-144px -96px }
.icon-remove-circle { background-position:-168px -96px }
.icon-ok-circle { background-position:-192px -96px }
.icon-ban-circle { background-position:-216px -96px }
.icon-arrow-left { background-position:-240px -96px }
.icon-arrow-right { background-position:-264px -96px }
.icon-arrow-up { background-position:-289px -96px }
.icon-arrow-down { background-position:-312px -96px }
.icon-share-alt { background-position:-336px -96px }
.icon-resize-full { background-position:-360px -96px }
.icon-resize-small { background-position:-384px -96px }
.icon-plus { background-position:-408px -96px }
.icon-minus { background-position:-433px -96px }
.icon-asterisk { background-position:-456px -96px }
.icon-exclamation-sign { background-position:0 -120px }
.icon-gift { background-position:-24px -120px }
.icon-leaf { background-position:-48px -120px }
.icon-fire { background-position:-72px -120px }
.icon-eye-open { background-position:-96px -120px }
.icon-eye-close { background-position:-120px -120px }
.icon-warning-sign { background-position:-144px -120px }
.icon-plane { background-position:-168px -120px }
.icon-calendar { background-position:-192px -120px }
.icon-random { width:16px; background-position:-216px -120px }
.icon-comment { background-position:-240px -120px }
.icon-magnet { background-position:-264px -120px }
.icon-chevron-up { background-position:-288px -120px }
.icon-chevron-down { background-position:-313px -119px }
.icon-retweet { background-position:-336px -120px }
.icon-shopping-cart { background-position:-360px -120px }
.icon-folder-close { background-position:-384px -120px }
.icon-folder-open { width:16px; background-position:-408px -120px }
.icon-resize-vertical { background-position:-432px -119px }
.icon-resize-horizontal { background-position:-456px -118px }
.icon-hdd { background-position:0 -144px }
.icon-bullhorn { background-position:-24px -144px }
.icon-bell { background-position:-48px -144px }
.icon-certificate { background-position:-72px -144px }
.icon-thumbs-up { background-position:-96px -144px }
.icon-thumbs-down { background-position:-120px -144px }
.icon-hand-right { background-position:-144px -144px }
.icon-hand-left { background-position:-168px -144px }
.icon-hand-up { background-position:-192px -144px }
.icon-hand-down { background-position:-216px -144px }
.icon-circle-arrow-right { background-position:-240px -144px }
.icon-circle-arrow-left { background-position:-264px -144px }
.icon-circle-arrow-up { background-position:-288px -144px }
.icon-circle-arrow-down { background-position:-312px -144px }
.icon-globe { background-position:-336px -144px }
.icon-wrench { background-position:-360px -144px }
.icon-tasks { background-position:-384px -144px }
.icon-filter { background-position:-408px -144px }
.icon-briefcase { background-position:-432px -144px }
.icon-fullscreen { background-position:-456px -144px }
.dropup,
.dropdown { position:relative }
.dropdown-toggle { *margin-bottom:-3px
}
.dropdown-toggle:active,
.open .dropdown-toggle { outline:0 }
.caret { display:inline-block; width:0; height:0; vertical-align:top; border-top:4px solid #000; border-right:4px solid transparent; border-left:4px solid transparent; content:"" }
.dropdown .caret { margin-top:8px; margin-left:2px }
.dropdown-menu { position:absolute; top:100%; left:0; z-index:1000; display:none; float:left; min-width:160px; padding:5px 0; margin:2px 0 0; list-style:none; background-color:#fff; border:1px solid #ccc; border:1px solid rgba(0,0,0,0.2); *border-right-width:2px;
*border-bottom-width:2px;
-webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px; -webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2); -moz-box-shadow:0 5px 10px rgba(0,0,0,0.2); box-shadow:0 5px 10px rgba(0,0,0,0.2); -webkit-background-clip:padding-box; -moz-background-clip:padding; background-clip:padding-box }
.dropdown-menu.pull-right { right:0; left:auto }
.dropdown-menu .divider {
*width:100%; height:1px; margin:9px 1px; *margin:-5px 0 5px;
overflow:hidden; background-color:#e5e5e5; border-bottom:1px solid #fff }
.dropdown-menu li>a { display:block; padding:3px 20px; clear:both; font-weight:normal; line-height:20px; color:#333; white-space:nowrap }
.dropdown-menu li>a:hover,
.dropdown-menu li>a:focus,
.dropdown-submenu:hover>a { color:#fff; text-decoration:none; background-color:#0081c2; background-repeat: repeat-x;
    background-image: linear-gradient(to bottom, #08c, #0077b3);
}
.dropdown-menu .active>a,
.dropdown-menu .active>a:hover { color:#333; text-decoration:none; background-color:#0081c2; background-repeat: repeat-x;
    outline: 0;
    background-image: linear-gradient(to bottom, #08c, #0077b3);
}
.dropdown-menu .disabled>a,
.dropdown-menu .disabled>a:hover { color:#999 }
.dropdown-menu .disabled>a:hover { text-decoration:none; cursor:default; background-color:transparent; background-image:none }
.open { *z-index:1000
}
.open>.dropdown-menu { display:block }
.pull-right>.dropdown-menu { right:0; left:auto }
.dropup .caret,
.navbar-fixed-bottom .dropdown .caret { border-top:0; border-bottom:4px solid #000; content:"" }
.dropup .dropdown-menu,
.navbar-fixed-bottom .dropdown .dropdown-menu { top:auto; bottom:100%; margin-bottom:1px }
.dropdown-submenu { position:relative }
.dropdown-submenu>.dropdown-menu { top:0; left:100%; margin-top:-6px; margin-left:-1px; -webkit-border-radius:0 6px 6px 6px; -moz-border-radius:0 6px 6px 6px; border-radius:0 6px 6px 6px }
.dropdown-submenu:hover>.dropdown-menu { display:block }
.dropup .dropdown-submenu>.dropdown-menu { top:auto; bottom:0; margin-top:0; margin-bottom:-2px; -webkit-border-radius:5px 5px 5px 0; -moz-border-radius:5px 5px 5px 0; border-radius:5px 5px 5px 0 }
.dropdown-submenu>a:after { display:block; float:right; width:0; height:0; margin-top:5px; margin-right:-10px; border-color:transparent; border-left-color:#ccc; border-style:solid; border-width:5px 0 5px 5px; content:" " }
.dropdown-submenu:hover>a:after { border-left-color:#fff }
.dropdown-submenu.pull-left { float:none }
.dropdown-submenu.pull-left>.dropdown-menu { left:-100%; margin-left:10px; -webkit-border-radius:6px 0 6px 6px; -moz-border-radius:6px 0 6px 6px; border-radius:6px 0 6px 6px }
.dropdown .dropdown-menu .nav-header { padding-right:20px; padding-left:20px }
.typeahead { margin-top:2px; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px }
.well { min-height:20px; padding:19px; margin-bottom:20px; background-color:#f5f5f5; border:1px solid #e3e3e3; }
.well blockquote { border-color:#ddd; border-color:rgba(0,0,0,0.15) }
.well-large { padding:24px; -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px }
.well-small { padding:9px; -webkit-border-radius:3px; -moz-border-radius:3px; border-radius:3px }
.fade { opacity:0; -webkit-transition:opacity .15s linear; -moz-transition:opacity .15s linear; -o-transition:opacity .15s linear; transition:opacity .15s linear }
.fade.in { opacity:1 }
.collapse { position:relative; height:0; overflow:hidden; -webkit-transition:height .35s ease; -moz-transition:height .35s ease; -o-transition:height .35s ease; transition:height .35s ease }
.collapse.in { height:auto }
.close { float:right; font-size:20px; font-weight:bold; line-height:20px; color:#000; text-shadow:0 1px 0 #fff; opacity:.2; filter:alpha(opacity=20) }
.close:hover { color:#000; text-decoration:none; cursor:pointer; opacity:.4; filter:alpha(opacity=40) }
button.close { padding:0; cursor:pointer; background:transparent; border:0; -webkit-appearance:none }
.btn { display:inline-block; *display:inline; padding:6px 12px;   *margin-left:.3em; font-size:14px; line-height:20px; *line-height:20px; color:#333; text-align:center; text-shadow:0 1px 1px rgba(255,255,255,0.75); vertical-align:middle; cursor:pointer; background-color:#dadada; *background-color:#dadada; }
.btn:hover,
.btn:active,
.btn.active,
.btn.disabled,
.btn[disabled] { color:#333; background-color:#e6e6e6; *background-color:#d9d9d9; }
.btn:active,
.btn.active { background-color:#ccc \9 }
.btn:first-child { *margin-left:0}
.btn:hover { color:#333; text-decoration:none; background-color:#e6e6e6; *background-color:#d9d9d9; }
.btn:focus { outline:thin dotted #333; outline:5px auto -webkit-focus-ring-color; outline-offset:-2px }
.btn.active,
.btn:active { background-color:#e6e6e6; background-color:#d9d9d9 \9; background-image:none; outline:0; -webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.05); -moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.05); box-shadow:inset 0 2px 4px rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.05) }
.btn.disabled,
.btn[disabled] { cursor:default; background-color:#e6e6e6; background-image:none; opacity:.65; filter:alpha(opacity=65); -webkit-box-shadow:none; -moz-box-shadow:none; box-shadow:none }
.btn-large { padding:11px 19px; font-size:17.5px; -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:0px }
.btn-large [class^="icon-"],
.btn-large [class*=" icon-"] { margin-top:2px }
.btn-small { padding:2px 10px; font-size:11.9px; -webkit-border-radius:3px; -moz-border-radius:3px; border-radius:0px }
.btn-small [class^="icon-"],
.btn-small [class*=" icon-"] { margin-top:0 }
.btn-mini { padding:1px 6px; font-size:10.5px; -webkit-border-radius:3px; -moz-border-radius:3px; border-radius:0px }
.btn-block { display:block; width:100%; padding-right:0; padding-left:0; -webkit-box-sizing:border-box; -moz-box-sizing:border-box; box-sizing:border-box }
.btn-block+.btn-block { margin-top:5px }
input[type="submit"].btn-block,
input[type="reset"].btn-block,
input[type="button"].btn-block { width:100% }
.btn-primary.active,
.btn-warning.active,
.btn-danger.active,
.btn-success.active,
.btn-info.active,
.btn-inverse.active { color:rgba(255,255,255,0.75) }
.btn { border:none}
.btn-primary { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#006dcc; *background-color:#04c;}
.btn-primary:hover,
.btn-primary:active,
.btn-primary.active,
.btn-primary.disabled,
.btn-primary[disabled] { color:#fff; background-color:#04c; *background-color:#003bb3
}
.btn-primary:active,
.btn-primary.active { background-color:#039 \9 }
.btn-warning { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#faa732; *background-color:#f89406;
/*background-image:-moz-linear-gradient(top, #fbb450, #f89406); background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406)); background-image:-webkit-linear-gradient(top, #fbb450, #f89406); background-image:-o-linear-gradient(top, #fbb450, #f89406); background-image:linear-gradient(to bottom, #fbb450, #f89406); background-repeat:repeat-x; border-color:#f89406 #f89406 #ad6704; border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25); filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450', endColorstr='#fff89406', GradientType=0);
filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)*/
}
.btn-warning:hover,
.btn-warning:active,
.btn-warning.active,
.btn-warning.disabled,
.btn-warning[disabled] { color:#fff; background-color:#f89406; *background-color:#df8505
}
.btn-warning:active,
.btn-warning.active { background-color:#c67605 \9 }
.btn-danger { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#da4f49; *background-color:#bd362f;
/*background-image:-moz-linear-gradient(top, #ee5f5b, #bd362f); background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#ee5f5b), to(#bd362f)); background-image:-webkit-linear-gradient(top, #ee5f5b, #bd362f); background-image:-o-linear-gradient(top, #ee5f5b, #bd362f); background-image:linear-gradient(to bottom, #ee5f5b, #bd362f); background-repeat:repeat-x; border-color:#bd362f #bd362f #802420; border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25); filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b', endColorstr='#ffbd362f', GradientType=0);
filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)*/
}
.btn-danger:hover,
.btn-danger:active,
.btn-danger.active,
.btn-danger.disabled,
.btn-danger[disabled] { color:#fff; background-color:#bd362f; *background-color:#a9302a
}
.btn-danger:active,
.btn-danger.active { background-color:#942a25 \9 }

.btn-success { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#5bb75b; *background-color:#51a351;
/*background-image:-moz-linear-gradient(top, #62c462, #51a351); background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#62c462), to(#51a351)); background-image:-webkit-linear-gradient(top, #62c462, #51a351); background-image:-o-linear-gradient(top, #62c462, #51a351); background-image:linear-gradient(to bottom, #62c462, #51a351); background-repeat:repeat-x; border-color:#51a351 #51a351 #387038; border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25); filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462', endColorstr='#ff51a351', GradientType=0);
filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)*/
}
.btn-success:hover,
.btn-success:active,
.btn-success.active,
.btn-success.disabled,
.btn-success[disabled] { color:#fff; background-color:#51a351; *background-color:#499249
}
.btn-success:active,
.btn-success.active { background-color:#408140 \9 }

.btn-info { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#49afcd; *background-color:#2f96b4;
/*background-image:-moz-linear-gradient(top, #5bc0de, #2f96b4); background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#5bc0de), to(#2f96b4)); background-image:-webkit-linear-gradient(top, #5bc0de, #2f96b4); background-image:-o-linear-gradient(top, #5bc0de, #2f96b4); background-image:linear-gradient(to bottom, #5bc0de, #2f96b4); background-repeat:repeat-x; border-color:#2f96b4 #2f96b4 #1f6377; border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25); filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de', endColorstr='#ff2f96b4', GradientType=0);
filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)*/
}
.btn-info:hover,
.btn-info:active,
.btn-info.active,
.btn-info.disabled,
.btn-info[disabled] { color:#fff; background-color:#2f96b4; *background-color:#2a85a0}
.btn-info:active,
.btn-info.active { background-color:#24748c \9 }

.btn-inverse { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#363636; *background-color:#222;
/*background-image:-moz-linear-gradient(top, #444, #222); background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#444), to(#222)); background-image:-webkit-linear-gradient(top, #444, #222); background-image:-o-linear-gradient(top, #444, #222); background-image:linear-gradient(to bottom, #444, #222); background-repeat:repeat-x; border-color:#222 #222 #000; border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25); filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff444444', endColorstr='#ff222222', GradientType=0);
filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)*/
}
.btn-inverse:hover,
.btn-inverse:active,
.btn-inverse.active,
.btn-inverse.disabled,
.btn-inverse[disabled] { color:#fff; background-color:#222; *background-color:#151515
}
.btn-inverse:active,
.btn-inverse.active { background-color:#080808 \9 }
button.btn,
input[type="submit"].btn { *padding-top:3px;
*padding-bottom:3px
}
button.btn::-moz-focus-inner, input[type="submit"].btn::-moz-focus-inner {
padding:0;
border:0
}
button.btn.btn-large,
input[type="submit"].btn.btn-large { *padding-top:7px;
*padding-bottom:7px
}
button.btn.btn-small,
input[type="submit"].btn.btn-small { *padding-top:3px;
*padding-bottom:3px
}
button.btn.btn-mini,
input[type="submit"].btn.btn-mini { *padding-top:1px;
*padding-bottom:1px
}
.btn-link,
.btn-link:active,
.btn-link[disabled] { background-color:transparent; background-image:none; -webkit-box-shadow:none; -moz-box-shadow:none; box-shadow:none }
.btn-link { color: #999; cursor:pointer; border-color:transparent; -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.btn-link:hover { color:#FFFFFF; //text-decoration:underline; background-color:transparent }
.btn-link[disabled]:hover { color:#333; text-decoration:none }
.btn-group { position:relative; display:inline-block; *display:inline; *margin-left:.3em;font-size:0; white-space:nowrap; vertical-align:middle; *zoom:1;}
.btn-group:first-child { *margin-left:0
}
.btn-group+.btn-group { margin-left:5px }
.btn-toolbar { margin-top:10px; margin-bottom:10px; font-size:0 }
.btn-toolbar .btn+.btn,
.btn-toolbar .btn-group+.btn,
.btn-toolbar .btn+.btn-group { margin-left:5px }
.btn-group>.btn { position:relative; -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.btn-group>.btn+.btn { margin-left:-1px }
.btn-group>.btn,
.btn-group>.dropdown-menu { font-size:14px }
.btn-group>.btn-mini { font-size:11px }
.btn-group>.btn-small { font-size:12px }
.btn-group>.btn-large { font-size:16px }
.btn-group>.btn:first-child { margin-left:0;}
.btn-group>.btn:last-child,
.btn-group>.dropdown-toggle {}
.btn-group>.btn.large:first-child { margin-left:0; -webkit-border-bottom-left-radius:6px; border-bottom-left-radius:6px; -webkit-border-top-left-radius:6px; border-top-left-radius:6px; -moz-border-radius-bottomleft:6px; -moz-border-radius-topleft:6px }
.btn-group>.btn.large:last-child,
.btn-group>.large.dropdown-toggle { -webkit-border-top-right-radius:6px; border-top-right-radius:6px; -webkit-border-bottom-right-radius:6px; border-bottom-right-radius:6px; -moz-border-radius-topright:6px; -moz-border-radius-bottomright:6px }
.btn-group>.btn:hover,
.btn-group>.btn:focus,
.btn-group>.btn:active,
.btn-group>.btn.active { z-index:2 }
.btn-group .dropdown-toggle:active,
.btn-group.open .dropdown-toggle { outline:0 }
.btn-group>.btn+.dropdown-toggle {
*padding-top:5px; padding-right:8px; *padding-bottom:5px;
padding-left:8px; -webkit-box-shadow:inset 1px 0 0 rgba(255,255,255,0.125), inset 0 1px 0 rgba(255,255,255,0.2), 0 1px 2px rgba(0,0,0,0.05); -moz-box-shadow:inset 1px 0 0 rgba(255,255,255,0.125), inset 0 1px 0 rgba(255,255,255,0.2), 0 1px 2px rgba(0,0,0,0.05); box-shadow:inset 1px 0 0 rgba(255,255,255,0.125), inset 0 1px 0 rgba(255,255,255,0.2), 0 1px 2px rgba(0,0,0,0.05) }
.btn-group>.btn-mini+.dropdown-toggle {
*padding-top:2px; padding-right:5px; *padding-bottom:2px;
padding-left:5px }
.btn-group>.btn-small+.dropdown-toggle { *padding-top:5px;
*padding-bottom:4px
}
.btn-group>.btn-large+.dropdown-toggle {
*padding-top:7px; padding-right:12px; *padding-bottom:7px;
padding-left:12px }
.btn-group.open .dropdown-toggle { background-image:none; -webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.05); -moz-box-shadow:inset 0 2px 4px rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.05); box-shadow:inset 0 2px 4px rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.05) }
.btn-group.open .btn.dropdown-toggle { background-color:#e6e6e6 }
.btn-group.open .btn-primary.dropdown-toggle { background-color:#04c }
.btn-group.open .btn-warning.dropdown-toggle { background-color:#f89406 }
.btn-group.open .btn-danger.dropdown-toggle { background-color:#bd362f }
.btn-group.open .btn-success.dropdown-toggle { background-color:#51a351 }
.btn-group.open .btn-info.dropdown-toggle { background-color:#2f96b4 }
.btn-group.open .btn-inverse.dropdown-toggle { background-color:#222 }
.btn .caret { margin-top:8px; margin-left:0 }
.btn-mini .caret,
.btn-small .caret,
.btn-large .caret { margin-top:6px }
.btn-large .caret { border-top-width:5px; border-right-width:5px; border-left-width:5px }
.dropup .btn-large .caret { border-bottom-width:5px }
.btn-primary .caret,
.btn-warning .caret,
.btn-danger .caret,
.btn-info .caret,
.btn-success .caret,
.btn-inverse .caret { border-top-color:#fff; border-bottom-color:#fff }
.btn-group-vertical { display:inline-block; *display:inline;
*zoom:1
}
.btn-group-vertical .btn { display:block; float:none; width:100%; -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.btn-group-vertical .btn+.btn { margin-top:-1px; margin-left:0 }
.btn-group-vertical .btn:first-child { -webkit-border-radius:4px 4px 0 0; -moz-border-radius:4px 4px 0 0; border-radius:4px 4px 0 0 }
.btn-group-vertical .btn:last-child { -webkit-border-radius:0 0 4px 4px; -moz-border-radius:0 0 4px 4px; border-radius:0 0 4px 4px }
.btn-group-vertical .btn-large:first-child { -webkit-border-radius:6px 6px 0 0; -moz-border-radius:6px 6px 0 0; border-radius:6px 6px 0 0 }
.btn-group-vertical .btn-large:last-child { -webkit-border-radius:0 0 6px 6px; -moz-border-radius:0 0 6px 6px; border-radius:0 0 6px 6px }
.alert_homepage { padding:8px 10px 8px 14px; color:#c09853; text-shadow:0 1px 0 rgba(255,255,255,0.5); background-color:#fcf8e3; border:1px solid #fbeed5; }
.alert { padding:8px 35px 8px 14px; color:#c09853; text-shadow:0 1px 0 rgba(255,255,255,0.5); background-color:#fcf8e3; border:1px solid #fbeed5; margin-bottom:20px;}
.alert h4 { margin:0 }
.alert .close { position:relative; top:-2px; right:-21px; line-height:20px }
.alert-success { color:#468847; background-color:#dff0d8; border-color:#d6e9c6 }
.alert-danger,
.alert-error { color:#b94a48; background-color:#f2dede; border-color:#eed3d7 }
.alert-info { color:#3a87ad; background-color:#d9edf7; border-color:#bce8f1 }
.alert-block { padding-top:14px; padding-bottom:14px }
.alert-block>p,
.alert-block>ul { margin-bottom:0 }
.alert-block p+p { margin-top:5px }
.nav { margin-bottom:20px; margin-left:0; list-style:none }
.nav>li>a { display:block }
.nav>li>a:hover { text-decoration:none; background-color:#eee }
.nav>.pull-right { float:right }
.nav-header { display:block; padding:3px 15px; font-size:11px; font-weight:bold; line-height:20px; color:#999; text-shadow:0 1px 0 rgba(255,255,255,0.5); text-transform:uppercase }
.nav li+.nav-header { margin-top:9px }
.nav-list { padding-right:15px; padding-left:15px; margin-bottom:0 }
.nav-list>li>a,
.nav-list .nav-header { margin-right:-15px; margin-left:-15px; text-shadow:0 1px 0 rgba(255,255,255,0.5) }
.nav-list>li>a { padding:3px 15px }
.nav-list>.active>a,
.nav-list>.active>a:hover { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.2); background-color:#08c }
.nav-list [class^="icon-"],
.nav-list [class*=" icon-"] { margin-right:2px }
.nav-list .divider {
*width:100%; height:1px; margin:9px 1px; *margin:-5px 0 5px;
overflow:hidden; background-color:#e5e5e5; border-bottom:1px solid #fff }
.nav-tabs,
.nav-pills { *zoom:1
}
.nav-tabs:before,
.nav-pills:before,
.nav-tabs:after,
.nav-pills:after { display:table; line-height:0; content:"" }
.nav-tabs:after,
.nav-pills:after { clear:both }
.nav-tabs>li,
.nav-pills>li { float:left }
.nav-tabs>li>a,
.nav-pills>li>a { padding-right:12px; padding-left:12px; margin-right:2px; line-height:14px }
.nav-tabs { border-bottom:1px solid #ddd }
.nav-tabs>li { margin-bottom:-1px }
.nav-tabs>li>a { padding-top:8px; padding-bottom:8px; line-height:20px; border:1px solid transparent; -webkit-border-radius:4px 4px 0 0; -moz-border-radius:4px 4px 0 0; border-radius:4px 4px 0 0 }
.nav-tabs>li>a:hover { border-color:#eee #eee #ddd }
.nav-tabs>.active>a,
.nav-tabs>.active>a:hover { color:#555; cursor:default; background-color:#fff; border:1px solid #ddd; border-bottom-color:transparent }
.nav-pills>li>a { padding-top:8px; padding-bottom:8px; margin-top:2px; margin-bottom:2px; -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:5px }
.nav-pills>.active>a,
.nav-pills>.active>a:hover { color:#fff; background-color:#08c }
.nav-stacked>li { float:none }
.nav-stacked>li>a { margin-right:0 }
.nav-tabs.nav-stacked { border-bottom:0 }
.nav-tabs.nav-stacked>li>a { border:1px solid #ddd; -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.nav-tabs.nav-stacked>li:first-child>a { -webkit-border-top-right-radius:4px; border-top-right-radius:4px; -webkit-border-top-left-radius:4px; border-top-left-radius:4px; -moz-border-radius-topright:4px; -moz-border-radius-topleft:4px }
.nav-tabs.nav-stacked>li:last-child>a { -webkit-border-bottom-right-radius:4px; border-bottom-right-radius:4px; -webkit-border-bottom-left-radius:4px; border-bottom-left-radius:4px; -moz-border-radius-bottomright:4px; -moz-border-radius-bottomleft:4px }
.nav-tabs.nav-stacked>li>a:hover { z-index:2; border-color:#ddd }
.nav-pills.nav-stacked>li>a { margin-bottom:3px }
.nav-pills.nav-stacked>li:last-child>a { margin-bottom:1px }
.nav-tabs .dropdown-menu { -webkit-border-radius:0 0 6px 6px; -moz-border-radius:0 0 6px 6px; border-radius:0 0 6px 6px }
.nav-pills .dropdown-menu { -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px }
.nav .dropdown-toggle .caret { margin-top:6px; border-top-color:#08c; border-bottom-color:#08c }
.nav .dropdown-toggle:hover .caret { border-top-color:#005580; border-bottom-color:#005580 }
.nav-tabs .dropdown-toggle .caret { margin-top:8px }
.nav .active .dropdown-toggle .caret { border-top-color:#fff; border-bottom-color:#fff }
.nav-tabs .active .dropdown-toggle .caret { border-top-color:#555; border-bottom-color:#555 }
.nav>.dropdown.active>a:hover { cursor:pointer }
.nav-tabs .open .dropdown-toggle,
.nav-pills .open .dropdown-toggle,
.nav>li.dropdown.open.active>a:hover { color:#fff; background-color:#999; border-color:#999 }
.nav li.dropdown.open .caret,
.nav li.dropdown.open.active .caret,
.nav li.dropdown.open a:hover .caret { border-top-color:#fff; border-bottom-color:#fff; opacity:1; filter:alpha(opacity=100) }
.tabs-stacked .open>a:hover { border-color:#999 }
.tabbable { *zoom:1
}
.tabbable:before,
.tabbable:after { display:table; line-height:0; content:"" }
.tabbable:after { clear:both }
.tab-content { overflow:auto }
.tabs-below>.nav-tabs,
.tabs-right>.nav-tabs,
.tabs-left>.nav-tabs { border-bottom:0 }
.tab-content>.tab-pane,
.pill-content>.pill-pane { display:none }
.tab-content>.active,
.pill-content>.active { display:block }
.tabs-below>.nav-tabs { border-top:1px solid #ddd }
.tabs-below>.nav-tabs>li { margin-top:-1px; margin-bottom:0 }
.tabs-below>.nav-tabs>li>a { -webkit-border-radius:0 0 4px 4px; -moz-border-radius:0 0 4px 4px; border-radius:0 0 4px 4px }
.tabs-below>.nav-tabs>li>a:hover { border-top-color:#ddd; border-bottom-color:transparent }
.tabs-below>.nav-tabs>.active>a,
.tabs-below>.nav-tabs>.active>a:hover { border-color:transparent #ddd #ddd #ddd }
.tabs-left>.nav-tabs>li,
.tabs-right>.nav-tabs>li { float:none }
.tabs-left>.nav-tabs>li>a,
.tabs-right>.nav-tabs>li>a { min-width:74px; margin-right:0; margin-bottom:3px }
.tabs-left>.nav-tabs { float:left; margin-right:19px; border-right:1px solid #ddd }
.tabs-left>.nav-tabs>li>a { margin-right:-1px; -webkit-border-radius:4px 0 0 4px; -moz-border-radius:4px 0 0 4px; border-radius:4px 0 0 4px }
.tabs-left>.nav-tabs>li>a:hover { border-color:#eee #ddd #eee #eee }
.tabs-left>.nav-tabs .active>a,
.tabs-left>.nav-tabs .active>a:hover { border-color:#ddd transparent #ddd #ddd; *border-right-color:#fff
}
.tabs-right>.nav-tabs { float:right; margin-left:19px; border-left:1px solid #ddd }
.tabs-right>.nav-tabs>li>a { margin-left:-1px; -webkit-border-radius:0 4px 4px 0; -moz-border-radius:0 4px 4px 0; border-radius:0 4px 4px 0 }
.tabs-right>.nav-tabs>li>a:hover { border-color:#eee #eee #eee #ddd }
.tabs-right>.nav-tabs .active>a,
.tabs-right>.nav-tabs .active>a:hover { border-color:#ddd #ddd #ddd transparent; *border-left-color:#fff
}
.nav>.disabled>a { color:#999 }
.nav>.disabled>a:hover { text-decoration:none; cursor:default; background-color:transparent }
.navbar {
*position:relative;
*z-index:2; margin-bottom:20px; overflow:visible; color:#777 }
.navbar-inner { min-height:40px; padding-right:20px; padding-left:20px; background-color:#fafafa; background-repeat: repeat-x;
    border: 1px solid #d4d4d4;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    zoom: 1;
    -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
    -moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.065);
    background-image: linear-gradient(to bottom, #fff, #f2f2f2);*
}
.navbar-inner:before,
.navbar-inner:after { display:table; line-height:0; content:"" }
.navbar-inner:after { clear:both }
.navbar .container { width:auto }
.nav-collapse.collapse { height:auto; overflow:visible }
.navbar .brand { display:block; float:left; padding:10px 20px 10px; margin-left:-20px; font-size:20px; font-weight:200; color:#777; text-shadow:0 1px 0 #fff }
.navbar .brand:hover { text-decoration:none }
.navbar-text { margin-bottom:0; line-height:40px }
.navbar-link { color:#777 }
.navbar-link:hover { color:#333 }
.navbar .divider-vertical { height:40px; margin:0 9px; border-right:1px solid #fff; border-left:1px solid #f2f2f2 }
.navbar .btn,
.navbar .btn-group { margin-top:5px }
.navbar .btn-group .btn,
.navbar .input-prepend .btn,
.navbar .input-append .btn { margin-top:0 }
.navbar-form { margin-bottom:0; *zoom:1
}
.navbar-form:before,
.navbar-form:after { display:table; line-height:0; content:"" }
.navbar-form:after { clear:both }
.navbar-form input,
.navbar-form select,
.navbar-form .radio,
.navbar-form .checkbox { margin-top:5px }
.navbar-form input,
.navbar-form select,
.navbar-form .btn { display:inline-block; margin-bottom:0 }
.navbar-form input[type="image"],
.navbar-form input[type="checkbox"],
.navbar-form input[type="radio"] { margin-top:3px }
.navbar-form .input-append,
.navbar-form .input-prepend { margin-top:6px; white-space:nowrap }
.navbar-form .input-append input,
.navbar-form .input-prepend input { margin-top:0 }
.navbar-search { position:relative; float:left; margin-top:5px; margin-bottom:0 }
.navbar-search .search-query { padding:4px 14px; margin-bottom:0; font-family:"Helvetica Neue", Helvetica, Arial, sans-serif; font-size:13px; font-weight:normal; line-height:1; -webkit-border-radius:15px; -moz-border-radius:15px; border-radius:15px }
.navbar-static-top { position:static; margin-bottom:0 }
.navbar-static-top .navbar-inner { -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.navbar-fixed-top,
.navbar-fixed-bottom { position:fixed; right:0; left:0; z-index:1030; margin-bottom:0 }
.navbar-fixed-top .navbar-inner,
.navbar-static-top .navbar-inner { border-width:0 0 1px }
.navbar-fixed-bottom .navbar-inner { border-width:1px 0 0 }
.navbar-fixed-top .navbar-inner,
.navbar-fixed-bottom .navbar-inner { padding-right:0; padding-left:0; -webkit-border-radius:0; -moz-border-radius:0; border-radius:0 }
.navbar-static-top .container,
.navbar-fixed-top .container,
.navbar-fixed-bottom .container { width:940px }
.navbar-fixed-top { top:0 }
.navbar-fixed-top .navbar-inner,
.navbar-static-top .navbar-inner { -webkit-box-shadow:0 1px 10px rgba(0,0,0,0.1); -moz-box-shadow:0 1px 10px rgba(0,0,0,0.1); box-shadow:0 1px 10px rgba(0,0,0,0.1) }
.navbar-fixed-bottom { bottom:0 }
.navbar-fixed-bottom .navbar-inner { -webkit-box-shadow:0 -1px 10px rgba(0,0,0,0.1); -moz-box-shadow:0 -1px 10px rgba(0,0,0,0.1); box-shadow:0 -1px 10px rgba(0,0,0,0.1) }
.navbar .nav { position:relative; right:0; display:block; float:left; margin:0 10px 0 0 }
.navbar .nav.pull-right { float:right; margin-right:0 }
.navbar .nav>li { float:left }
.navbar .nav>li>a { float:none; padding:10px 15px 10px; color:#777; text-decoration:none; text-shadow:0 1px 0 #fff }
.navbar .nav .dropdown-toggle .caret { margin-top:8px }
.navbar .nav>li>a:focus,
.navbar .nav>li>a:hover { color:#333; text-decoration:none; background-color:transparent }
.navbar .nav>.active>a,
.navbar .nav>.active>a:hover,
.navbar .nav>.active>a:focus { color:#555; text-decoration:none; background-color:#e5e5e5; -webkit-box-shadow:inset 0 3px 8px rgba(0,0,0,0.125); -moz-box-shadow:inset 0 3px 8px rgba(0,0,0,0.125); box-shadow:inset 0 3px 8px rgba(0,0,0,0.125) }
.navbar .btn-navbar { display:none; float:right; padding:7px 10px; margin-right:5px; margin-left:5px; color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#ededed; *background-color:#e5e5e5;
background-repeat:repeat-x; -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.075);
    -moz-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.075);
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1), 0 1px 0 rgba(255, 255, 255, 0.075);
    background-image: linear-gradient(to bottom, #f2f2f2, #e5e5e5);
    border-left-color: #e5e5e5;
    border-right-color: #e5e5e5;
    border-top-color: #e5e5e5;
    border-bottom-color: #bfbfbf;
}
.navbar .btn-navbar:hover,
.navbar .btn-navbar:active,
.navbar .btn-navbar.active,
.navbar .btn-navbar.disabled,
.navbar .btn-navbar[disabled] { color:#fff; background-color:#e5e5e5; *background-color:#d9d9d9
}
.navbar .btn-navbar:active,
.navbar .btn-navbar.active { background-color:#ccc \9 }
.navbar .btn-navbar .icon-bar { display:block; width:18px; height:2px; background-color:#f5f5f5; -webkit-border-radius:1px; -moz-border-radius:1px; border-radius:1px; -webkit-box-shadow:0 1px 0 rgba(0,0,0,0.25); -moz-box-shadow:0 1px 0 rgba(0,0,0,0.25); box-shadow:0 1px 0 rgba(0,0,0,0.25) }
.btn-navbar .icon-bar+.icon-bar { margin-top:3px }
.navbar .nav>li>.dropdown-menu:before { position:absolute; top:-7px; left:9px; display:inline-block; border-right:7px solid transparent; border-bottom:7px solid #ccc; border-left:7px solid transparent; border-bottom-color:rgba(0,0,0,0.2); content:'' }
.navbar .nav>li>.dropdown-menu:after { position:absolute; top:-6px; left:10px; display:inline-block; border-right:6px solid transparent; border-bottom:6px solid #fff; border-left:6px solid transparent; content:'' }
.navbar-fixed-bottom .nav>li>.dropdown-menu:before { top:auto; bottom:-7px; border-top:7px solid #ccc; border-bottom:0; border-top-color:rgba(0,0,0,0.2) }
.navbar-fixed-bottom .nav>li>.dropdown-menu:after { top:auto; bottom:-6px; border-top:6px solid #fff; border-bottom:0 }
.navbar .nav li.dropdown.open>.dropdown-toggle,
.navbar .nav li.dropdown.active>.dropdown-toggle,
.navbar .nav li.dropdown.open.active>.dropdown-toggle { color:#555; background-color:#e5e5e5 }
.navbar .nav li.dropdown>.dropdown-toggle .caret { border-top-color:#777; border-bottom-color:#777 }
.navbar .nav li.dropdown.open>.dropdown-toggle .caret,
.navbar .nav li.dropdown.active>.dropdown-toggle .caret,
.navbar .nav li.dropdown.open.active>.dropdown-toggle .caret { border-top-color:#555; border-bottom-color:#555 }
.navbar .pull-right>li>.dropdown-menu,
.navbar .nav>li>.dropdown-menu.pull-right { right:0; left:auto }
.navbar .pull-right>li>.dropdown-menu:before,
.navbar .nav>li>.dropdown-menu.pull-right:before { right:12px; left:auto }
.navbar .pull-right>li>.dropdown-menu:after,
.navbar .nav>li>.dropdown-menu.pull-right:after { right:13px; left:auto }
.navbar .pull-right>li>.dropdown-menu .dropdown-menu,
.navbar .nav>li>.dropdown-menu.pull-right .dropdown-menu { right:100%; left:auto; margin-right:-1px; margin-left:0; -webkit-border-radius:6px 0 6px 6px; -moz-border-radius:6px 0 6px 6px; border-radius:6px 0 6px 6px }
.navbar-inverse { color:#999 }
.navbar-inverse .navbar-inner { background-color:#1b1b1b; background-repeat: repeat-x;
    border-color: #252525;
    background-image: linear-gradient(to bottom, #222, #111);
}
.navbar-inverse .brand,
.navbar-inverse .nav>li>a { color:#999; text-shadow:0 -1px 0 rgba(0,0,0,0.25) }
.navbar-inverse .brand:hover,
.navbar-inverse .nav>li>a:hover { color:#fff }
.navbar-inverse .nav>li>a:focus,
.navbar-inverse .nav>li>a:hover { color:#fff; background-color:transparent }
.navbar-inverse .nav .active>a,
.navbar-inverse .nav .active>a:hover,
.navbar-inverse .nav .active>a:focus { color:#fff; background-color:#111 }
.navbar-inverse .navbar-link { color:#999 }
.navbar-inverse .navbar-link:hover { color:#fff }
.navbar-inverse .divider-vertical { border-right-color:#222; border-left-color:#111 }
.navbar-inverse .nav li.dropdown.open>.dropdown-toggle,
.navbar-inverse .nav li.dropdown.active>.dropdown-toggle,
.navbar-inverse .nav li.dropdown.open.active>.dropdown-toggle { color:#fff; background-color:#111 }
.navbar-inverse .nav li.dropdown>.dropdown-toggle .caret { border-top-color:#999; border-bottom-color:#999 }
.navbar-inverse .nav li.dropdown.open>.dropdown-toggle .caret,
.navbar-inverse .nav li.dropdown.active>.dropdown-toggle .caret,
.navbar-inverse .nav li.dropdown.open.active>.dropdown-toggle .caret { border-top-color:#fff; border-bottom-color:#fff }
.navbar-inverse .navbar-search .search-query { color:#fff; background-color:#515151; border-color:#111; -webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1), 0 1px 0 rgba(255,255,255,0.15); -moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1), 0 1px 0 rgba(255,255,255,0.15); box-shadow:inset 0 1px 2px rgba(0,0,0,0.1), 0 1px 0 rgba(255,255,255,0.15); -webkit-transition:none; -moz-transition:none; -o-transition:none; transition:none }
.navbar-inverse .navbar-search .search-query:-moz-placeholder {
color:#ccc
}
.navbar-inverse .navbar-search .search-query:-ms-input-placeholder {
color:#ccc
}
.navbar-inverse .navbar-search .search-query::-webkit-input-placeholder {
color:#ccc
}
.navbar-inverse .navbar-search .search-query:focus,
.navbar-inverse .navbar-search .search-query.focused { padding:5px 15px; color:#333; text-shadow:0 1px 0 #fff; background-color:#fff; border:0; outline:0; -webkit-box-shadow:0 0 3px rgba(0,0,0,0.15); -moz-box-shadow:0 0 3px rgba(0,0,0,0.15); box-shadow:0 0 3px rgba(0,0,0,0.15) }
.navbar-inverse .btn-navbar { color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#0e0e0e; *background-color:#040404;
background-repeat:repeat-x; background-image: linear-gradient(to bottom, #151515, #040404);
    border-left-color: #040404;
    border-right-color: #040404;
    border-top-color: #040404;
    border-bottom-color: #000;
}
.navbar-inverse .btn-navbar:hover,
.navbar-inverse .btn-navbar:active,
.navbar-inverse .btn-navbar.active,
.navbar-inverse .btn-navbar.disabled,
.navbar-inverse .btn-navbar[disabled] { color:#fff; background-color:#040404; *background-color:#000
}
.navbar-inverse .btn-navbar:active,
.navbar-inverse .btn-navbar.active { background-color:#000 \9 }
.breadcrumb { padding:8px 15px; margin:0 0 20px; list-style:none; background-color:#f5f5f5; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px }
.breadcrumb li { display:inline-block; *display:inline;
text-shadow:0 1px 0 #fff; *zoom:1
}
.breadcrumb .divider { padding:0 5px; color:#ccc }
.breadcrumb .active { color:#999 }
.pagination { margin:20px 0 }
.pagination ul { display:inline-block; *display:inline;
margin-bottom:0; margin-left:0; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px; *zoom:1;
-webkit-box-shadow:0 1px 2px rgba(0,0,0,0.05); -moz-box-shadow:0 1px 2px rgba(0,0,0,0.05); box-shadow:0 1px 2px rgba(0,0,0,0.05) }
.pagination ul>li { display:inline }
.pagination ul>li>a,
.pagination ul>li>span { float:left; padding:4px 12px; line-height:20px; text-decoration:none; background-color:#fff; border:1px solid #ddd; border-left-width:0 }
.pagination ul>li>a:hover,
.pagination ul>.active>a,
.pagination ul>.active>span { background-color:#f5f5f5 }
.pagination ul>.active>a,
.pagination ul>.active>span { color:#999; cursor:default }
.pagination ul>.disabled>span,
.pagination ul>.disabled>a,
.pagination ul>.disabled>a:hover { color:#999; cursor:default; background-color:transparent }
.pagination ul>li:first-child>a,
.pagination ul>li:first-child>span { border-left-width:1px; -webkit-border-bottom-left-radius:4px; border-bottom-left-radius:4px; -webkit-border-top-left-radius:4px; border-top-left-radius:4px; -moz-border-radius-bottomleft:4px; -moz-border-radius-topleft:4px }
.pagination ul>li:last-child>a,
.pagination ul>li:last-child>span { -webkit-border-top-right-radius:4px; border-top-right-radius:4px; -webkit-border-bottom-right-radius:4px; border-bottom-right-radius:4px; -moz-border-radius-topright:4px; -moz-border-radius-bottomright:4px }
.pagination-centered { text-align:center }
.pagination-right { text-align:right }
.pagination-large ul>li>a,
.pagination-large ul>li>span { padding:11px 19px; font-size:17.5px }
.pagination-large ul>li:first-child>a,
.pagination-large ul>li:first-child>span { -webkit-border-bottom-left-radius:6px; border-bottom-left-radius:6px; -webkit-border-top-left-radius:6px; border-top-left-radius:6px; -moz-border-radius-bottomleft:6px; -moz-border-radius-topleft:6px }
.pagination-large ul>li:last-child>a,
.pagination-large ul>li:last-child>span { -webkit-border-top-right-radius:6px; border-top-right-radius:6px; -webkit-border-bottom-right-radius:6px; border-bottom-right-radius:6px; -moz-border-radius-topright:6px; -moz-border-radius-bottomright:6px }
.pagination-mini ul>li:first-child>a,
.pagination-small ul>li:first-child>a,
.pagination-mini ul>li:first-child>span,
.pagination-small ul>li:first-child>span { -webkit-border-bottom-left-radius:3px; border-bottom-left-radius:3px; -webkit-border-top-left-radius:3px; border-top-left-radius:3px; -moz-border-radius-bottomleft:3px; -moz-border-radius-topleft:3px }
.pagination-mini ul>li:last-child>a,
.pagination-small ul>li:last-child>a,
.pagination-mini ul>li:last-child>span,
.pagination-small ul>li:last-child>span { -webkit-border-top-right-radius:3px; border-top-right-radius:3px; -webkit-border-bottom-right-radius:3px; border-bottom-right-radius:3px; -moz-border-radius-topright:3px; -moz-border-radius-bottomright:3px }
.pagination-small ul>li>a,
.pagination-small ul>li>span { padding:2px 10px; font-size:11.9px }
.pagination-mini ul>li>a,
.pagination-mini ul>li>span { padding:1px 6px; font-size:10.5px }
.pager { margin:20px 0; text-align:center; list-style:none; *zoom:1
}
.pager:before,
.pager:after { display:table; line-height:0; content:"" }
.pager:after { clear:both }
.pager li { display:inline }
.pager li>a,
.pager li>span { display:inline-block; padding:5px 14px; background-color:#fff; border:1px solid #ddd; -webkit-border-radius:15px; -moz-border-radius:15px; border-radius:15px }
.pager li>a:hover { text-decoration:none; background-color:#f5f5f5 }
.pager .next>a,
.pager .next>span { float:right }
.pager .previous>a,
.pager .previous>span { float:left }
.pager .disabled>a,
.pager .disabled>a:hover,
.pager .disabled>span { color:#999; cursor:default; background-color:#fff }
.modal-backdrop { position:fixed; top:0; right:0; bottom:0; left:0; z-index:1040; background-color:#000 }
.modal-backdrop.fade { opacity:0 }
.modal-backdrop,
.modal-backdrop.fade.in { opacity:.8; filter:alpha(opacity=80) }
.modal { position:fixed; top:50%; left:50%; z-index:1050; width:560px; margin:-250px 0 0 -280px; background-color:#fff; border:1px solid #999; border:1px solid rgba(0,0,0,0.3); *border:1px solid #999;
 outline:0; -webkit-box-shadow:0 3px 7px rgba(0,0,0,0.3); -moz-box-shadow:0 3px 7px rgba(0,0,0,0.3); box-shadow:0 3px 7px rgba(0,0,0,0.3); -webkit-background-clip:padding-box; -moz-background-clip:padding-box; background-clip:padding-box }
.modal.fade { top:-25%; -webkit-transition:opacity .3s linear, top .3s ease-out; -moz-transition:opacity .3s linear, top .3s ease-out; -o-transition:opacity .3s linear, top .3s ease-out; transition:opacity .3s linear, top .3s ease-out }
.modal.fade.in { top:50% }
.modal-header { padding:9px 15px; border-bottom:1px solid #eee }
.modal-header .close { margin-top:2px }
.modal-header h3 { margin:0; line-height:30px }
.modal-body { max-height:400px; padding:15px; overflow-y:auto }
.modal-form { margin-bottom:0 }
.modal-footer { padding:14px 15px 15px; margin-bottom:0; text-align:right; background-color:#f5f5f5; border-top:1px solid #ddd; -webkit-border-radius:0 0 6px 6px; -moz-border-radius:0 0 6px 6px; border-radius:0 0 6px 6px; *zoom:1;
-webkit-box-shadow:inset 0 1px 0 #fff; -moz-box-shadow:inset 0 1px 0 #fff; box-shadow:inset 0 1px 0 #fff }
.modal-footer:before,
.modal-footer:after { display:table; line-height:0; content:"" }
.modal-footer:after { clear:both }
.modal-footer .btn+.btn { margin-bottom:0; margin-left:5px }
.modal-footer .btn-group .btn+.btn { margin-left:-1px }
.modal-footer .btn-block+.btn-block { margin-left:0 }
.tooltip { position:absolute; z-index:1030; display:block; padding:5px; font-size:11px; opacity:0; filter:alpha(opacity=0); visibility:visible }
.tooltip.in { opacity:.8; filter:alpha(opacity=80) }
.tooltip.top { margin-top:-3px }
.tooltip.right { margin-left:3px }
.tooltip.bottom { margin-top:3px }
.tooltip.left { margin-left:-3px }
.tooltip-inner { max-width:200px; padding:3px 8px; color:#fff; text-align:center; text-decoration:none; background-color:#000; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px }
.tooltip-arrow { position:absolute; width:0; height:0; border-color:transparent; border-style:solid }
.tooltip.top .tooltip-arrow { bottom:0; left:50%; margin-left:-5px; border-top-color:#000; border-width:5px 5px 0 }
.tooltip.right .tooltip-arrow { top:50%; left:0; margin-top:-5px; border-right-color:#000; border-width:5px 5px 5px 0 }
.tooltip.left .tooltip-arrow { top:50%; right:0; margin-top:-5px; border-left-color:#000; border-width:5px 0 5px 5px }
.tooltip.bottom .tooltip-arrow { top:0; left:50%; margin-left:-5px; border-bottom-color:#000; border-width:0 5px 5px }
.popover { position:absolute; top:0; left:0; z-index:1010; display:none; width:236px; padding:1px; background-color:#fff; border:1px solid #ccc; border:1px solid rgba(0,0,0,0.2); -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px; -webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2); -moz-box-shadow:0 5px 10px rgba(0,0,0,0.2); box-shadow:0 5px 10px rgba(0,0,0,0.2); -webkit-background-clip:padding-box; -moz-background-clip:padding; background-clip:padding-box }
.popover.top { margin-top:-10px }
.popover.right { margin-left:10px }
.popover.bottom { margin-top:10px }
.popover.left { margin-left:-10px }
.popover-title { padding:8px 14px; margin:0; font-size:14px; font-weight:normal; line-height:18px; background-color:#f7f7f7; border-bottom:1px solid #ebebeb; -webkit-border-radius:5px 5px 0 0; -moz-border-radius:5px 5px 0 0; border-radius:5px 5px 0 0 }
.popover-content { padding:9px 14px }
.popover-content p,
.popover-content ul,
.popover-content ol { margin-bottom:0 }
.popover .arrow,
.popover .arrow:after { position:absolute; display:inline-block; width:0; height:0; border-color:transparent; border-style:solid }
.popover .arrow:after { z-index:-1; content:"" }
.popover.top .arrow { bottom:-10px; left:50%; margin-left:-10px; border-top-color:#fff; border-width:10px 10px 0 }
.popover.top .arrow:after { bottom:-1px; left:-11px; border-top-color:rgba(0,0,0,0.25); border-width:11px 11px 0 }
.popover.right .arrow { top:50%; left:-10px; margin-top:-10px; border-right-color:#fff; border-width:10px 10px 10px 0 }
.popover.right .arrow:after { bottom:-11px; left:-1px; border-right-color:rgba(0,0,0,0.25); border-width:11px 11px 11px 0 }
.popover.bottom .arrow { top:-10px; left:50%; margin-left:-10px; border-bottom-color:#fff; border-width:0 10px 10px }
.popover.bottom .arrow:after { top:-1px; left:-11px; border-bottom-color:rgba(0,0,0,0.25); border-width:0 11px 11px }
.popover.left .arrow { top:50%; right:-10px; margin-top:-10px; border-left-color:#fff; border-width:10px 0 10px 10px }
.popover.left .arrow:after { right:-1px; bottom:-11px; border-left-color:rgba(0,0,0,0.25); border-width:11px 0 11px 11px }
.thumbnails { margin-left:-20px; list-style:none; *zoom:1
}
.thumbnails:before,
.thumbnails:after { display:table; line-height:0; content:"" }
.thumbnails:after { clear:both }
.row-fluid .thumbnails { margin-left:0 }
.thumbnails>li { float:left; margin-bottom:20px; margin-left:20px }
.thumbnail { display:block; padding:4px; line-height:20px; border:1px solid #ddd; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px; -webkit-box-shadow:0 1px 3px rgba(0,0,0,0.055); -moz-box-shadow:0 1px 3px rgba(0,0,0,0.055); box-shadow:0 1px 3px rgba(0,0,0,0.055); -webkit-transition:all .2s ease-in-out; -moz-transition:all .2s ease-in-out; -o-transition:all .2s ease-in-out; transition:all .2s ease-in-out }
a.thumbnail:hover { border-color:#2b2b2b; -webkit-box-shadow:0 1px 4px rgba(0,105,214,0.25); -moz-box-shadow:0 1px 4px rgba(0,105,214,0.25); box-shadow:0 1px 4px rgba(0,105,214,0.25); opacity:0.5}
.thumbnail>img { display:block; max-width:100%; margin-right:auto; margin-left:auto;  }
.thumbnail .caption { padding:9px; color:#555 }
.media,
.media-body { overflow:hidden; *overflow:visible;
zoom:1 }
.media,
.media .media { margin-top:15px }
.media:first-child { margin-top:0 }
.media-object { display:block }
.media-heading { margin:0 0 5px }
.media .pull-left { margin-right:10px }
.media .pull-right { margin-left:10px }
.media-list { margin-left:0; list-style:none }
.label,
.badge { display:inline-block; padding:2px 4px; font-size:11.844px; font-weight:bold; line-height:14px; color:#fff; text-shadow:0 -1px 0 rgba(0,0,0,0.25); white-space:nowrap; vertical-align:baseline; background-color:#999 }
.label { -webkit-border-radius:15px; -moz-border-radius:15px; border-radius:15px }
.badge { padding-right:9px; padding-left:9px; -webkit-border-radius:2px; -moz-border-radius:2px; border-radius:2px }
a.label:hover,
a.badge:hover { color:#fff; text-decoration:none; cursor:pointer }
.label-important,
.badge-important { background-color:#f96151 }
.label-important[href],
.badge-important[href] { background-color:#953b39 }
.label-warning,
.badge-warning { background-color:#f89406 }
.label-warning[href],
.badge-warning[href] { background-color:#c67605 }
.label-success,
.badge-success { background-color:#468847 }
.label-success[href],
.badge-success[href] { background-color:#356635 }
.label-info,
.badge-info { background-color:#fe4b4b }
.label-info[href],
.badge-info[href] { background-color:#2d6987 }
.label-inverse,
.badge-inverse { background-color:#333 }
.label-inverse[href],
.badge-inverse[href] { background-color:#1a1a1a }
.btn .label,
.btn .badge { position:relative; top:-1px }
.btn-mini .label,
.btn-mini .badge { top:0 }
@-webkit-keyframes progress-bar-stripes { from {
background-position:40px 0
}
to { background-position:0 0 }
}
@-moz-keyframes progress-bar-stripes { from {
background-position:40px 0
}
to { background-position:0 0 }
}
@-ms-keyframes progress-bar-stripes { from {
background-position:40px 0
}
to { background-position:0 0 }
}
@-o-keyframes progress-bar-stripes { from {
background-position:0 0
}
to { background-position:40px 0 }
}
@keyframes progress-bar-stripes { from {
background-position:40px 0
}
to { background-position:0 0 }
}
.progress { height:20px; margin-bottom:20px; overflow:hidden; background-color:#f7f7f7; background-repeat: repeat-x;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    background-image: linear-gradient(to bottom, #f5f5f5, #f9f9f9);
}
.progress .bar { float:left; width:0; height:100%; font-size:12px; color:#fff; text-align:center; text-shadow:0 -1px 0 rgba(0,0,0,0.25); background-color:#0e90d2; background-repeat: repeat-x;
    -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    -moz-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    box-shadow: inset 0 -1px 0 rgba(0, 0, 0, 0.15);
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    -webkit-transition: width .6s ease;
    -moz-transition: width .6s ease;
    -o-transition: width .6s ease;
    transition: width .6s ease;
    background-image: linear-gradient(to bottom, #149bdf, #0480be);
}
.progress .bar+.bar { -webkit-box-shadow:inset 1px 0 0 rgba(0,0,0,0.15), inset 0 -1px 0 rgba(0,0,0,0.15); -moz-box-shadow:inset 1px 0 0 rgba(0,0,0,0.15), inset 0 -1px 0 rgba(0,0,0,0.15); box-shadow:inset 1px 0 0 rgba(0,0,0,0.15), inset 0 -1px 0 rgba(0,0,0,0.15) }
.progress-striped .bar { background-color:#149bdf; background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255,255,255,0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255,255,255,0.15)), color-stop(0.75, rgba(255,255,255,0.15)), color-stop(0.75, transparent), to(transparent)); background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); -webkit-background-size:40px 40px; -moz-background-size:40px 40px; -o-background-size:40px 40px; background-size:40px 40px }
.progress.active .bar { -webkit-animation:progress-bar-stripes 2s linear infinite; -moz-animation:progress-bar-stripes 2s linear infinite; -ms-animation:progress-bar-stripes 2s linear infinite; -o-animation:progress-bar-stripes 2s linear infinite; animation:progress-bar-stripes 2s linear infinite }
.progress-danger .bar,
.progress .bar-danger { background-color:#dd514c; background-repeat: repeat-x;
    background-image: linear-gradient(to bottom, #ee5f5b, #c43c35);
}
.progress-danger.progress-striped .bar,
.progress-striped .bar-danger { background-color:#ee5f5b; background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255,255,255,0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255,255,255,0.15)), color-stop(0.75, rgba(255,255,255,0.15)), color-stop(0.75, transparent), to(transparent)); background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent) }
.progress-success .bar,
.progress .bar-success { background-color:#5eb95e; background-repeat: repeat-x;
    background-image: linear-gradient(to bottom, #62c462, #57a957);
}
.progress-success.progress-striped .bar,
.progress-striped .bar-success { background-color:#62c462; background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255,255,255,0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255,255,255,0.15)), color-stop(0.75, rgba(255,255,255,0.15)), color-stop(0.75, transparent), to(transparent)); background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent) }
.progress-info .bar,
.progress .bar-info { background-color:#4bb1cf; background-repeat: repeat-x;
    background-image: linear-gradient(to bottom, #5bc0de, #339bb9);
}
.progress-info.progress-striped .bar,
.progress-striped .bar-info { background-color:#5bc0de; background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255,255,255,0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255,255,255,0.15)), color-stop(0.75, rgba(255,255,255,0.15)), color-stop(0.75, transparent), to(transparent)); background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent) }
.progress-warning .bar,
.progress .bar-warning { background-color:#faa732; background-repeat: repeat-x;
    background-image: linear-gradient(to bottom, #fbb450, #f89406);
}
.progress-warning.progress-striped .bar,
.progress-striped .bar-warning { background-color:#fbb450; background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255,255,255,0.15)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255,255,255,0.15)), color-stop(0.75, rgba(255,255,255,0.15)), color-stop(0.75, transparent), to(transparent)); background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent); background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent) }
.accordion { margin-bottom:20px }
.accordion-group { margin-bottom:2px; border:1px solid #e5e5e5; -webkit-border-radius:4px; -moz-border-radius:4px; border-radius:4px }
.accordion-heading { border-bottom:0 }
.accordion-heading .accordion-toggle { display:block; padding:8px 15px }
.accordion-toggle { cursor:pointer }
.accordion-inner { padding:9px 15px; border-top:1px solid #e5e5e5 }
.carousel { position:relative; margin-bottom:20px; line-height:1 }
.carousel-inner { position:relative; width:100%; overflow:hidden }
.carousel .item { position:relative; display:none; -webkit-transition:.6s ease-in-out left; -moz-transition:.6s ease-in-out left; -o-transition:.6s ease-in-out left; transition:.6s ease-in-out left }
.carousel .item>img { display:block; line-height:1 }
.carousel .active,
.carousel .next,
.carousel .prev { display:block }
.carousel .active { left:0 }
.carousel .next,
.carousel .prev { position:absolute; top:0; width:100% }
.carousel .next { left:100% }
.carousel .prev { left:-100% }
.carousel .next.left,
.carousel .prev.right { left:0 }
.carousel .active.left { left:-100% }
.carousel .active.right { left:100% }
.carousel-control { position:absolute; top:40%; left:15px; width:40px; height:40px; margin-top:-20px; font-size:60px; font-weight:100; line-height:30px; color:#fff; text-align:center; background:#222; border:3px solid #fff; -webkit-border-radius:23px; -moz-border-radius:23px; border-radius:23px; opacity:.5; filter:alpha(opacity=50) }
.carousel-control.right { right:15px; left:auto }
.carousel-control:hover { color:#fff; text-decoration:none; opacity:.9; filter:alpha(opacity=90) }
.carousel-caption { position:absolute; right:0; bottom:0; left:0; padding:15px; background:#333; background:rgba(0,0,0,0.75) }
.carousel-caption h4,
.carousel-caption p { line-height:20px; color:#fff }
.carousel-caption h4 { margin:0 0 5px }
.carousel-caption p { margin-bottom:0 }
.hero-unit { padding:60px; margin-bottom:30px; font-size:18px; font-weight:200; line-height:30px; color:inherit; background-color:#eee; -webkit-border-radius:6px; -moz-border-radius:6px; border-radius:6px }
.hero-unit h1 { margin-bottom:0; font-size:60px; line-height:1; letter-spacing:-1px; color:inherit }
.hero-unit li { line-height:30px }
.pull-right { float:right }
.pull-left { float:left }
.hide { display:none }
.show { display:block }
.invisible { visibility:hidden }
.affix { position:fixed }
.clearfix{*zoom:1}.clearfix:before,.clearfix:after{display:table;line-height:0;content:""}.clearfix:after{clear:both}.hide-text{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.input-block-level{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.hidden{display:none;visibility:hidden}.visible-phone{display:none!important}.visible-tablet{display:none!important}.hidden-desktop{display:none!important}.visible-desktop{display:inherit!important}@media(min-width:768px) and (max-width:979px){.hidden-desktop{display:inherit!important}.visible-desktop{display:none!important}.visible-tablet{display:inherit!important}.hidden-tablet{display:none!important}}@media(max-width:767px){.hidden-desktop{display:inherit!important}.visible-desktop{display:none!important}.visible-phone{display:inherit!important}.hidden-phone{display:none!important}}@media(min-width:1200px){.row{margin-left:-30px;*zoom:1}.row:before,.row:after{display:table;line-height:0;content:""}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:30px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom .container{width:1170px}.span12{width:1170px}.span11{width:1070px}.span10{width:970px}.span9{width:870px}.span8{width:770px}.span7{width:670px}.span6{width:570px}.span5{width:470px}.span4{width:370px}.span3{width:270px}.span2{width:170px}.span1{width:70px}.offset12{margin-left:1230px}.offset11{margin-left:1130px}.offset10{margin-left:1030px}.offset9{margin-left:930px}.offset8{margin-left:830px}.offset7{margin-left:730px}.offset6{margin-left:630px}.offset5{margin-left:530px}.offset4{margin-left:430px}.offset3{margin-left:330px}.offset2{margin-left:230px}.offset1{margin-left:130px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;line-height:0;content:""}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;float:left;width:100%;min-height:30px;margin-left:2.564102564102564%;*margin-left:2.5109110747408616%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.564102564102564%}.row-fluid .span12{width:100%;*width:99.94680851063829%}.row-fluid .span11{width:91.45299145299145%;*width:91.39979996362975%}.row-fluid .span10{width:82.90598290598291%;*width:82.8527914166212%}.row-fluid .span9{width:74.35897435897436%;*width:74.30578286961266%}.row-fluid .span8{width:65.81196581196582%;*width:65.75877432260411%}.row-fluid .span7{width:57.26495726495726%;*width:57.21176577559556%}.row-fluid .span6{width:48.717948717948715%;*width:48.664757228587014%}.row-fluid .span5{width:40.17094017094017%;*width:40.11774868157847%}.row-fluid .span4{width:31.623931623931625%;*width:31.570740134569924%}.row-fluid .span3{width:23.076923076923077%;*width:23.023731587561375%}.row-fluid .span2{width:14.52991452991453%;*width:14.476723040552828%}.row-fluid .span1{width:5.982905982905983%;*width:5.929714493544281%}.row-fluid .offset12{margin-left:105.12820512820512%;*margin-left:105.02182214948171%}.row-fluid .offset12:first-child{margin-left:102.56410256410257%;*margin-left:102.45771958537915%}.row-fluid .offset11{margin-left:96.58119658119658%;*margin-left:96.47481360247316%}.row-fluid .offset11:first-child{margin-left:94.01709401709402%;*margin-left:93.91071103837061%}.row-fluid .offset10{margin-left:88.03418803418803%;*margin-left:87.92780505546462%}.row-fluid .offset10:first-child{margin-left:85.47008547008548%;*margin-left:85.36370249136206%}.row-fluid .offset9{margin-left:79.48717948717949%;*margin-left:79.38079650845607%}.row-fluid .offset9:first-child{margin-left:76.92307692307693%;*margin-left:76.81669394435352%}.row-fluid .offset8{margin-left:70.94017094017094%;*margin-left:70.83378796144753%}.row-fluid .offset8:first-child{margin-left:68.37606837606839%;*margin-left:68.26968539734497%}.row-fluid .offset7{margin-left:62.393162393162385%;*margin-left:62.28677941443899%}.row-fluid .offset7:first-child{margin-left:59.82905982905982%;*margin-left:59.72267685033642%}.row-fluid .offset6{margin-left:53.84615384615384%;*margin-left:53.739770867430444%}.row-fluid .offset6:first-child{margin-left:51.28205128205128%;*margin-left:51.175668303327875%}.row-fluid .offset5{margin-left:45.299145299145295%;*margin-left:45.1927623204219%}.row-fluid .offset5:first-child{margin-left:42.73504273504273%;*margin-left:42.62865975631933%}.row-fluid .offset4{margin-left:36.75213675213675%;*margin-left:36.645753773413354%}.row-fluid .offset4:first-child{margin-left:34.18803418803419%;*margin-left:34.081651209310785%}.row-fluid .offset3{margin-left:28.205128205128204%;*margin-left:28.0987452264048%}.row-fluid .offset3:first-child{margin-left:25.641025641025642%;*margin-left:25.53464266230224%}.row-fluid .offset2{margin-left:19.65811965811966%;*margin-left:19.551736679396257%}.row-fluid .offset2:first-child{margin-left:17.094017094017094%;*margin-left:16.98763411529369%}.row-fluid .offset1{margin-left:11.11111111111111%;*margin-left:11.004728132387708%}.row-fluid .offset1:first-child{margin-left:8.547008547008547%;*margin-left:8.440625568285142%}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:30px}input.span12,textarea.span12,.uneditable-input.span12{width:1156px}input.span11,textarea.span11,.uneditable-input.span11{width:1056px}input.span10,textarea.span10,.uneditable-input.span10{width:956px}input.span9,textarea.span9,.uneditable-input.span9{width:856px}input.span8,textarea.span8,.uneditable-input.span8{width:756px}input.span7,textarea.span7,.uneditable-input.span7{width:656px}input.span6,textarea.span6,.uneditable-input.span6{width:556px}input.span5,textarea.span5,.uneditable-input.span5{width:456px}input.span4,textarea.span4,.uneditable-input.span4{width:356px}input.span3,textarea.span3,.uneditable-input.span3{width:256px}input.span2,textarea.span2,.uneditable-input.span2{width:156px}input.span1,textarea.span1,.uneditable-input.span1{width:56px}.thumbnails{margin-left:-30px}.thumbnails>li{margin-left:30px}.row-fluid .thumbnails{margin-left:0}}@media(min-width:768px) and (max-width:979px){.row{margin-left:-20px;*zoom:1}.row:before,.row:after{display:table;line-height:0;content:""}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:20px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom .container{width:724px}.span12{width:724px}.span11{width:662px}.span10{width:600px}.span9{width:538px}.span8{width:476px}.span7{width:414px}.span6{width:352px}.span5{width:290px}.span4{width:228px}.span3{width:166px}.span2{width:104px}.span1{width:42px}.offset12{margin-left:764px}.offset11{margin-left:702px}.offset10{margin-left:640px}.offset9{margin-left:578px}.offset8{margin-left:516px}.offset7{margin-left:454px}.offset6{margin-left:392px}.offset5{margin-left:330px}.offset4{margin-left:268px}.offset3{margin-left:206px}.offset2{margin-left:144px}.offset1{margin-left:82px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;line-height:0;content:""}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;float:left;width:100%;min-height:30px;margin-left:2.7624309392265194%;*margin-left:2.709239449864817%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.7624309392265194%}.row-fluid .span12{width:100%;*width:99.94680851063829%}.row-fluid .span11{width:91.43646408839778%;*width:91.38327259903608%}.row-fluid .span10{width:82.87292817679558%;*width:82.81973668743387%}.row-fluid .span9{width:74.30939226519337%;*width:74.25620077583166%}.row-fluid .span8{width:65.74585635359117%;*width:65.69266486422946%}.row-fluid .span7{width:57.18232044198895%;*width:57.12912895262725%}.row-fluid .span6{width:48.61878453038674%;*width:48.56559304102504%}.row-fluid .span5{width:40.05524861878453%;*width:40.00205712942283%}.row-fluid .span4{width:31.491712707182323%;*width:31.43852121782062%}.row-fluid .span3{width:22.92817679558011%;*width:22.87498530621841%}.row-fluid .span2{width:14.3646408839779%;*width:14.311449394616199%}.row-fluid .span1{width:5.801104972375691%;*width:5.747913483013988%}.row-fluid .offset12{margin-left:105.52486187845304%;*margin-left:105.41847889972962%}.row-fluid .offset12:first-child{margin-left:102.76243093922652%;*margin-left:102.6560479605031%}.row-fluid .offset11{margin-left:96.96132596685082%;*margin-left:96.8549429881274%}.row-fluid .offset11:first-child{margin-left:94.1988950276243%;*margin-left:94.09251204890089%}.row-fluid .offset10{margin-left:88.39779005524862%;*margin-left:88.2914070765252%}.row-fluid .offset10:first-child{margin-left:85.6353591160221%;*margin-left:85.52897613729868%}.row-fluid .offset9{margin-left:79.8342541436464%;*margin-left:79.72787116492299%}.row-fluid .offset9:first-child{margin-left:77.07182320441989%;*margin-left:76.96544022569647%}.row-fluid .offset8{margin-left:71.2707182320442%;*margin-left:71.16433525332079%}.row-fluid .offset8:first-child{margin-left:68.50828729281768%;*margin-left:68.40190431409427%}.row-fluid .offset7{margin-left:62.70718232044199%;*margin-left:62.600799341718584%}.row-fluid .offset7:first-child{margin-left:59.94475138121547%;*margin-left:59.838368402492065%}.row-fluid .offset6{margin-left:54.14364640883978%;*margin-left:54.037263430116376%}.row-fluid .offset6:first-child{margin-left:51.38121546961326%;*margin-left:51.27483249088986%}.row-fluid .offset5{margin-left:45.58011049723757%;*margin-left:45.47372751851417%}.row-fluid .offset5:first-child{margin-left:42.81767955801105%;*margin-left:42.71129657928765%}.row-fluid .offset4{margin-left:37.01657458563536%;*margin-left:36.91019160691196%}.row-fluid .offset4:first-child{margin-left:34.25414364640884%;*margin-left:34.14776066768544%}.row-fluid .offset3{margin-left:28.45303867403315%;*margin-left:28.346655695309746%}.row-fluid .offset3:first-child{margin-left:25.69060773480663%;*margin-left:25.584224756083227%}.row-fluid .offset2{margin-left:19.88950276243094%;*margin-left:19.783119783707537%}.row-fluid .offset2:first-child{margin-left:17.12707182320442%;*margin-left:17.02068884448102%}.row-fluid .offset1{margin-left:11.32596685082873%;*margin-left:11.219583872105325%}.row-fluid .offset1:first-child{margin-left:8.56353591160221%;*margin-left:8.457152932878806%}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:20px}input.span12,textarea.span12,.uneditable-input.span12{width:710px}input.span11,textarea.span11,.uneditable-input.span11{width:648px}input.span10,textarea.span10,.uneditable-input.span10{width:586px}input.span9,textarea.span9,.uneditable-input.span9{width:524px}input.span8,textarea.span8,.uneditable-input.span8{width:462px}input.span7,textarea.span7,.uneditable-input.span7{width:400px}input.span6,textarea.span6,.uneditable-input.span6{width:338px}input.span5,textarea.span5,.uneditable-input.span5{width:276px}input.span4,textarea.span4,.uneditable-input.span4{width:214px}input.span3,textarea.span3,.uneditable-input.span3{width:152px}input.span2,textarea.span2,.uneditable-input.span2{width:90px}input.span1,textarea.span1,.uneditable-input.span1{width:28px}}@media(max-width:767px){body{padding-right:20px;padding-left:20px}.navbar-fixed-top,.navbar-fixed-bottom,.navbar-static-top{margin-right:-20px;margin-left:-20px}.container-fluid{padding:0}.dl-horizontal dt{float:none;width:auto;clear:none;text-align:left}.dl-horizontal dd{margin-left:0}.container{width:auto}.row-fluid{width:100%}.row,.thumbnails{margin-left:0}.thumbnails>li{float:none;margin-left:0}[class*="span"],.uneditable-input[class*="span"],.row-fluid [class*="span"]{display:block;float:none;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.span12,.row-fluid .span12{width:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="offset"]:first-child{margin-left:0}.input-large,.input-xlarge,.input-xxlarge,input[class*="span"],select[class*="span"],textarea[class*="span"],.uneditable-input{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.input-prepend input,.input-append input,.input-prepend input[class*="span"],.input-append input[class*="span"]{display:inline-block;width:auto}.controls-row [class*="span"]+[class*="span"]{margin-left:0}.modal{position:fixed;top:20px;right:20px;left:20px;width:auto;margin:0}.modal.fade{top:-100px}.modal.fade.in{top:20px}}@media(max-width:480px){.nav-collapse{-webkit-transform:translate3d(0,0,0)}.page-header h1 small{display:block;line-height:20px}input[type="checkbox"],input[type="radio"]{border:1px solid #ccc}.form-horizontal .control-label{float:none;width:auto;padding-top:0;text-align:left}.form-horizontal .controls{margin-left:0}.form-horizontal .control-list{padding-top:0}.form-horizontal .form-actions{padding-right:10px;padding-left:10px}.media .pull-left,.media .pull-right{display:block;float:none;margin-bottom:10px}.media-object{margin-right:0;margin-left:0}.modal{top:10px;right:10px;left:10px}.modal-header .close{padding:10px;margin:-10px}.carousel-caption{position:static}}@media(max-width:979px){body{padding-top:0}.navbar-fixed-top,.navbar-fixed-bottom{position:static}.navbar-fixed-top{margin-bottom:20px}.navbar-fixed-bottom{margin-top:20px}.navbar-fixed-top .navbar-inner,.navbar-fixed-bottom .navbar-inner{padding:5px}.navbar .container{width:auto;padding:0}.navbar .brand{padding-right:10px;padding-left:10px;margin:0 0 0 -5px}.nav-collapse{clear:both}.nav-collapse .nav{float:none;margin:0 0 10px}.nav-collapse .nav>li{float:none}.nav-collapse .nav>li>a{margin-bottom:2px}.nav-collapse .nav>.divider-vertical{display:none}.nav-collapse .nav .nav-header{color:#777;text-shadow:none}.nav-collapse .nav>li>a,.nav-collapse .dropdown-menu a{padding:9px 15px;font-weight:bold;color:#777;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.nav-collapse .btn{padding:4px 10px 4px;font-weight:normal;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.nav-collapse .dropdown-menu li+li a{margin-bottom:2px}.nav-collapse .nav>li>a:hover,.nav-collapse .dropdown-menu a:hover{background-color:#f2f2f2}.navbar-inverse .nav-collapse .nav>li>a,.navbar-inverse .nav-collapse .dropdown-menu a{color:#999}.navbar-inverse .nav-collapse .nav>li>a:hover,.navbar-inverse .nav-collapse .dropdown-menu a:hover{background-color:#111}.nav-collapse.in .btn-group{padding:0;margin-top:5px}.nav-collapse .dropdown-menu{position:static;top:auto;left:auto;display:none;float:none;max-width:none;padding:0;margin:0 15px;background-color:transparent;border:0;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.nav-collapse .open>.dropdown-menu{display:block}.nav-collapse .dropdown-menu:before,.nav-collapse .dropdown-menu:after{display:none}.nav-collapse .dropdown-menu .divider{display:none}.nav-collapse .nav>li>.dropdown-menu:before,.nav-collapse .nav>li>.dropdown-menu:after{display:none}.nav-collapse .navbar-form,.nav-collapse .navbar-search{float:none;padding:10px 15px;margin:10px 0;border-top:1px solid #f2f2f2;border-bottom:1px solid #f2f2f2;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1);box-shadow:inset 0 1px 0 rgba(255,255,255,0.1),0 1px 0 rgba(255,255,255,0.1)}.navbar-inverse .nav-collapse .navbar-form,.navbar-inverse .nav-collapse .navbar-search{border-top-color:#111;border-bottom-color:#111}.navbar .nav-collapse .nav.pull-right{float:none;margin-left:0}.nav-collapse,.nav-collapse.collapse{height:0;overflow:hidden}.navbar .btn-navbar{display:block}.navbar-static .navbar-inner{padding-right:10px;padding-left:10px}}@media(min-width:980px){.nav-collapse.collapse{height:auto!important;overflow:visible!important}}

* {
	outline:none !important;
	-moz-outline: none !important;
}
/* Main */
body {
	overflow-x: hidden;
    margin-top: -9px;
}
a:hover {
	text-decoration: none;
}

/* Header */
#header {
    height: 60px;
    position: relative;
    width: 100%;
    z-index: -9;
}

#header h1 {
    background: url("../img/logo.png") no-repeat scroll 0 0 transparent;
    height: 40px;
    left: 15px;
    line-height: 600px;
    overflow: hidden;
    position: relative;
    top: 2px;
    width: 211px;
}

#header h1 a {
    display: block;
}
.fl{ float:left}
.fr{ float:right}
/* Search input */
#search {
	position: relative;
	z-index: 1;
	top:42px;
	float:right;
}
#search input[type=text] {
	border-radius: 0px 0 0 0px;
	padding:8px 10px ;
	border:1px; line-height:24px; 
	width:166px;
}

#search button {
	border: 0;
	margin-top: -11px;
	padding:8px 10px; margin-left:-5px;
	background-color:#5c5c5c; 
}
#search button i {
	opacity: 0.5;
}
#search button:hover i, #search button:active i {
	opacity: 0.9;
}
/* Top user navigation */
#sidebar{ width:100%; background:none;  position:absolute; clear:both; top:65px;}
#sidebar > ul{ margin:0px; padding:0px; width:100%; display:block; z-index:999;} 
#sidebar > ul > li { list-style-type:none; float:left; display:block; margin:0px; border-right:1px dotted #6b6b6b; position:relative; padding:10px; cursor:pointer} 
#sidebar > ul > li:hover ul { display:block; } 
#sidebar > ul > li:hover { background-color:#2b2b2b;} 
#sidebar > ul > li:hover a{ background:none;}
#sidebar > ul li ul { margin:0px; padding:0px; display:none; z-index:999;  position:absolute; border-radius:3px; left:0px; top:40px;  background:#2b2b2b; min-width:200px;} 
#sidebar > ul li ul li { list-style-type:none; margin:0px; font-size:12px;line-height:30px;  } 
#sidebar > ul li ul li a { display:block; padding:5px 10px; color:#fff; text-decoration:none; font-weight:bold; } 
#sidebar > ul li ul li:hover a{ background-color:#606060; border-radius:3px;} 
#sidebar > ul li span { cursor:pointer; margin:0px 2px 0 5px; font-weight:bold; color:#fff; font-size:11px; }
#sidebar > ul li a i{ background-image: url("../img/glyphicons-halflings-white.png");     margin-top:4px;    vertical-align: top;}
#my_menu_input{ display:none;}
#user-nav {
    position: absolute;
    right:0px;
    top: 5px;
    z-index: 20;
    margin: 0; border-left:1px solid #3d3a37;
}
#user-nav > ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

#user-nav > ul > li {
    float: left;
    list-style-type: none;
    margin: 0;
    position: relative;
    padding:6px 0;
	background:#2b2b2b;
	border-left:1px solid #1e1c1a;
	border-right:1px solid #3d3a37;
}
#user-nav > ul > li:hover{ background:#000;}
#user-nav > ul > li > a {
	padding: 13px 10px; 
	display: block;
	font-size: 12px;
}

#user-nav > ul > li > a:hover, #user-nav > ul > li.open > a {
	color: #ffffff;
}
#user-nav > ul > li > a > i, #sidebar li a i {
	vertical-align: top;
	background-image: url('../img/glyphicons-halflings-white.png');
	margin-top: 2px;
}
#user-nav > ul > li > a:hover > i, #user-nav > ul > li.open > a > i {
	opacity: 1;
}

#user-nav > ul > li > a > .label {
	vertical-align: middle;
	padding: 1px 4px 1px;
	margin: -2px 4px 0;
	display: inline-block;
}


#user-nav > ul ul > li > a {
	text-align: left;
	text-shadow: 0 1px 0 #ffffff;
}
#user-nav > ul ul > li > a:hover {
	text-shadow: 0 1px 0 rgba(0,0,0,0.5);
}



/* Content */
#content {
    background: none repeat scroll 0 0 #fff;
    margin-left:0px;
    margin-right: 0;
	margin-top:80px;
    padding-bottom: 25px;
    position: relative;
    min-height: 478px;
    width: auto;
}

#content-header {
	position: abslute;
    width: 100%;
    margin-top: -38px;
    z-index: 20;
}

#content-header h1 {
    color: #555555;
    font-size: 28px;
    font-weight: normal;
    float: none;
    text-shadow: 0 1px 0 #ffffff;
    margin-left: 20px;
    position: relative;
}

#content-header .btn-group {
	float: right;
	right: 20px;
	position: absolute;
}

#content-header h1, #content-header .btn-group {
	margin-top: 20px;
}
#content-header .btn-group .btn {
	padding: 11px 14px 9px;
}
#content-header .btn-group .btn .label {
	position: absolute;
	top: -7px;
}

.container-fluid .row-fluid:first-child {
	/*margin-top: 20px;*/
}
/* Breadcrumb */
#breadcrumb {
	background-color: #e5e5e5;
	border-bottom: 1px solid #d6d6d6;
	padding-left: 10px;
}
#breadcrumb a {
	padding: 8px 20px 8px 10px;
	display: inline-block;
	background-image: url('../img/breadcrumb.png');
	background-position: center right;
	background-repeat: no-repeat;
	font-size: 11px;
	color: #666666;
}
#breadcrumb a:hover {
	color: #333333;
}
#breadcrumb a:last-child {
	background-image:none;
}
#breadcrumb a.current {
	font-weight: bold;
	color: #444444;
}
#breadcrumb a i {
	margin-right: 5px;
	opacity: .6;
}
#breadcrumb a:hover i {
	margin-right: 5px;
	opacity: .8;
}

/* Style Switcher */
#style-switcher {
	position: absolute;
	width: 220px;
	height: 30px;
	background-color: #000000;
	z-index: 40;
	right: 0;
	top: 123px;
	border-radius: 5px 0 0 5px;
	margin-right: -190px;
}
#style-switcher i {
	display: inline-block;
	margin: -5px 10px 0 10px;
}
#style-switcher i:hover {
	cursor: pointer;
}
#style-switcher span {
	font-weight: bold;
	color: #ffffff;
	display: inline-block;
	margin: -15px 20px 0 0;
	vertical-align:middle;
}
#style-switcher a {
	display: inline-block;
	width: 20px;
	height: 20px;
	margin-top: 4px;
	border-style: solid;
	border-width: 1px;
	border-color: transparent;	
}
/* Footer */
#footer {
	text-align: center;
	color: #777777; padding:5px 0; background:#2B2927;
}
/* Stat boxes and quick actions */
.quick-actions_homepage{ width:100%; text-align:center; float:left; margin-top:10px;}
.stat-boxes, .quick-actions, .quick-actions-horizontal, .stats-plain {
    display: inline-block;
    list-style: none outside none;
    margin: 20px 0 10px;
    text-align: center;
}
.stat-boxes2{ background:none; width:100%;  padding:0px; margin:0 auto; position:relative; top:13px; right:10px;}
.stats-plain {	width: 100%;}

.stat-boxes li, .quick-actions li, .quick-actions-horizontal li {
    background: #F6F6F6;
    border: 1px solid #D5D5D5;
    box-shadow: 0 1px 0 0 #FFFFFF inset, 0 1px 0 rgba(255, 255, 255, 0.4);
    display: inline-block;
    line-height: 18px;
    margin: 0 10px 10px;
    padding: 0 10px;
}
.stat-boxes li a:hover, .quick-actions li a:hover, .quick-actions-horizontal li a:hover, .stat-boxes li:hover, .quick-actions li:hover, .quick-actions-horizontal li:hover{ background: #fff;}
.quick-actions li {
	min-width: 175px;
}
.quick-actions li, .quick-actions-horizontal li {
	padding: 0;
}
.stats-plain li {
	padding: 0 30px;
	display: inline-block;
	margin: 0 10px 20px;
}
.quick-actions li a {
	padding: 10px 30px;
}
.stats-plain li h4 {
	font-size: 40px;
	margin-bottom: 15px;
}
.stats-plain li span {
	font-size: 14px;
	color: #555555;
}
.quick-actions-horizontal li a span {
	padding: 10px 12px 10px 10px;
	display: inline-block;
}
.quick-actions li a, .quick-actions-horizontal li a {
	display: block;
	color: #666666; font-weight:bold;
	text-shadow: 0 1px 0 #ffffff;
}
.quick-actions li a i[class^="icon-"], .quick-actions li a i[class*=" icon-"] {
	background-repeat: no-repeat;
	background-attachment: scroll;
	background-position: 0 0;
	background-color: transparent;
	width: 32px;
	height: 32px;
	display: block;
	margin: 0 auto 5px;
}
.quick-actions-horizontal li a i[class^="icon-"], .quick-actions-horizontal li a i[class*=" icon-"] {
	background-repeat: no-repeat;
	background-attachment: scroll;
	background-position: center;
	background-color: transparent;
	width: 16px;
	height: 16px;
	display: inline-block;
	margin: -2px 0 0 !important; 
	border-right: 1px solid #dddddd;
	margin-right: 10px;
	padding: 10px;
	vertical-align: middle;
}

.quick-actions i.icon-book {
	background-image: url('../img/icons/32/book.png');
}
.quick-actions i.icon-cabinet {
	background-image: url('../img/icons/32/cabinet.png');
}
.quick-actions i.icon-calendar {
	background-image: url('../img/icons/32/calendar.png');
}
.quick-actions i.icon-client {
	background-image: url('../img/icons/32/client.png');
}
.quick-actions i.icon-database {
	background-image: url('../img/icons/32/database.png');
}
.quick-actions i.icon-download {
	background-image: url('../img/icons/32/download.png');
}
.quick-actions i.icon-graph {
	background-image: url('../img/icons/32/graph.png');
}
.quick-actions i.icon-home {
	background-image: url('../img/icons/32/home.png');
}
.quick-actions i.icon-lock {
	background-image: url('../img/icons/32/lock.png');
}
.quick-actions i.icon-mail {
	background-image: url('../img/icons/32/mail.png');
}
.quick-actions i.icon-pdf {
	background-image: url('../img/icons/32/pdf.png');
}
.quick-actions i.icon-people {
	background-image: url('../img/icons/32/people.png');
}
.quick-actions i.icon-piechart {
	background-image: url('../img/icons/32/piechart.png');
}
.quick-actions i.icon-search {
	background-image: url('../img/icons/32/search.png');
}
.quick-actions i.icon-shopping-bag {
	background-image: url('../img/icons/32/shopping-bag.png');
}
.quick-actions i.icon-survey {
	background-image: url('../img/icons/32/survey.png');
}
.quick-actions i.icon-tag {
	background-image: url('../img/icons/32/tag.png');
}
.quick-actions i.icon-user {
	background-image: url('../img/icons/32/user.png');
}
.quick-actions i.icon-wallet {
	background-image: url('../img/icons/32/wallet.png');
}
.quick-actions i.icon-web {
	background-image: url('../img/icons/32/web.png');
}
.quick-actions i.icon-dashboard {
	background-image: url('../img/icons/32/dashboard.png');
}
.quick-actions-horizontal i.icon-book {
	background-image: url('../img/icons/16/book.png');
}
.quick-actions-horizontal i.icon-cabinet {
	background-image: url('../img/icons/16/cabinet.png');
}
.quick-actions-horizontal i.icon-calendar {
	background-image: url('../img/icons/16/calendar.png');
}
.quick-actions-horizontal i.icon-client {
	background-image: url('../img/icons/16/client.png');
}
.quick-actions-horizontal i.icon-database {
	background-image: url('../img/icons/16/database.png');
}
.quick-actions-horizontal i.icon-download {
	background-image: url('../img/icons/16/download.png');
}
.quick-actions-horizontal i.icon-graph {
	background-image: url('../img/icons/16/graph.png');
}
.quick-actions-horizontal i.icon-home {
	background-image: url('../img/icons/16/home.png');
}
.quick-actions-horizontal i.icon-lock {
	background-image: url('../img/icons/16/lock.png');
}
.quick-actions-horizontal i.icon-mail {
	background-image: url('../img/icons/16/mail.png');
}
.quick-actions-horizontal i.icon-pdf {
	background-image: url('../img/icons/16/pdf.png');
}
.quick-actions-horizontal i.icon-people {
	background-image: url('../img/icons/16/people.png');
}
.quick-actions-horizontal i.icon-piechart {
	background-image: url('../img/icons/16/piechart.png');
}
.quick-actions-horizontal i.icon-search {
	background-image: url('../img/icons/16/search.png');
}
.quick-actions-horizontal i.icon-shopping-bag {
	background-image: url('../img/icons/16/shopping-bag.png');
}
.quick-actions-horizontal i.icon-survey {
	background-image: url('../img/icons/16/survey.png');
}
.quick-actions-horizontal i.icon-tag {
	background-image: url('../img/icons/16/tag.png');
}
.quick-actions-horizontal i.icon-user {
	background-image: url('../img/icons/16/user.png');
}
.quick-actions-horizontal i.icon-wallet {
	background-image: url('../img/icons/16/wallet.png');
}
.quick-actions-horizontal i.icon-web {
	background-image: url('../img/icons/16/web.png');
}


.quick-actions li:active, .quick-actions-horizontal li:active  {
	background-image: -webkit-gradient(linear, 0 0%, 0 100%, from(#EEEEEE), to(#F4F4F4));
	background-image: -webkit-linear-gradient(top, #EEEEEE 0%, #F4F4F4 100%);
    background-image: -moz-linear-gradient(top, #EEEEEE 0%, #F4F4F4 100%);
    background-image: -ms-linear-gradient(top, #EEEEEE 0%, #F4F4F4 100%);
    background-image: -o-linear-gradient(top, #EEEEEE 0%, #F4F4F4 100%);
    background-image: linear-gradient(top, #EEEEEE 0%, #F4F4F4 100%);
    box-shadow: 0 1px 4px 0 rgba(0,0,0,0.2) inset, 0 1px 0 rgba(255,255,255,0.4);
}


.stat-boxes .left, .stat-boxes .right {
	text-shadow: 0 1px 0 #fff;
    float: left;
}
.stat-boxes .left {
    border-right: 1px solid #DCDCDC;
    box-shadow: 1px 0 0 0 #FFFFFF;
    font-size: 10px;
    font-weight: bold;
    margin-right: 10px;
    padding: 10px 14px 6px 4px;
}

.stat-boxes .right {
 color: #666666;
    font-size: 12px;
    padding: 9px 10px 7px 0;
    text-align: center;
    width: 70px;
}
.stat-boxes .left span, .stat-boxes .right strong {
	display: block;
}
.stat-boxes .right strong {
	font-size: 26px;
	margin-bottom: 3px;
	margin-top: 6px;
}
.stat-boxes .peity_bar_good, .stat-boxes .peity_line_good  {
	color: #459D1C;
}
.stat-boxes .peity_bar_neutral, .stat-boxes .peity_line_neutral  {
	color: #757575;
}
.stat-boxes .peity_bar_bad, .stat-boxes .peity_line_bad  {
	color: #BA1E20;
}

.stats-plain {

}

/* Charts & graphs **/
.chart, .pie, .bars {
	height: 300px;
	max-width: 100%;
}
#tooltip {
	position: absolute;
	display:none;
	border: none;
	padding: 3px 8px;
	border-radius: 3px;
	font-size: 10px;
	background-color: #222222;
	color: #ffffff;
	z-index: 25;
}

/* Widgets */
.widget-box {
    background: none repeat scroll 0 0 #F9F9F9;
    border-top: 1px solid #CDCDCD;
    border-left: 1px solid #CDCDCD;
    border-right: 1px solid #CDCDCD;
    clear: both;
    margin-top: 16px;
    margin-bottom: 16px;
    position: relative;
    top: 0px;
    left: 0px;
}
.widget-box.widget-calendar, .widget-box.widget-chat {
    overflow:hidden !important;
}
.accordion .widget-box {
	margin-top: -2px;
	margin-bottom: 0;
	border-radius: 0;
}
.widget-box.widget-plain {
	background: transparent;
	border: none;
	margin-top: 0;
	margin-bottom: 0;
}

.widget-title, .modal-header, .table th, div.dataTables_wrapper .ui-widget-header {
	background-color: #efefef;
	
    border-bottom: 1px solid #CDCDCD;
    height: 36px;
}
.widget-title .nav-tabs {
    border-bottom: 0 none;
}
.widget-title .nav-tabs li a {
    border-bottom: medium none !important;
    border-left: 1px solid #DDDDDD;
    border-radius: 0 0 0 0;
    border-right: 1px solid #DDDDDD;
    border-top: medium none;
    color: #999999;
    margin: 0;
    outline: medium none;
    padding: 9px 10px 8px;
    font-weight: bold;
    text-shadow: 0 1px 0 #FFFFFF;
}
.widget-title .nav-tabs li:first-child a{
    border-left: medium none !important;
}
.widget-title .nav-tabs li a:hover {
    background-color: transparent !important;
    border-color: #D6D6D6;
    border-width: 0 1px;
    color: #666666;
}
.widget-title .nav-tabs li.active a {
    background-color: #F9F9F9 !important;
    color: #444444;
}
.widget-title span.icon {
	border-right: 1px solid #cdcdcd;
	padding: 9px 10px 7px 11px;
	float: left;
	opacity: .7;
}
.widget-title h5 {
    color: #666666;
	text-shadow: 0 1px 0 #ffffff;
    float: left;
    font-size: 12px;
    font-weight: bold;
    padding: 12px;
    line-height: 12px;
    margin: 0;
}
.widget-title .buttons {
	float: right;
	margin: 8px 10px 0 0;
}
.widget-title .label {
	padding: 3px 5px 2px;
	float: right;
	margin: 9px 11px 0 0;
	box-shadow: 0 1px 2px rgba(0,0,0,0.3) inset, 0 1px 0 #ffffff;
}
.widget-calendar .widget-title .label {
	margin-right: 190px;
}

.widget-content {
	padding: 12px 15px;
    border-bottom: 1px solid #cdcdcd;
}
.widget-box.widget-plain .widget-content {
	padding: 12px 0 0;
}
.widget-box.collapsible .collapse.in .widget-content {
    border-bottom: 1px solid #CDCDCD;
}
.recent-posts, .recent-comments, .recent-users {
	margin: 0;
	padding: 0;
}
.recent-posts li, .recent-comments li, .article-post li, .recent-users li {
    border-bottom: 1px dotted #AEBDC8;
    list-style: none outside none;
    padding: 10px;
}
.recent-posts li.viewall, .recent-comments li.viewall, .recent-users li.viewall {
	padding: 0;
}
.recent-posts li.viewall a, .recent-comments li.viewall a, .recent-users li.viewall a {
	padding: 5px;
	text-align: center;
	display: block;
	color: #888888;
}
.recent-posts li.viewall a:hover, .recent-comments li.viewall a:hover, .recent-users li.viewall a:hover {
	background-color: #eeeeee;
}

.recent-posts li:last-child, .recent-comments li:last-child, .recent-users li:last-child {
    border-bottom: none !important;
}

.user-thumb {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 1px solid #B6BCBF;
    float: left;
    height: 40px;
    margin-right: 10px;
    margin-top: 5px;
    padding: 2px;
    width: 40px;
}
.user-info {
    color: #666666;
    font-size: 11px;
}

.site-stats {
	margin: 0;
	padding: 0;
	list-style: none;
}
.site-stats li {
    background-color: #F5F5F5;
    border: 1px solid #DDDDDD;
    cursor: pointer;
    margin: 0 0 10px;
    padding: 13px 20px 10px;
    position: relative;
}
.site-stats li:hover {
    background-color: #EDEDED;
}
.site-stats li.divider {
	padding: 0;
	border-width: 1px 0 0;
	border-color: #DDDDDD;
	border-style: dashed;
}
.site-stats li i {
	vertical-align: baseline;
}
.site-stats li strong {
	font-weight: bold;
	font-size: 20px;
	margin-left: 5px;
}
.site-stats li small {
	margin-left: 5px;
	font-size: 12px;
	color: #888888;
	font-style: italic;
}

.invoice-content {
	padding: 20px;
}
.invoice-action {
    margin-bottom: 30px;
}
.invoice-head {
    clear: both;
    margin-bottom: 40px;
    overflow: hidden;
    width: auto;
}
.invoice-meta {
    font-size: 18px;
    margin-bottom: 40px;
}
.invoice-date {
    float: right;
    font-size: 80%;
}
.invoice-content h5 {
    color: #333333;
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 10px;
}
.invoice-content ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.invoice-to {
    float: left;
    width: 370px;
}
.invoice-from {
    float: right;
    width: 300px;
}
.invoice-to li, .invoice-from li {
    clear: left;
}
.invoice-to li span, .invoice-from li span {
    display: block;
}
.invoice-content th.total-label {
	text-align: right;
}
.invoice-content th.total-amount {
	text-align: left;
}
.amount-word {
    color: #666666;
    margin-bottom: 40px;
    margin-top: 40px;
}
.amount-word span {
    color: #5476A6;
    font-weight: bold;
    padding-left: 20px;
}
.panel-left {
	margin-top:103px;
}
.panel-left2 {
	margin-left:176px;
}
.panel-right {
	width: 100%;
	background-color: #fff;
	border-bottom: 1px solid #dddddd;
	position: absolute;
	right: 0; overflow:auto;
	top:38px;
	height:76px;
}
.panel-right2 {
	width: 100%;
	background-color: #fff;
	border-right: 1px solid #dddddd;
	position: absolute;
	left: 0; overflow:auto;
	top:38px;
	height:87%; width:175px;
}

.panel-right .panel-title, .panel-right2 .panel-title  {
	width: 100%;
	background-color: #ececec; 
	border-bottom: 1px solid #dddddd;
}
.panel-right .panel-title h5 ,.panel-right2 .panel-title h5{
	font-size: 12px;
	color: #777777;
	text-shadow: 0 1px 0 #ffffff;
	padding: 6px 10px 5px;
    margin: 0;
}
.panel-right .panel-content {
	padding: 10px;
}
.chat-content {
	height: 470px;
	padding: 15px;
}
.chat-messages {
    height: 420px;
    overflow: auto;
    position: relative;
}
.chat-message {
	padding: 7px 15px;
	margin: 7px 0 0;
}
.chat-message input[type=text] {
	margin-bottom: 0 !important;
	width: 100%;
}
.chat-message .input-box {
    display: block;
    margin-right: 90px;
}
.chat-message button {
	float: right;
}
#chat-messages-inner p {
    padding:0px;
    margin: 10px 0 0 0;
}
#chat-messages-inner p img {
    display: inline-block;
    float: left;
    vertical-align: middle;
    width: 28px;
    height: 28px;
    margin-top:-1px;
	margin-right:10px;
}
#chat-messages-inner .msg-block, #chat-messages-inner p.offline span {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 1px solid #cccccc;
    box-shadow: 1px 1px 0 1px rgba(0, 0, 0, 0.05);
    display: block;
    margin-left:0px;
    padding: 10px;
    position: relative;
}
#chat-messages-inner p.offline span {
    background: none repeat scroll  0 0 #FFF5F5;
}
#chat-messages-inner .time {
    color: #999999;
    font-size: 11px;
	float:right;
}
#chat-messages-inner .msg {
    display: block;
    margin-top: 13px; border-top:1px solid #dadada;
}
#chat-messages-inner .msg-block:before {
	border-right: 7px solid rgba(0,0,0,0.1);
	border-top: 7px solid transparent;
	border-bottom: 7px solid transparent;
	content: "";
	display:none;
	left: -7px;
	position: absolute;
	top: 11px;
}
#chat-messages-inner .msg-block:after {
	border-right: 6px solid #ffffff;
	border-top: 6px solid transparent;
	border-bottom: 6px solid transparent;
	content: "";
	display: none;
	left: -6px;
	position: absolute;
	top: 12px;
}
.chat-users {
	padding: 0 0 30px;
}
.chat-users .contact-list {
    line-height: 21px;
    list-style: none outside none;
    margin: 0;
    padding: 0;
    font-size: 10px;
}
.chat-users .contact-list li {
    border: 1px solid #DADADA;
    margin:5px 5px; 
    padding: 1px;
    position: relative;
}
.chat-users .contact-list li:hover {
	background-color: #efefef;
}
.chat-users .contact-list li a {
    color: #666666;
    display: block;
    padding: 8px 5px;
}
.chat-users .contact-list li.online a {
	font-weight: bold;
}
.chat-users .contact-list li.new {
	background-color: #eaeaea;
}
.chat-users .contact-list li.offline {
	background-color: #EDE0E0;
}
.chat-users .contact-list li a img {
    display: inline-block;
    margin-right: 10px;
    vertical-align: middle;
    width: 28px;
    height: 28px;
    border-radius: 3px;
}
.chat-users .contact-list li .msg-count {
	padding: 3px 5px;
    position: absolute;
    right: 10px;
    top: 12px;
}
.taskDesc i {
    margin: 1px 5px 0;
}
.taskStatus, .taskOptions {
    text-align: center !important;
}
.taskStatus .in-progress {
    color: #64909E;
}
.taskStatus .pending {
    color: #AC6363;
}
.taskStatus .done {
    color: #75B468;
}
.activity-list {
    list-style: none outside none;
    margin: 0;
}
.activity-list li {
    border-bottom: 1px solid #EEEEEE;
    display: block;
}
.activity-list li:last-child {
    border-bottom: medium none;
}
.activity-list li a {
    color: #888888;
    display: block;
    padding: 7px 10px;
}
.activity-list li a:hover {
    background-color: #FBFBFB;
}
.activity-list li a span {
    color: #AAAAAA;
    font-size: 11px;
    font-style: italic;
}
.activity-list li a i {
    margin-right: 10px;
    opacity: 0.6;
    vertical-align: middle;
}
.new-update {
    border-top: 1px solid #DDDDDD;
    padding: 10px 12px;
}
.new-update:first-child {
    border-top: medium none;
}
.new-update span {
	display:block;
}
.new-update i{
	float: left;
	margin-top: 3px;
	margin-right: 13px;
}
.new-update .update-date {
    color: #BBBBBB;
    float: right;
    margin: 4px -2px 0 0;
    text-align: center;
    width: 30px;
}
.new-update .update-date .update-day {
    display: block;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: -4px;
}
.update-done, .update-alert, .update-notice {
    display: block;
    float: left;
    max-width: 76%;
}

/* Tables */

span.icon .checker {
	margin-top: -5px;
	margin-right: 0;
}

.dataTables_length {
    color: #878787;
    margin: 7px 5px 0;
    position: absolute;
    right: 2px;
    top: -2px;
}
.dataTables_length div {
	vertical-align: middle;
}

.dataTables_paginate {
    line-height: 16px;
    text-align: right;
    margin-top: 5px;
    margin-right: 10px;
}
.dataTables_paginate .ui-button,  .pagination.alternate li a {
    font-size: 12px;
    padding: 4px 10px !important;
    border-style: solid;
    border-width: 1px;
    border-color: #dddddd #dddddd #cccccc; /* for IE < 9 */
    border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
    display: inline-block;
    line-height: 16px;
    background: #f5f5f5;
   
    color: #333333;
    text-shadow: 0 1px 0 #ffffff;
}
.dataTables_paginate .ui-button:hover, .pagination.alternate li a:hover{
    background: #e8e8e8;
   
    color: #222222;
    text-shadow: 0 1px 0 #ffffff;
    cursor: pointer;
}

.dataTables_paginate .first{
    border-radius: 4px 0 0 4px;    
}
.dataTables_paginate .last {
    border-radius: 0 4px 4px 0;    
}
.dataTables_paginate .ui-state-disabled, .fc-state-disabled, .pagination.alternate li.disabled a {
    color: #AAAAAA !important;
}
.dataTables_paginate .ui-state-disabled:hover, .fc-state-disabled:hover, .pagination.alternate li.disabled a:hover {
    background: #f5f5f5;
  
    cursor: default !important;
}
.dataTables_paginate span .ui-state-disabled, .pagination.alternate li.active a {
    background:#F77825;
    color: #ffffff !important;
    cursor: default !important;
}
div.dataTables_wrapper .ui-widget-header {
    border-right: medium none;
    border-top: 1px solid #D5D5D5;
    font-weight: normal;
    margin-top: -1px;
}
.dataTables_wrapper .ui-toolbar {
    padding: 5px;
}
.dataTables_filter {
    color: #878787;
    font-size: 11px;
    left: 0;
    margin: 4px 8px 2px 10px;
    position: absolute;
    text-align: left;
}
.dataTables_filter input {
	margin-bottom: 0;
}


.table th {
	height: auto;
	font-size: 12px;
	padding: 5px 10px 2px;
	border-bottom: 0;
	text-align: center;
	color: #666666;
}
.table.with-check tr th:first-child, .table.with-check tr td:first-child {
	width: 10px;
}
.table.with-check tr th:first-child i{
	margin-top: -2px;
	opacity: 0.6;
}
.table.with-check tr td:first-child .checker {
	margin-right: 0;
}
.table tr.checked td {
	background-color: #FFFFE3 !important;
}
/* Misc */
.nopadding {	
	padding: 0 !important;
}
.nopadding .table {
	margin-bottom: 0;
}
.nopadding .table-bordered {
	border: 0;
}
.thumbnails {
	margin-left: -2.12766% !important;
}
.thumbnails [class*="span"] {
    margin-left: 2.12766% !important;
    position: relative;
}
.thumbnails .actions {
	width: 32px;
	height: 16px;
	background-color: #000000;
	padding: 4px 8px;
	position: absolute;
	bottom:0%;
	left:50%;
	margin-top: -13px;
	margin-left: -24px;
	opacity: 0;
	-moz-transition: opacity 0.3s ease-in-out;
}
.thumbnails li:hover .actions {
	opacity: 1;
}
.line {
    background: url("../img/line.png") repeat-x scroll 0 0 transparent;
    display: block;
    height: 8px;
}
.modal {
	z-index: 99999 !important;
}
.modal-backdrop {
	z-index: 999 !important;
}
.modal-header {
	height: auto;
	padding: 8px 15px 5px;
}
.modal-header h3 {
	font-size: 12px;
	text-shadow: 0 1px 0 #ffffff;
}

.notify-ui ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.notify-ui li {
	background-image: -moz-linear-gradient(top, #eeeeee,#dddddd);
	margin-bottom: 5px;
	padding: 5px 10px;
	text-align: center;
	border: 1px solid #dddddd;
}
.notify-ui li:hover {
	cursor: pointer;
	color: #777777;
}

/* Forms */
form {
	margin-bottom: 0;
}
.form-horizontal .control-group {
	border-top: 1px solid #ffffff;
	border-bottom: 1px solid #eeeeee;
	margin-bottom: 0;
	padding-left:10px;
}
.form-horizontal .control-group:last-child {
	border-bottom: 0;
}
.form-horizontal .control-label {
	padding-top: 15px;
	width: 180px;
}
.form-horizontal .controls {
	margin-left: 200px;
	padding: 10px 0;
}
.form-horizontal input[type=text], .form-horizontal input[type=password], .form-horizontal textarea {
	
}
.row-fluid .span20{ width:97.8%}
.form-horizontal .form-actions {
	margin-top: 0;
	margin-bottom: 0;
}
.help-block, .help-inline {
    color: #999999;
}
/***********light-box***************/
#lightbox {	position:fixed; /* keeps the lightbox window in the current viewport */	top:0; 	left:0; width:100%; height:100%; background:url(overlay.png) repeat #000; text-align:center;}
#lightbox p{ position:absolute; top:10px; right:10px; width:22px; height:22px; cursor:pointer; z-index:22; border:1px solid #fff; border-radius:100%; padding:2px; text-align:center; transition:0.5s;}
#lightbox p:hover{ transform:rotate(180deg)}
#imgbox{ position:absolute; /* keeps the lightbox window in the current viewport */	left:0;	top:0px; width:100%; height:100%; background:url(overlay.png) repeat #000; 	text-align:center; z-index:21; }
#imgbox img{ margin-top:100px; border:10px solid #fff;}
/***********light-box-end***************/

.btn-icon-pg ul{ margin:0px; padding:0px;}
.btn-icon-pg ul li{ margin:5px; padding:5px; list-style:none; display:inline-block; border:1px solid #dadada; min-width:157px; cursor:pointer }
.btn-icon-pg ul li:hover i{ transition:0.3s; -moz-transition:0.3s; -webkit-transition:0.3s; -o-transition:0.3s; transform:rotate(360deg); margin-left:8px; }
/* Responsive design */
@media (max-width: 480px) {
	#header h1 {
		top: auto;
		left: auto;
		margin: 3px auto;
	}
	#user-nav {
		position: relative;
		left: auto;
		right: auto;
		width: 100%;
		margin-top: -36px; border-top:1px solid #3D3A37;
		margin-bottom: 0px; background:#2b2b2b; float:right;
	}
	.navbar > .nav {
		float: none;
	}
	
	#my_menu{ display:none;}
	#my_menu_input{ display:block;}
	.stat-boxes2{ background:none; width:100%;  margin:-30px 0 20px 0; padding:0px; position:relative; top:13px; right:10px;}
	#user-nav > ul {
		right: 0px; margin-left:15%!important;
		margin-top:0px; width:100%; background:#000;
		position: relative;
	}
	#user-nav > ul > li{ padding:0px 0px;}
	#user-nav > ul > li > a{ padding:5px 10px;}
	#content {
		margin-left: 0 !important;
		border-top-left-radius: 0;
		margin-top:0px;
	}
	#content-header {
		margin-top: 0;
		
		text-align: center;
	}
	#content-header h1, #content-header .btn-group {
		float: none;
	}
	#content-header h1 {
		display: block;
		text-align: center;
		margin-left: auto;
		margin-top: 0;
		padding-top: 15px;
		width: 100%;
	}
	#content-header .btn-group {
		margin-top: 70px;
		margin-bottom: 0;
		margin-right: 0;
		left: 30%;
	}
	
#sidebar { float: none; width: 100% !important;	display:block; position:relative; top:0px;}
#sidebar > ul{ margin:0px; padding:0px; width:100%; display:block; z-index:999; position:relative} 
#sidebar > ul > li { list-style-type:none; display:block; border-bottom:1px solid #333; border-top:1px solid #5d5d5d; float:none !important; margin:0px; border-left:1px dotted #6b6b6b; position:relative; padding:10px; cursor:pointer} 
#sidebar > ul > li:hover ul { display:none;} 
#sidebar > ul > li:hover { background-color:#2b2b2b;} 
#sidebar > ul > li:hover a{ background:none;}
#sidebar > ul li ul { margin:0px; padding:0px; z-index:999; display:none; position:absolute;  background:#2b2b2b; width:100%; min-width:100%; border-radius:none;  box-shadow: 0 0 3px rgba(0,0,0,0.5) inset;} 
#sidebar > ul li ul li { list-style-type:none; margin:0px; font-size:12px; line-height:30px;  } 
#sidebar > ul li ul li a { display:block; padding:5px 10px; color:#fff; text-decoration:none; font-weight:bold; } 
#sidebar > ul li ul li:hover a{ background-color:#606060; border-radius:0px;} 
#sidebar > ul li span { cursor:pointer; margin:0px 2px 0 5px; font-weight:bold; color:#fff; font-size:12px; }
#sidebar > ul li a i{ background-image: url("../img/glyphicons-halflings-white.png");  margin-top:4px;  vertical-align: top;}	
#sidebar > a { padding: 9px 20px 9px 15px; display: block !important; text-transform: uppercase; color: #eeeeee; float:none !important;	font-size:12px;	}
#sidebar > ul > li > a { padding:5px;	display:block; 	color: #AAAAAA;}
.widget-title .buttons > .btn {
		width: 11px;
		white-space: nowrap;
		overflow: hidden;
	}
    .form-horizontal .control-label {
        padding-left: 30px;
    }
    .form-horizontal .controls {
        margin-left: 0;
        padding: 10px 30px;
    }
    .form-actions {
        text-align: center;
    }
	.panel-right2 {
	width: 100%;
	background-color: #fff;
	border-right: 1px solid #dddddd;
	position: relative;
	left: 0; overflow:auto;
	top:0px;
	height:87%; width:100%;
}
.panel-left2{ margin-left:0px;}
.dataTables_paginate .ui-button,  .pagination.alternate li a { padding:4px 4px!important;}
.table th {	padding: 5px 4px 2px;}

.widget-title .dataTables_filter{
	display:none;
}

}

@media (min-width: 481px) and (max-width: 970px) {
	#header h1 {
		top: 3px;
	}
	#search{ top:3px}
	#my_menu{ display:none;}
	#my_menu_input{ display:block;}
	#content{ margin-top:41px;}
	.stat-boxes2{ background:none; width:100%;  padding:60px 0 20px 0; margin:0 auto; position:relative; top:13px; right:10px;}
	#sidebar > ul > li{ float:none;}
	#sidebar > ul > li:hover ul{ display:block;}
	#sidebar, #sidebar > ul {
		width: 43px; display: block; position: absolute;
	}
	#sidebar > ul ul {
		display: none;
		position: absolute;
		left:50px;
		top: 0;
		min-width: 150px;
		box-shadow: 0 1px 5px rgba(0,0,0,0.7);
		border-radius: 5px;		
		list-style: none;
	}
	#sidebar > ul ul li a {
		white-space: nowrap;
		padding: 10px 25px;
	}
	#sidebar > ul ul:before {
		border-top: 7px solid transparent;
		border-bottom: 7px solid transparent;
		content: "";
		display: inline-block;
		left: -6px;
		position: absolute;
		top: 11px;
	}
	#sidebar > ul ul:after {
		border-top: 6px solid transparent;
		border-bottom: 6px solid transparent;
		content: "";
		display: inline-block;
		left: -5px;
		position: absolute;
		top: 12px;
    }
	#sidebar > a {
		display: none !important;
	}
	#sidebar > ul > li.open.submenu > a {
    border-bottom: none !important;
	}
	#sidebar > ul > li > a > span {
		display: none;
	}
	#content {
		margin-left: 43px;
	}
}
@media (max-width: 600px) {
	.widget-title .buttons {
		float: left;
	}
	.panel-left {
		margin-right: 0;
	}
	.panel-right {
		border-top: 1px solid #DDDDDD;
		border-left: none;
		position: relative;
		top: auto;
		right: auto;
		height: auto;
		width: auto;
	}
.widget-title .dataTables_filter{
	display:none;
}
}
@media (max-width: 767px) {
	body {
		padding: 0 !important;
	}
	.container-fluid {
		padding-left: 20px;
		padding-right: 20px;
	}
	#search { display: none; }
	#user-nav > ul > li > a > span.text {
		display: none;
	}
}
@media (min-width: 768px) and (max-width: 979px) {
	[class*="span"], .row-fluid [class*="span"] {
		display: block;
		float: none;
		margin-left: 0;
		width: auto;
	}
}
@media (max-width: 979px) {
	div.dataTables_wrapper .ui-widget-header {
		height: 68px;
	}
	.dataTables_filter {
		position: relative;
	}
	.dataTables_filter, .dataTables_paginate {
		text-align: center;
	}
}

.widget-title   .dataTables_filter{
	height:30px ; float:left;
}
  .dataTables_filter input{
	width:150px;
}
 
div.table-action{
	text-align: left; float: left;min-width:100px;
}
div.table-action a{
	   border: 1px solid #E6E6E6;
	   background-color:#E6E6E6;
    font-size: 14px; 
    line-height: 36px;
    margin: 5px;
    padding: 5px;
}
div.table-action a:hover{
	background-color:#FFF;
}

table  tr:hover{
	background-color:#F8F9D2;
}
.txtc{text-align:center;}
.btn-back{
	padding:16px;
	float:left; background-color:transparent;
   background:url(../img/back32.png) no-repeat center center transparent;
   opacity:0.5;
}

.btn-back:hover{
	opacity:1; background-color:transparent;
}
.menuj
{}
body {
	background:url(../images/backgrounds/default.jpg) repeat;
}

#header {
	background-color: #2b2927;
	border-top:3px solid #f77825;  
    border-bottom: 1px solid #555555; margin-top:10px;
}

#search input[type=text] {
	background-color: #fff;
}
#search input[type=text]:focus {
	color: #777777;
}
.dropdown-menu li a:hover, .dropdown-menu .active a, .dropdown-menu .active a:hover {
    color: #eeeeee;
	background:#F77825;
   
}
.top_message{ float:right; padding:20px 12px; position:relative; top:-13px; border-left:1px solid #3D3A37; font-size:14px; line-height:20px; *line-height:20px; color:#333; text-align:center;  vertical-align:middle; cursor:pointer; }
.top_message:hover{ background:#000}
.rightzero{ right:0px; display:none;}
@media (max-width: 480px) {
	#sidebar > a {
		background-image: -moz-linear-gradient(top, #464646 0%, #404040 100%);
		border-bottom: 1px solid #6e6e6e;
	}
	#sidebar > ul {
		background-color: #444444;
	}
}
@media (min-width: 481px) and (max-width: 767px) {
	#sidebar > ul ul:before {
		border-right: 7px solid rgba(0, 0, 0, 0.2);
	}
	#sidebar > ul ul:after {
		border-right: 6px solid #222222;
    }
}
/*

Uniform Theme: Uniform Default
Version: 1.6
By: Josh Pyles
License: MIT License
---
For use with the Uniform plugin:
http://pixelmatrixdesign.com/uniform/
---
Generated by Uniform Theme Generator:
http://pixelmatrixdesign.com/uniform/themer.html

*/

/* Global Declaration */

div.selector, 
div.selector span, 
div.checker span,
div.radio span, 
div.uploader, 
div.uploader span.action,
div.button,
div.button span {
  background-image: url(../img/sprite.png);
  background-repeat: no-repeat;
  -webkit-font-smoothing: antialiased;
}

.selector, 
.radio, 
.checker, 
.uploader,
.button, 
.selector *, 
.radio *, 
.checker *, 
.uploader *,
.button *{
  margin: 0;
  padding: 0;
}

/* INPUT & TEXTAREA */

input.text,
input.email, 
input.password,
textarea.uniform {
  font-size: 12px;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-weight: normal;
  padding: 3px;
  color: #777;
  background: url('../img/bg-input-focus.html') repeat-x 0px 0px;
  background: url('../img/bg-input.html') repeat-x 0px 0px;
  border-top: solid 1px #aaa;
  border-left: solid 1px #aaa;
  border-bottom: solid 1px #ccc;
  border-right: solid 1px #ccc;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  outline: 0;
}

input.text:focus,
input.email:focus,
input.password:focus,
textarea.uniform:focus {
  -webkit-box-shadow: 0px 0px 4px rgba(0,0,0,0.3);
  -moz-box-shadow: 0px 0px 4px rgba(0,0,0,0.3);
  box-shadow: 0px 0px 4px rgba(0,0,0,0.3);
  border-color: #999;
  background: url('../img/bg-input-focus.html') repeat-x 0px 0px;
}

/* SPRITES */

/* Select */

div.selector {
  background-position: -483px -130px;
  line-height: 26px;
  height: 26px;
}

div.selector span {
  background-position: right 0px;
  height: 26px;
  line-height: 26px;
}

div.selector select {
  /* change these to adjust positioning of select element */
  top: 0px;
  left: 0px;
}

div.selector:active, 
div.selector.active {
  background-position: -483px -156px;
}

div.selector:active span, 
div.selector.active span {
  background-position: right -26px;
}

div.selector.focus, div.selector.hover, div.selector:hover {
  background-position: -483px -182px;
}

div.selector.focus span, div.selector.hover span, div.selector:hover span {
  background-position: right -52px;
}

div.selector.focus:active,
div.selector.focus.active,
div.selector:hover:active,
div.selector.active:hover {
  background-position: -483px -208px;
}

div.selector.focus:active span,
div.selector:hover:active span,
div.selector.active:hover span,
div.selector.focus.active span {
  background-position: right -78px;
}

div.selector.disabled {
  background-position: -483px -234px;
}

div.selector.disabled span {
  background-position: right -104px;
}

/* Checkbox */

div.checker {
  width: 19px;
  height: 19px;
}

div.checker input {
  width: 19px;
  height: 19px;
}

div.checker span {
  background-position: 0px -260px;
  height: 19px;
  width: 19px;
}

div.checker:active span, 
div.checker.active span {
  background-position: -19px -260px;
}

div.checker.focus span,
div.checker:hover span {
  background-position: -38px -260px;
}

div.checker.focus:active span,
div.checker:active:hover span,
div.checker.active:hover span,
div.checker.focus.active span {
  background-position: -57px -260px;
}

div.checker span.checked {
  background-position: -76px -260px;
}

div.checker:active span.checked, 
div.checker.active span.checked {
  background-position: -95px -260px;
}

div.checker.focus span.checked,
div.checker:hover span.checked {
  background-position: -114px -260px;
}

div.checker.focus:active span.checked,
div.checker:hover:active span.checked,
div.checker.active:hover span.checked,
div.checker.active.focus span.checked {
  background-position: -133px -260px;
}

div.checker.disabled span,
div.checker.disabled:active span,
div.checker.disabled.active span {
  background-position: -152px -260px;
}

div.checker.disabled span.checked,
div.checker.disabled:active span.checked,
div.checker.disabled.active span.checked {
  background-position: -171px -260px;
}

/* Radio */

div.radio {
  width: 18px;
  height: 18px;
}

div.radio input {
  width: 18px;
  height: 18px;
}

div.radio span {
  height: 18px;
  width: 18px;
  background-position: 0px -279px;
}

div.radio:active span, 
div.radio.active span {
  background-position: -18px -279px;
}

div.radio.focus span, 
div.radio:hover span {
  background-position: -36px -279px;
}

div.radio.focus:active span,
div.radio:active:hover span,
div.radio.active:hover span,
div.radio.active.focus span {
  background-position: -54px -279px;
}

div.radio span.checked {
  background-position: -72px -279px;
}

div.radio:active span.checked,
div.radio.active span.checked {
  background-position: -90px -279px;
}

div.radio.focus span.checked, div.radio:hover span.checked {
  background-position: -108px -279px;
}

div.radio.focus:active span.checked, 
div.radio:hover:active span.checked,
div.radio.focus.active span.checked,
div.radio.active:hover span.checked {
  background-position: -126px -279px;
}

div.radio.disabled span,
div.radio.disabled:active span,
div.radio.disabled.active span {
  background-position: -144px -279px;
}

div.radio.disabled span.checked,
div.radio.disabled:active span.checked,
div.radio.disabled.active span.checked {
  background-position: -162px -279px;
}

/* Uploader */

div.uploader {
  background-position: 0px -297px;
  height: 28px;
}

div.uploader span.action {
  background-position: right -409px;
  height: 24px;
  line-height: 24px;
}

div.uploader span.filename {
  height: 24px;
  /* change this line to adjust positioning of filename area */
  margin: 2px 0px 2px 2px;
  line-height: 24px;
}

div.uploader.focus,
div.uploader.hover,
div.uploader:hover {
  background-position: 0px -353px;
}

div.uploader.focus span.action,
div.uploader.hover span.action,
div.uploader:hover span.action {
  background-position: right -437px;
}

div.uploader.active span.action,
div.uploader:active span.action {
  background-position: right -465px;
}

div.uploader.focus.active span.action,
div.uploader:focus.active span.action,
div.uploader.focus:active span.action,
div.uploader:focus:active span.action {
  background-position: right -493px;
}

div.uploader.disabled {
  background-position: 0px -325px;
}

div.uploader.disabled span.action {
  background-position: right -381px;
}

div.button {
  background-position: 0px -523px;
}

div.button span {
  background-position: right -643px;
}

div.button.focus,
div.button:focus,
div.button:hover,
div.button.hover {
  background-position: 0px -553px;
}

div.button.focus span,
div.button:focus span,
div.button:hover span,
div.button.hover span {
  background-position: right -673px; 
}

div.button.active,
div.button:active {
  background-position: 0px -583px;
}

div.button.active span,
div.button:active span {
  background-position: right -703px;
  color: #555;
}

div.button.disabled,
div.button:disabled {
  background-position: 0px -613px;
}

div.button.disabled span,
div.button:disabled span {
  background-position: right -733px;
  color: #bbb;
  cursor: default;
}

/* PRESENTATION */

/* Button */

div.button {
  height: 30px;
}

div.button span {
  margin-left: 13px;
  height: 22px;
  padding-top: 8px;
  font-weight: bold;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 12px;
  letter-spacing: 1px;
  text-transform: uppercase;
  padding-left: 2px;
  padding-right: 15px;
}

/* Select */
div.selector {
  width: 190px;
  font-size: 12px;
}

div.selector select {
  min-width: 190px;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 12px;
  border: solid 1px #fff;
}

div.selector span {
  padding: 0px 25px 0px 2px;
  cursor: pointer;
}

div.selector span {
  color: #666;
  width: 158px;
  text-shadow: 0 1px 0 #fff;
}

div.selector.disabled span {
  color: #bbb;
}

/* Checker */
div.checker {
  margin-right: 5px;
}

/* Radio */
div.radio {
  margin-right: 3px;
}

/* Uploader */
div.uploader {
  width: 190px;
  cursor: pointer;
}

div.uploader span.action {
  width: 85px;
  text-align: center;
  text-shadow: #fff 0px 1px 0px;
  background-color: #fff;
  font-size: 11px;
  font-weight: bold;
}

div.uploader span.filename {
  color: #777;
  width: 82px;
  border-right: solid 1px #bbb;
  font-size: 11px;
}

div.uploader input {
  width: 190px;
}

div.uploader.disabled span.action {
  color: #aaa;
}

div.uploader.disabled span.filename {
  border-color: #ddd;
  color: #aaa;
}
/*

CORE FUNCTIONALITY 

Not advised to edit stuff below this line
-----------------------------------------------------
*/

.selector, 
.checker, 
.button, 
.radio, 
.uploader {
  display: -moz-inline-box;
  display: inline-block;
  vertical-align: middle;
  zoom: 1;
  *display: inline;
}

.selector select:focus, .radio input:focus, .checker input:focus, .uploader input:focus {
  outline: 0;
}

/* Button */

div.button a,
div.button button,
div.button input {
  position: absolute;
}

div.button {
  cursor: pointer;
  position: relative;
}

div.button span {
  display: -moz-inline-box;
  display: inline-block;
  line-height: 1;
  text-align: center;
}

/* Select */

div.selector {
  position: relative;
  padding-left: 10px;
  overflow: hidden;
}

div.selector span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

div.selector select {
  position: absolute;
  opacity: 0;
  filter: alpha(opacity:0);
  height: 25px;
  border: none;
  background: none;
}

/* Checker */

div.checker {
  position: relative;
}

div.checker span {
  display: -moz-inline-box;
  display: inline-block;
  text-align: center;
}

div.checker input {
  opacity: 0;
  filter: alpha(opacity:0);
  display: inline-block;
  background: none;
}

/* Radio */

div.radio {
  position: relative;
}

div.radio span {
  display: -moz-inline-box;
  display: inline-block;
  text-align: center;
}

div.radio input {
  opacity: 0;
  filter: alpha(opacity:0);
  text-align: center;
  display: inline-block;
  background: none;
}

/* Uploader */

div.uploader {
  position: relative;
  overflow: hidden;
  cursor: default;
}

div.uploader span.action {
  float: left;
  display: inline;
  padding: 2px 0px;
  overflow: hidden;
  cursor: pointer;
}

div.uploader span.filename {
  padding: 0px 10px;
  float: left;
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: default;
  position:relative;
}

div.uploader input {
  opacity: 0;
  filter: alpha(opacity:0);
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  float: right;
  height: 25px;
  border: none;
  cursor: default;
}
/*
Version: 3.2 Timestamp: Mon Sep 10 10:38:04 PDT 2012
*/
.select2-container {
    position: relative;
    display: inline-block;
    /* inline-block for ie7 */
    zoom: 1;
    *display: inline;
    vertical-align: top;
}

.select2-container,
.select2-drop,
.select2-search,
.select2-search input{
  /*
    Force border-box so that % widths fit the parent
    container without overlap because of margin/padding.

    More Info : http://www.quirksmode.org/css/box.html
  */
  -moz-box-sizing: border-box;    /* firefox */
  -ms-box-sizing: border-box;     /* ie */
  -webkit-box-sizing: border-box; /* webkit */
  -khtml-box-sizing: border-box;  /* konqueror */
  box-sizing: border-box;         /* css3 */
}

.select2-container .select2-choice {
    background-color: #fff;
  
    -moz-background-clip: padding;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    border: 1px solid #aaa;
    display: block;
    overflow: hidden;
    white-space: nowrap;
    position: relative;
    height: 26px;
    line-height: 26px;
    padding: 0 0 0 8px;
    color: #444;
    text-decoration: none;
}

.select2-container.select2-drop-above .select2-choice
{
    border-bottom-color: #aaa;
   
}

.select2-container .select2-choice span {
    margin-right: 26px;
    display: block;
    overflow: hidden;
    white-space: nowrap;
    -o-text-overflow: ellipsis;
    -ms-text-overflow: ellipsis;
    text-overflow: ellipsis;
}

.select2-container .select2-choice abbr {
  display: block;
  position: absolute;
  right: 26px;
  top: 8px;
  width: 12px;
  height: 12px;
  font-size: 1px;
  background: url('../img/select2.png') right top no-repeat;
  cursor: pointer;
  text-decoration: none;
  border:0;
  outline: 0;
}
.select2-container .select2-choice abbr:hover {
  background-position: right -11px;
  cursor: pointer;
}

.select2-drop {
    background: #fff;
    color: #000;
    border: 1px solid #aaa;
    border-top: 0;
    position: absolute;
    top: 100%;
    -webkit-box-shadow: 0 4px 5px rgba(0, 0, 0, .15);
    -moz-box-shadow: 0 4px 5px rgba(0, 0, 0, .15);
    -o-box-shadow: 0 4px 5px rgba(0, 0, 0, .15);
    box-shadow: 0 4px 5px rgba(0, 0, 0, .15);
    z-index: 9999;
    width:100%;
    margin-top:-1px;

}

.select2-drop.select2-drop-above {
 
    margin-top:1px;
    border-top: 1px solid #aaa;
    border-bottom: 0;

    -webkit-box-shadow: 0 -4px 5px rgba(0, 0, 0, .15);
    -moz-box-shadow: 0 -4px 5px rgba(0, 0, 0, .15);
    -o-box-shadow: 0 -4px 5px rgba(0, 0, 0, .15);
    box-shadow: 0 -4px 5px rgba(0, 0, 0, .15);
}

.select2-container .select2-choice div {
   
    -moz-background-clip: padding;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    background: #ccc;
    border-left: 1px solid #aaa;
    position: absolute;
    right: 0;
    top: 0;
    display: block;
    height: 100%;
    width: 18px;
}

.select2-container .select2-choice div b {
    background: url('../img/select2.png') no-repeat 0 1px;
    display: block;
    width: 100%;
    height: 100%;
}

.select2-search {
  display: inline-block;
    white-space: nowrap;
    z-index: 10000;
  min-height: 26px;
  width: 100%;
  margin: 0;
  padding-left: 4px;
  padding-right: 4px;
}

.select2-search-hidden {
  display: block;
  position: absolute;
  left: -10000px;
}

.select2-search input {
    background: #fff url('../img/select2.png') no-repeat 100% -22px;
    background: url('../img/select2.png') no-repeat 100% -22px, -webkit-gradient(linear, left bottom, left top, color-stop(0.85, white), color-stop(0.99, #eeeeee));
    background: url('../img/select2.png') no-repeat 100% -22px, -webkit-linear-gradient(center bottom, white 85%, #eeeeee 99%);
    background: url('../img/select2.png') no-repeat 100% -22px, -moz-linear-gradient(center bottom, white 85%, #eeeeee 99%);
    background: url('../img/select2.png') no-repeat 100% -22px, -o-linear-gradient(bottom, white 85%, #eeeeee 99%);
    background: url('../img/select2.png') no-repeat 100% -22px, -ms-linear-gradient(top, #ffffff 85%, #eeeeee 99%);
    background: url('../img/select2.png') no-repeat 100% -22px, linear-gradient(top, #ffffff 85%, #eeeeee 99%);
    padding: 4px 20px 4px 5px;
    outline: 0;
    border: 1px solid #aaa;
    font-family: sans-serif;
    font-size: 1em;
    width:100%;
    margin:0;
    height:auto !important;
    min-height: 26px;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    border-radius: 0;
    -moz-border-radius: 0;
    -webkit-border-radius: 0;
}

.select2-drop.select2-drop-above .select2-search input
{
    margin-top:4px;
}

.select2-search input.select2-active {
    background: #fff url('../img/spinner.gif') no-repeat 100%;
    background: url('../img/spinner.gif') no-repeat 100%, -webkit-gradient(linear, left bottom, left top, color-stop(0.85, white), color-stop(0.99, #eeeeee));
    background: url('../img/spinner.gif') no-repeat 100%, -webkit-linear-gradient(center bottom, white 85%, #eeeeee 99%);
    background: url('../img/spinner.gif') no-repeat 100%, -moz-linear-gradient(center bottom, white 85%, #eeeeee 99%);
    background: url('../img/spinner.gif') no-repeat 100%, -o-linear-gradient(bottom, white 85%, #eeeeee 99%);
    background: url('../img/spinner.gif') no-repeat 100%, -ms-linear-gradient(top, #ffffff 85%, #eeeeee 99%);
    background: url('../img/spinner.gif') no-repeat 100%, linear-gradient(top, #ffffff 85%, #eeeeee 99%);
}


.select2-container-active .select2-choice,
.select2-container-active .select2-choices {
    -webkit-box-shadow: 0 0 5px rgba(0,0,0,.3);
    -moz-box-shadow   : 0 0 5px rgba(0,0,0,.3);
    -o-box-shadow     : 0 0 5px rgba(0,0,0,.3);
    box-shadow        : 0 0 5px rgba(0,0,0,.3);
    border: 1px solid #5897fb;
    outline: none;
}

.select2-dropdown-open .select2-choice {
  border: 1px solid #aaa;
  border-bottom-color: transparent;
  -webkit-box-shadow: 0 1px 0 #fff inset;
  -moz-box-shadow   : 0 1px 0 #fff inset;
  -o-box-shadow     : 0 1px 0 #fff inset;
  box-shadow        : 0 1px 0 #fff inset;
  background-color: #eee;
  background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, white), color-stop(0.5, #eeeeee));
  background-image: -webkit-linear-gradient(center bottom, white 0%, #eeeeee 50%);
  background-image: -moz-linear-gradient(center bottom, white 0%, #eeeeee 50%);
  background-image: -o-linear-gradient(bottom, white 0%, #eeeeee 50%);
  background-image: -ms-linear-gradient(top, #ffffff 0%,#eeeeee 50%);
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#eeeeee',GradientType=0 );
  background-image: linear-gradient(top, #ffffff 0%,#eeeeee 50%);
  -webkit-border-bottom-left-radius : 0;
  -webkit-border-bottom-right-radius: 0;
  -moz-border-radius-bottomleft : 0;
  -moz-border-radius-bottomright: 0;
  border-bottom-left-radius : 0;
  border-bottom-right-radius: 0;
}

.select2-dropdown-open .select2-choice div {
  background: transparent;
  border-left: none;
}
.select2-dropdown-open .select2-choice div b {
  background-position: -18px 1px;
}

/* results */
.select2-results {
  margin: 4px 4px 4px 0;
  padding: 0 0 0 4px;
  position: relative;
  overflow-x: hidden;
  overflow-y: auto;
  max-height: 200px;
}

.select2-results ul.select2-result-sub {
  margin: 0 0 0 0;
}

.select2-results ul.select2-result-sub > li .select2-result-label { padding-left: 20px }
.select2-results ul.select2-result-sub ul.select2-result-sub > li .select2-result-label { padding-left: 40px }
.select2-results ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub > li .select2-result-label { padding-left: 60px }
.select2-results ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub > li .select2-result-label { padding-left: 80px }
.select2-results ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub > li .select2-result-label { padding-left: 100px }
.select2-results ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub > li .select2-result-label { padding-left: 110px }
.select2-results ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub ul.select2-result-sub > li .select2-result-label { padding-left: 120px }

.select2-results li {
  list-style: none;
  display: list-item;
}

.select2-results li.select2-result-with-children > .select2-result-label {
  font-weight: bold;
}

.select2-results .select2-result-label {
  padding: 3px 7px 4px;
  margin: 0;
  cursor: pointer;
}

.select2-results .select2-highlighted {
  background: #3875d7;
  color: #fff;
}
.select2-results li em {
  background: #feffde;
  font-style: normal;
}
.select2-results .select2-highlighted em {
  background: transparent;
}
.select2-results .select2-no-results,
.select2-results .select2-searching,
.select2-results .select2-selection-limit {
  background: #f4f4f4;
  display: list-item;
}

/*
disabled look for already selected choices in the results dropdown
.select2-results .select2-disabled.select2-highlighted {
    color: #666;
    background: #f4f4f4;
    display: list-item;
    cursor: default;
}
.select2-results .select2-disabled {
  background: #f4f4f4;
  display: list-item;
  cursor: default;
}
*/
.select2-results .select2-disabled {
    display: none;
}

.select2-more-results.select2-active {
    background: #f4f4f4 url('../img/spinner.gif') no-repeat 100%;
}

.select2-more-results {
  background: #f4f4f4;
  display: list-item;
}

/* disabled styles */

.select2-container.select2-container-disabled .select2-choice {
    background-color: #f4f4f4;
    background-image: none;
    border: 1px solid #ddd;
    cursor: default;
}

.select2-container.select2-container-disabled .select2-choice div {
    background-color: #f4f4f4;
    background-image: none;
    border-left: 0;
}


/* multiselect */

.select2-container-multi .select2-choices {
    background-color: #fff;
      background-image: -webkit-gradient(linear, 0% 0%, 0% 100%, color-stop(1%, #eeeeee), color-stop(15%, #ffffff));
      background-image: -webkit-linear-gradient(top, #eeeeee 1%, #ffffff 15%);
      background-image: -moz-linear-gradient(top, #eeeeee 1%, #ffffff 15%);
      background-image: -o-linear-gradient(top, #eeeeee 1%, #ffffff 15%);
      background-image: -ms-linear-gradient(top, #eeeeee 1%, #ffffff 15%);
      background-image: linear-gradient(top, #eeeeee 1%, #ffffff 15%);
      border: 1px solid #ccc;
      margin: 0;
      padding: 0;
      cursor: text;
      overflow: hidden;
      height: auto !important;
      height: 1%;
      position: relative;
      
}

.select2-container-multi .select2-choices {
    min-height: 26px;
}

.select2-container-multi.select2-container-active .select2-choices {
    -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);
    -moz-box-shadow   : 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);
    -o-box-shadow     : 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);
    box-shadow        : 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6);
    border: 1px solid #5897fb;
    outline: none;
}
.select2-container-multi .select2-choices li {
  float: left;
  list-style: none;
}
.select2-container-multi .select2-choices .select2-search-field {
  white-space: nowrap;
  margin: 0;
  padding: 0;
}

.select2-container-multi .select2-choices .select2-search-field input {
  color: #666;
  background: transparent !important;
  font-family: sans-serif;
  font-size: 100%;
  height: 15px;
  padding: 5px;
  margin: 1px 0;
  outline: 0;
  border: 0;
  -webkit-box-shadow: none;
  -moz-box-shadow   : none;
  -o-box-shadow     : none;
  box-shadow        : none;
}

.select2-container-multi .select2-choices .select2-search-field input.select2-active {
    background: #fff url('../img/spinner.gif') no-repeat 100% !important;
}

.select2-default {
  color: #999 !important;
}

.select2-container-multi .select2-choices .select2-search-choice {
  -moz-background-clip   : padding;
  -webkit-background-clip: padding-box;
  background-clip        : padding-box;
  background:#f9eae1;
  -webkit-box-shadow: 0 0 2px #ffffff inset, 0 1px 0 rgba(0,0,0,0.05);
  -moz-box-shadow   : 0 0 2px #ffffff inset, 0 1px 0 rgba(0,0,0,0.05);
  box-shadow        : 0 0 2px #ffffff inset, 0 1px 0 rgba(0,0,0,0.05);
  color: #333;
  border: 1px solid #F77825;
  line-height: 13px;
  padding: 3px 5px 3px 18px;
  margin: 3px 0 3px 5px;
  position: relative;
  cursor: default;
}
.select2-container-multi .select2-choices .select2-search-choice span {
  cursor: default;
}
.select2-container-multi .select2-choices .select2-search-choice-focus {
  background: #d4d4d4;
}

.select2-search-choice-close {
  display: block;
  position: absolute;
  right: 3px;
  top: 4px;
  width: 12px;
  height: 13px;
  font-size: 1px;
  background: url('../img/select2.png') right top no-repeat;
  outline: none;
}

.select2-container-multi .select2-search-choice-close {
  left: 3px;
}


.select2-container-multi .select2-choices .select2-search-choice .select2-search-choice-close:hover {
  background-position: right -11px;
}
.select2-container-multi .select2-choices .select2-search-choice-focus .select2-search-choice-close {
  background-position: right -11px;
}

/* disabled styles */

.select2-container-multi.select2-container-disabled .select2-choices{
    background-color: #f4f4f4;
    background-image: none;
    border: 1px solid #ddd;
    cursor: default;
}

.select2-container-multi.select2-container-disabled .select2-choices .select2-search-choice {
    background-image: none;
    background-color: #f4f4f4;
    border: 1px solid #ddd;
    padding: 3px 5px 3px 5px;
}

.select2-container-multi.select2-container-disabled .select2-choices .select2-search-choice .select2-search-choice-close {
    display: none;
}
/* end multiselect */

.select2-result-selectable .select2-match,
.select2-result-unselectable .select2-result-selectable .select2-match { text-decoration: underline; }
.select2-result-unselectable .select2-match { text-decoration: none; }

.select2-offscreen { position: absolute; left: -10000px; }

/* Retina-ize icons */

@media only screen and (-webkit-min-device-pixel-ratio: 1.5) {
	.select2-search input, .select2-search-choice-close, .select2-container .select2-choice abbr, .select2-container .select2-choice div b {
		background-image: url(../img/select2x2.png) !important;
		background-repeat: no-repeat !important;
		background-size: 60px 40px !important;
	}
	.select2-search input {
		background-position: 100% -21px !important;
	}
}


</style>