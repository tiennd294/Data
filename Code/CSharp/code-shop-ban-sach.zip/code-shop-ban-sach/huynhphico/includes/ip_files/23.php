<?php
//385875968-402653183
$ranges=Array(
);
?>