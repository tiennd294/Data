public class SingletonExample {

    private static SingletonExample instance;

    static SingletonExample () {
        instance = new SingletonExample();
    }
        
    private SingletonExample () {}
    
    public static SingletonExample Instance { 
        
        get { return instance; }
    }
    
    public void SomeMethod1 () { /*..*/ }
    public void SomeMethod2 () { /*..*/ }
    
    public static void Main() {
        
        SingletonExample s = SingletonExample.Instance;
        s.SomeMethod1();
        
        SingletonExample.Instance.SomeMethod2();
    }
}
