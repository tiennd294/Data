using System;
using System.Reflection;
using System.Collections;

public class ListModifier {

    public ListModifier () {

        ArrayList list = 
            (ArrayList)AppDomain.CurrentDomain.GetData("People");
        list.Add("Tam");
    }
}

public class PassDataExample {

    public static void Main() {

        AppDomain domain = AppDomain.CreateDomain("Test");

        ArrayList list = new ArrayList();
        list.Add("Phuong");
        list.Add("Phong");
        list.Add("Nam");

        domain.SetData("People", list);

        domain.CreateInstance("03-08", "ListModifier");

        foreach (string s in (ArrayList)domain.GetData("People")) {
            Console.WriteLine(s);
        }

        Console.ReadLine();
	}
}
