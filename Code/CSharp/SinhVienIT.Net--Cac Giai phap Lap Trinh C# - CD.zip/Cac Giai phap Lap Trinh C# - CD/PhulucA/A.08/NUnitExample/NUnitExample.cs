using System;
using System.Collections;
using NUnit.Framework;

namespace NUnitExample
{
	[TestFixture]
	public class HashtableTest 
	{
		public HashtableTest() 
		{
            
		}

		/// <summary>
		/// This test adds a number of values to the Hashtable collection 
		/// and then retrieves those values and checks if they match.
		/// </summary>
		[Test]
		public void HashtableAddTest()
		{
			Hashtable ht = new Hashtable();
            
			ht.Add("Key1", "Value1");
			ht.Add("Key2", "Value2");

			Assert.AreEqual("Value1", ht["Key1"], "Wrong object returned!");
			Assert.AreEqual("Value2", ht["Key2"], "Wrong object returned!");
		}
	
	}

}

