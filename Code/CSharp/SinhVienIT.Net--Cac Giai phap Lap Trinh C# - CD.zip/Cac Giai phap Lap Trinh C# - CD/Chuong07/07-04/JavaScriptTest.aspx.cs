using System;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.SessionState;

/// <summary>
/// Summary description for JavaScriptTest.
/// </summary>
public class JavaScriptTest : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.Table Table1;
	protected System.Web.UI.WebControls.Image Image1;

	private void Page_Load(object sender, System.EventArgs e) {

		string highlightScript = 
			"<script language=JavaScript> " +
			"function HighlightCell(cell) {" +
			"cell.bgColor = '#C0C0C0';" +
			"if (cell.cellIndex == 0)"+
			"{document.Form1.Image1.src='happy_animation.gif';}"+
			"else {document.Form1.Image1.src='question_animation.gif';}" +
			";}" +
			"</script>";

		string unhighlightScript = 
			"<script language=JavaScript> " +
			"function UnHighlightCell(cell) {" +
			"cell.bgColor = '#FFFFFF';" +
			"}" +
			"</script>";

		if (!this.IsClientScriptBlockRegistered("Highlight")) {
			Page.RegisterClientScriptBlock("Highlight", highlightScript);
		}

		if (!this.IsClientScriptBlockRegistered("UnHighlight")) {
			Page.RegisterClientScriptBlock("UnHighlight", unhighlightScript);
		}
		
		foreach (TableRow row in Table1.Rows) {
	
			foreach (TableCell cell in row.Cells) {
			
				cell.Attributes.Add("onMouseOver", "HighlightCell(this);");
				cell.Attributes.Add("onMouseOut", "UnHighlightCell(this);");
			}
		}
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion
}
