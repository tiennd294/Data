namespace System
{
    partial class frmSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpcustomer = new System.Windows.Forms.GroupBox();
            this.lblzip = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblstreet = new System.Windows.Forms.Label();
            this.lblstate = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.txtzip = new System.Windows.Forms.TextBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtstreet = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.grpitem = new System.Windows.Forms.GroupBox();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.lblprice = new System.Windows.Forms.Label();
            this.lblweight = new System.Windows.Forms.Label();
            this.lblquantity = new System.Windows.Forms.Label();
            this.lbldescription = new System.Windows.Forms.Label();
            this.txtdescription = new System.Windows.Forms.TextBox();
            this.txtweight = new System.Windows.Forms.TextBox();
            this.grpsummary = new System.Windows.Forms.GroupBox();
            this.txtsales = new System.Windows.Forms.TextBox();
            this.txtdue = new System.Windows.Forms.TextBox();
            this.lbldue = new System.Windows.Forms.Label();
            this.txtshipping = new System.Windows.Forms.TextBox();
            this.lblshipping = new System.Windows.Forms.Label();
            this.lblsales = new System.Windows.Forms.Label();
            this.txtdollar = new System.Windows.Forms.TextBox();
            this.lbldollar = new System.Windows.Forms.Label();
            this.btnitem = new System.Windows.Forms.Button();
            this.btnoder = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.grpcustomer.SuspendLayout();
            this.grpitem.SuspendLayout();
            this.grpsummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpcustomer
            // 
            this.grpcustomer.Controls.Add(this.lblzip);
            this.grpcustomer.Controls.Add(this.lblcity);
            this.grpcustomer.Controls.Add(this.lblstreet);
            this.grpcustomer.Controls.Add(this.lblstate);
            this.grpcustomer.Controls.Add(this.lblname);
            this.grpcustomer.Controls.Add(this.txtzip);
            this.grpcustomer.Controls.Add(this.txtstate);
            this.grpcustomer.Controls.Add(this.txtcity);
            this.grpcustomer.Controls.Add(this.txtstreet);
            this.grpcustomer.Controls.Add(this.txtname);
            this.grpcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpcustomer.ForeColor = System.Drawing.SystemColors.Desktop;
            this.grpcustomer.Location = new System.Drawing.Point(12, 1);
            this.grpcustomer.Name = "grpcustomer";
            this.grpcustomer.Size = new System.Drawing.Size(528, 107);
            this.grpcustomer.TabIndex = 0;
            this.grpcustomer.TabStop = false;
            this.grpcustomer.Text = "Customer";
            // 
            // lblzip
            // 
            this.lblzip.AutoSize = true;
            this.lblzip.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblzip.Location = new System.Drawing.Point(309, 75);
            this.lblzip.Name = "lblzip";
            this.lblzip.Size = new System.Drawing.Size(31, 17);
            this.lblzip.TabIndex = 1;
            this.lblzip.Text = "Zip";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblcity.Location = new System.Drawing.Point(14, 75);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(35, 17);
            this.lblcity.TabIndex = 1;
            this.lblcity.Text = "City";
            // 
            // lblstreet
            // 
            this.lblstreet.AutoSize = true;
            this.lblstreet.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblstreet.Location = new System.Drawing.Point(14, 49);
            this.lblstreet.Name = "lblstreet";
            this.lblstreet.Size = new System.Drawing.Size(52, 17);
            this.lblstreet.TabIndex = 1;
            this.lblstreet.Text = "Street";
            // 
            // lblstate
            // 
            this.lblstate.AutoSize = true;
            this.lblstate.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblstate.Location = new System.Drawing.Point(162, 75);
            this.lblstate.Name = "lblstate";
            this.lblstate.Size = new System.Drawing.Size(46, 17);
            this.lblstate.TabIndex = 1;
            this.lblstate.Text = "State";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblname.Location = new System.Drawing.Point(14, 23);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(49, 17);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "Name";
            // 
            // txtzip
            // 
            this.txtzip.Location = new System.Drawing.Point(380, 72);
            this.txtzip.Name = "txtzip";
            this.txtzip.Size = new System.Drawing.Size(132, 23);
            this.txtzip.TabIndex = 0;
            // 
            // txtstate
            // 
            this.txtstate.Location = new System.Drawing.Point(223, 72);
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(73, 23);
            this.txtstate.TabIndex = 0;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(82, 72);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(66, 23);
            this.txtcity.TabIndex = 0;
            // 
            // txtstreet
            // 
            this.txtstreet.Location = new System.Drawing.Point(82, 46);
            this.txtstreet.Name = "txtstreet";
            this.txtstreet.Size = new System.Drawing.Size(430, 23);
            this.txtstreet.TabIndex = 0;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(82, 20);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(430, 23);
            this.txtname.TabIndex = 0;
            // 
            // grpitem
            // 
            this.grpitem.Controls.Add(this.txtquantity);
            this.grpitem.Controls.Add(this.txtprice);
            this.grpitem.Controls.Add(this.lblprice);
            this.grpitem.Controls.Add(this.lblweight);
            this.grpitem.Controls.Add(this.lblquantity);
            this.grpitem.Controls.Add(this.lbldescription);
            this.grpitem.Controls.Add(this.txtdescription);
            this.grpitem.Controls.Add(this.txtweight);
            this.grpitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpitem.ForeColor = System.Drawing.SystemColors.Desktop;
            this.grpitem.Location = new System.Drawing.Point(12, 123);
            this.grpitem.Name = "grpitem";
            this.grpitem.Size = new System.Drawing.Size(528, 87);
            this.grpitem.TabIndex = 0;
            this.grpitem.TabStop = false;
            this.grpitem.Text = "Item";
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(116, 51);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(63, 23);
            this.txtquantity.TabIndex = 0;
            this.txtquantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(380, 51);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(132, 23);
            this.txtprice.TabIndex = 0;
            this.txtprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblprice.Location = new System.Drawing.Point(322, 54);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(45, 17);
            this.lblprice.TabIndex = 1;
            this.lblprice.Text = "Price";
            // 
            // lblweight
            // 
            this.lblweight.AutoSize = true;
            this.lblweight.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblweight.Location = new System.Drawing.Point(185, 54);
            this.lblweight.Name = "lblweight";
            this.lblweight.Size = new System.Drawing.Size(58, 17);
            this.lblweight.TabIndex = 1;
            this.lblweight.Text = "Weight";
            // 
            // lblquantity
            // 
            this.lblquantity.AutoSize = true;
            this.lblquantity.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblquantity.Location = new System.Drawing.Point(37, 54);
            this.lblquantity.Name = "lblquantity";
            this.lblquantity.Size = new System.Drawing.Size(69, 17);
            this.lblquantity.TabIndex = 1;
            this.lblquantity.Text = "Quantity";
            // 
            // lbldescription
            // 
            this.lbldescription.AutoSize = true;
            this.lbldescription.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbldescription.Location = new System.Drawing.Point(14, 28);
            this.lbldescription.Name = "lbldescription";
            this.lbldescription.Size = new System.Drawing.Size(90, 17);
            this.lbldescription.TabIndex = 1;
            this.lbldescription.Text = "Description";
            // 
            // txtdescription
            // 
            this.txtdescription.Location = new System.Drawing.Point(116, 25);
            this.txtdescription.Name = "txtdescription";
            this.txtdescription.Size = new System.Drawing.Size(396, 23);
            this.txtdescription.TabIndex = 0;
            // 
            // txtweight
            // 
            this.txtweight.Location = new System.Drawing.Point(243, 51);
            this.txtweight.Name = "txtweight";
            this.txtweight.Size = new System.Drawing.Size(73, 23);
            this.txtweight.TabIndex = 0;
            this.txtweight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // grpsummary
            // 
            this.grpsummary.Controls.Add(this.txtsales);
            this.grpsummary.Controls.Add(this.txtdue);
            this.grpsummary.Controls.Add(this.lbldue);
            this.grpsummary.Controls.Add(this.txtshipping);
            this.grpsummary.Controls.Add(this.lblshipping);
            this.grpsummary.Controls.Add(this.lblsales);
            this.grpsummary.Controls.Add(this.txtdollar);
            this.grpsummary.Controls.Add(this.lbldollar);
            this.grpsummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpsummary.ForeColor = System.Drawing.SystemColors.Desktop;
            this.grpsummary.Location = new System.Drawing.Point(12, 226);
            this.grpsummary.Name = "grpsummary";
            this.grpsummary.Size = new System.Drawing.Size(528, 126);
            this.grpsummary.TabIndex = 0;
            this.grpsummary.TabStop = false;
            this.grpsummary.Text = "Summary";
            // 
            // txtsales
            // 
            this.txtsales.Enabled = false;
            this.txtsales.Location = new System.Drawing.Point(223, 43);
            this.txtsales.Name = "txtsales";
            this.txtsales.Size = new System.Drawing.Size(289, 23);
            this.txtsales.TabIndex = 0;
            this.txtsales.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtdue
            // 
            this.txtdue.Enabled = false;
            this.txtdue.Location = new System.Drawing.Point(223, 95);
            this.txtdue.Name = "txtdue";
            this.txtdue.Size = new System.Drawing.Size(289, 23);
            this.txtdue.TabIndex = 0;
            this.txtdue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbldue
            // 
            this.lbldue.AutoSize = true;
            this.lbldue.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbldue.Location = new System.Drawing.Point(58, 98);
            this.lbldue.Name = "lbldue";
            this.lbldue.Size = new System.Drawing.Size(138, 17);
            this.lbldue.TabIndex = 1;
            this.lbldue.Text = "Total Amount Due";
            // 
            // txtshipping
            // 
            this.txtshipping.Enabled = false;
            this.txtshipping.Location = new System.Drawing.Point(223, 69);
            this.txtshipping.Name = "txtshipping";
            this.txtshipping.Size = new System.Drawing.Size(289, 23);
            this.txtshipping.TabIndex = 0;
            this.txtshipping.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblshipping
            // 
            this.lblshipping.AutoSize = true;
            this.lblshipping.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblshipping.Location = new System.Drawing.Point(23, 72);
            this.lblshipping.Name = "lblshipping";
            this.lblshipping.Size = new System.Drawing.Size(173, 17);
            this.lblshipping.TabIndex = 1;
            this.lblshipping.Text = "Shipping And Handling";
            // 
            // lblsales
            // 
            this.lblsales.AutoSize = true;
            this.lblsales.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblsales.Location = new System.Drawing.Point(117, 46);
            this.lblsales.Name = "lblsales";
            this.lblsales.Size = new System.Drawing.Size(79, 17);
            this.lblsales.TabIndex = 1;
            this.lblsales.Text = "Sales Tax";
            // 
            // txtdollar
            // 
            this.txtdollar.Enabled = false;
            this.txtdollar.Location = new System.Drawing.Point(223, 17);
            this.txtdollar.Name = "txtdollar";
            this.txtdollar.Size = new System.Drawing.Size(289, 23);
            this.txtdollar.TabIndex = 0;
            this.txtdollar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbldollar
            // 
            this.lbldollar.AutoSize = true;
            this.lbldollar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbldollar.Location = new System.Drawing.Point(52, 23);
            this.lbldollar.Name = "lbldollar";
            this.lbldollar.Size = new System.Drawing.Size(144, 17);
            this.lbldollar.TabIndex = 1;
            this.lbldollar.Text = "Dollar Amount Due";
            // 
            // btnitem
            // 
            this.btnitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnitem.Location = new System.Drawing.Point(29, 369);
            this.btnitem.Name = "btnitem";
            this.btnitem.Size = new System.Drawing.Size(89, 49);
            this.btnitem.TabIndex = 1;
            this.btnitem.Text = "&Next Item";
            this.btnitem.UseVisualStyleBackColor = true;
            this.btnitem.Click += new System.EventHandler(this.btnitem_Click);
            // 
            // btnoder
            // 
            this.btnoder.Enabled = false;
            this.btnoder.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnoder.Location = new System.Drawing.Point(128, 369);
            this.btnoder.Name = "btnoder";
            this.btnoder.Size = new System.Drawing.Size(89, 49);
            this.btnoder.TabIndex = 1;
            this.btnoder.Text = "Next &Oder";
            this.btnoder.UseVisualStyleBackColor = true;

            // 
            // btnupdate
            // 
            this.btnupdate.Enabled = false;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(227, 369);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(104, 49);
            this.btnupdate.TabIndex = 1;
            this.btnupdate.Text = "Update &Summary";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(435, 369);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(89, 49);
            this.btnexit.TabIndex = 1;
            this.btnexit.Text = "&Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // frmSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 439);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnoder);
            this.Controls.Add(this.btnitem);
            this.Controls.Add(this.grpsummary);
            this.Controls.Add(this.grpitem);
            this.Controls.Add(this.grpcustomer);
            this.Name = "frmSystem";
            this.Text = "The system to process customer orders";
            this.grpcustomer.ResumeLayout(false);
            this.grpcustomer.PerformLayout();
            this.grpitem.ResumeLayout(false);
            this.grpitem.PerformLayout();
            this.grpsummary.ResumeLayout(false);
            this.grpsummary.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpcustomer;
        private System.Windows.Forms.Label lblzip;
        private System.Windows.Forms.Label lblstate;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblstreet;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtstreet;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.GroupBox grpitem;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.TextBox txtdescription;
        private System.Windows.Forms.TextBox txtweight;
        private System.Windows.Forms.GroupBox grpsummary;
        private System.Windows.Forms.TextBox txtsales;
        private System.Windows.Forms.TextBox txtdue;
        private System.Windows.Forms.TextBox txtshipping;
        private System.Windows.Forms.TextBox txtdollar;
        private System.Windows.Forms.Button btnitem;
        private System.Windows.Forms.Button btnoder;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label lblweight;
        private System.Windows.Forms.Label lblquantity;
        private System.Windows.Forms.Label lbldescription;
        private System.Windows.Forms.Label lbldue;
        private System.Windows.Forms.Label lblshipping;
        private System.Windows.Forms.Label lblsales;
        private System.Windows.Forms.Label lbldollar;
        private System.Windows.Forms.TextBox txtzip;
    }
}

