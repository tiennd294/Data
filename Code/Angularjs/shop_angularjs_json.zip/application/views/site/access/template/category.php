<div class="container">
      <div class="sixteen columns">
        <div id="mainNav" class="clearfix">
          <nav>
          <ul>
              <li>
                <a href="<?php echo base_url();?>"><i class="home"></i></a>
              </li>

         
            


             <?php
             
              foreach ($tblcatagory as $row):
                if($row->Parentid==0 &&  $row->Startus=='on' &&  $row->Classify==1){
                
              ?>
                    <li class="list">
                      <a class="hasdropdown"  href="">
                        <?php echo $row->Name;?>
                        </a>
                        <ul class="submenu">
              <?php
                
                 foreach ($tblcatagory as $row2):

                    if($row2->Parentid==$row->Idc &&  $row2->Startus=='on' &&  $row2->Classify==1){
                    
              ?>
                   <li><a href="<?php echo base_url()."defaults/ShowProduct/".$row2->Idc; ?>"><?php echo $row2->Name;?></a></li>
                   
               <?php
                    }
                  endforeach;
               ?> 
                           </ul>
                 </li>
               <?php
                }
              endforeach;
          ?>


              
            </ul>

          </nav><!--end nav-->
          
          <div id="cart">
            <a class="cart_dropdown " id="data" href="<?php if($total_items>0) echo base_url().'defaults/showcart';?>"><img class="cart_dropdown" src="<?php echo public_url();?>/site/access/template/images/icons/cart_icon.png" alt=""> 

<?php
if (isset($carts)) {
  
              echo "<label class='countitems'>".$total_items."</label>";
}
else{
              $items = 0;
              echo "<label class='countitems'>".$items."</label>";
  
}

?>
</a>
            
            <div class="cart_content delete_item">
              <b class="cart_content_arrow2"></b>
              <ul class="cartmenu">

              <?php
                if (isset($carts)) {
                  $TOTAL=0;

                  foreach ($carts as $row):
                    
              ?>
                    <li class="clearfix  delete_item<?php echo $row['id'];?>">
                      <div class="cart_product_name">
              <?php
                      echo "<img style='width:65px;height:65px;' src='".base_url().$row['image_link']."' alt='product image'>";
                      echo "<span>";
                      echo "<strong>".$row['name']."</strong><br>";
                      echo "<br>";
                      echo "</span></div><div class='cart_product_price'><span>";
                      echo "<strong><label  class='qtycart".$row['id']."'>".$row['qty']."</label>x - ".$row['price'].".đ</strong><br>";
                      ?>
                      <a class='remove_item unlinka' onclick="Remove_cart(<?php echo $row['id'];?>)">Remove</a>
                      <?php
                      echo "</span></div><div class='clear'></div></li>";
                      
                      $TOTAL=$TOTAL+$row['subtotal'];
                    
                  endforeach;
                }
              ?>

                
              </ul><!--end ul-->
<?php
if($total_items>0) {

?>
              <div class="dropdown_cart_info clearfix">
                <div class="cart_buttons">
                  <a class="gray_btn" href="<?php echo base_url();?>defaults/showcart">Chi tiết đơn hàng</a><br>
                  <a class="red_btn" href="<?php if((!isset($_SESSION["User"])) || ($_SESSION["User"]=="")) echo base_url();?>defaults/checkout">Tiến hành đặt hàng</a>
                </div><!--end cart buttons-->

                <div class="cart_total_price">
                  <span>

                    <strong>Tổng tiền : <label class="totalcartmoney"><?php echo $TOTAL."</label>.đ";?></strong><br>
                    (Đã bao gồm VAT)
                  </span>
                </div><!--end cart buttons-->
              </div><!--end dropdown_cart_info-->
<?php

}
?>

            </div><!--end cart_content-->
          </div><!--end cart-->

        </div><!--end main-->
      </div><!--end sixteen-->
    </div><!--end container-->





