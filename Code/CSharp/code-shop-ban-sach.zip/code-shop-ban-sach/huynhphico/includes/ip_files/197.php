<?php
//-
$ranges=Array(
"3321886720" => array("3321888767","ZA"),
);
?>