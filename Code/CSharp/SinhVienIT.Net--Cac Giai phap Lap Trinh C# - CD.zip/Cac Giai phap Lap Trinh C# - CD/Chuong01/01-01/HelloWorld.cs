public class HelloWorld {

    public static void Main() {
    
        ConsoleUtils.WriteString("Hello, world");

		System.Console.ReadLine();
    }
}
