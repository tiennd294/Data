namespace BT_Hoten
{
    partial class BT_Hoten
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblhovaten = new System.Windows.Forms.Label();
            this.lblholot = new System.Windows.Forms.Label();
            this.lblten = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnHovaten = new System.Windows.Forms.Button();
            this.btnthoat = new System.Windows.Forms.Button();
            this.btnholot = new System.Windows.Forms.Button();
            this.btnten = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblhovaten
            // 
            this.lblhovaten.AutoSize = true;
            this.lblhovaten.Location = new System.Drawing.Point(102, 9);
            this.lblhovaten.Name = "lblhovaten";
            this.lblhovaten.Size = new System.Drawing.Size(0, 13);
            this.lblhovaten.TabIndex = 0;
            // 
            // lblholot
            // 
            this.lblholot.AutoSize = true;
            this.lblholot.Location = new System.Drawing.Point(41, 52);
            this.lblholot.Name = "lblholot";
            this.lblholot.Size = new System.Drawing.Size(35, 13);
            this.lblholot.TabIndex = 1;
            this.lblholot.Text = "Ho lot";
            // 
            // lblten
            // 
            this.lblten.AutoSize = true;
            this.lblten.Location = new System.Drawing.Point(41, 84);
            this.lblten.Name = "lblten";
            this.lblten.Size = new System.Drawing.Size(26, 13);
            this.lblten.TabIndex = 2;
            this.lblten.Text = "Ten";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(105, 137);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(202, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(105, 100);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(202, 20);
            this.textBox2.TabIndex = 4;
            // 
            // btnHovaten
            // 
            this.btnHovaten.Location = new System.Drawing.Point(289, 192);
            this.btnHovaten.Name = "btnHovaten";
            this.btnHovaten.Size = new System.Drawing.Size(83, 29);
            this.btnHovaten.TabIndex = 5;
            this.btnHovaten.Text = "Ho va ten";
            this.btnHovaten.UseVisualStyleBackColor = true;
            // 
            // btnthoat
            // 
            this.btnthoat.Location = new System.Drawing.Point(151, 285);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(83, 29);
            this.btnthoat.TabIndex = 5;
            this.btnthoat.Text = "Thoat";
            this.btnthoat.UseVisualStyleBackColor = true;
            // 
            // btnholot
            // 
            this.btnholot.Location = new System.Drawing.Point(34, 192);
            this.btnholot.Name = "btnholot";
            this.btnholot.Size = new System.Drawing.Size(83, 29);
            this.btnholot.TabIndex = 5;
            this.btnholot.Text = "Ho Lot";
            this.btnholot.UseVisualStyleBackColor = true;
            this.btnholot.Click += new System.EventHandler(this.btnholot_Click);
            // 
            // btnten
            // 
            this.btnten.Location = new System.Drawing.Point(151, 192);
            this.btnten.Name = "btnten";
            this.btnten.Size = new System.Drawing.Size(83, 29);
            this.btnten.TabIndex = 5;
            this.btnten.Text = "Ten";
            this.btnten.UseVisualStyleBackColor = true;
            // 
            // BT_Hoten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BT_Hoten.Properties.Resources.Tulips;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.btnten);
            this.Controls.Add(this.btnholot);
            this.Controls.Add(this.btnthoat);
            this.Controls.Add(this.btnHovaten);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblten);
            this.Controls.Add(this.lblholot);
            this.Controls.Add(this.lblhovaten);
            this.Name = "BT_Hoten";
            this.Text = "BT_Hoten";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblhovaten;
        private System.Windows.Forms.Label lblholot;
        private System.Windows.Forms.Label lblten;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnHovaten;
        private System.Windows.Forms.Button btnthoat;
        private System.Windows.Forms.Button btnholot;
        private System.Windows.Forms.Button btnten;
    }
}

