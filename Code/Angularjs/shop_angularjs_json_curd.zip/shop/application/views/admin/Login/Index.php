
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8"/>
    <title>Login Administrator</title>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.min.js" type="text/javascript"></script>
        <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/style.css"/>
  </head>

  <body>
        <form id="form1" name="form1" method="post" action="">
            <div class="vid-container">
         
          <div class="inner-container">
            <div class="box">
              <h1>Administrator Login</h1>
              <?php echo form_error('login'); ?>
              <input type="text" name="username" placeholder="Username" />
              <input type="password" name='password' placeholder="Password" />
                
              <button name="login" >Login</button>
              <p></p>
            </div>
          </div>
        </div>
        </form>


  </body>
</html>