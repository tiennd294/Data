using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;

public class ErrorProviderValidation : System.Windows.Forms.Form
{
	internal System.Windows.Forms.Button Button1;
	internal System.Windows.Forms.ErrorProvider errProvider;
	internal System.Windows.Forms.Label Label3;
	internal System.Windows.Forms.TextBox txtEmail;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ErrorProviderValidation()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.Button1 = new System.Windows.Forms.Button();
		this.errProvider = new System.Windows.Forms.ErrorProvider();
		this.Label3 = new System.Windows.Forms.Label();
		this.txtEmail = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// Button1
		// 
		this.Button1.Location = new System.Drawing.Point(212, 80);
		this.Button1.Name = "Button1";
		this.Button1.Size = new System.Drawing.Size(76, 24);
		this.Button1.TabIndex = 12;
		this.Button1.Text = "OK";
		this.Button1.Click += new System.EventHandler(this.cmdOK_Click);
		// 
		// errProvider
		// 
		this.errProvider.DataMember = null;
		// 
		// Label3
		// 
		this.Label3.Location = new System.Drawing.Point(24, 24);
		this.Label3.Name = "Label3";
		this.Label3.Size = new System.Drawing.Size(40, 16);
		this.Label3.TabIndex = 14;
		this.Label3.Text = "Email:";
		// 
		// txtEmail
		// 
		this.txtEmail.Location = new System.Drawing.Point(68, 20);
		this.txtEmail.Name = "txtEmail";
		this.txtEmail.Size = new System.Drawing.Size(220, 21);
		this.txtEmail.TabIndex = 13;
		this.txtEmail.Text = "";
		this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
		// 
		// ErrorProviderValidation
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(328, 126);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.Label3,
																		this.txtEmail,
																		this.Button1});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "ErrorProviderValidation";
		this.Text = "ErrorProviderValidation";
		this.ResumeLayout(false);

	}
	#endregion

	[STAThread]
	static void Main() 
	{
		Application.Run(new ErrorProviderValidation());
	}

	private void txtEmail_TextChanged(object sender, System.EventArgs e)
	{
		Regex regex;
		regex = new Regex(@"\S+@\S+\.\S+");

		Control ctrl = (Control)sender;
		if (regex.IsMatch(ctrl.Text))
		{
			errProvider.SetError(ctrl, "");
		}
		else
		{
			errProvider.SetError(ctrl, "This is not a valid email address.");
		}
	}

	private void cmdOK_Click(object sender, System.EventArgs e)
	{
		string errorText = "";
		bool invalidInput = false;
		
		foreach (Control ctrl in this.Controls)
		{
			if (errProvider.GetError(ctrl) != "")
			{
				errorText += "   * " + errProvider.GetError(ctrl) + "\n";
				invalidInput = true;
			}
		}
        
		if (invalidInput)
		{
			MessageBox.Show("The form contains the following unresolved errors:\n\n" +
				errorText, "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
		}
		else
		{
			this.Close();
		}
    
	}
}