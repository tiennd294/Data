using System;
using System.Web;
using System.Web.UI.WebControls;

	/// <summary>
	/// Summary description for PopUpTest.
	/// </summary>
	public class PopUpTest : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button cmdPopUp;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string popupScript = "<script language='javascript'>window.open('PopUp.aspx', "+
				"'CustomPopUp', "+
				"'width=200, height=200, menubar=yes, resizable=no')</script>";

			this.RegisterStartupScript("PopupScript", popupScript);

			cmdPopUp.Attributes.Add("onClick","window.open('PopUp.aspx','CustomPopUp2','width=200,height=200,menubar=yes,resizable=no')");
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


	}