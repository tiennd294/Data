Angular Bootstrap Multiselect
========

![Build status](https://travis-ci.org/bentorfs/angular-bootstrap-multiselect.svg?branch=master)

Find documentation on [ the github page](http://bentorfs.github.io/angular-bootstrap-multiselect/)

Contributions welcome