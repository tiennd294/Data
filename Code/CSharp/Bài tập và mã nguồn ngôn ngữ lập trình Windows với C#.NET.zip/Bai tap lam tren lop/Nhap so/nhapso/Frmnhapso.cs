using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace nhapso
{
    public partial class Frmnhapso : Form
    {
        public Frmnhapso()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        int n, cong, i;
        private void btncapnhat_Click(object sender, EventArgs e)
        {
            n = Convert.ToInt32(txtnhapso.Text);
            for (i = 0; i < n; i++)
                lstso.Items.Add(i + 1);

        }

        private void btntong_Click(object sender, EventArgs e)
        {
            for (i = 0; i < n; i++)
            {
                cong +=n- i;
                lstso.Items.Remove(i + 1);
            }
            lstso.Items.Add(cong);
        }

        private void btnthoat_Click(object sender, EventArgs e)
        {
            DialogResult re;
            re = MessageBox.Show("Chac thoat khong?", "Dong", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re  == DialogResult.Yes)
                this.Close(); 
        }

     

        private void btntang_Click(object sender, EventArgs e)
        {
            for (i = 0; i < n; i++)
            {
                lstso.Items.Remove(i + 1);
                lstso.Items.Add(i + 1 + 2);
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            lstso.Items.RemoveAt(n - 1);
            lstso.Items.RemoveAt(0);
        }

        private void btnbinhphuong_Click(object sender, EventArgs e)
        {
            for (i = 0; i < n; i++)
            {
                lstso.Items.Add((i+1)* (i+1) );
                lstso.Items.Remove(i + 1);
            }
        }

        private void btnxoa2_Click(object sender, EventArgs e)
        {
            for (i = lstso.Items.Count - 1; i >= 0; i--)
            {
                if (lstso.GetSelected(i) == true)
                    lstso.Items.RemoveAt(i);
            }
        }


    }
}