using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace bt19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnNhap_Click(object sender, EventArgs e)
        {
            cboSo.Items.Clear();
            Random gt = new Random();
            int a;
            int n = Convert.ToInt32(txtNhap.Text);
            for (int i = 0; i < n; i++)
            {
                a =Convert.ToInt32(gt.Next(100) + 1);
                cboSo.Items.Add(a);
            }
                
        }

        private void cboSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstUS.Items.Clear();
            int gt = Convert.ToInt32(cboSo.Text);
            for (int i = 1; i < gt; i++)
                if (gt % i == 0)
                    lstUS.Items.Add(i);
                    
        }

        private void btnUoc_Click(object sender, EventArgs e)
        {
            int t=0;
            for (int i = 0; i < lstUS.Items.Count; i++)
            {
                t+=Convert.ToInt32 (lstUS.Items[i]);
 
            }
            MessageBox.Show("Tong uoc so la"+t);
        }
    }
}