using System;
using System.IO;
using System.IO.IsolatedStorage;

public class IsolatedStoreTest
{
	private static void Main()
	{
            
		IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForAssembly();

		store.CreateDirectory("MyFolder");
		
		Stream fs = new IsolatedStorageFileStream("MyFile.txt", FileMode.Create, store);

        StreamWriter w = new StreamWriter(fs);

		w.WriteLine("Test");
		w.Flush();
		fs.Close();
		
		Console.WriteLine("Current size: " + store.CurrentSize.ToString());
		Console.WriteLine("Scope: " + store.Scope.ToString());

		Console.WriteLine("Contained files include:");
		string [] files = store.GetFileNames("*.*");
		foreach (string file in files)
		{
			Console.WriteLine(file);
		}
    
		Console.ReadLine();
	}
}