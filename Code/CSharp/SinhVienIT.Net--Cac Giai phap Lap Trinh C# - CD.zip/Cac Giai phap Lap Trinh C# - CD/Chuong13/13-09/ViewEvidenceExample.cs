using System;
using System.Reflection;
using System.Collections;
using System.Security.Policy;

public class ViewEvidenceExample {

    public static void Main(string[] args) {
            	
        Assembly a = Assembly.LoadFrom(args[0]);
    	
        Evidence e = a.Evidence;
				
        IEnumerator x = e.GetHostEnumerator();		
        Console.WriteLine("HOST EVIDENCE COLLECTION:");
        while(x.MoveNext()) {
            Console.WriteLine(x.Current.ToString());
        }

        x = e.GetAssemblyEnumerator();		
        Console.WriteLine("ASSEMBLY EVIDENCE COLLECTION:");
        while(x.MoveNext()) {
            Console.WriteLine(x.Current.ToString());
        }

        Console.ReadLine();
    }
}
