<script type='text/javascript'>
$(document).ready(function () {
        $(".Level2").hide();
        $('.danhmuc').click(function(){
            
        if($( ".danhmuc option:selected" ).val()==1)
        {
            
            $(".Level1").show();
            $(".Level2").hide();
        }
        else{
            
            $(".Level1").hide();
            $(".Level2").show();
        }
        })
    });


</script> 
    <div id='datatable' class='container-fluid'>
    
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        
                                <div class='control-group' style='margin-left: 5%;'>
									<label class='control-label'>Danh mục</label>
									<div class='controls '>
									     <select name='danhmuc' id='danhmuc' class='danhmuc'>
                                                    <option value="1">San pham</option>
                                                    <option value="2">Tin tuc</option>
									     </select>
									</div>
								</div>
                                
                                
                                
                                
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                        <div class='table-action'>
                            <a href='#' class='btnadd tip-top' data-original-title='Add'><i class='icon-plus'></i> Thêm mới</a>
                        </div>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã danh mục</th>  
                                    <th>Tên danh mục</th>  
                                    <th>Sắp xếp</th>  
                                    <th>Trạng thái</th>  
                                    <th>Quan Ly</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                while($row=mysql_fetch_array($category_news))
                                {
                                    if($row['Level']==1 && $row['Parentid']==0){
                            ?>
                                <tr class='gradeU Level<?php echo $row['Level']; ?> <?php echo $row['Parentid']; ?>' >
                                    <td><?php echo $row['Idc']; ?></td>
                                    <td><?php echo $row['Name']; ?></td>
                                    <td><?php echo $row['Display']; ?></td>
                                    <td><?php echo $row['Startus']; ?></td>
                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                                }
                                if($row['Level']==2 && $row['Parentid']==0){
                                    ?>
                                <tr class='gradeU Level<?php echo $row['Level']; ?> <?php echo $row['Parentid']; ?>'>
                                    <td><?php echo $row['Idc']; ?></td>
                                    <td><?php echo $row['Name']; ?></td>
                                    <td><?php echo $row['Display']; ?></td>
                                    <td><?php echo $row['Startus']; ?></td>
                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                                    }
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Thêm mới</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='?c=category&a=add'>

                                <div class='control-group'>
									<label class='control-label'>Danh mục :</label>
									<div class='controls '>
									     <select name='danhmuca' id='danhmuca' class='danhmuca'>
                                                    <option value="1">San pham</option>
                                                    <option value="2">Tin tuc</option>
									     </select>
									</div>
								</div>
								<div class='control-group'>
									<label class='control-label'>Tên danh mục :</label>
									<div class='controls'>
										<input  name='atextdata1' type='text' class='span20 atextdata1' placeholder='Tên danh mục' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Sắp xếp :</label>
									<div class='controls'>
										<input  name='atextdata2' type='text' class='span20 atextdata2' placeholder='Sắp xếp' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='atextdata3' class='atextdata3 atextdata3cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnadd' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	<div class='frmedit' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-pencil'></i>
									</span>
									<h5>Cập nhật</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form3' class='form-horizontal' name='form3' method='post' action='?c=category&a=edit'>
								
								<div class='control-group'>
										<label class='control-label'>Mã danh mục :</label>
										<div class='controls'><input id='etextid' name='etextid' type='text' class='span20 etextid'/></div>
								</div>
                                                                
								<div class='control-group'>
									<label class='control-label'>Tên danh mục :</label>
									<div class='controls'>
										<input  name='etextdata1' type='text' class='span20 etextdata1' placeholder='Tên danh mục' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Sắp xếp :</label>
									<div class='controls'>
										<input  name='etextdata2' type='text' class='span20 etextdata2' placeholder='Sắp xếp' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='etextdata3' class='etextdata3 etextdata3cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnedit' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>







	<div class='frmdelete' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-trash'></i>
									</span>
									<h5>Xóa</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form2' class='form-horizontal' name='form2' method='post' action='?c=category&a=delete'>
								<div class='controls'>                                   <label id='Label2' class='control-label'> Bạn có chắc chắn muốn xóa không?</label>                               </div>                               <div class='control-group' style='padding-left:5px; padding-top:5px;'>                                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:13px;height:13px;overflow:auto;'>                                        <div class='control-group'>                                               <label class='control-label'>ID dstaikhoan:</label>                                           <div class='controls'>                                               <input id='textid' class='textid' name='textid' type='text' class='span20' />                                           </div>                                       </div>                                   </div>                               </div>								<div class='form-actions  txtc'   align='center'>
									<button id='btndelete' class='btn btnyes btn-success'>Có</button>
									<button id='btnhuy'  class='btn btn-success btncancel' style='margin-left:10px'> Không</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
