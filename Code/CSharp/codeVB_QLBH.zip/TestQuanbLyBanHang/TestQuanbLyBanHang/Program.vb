Imports System.Collections.Generic
Imports System.Linq
Imports System.Windows.Forms

Namespace TestQuanbLyBanHang
	NotInheritable Class Program
		Private Sub New()
		End Sub
		''' <summary>
		''' The main entry point for the application.
		''' </summary>
		<STAThread> _
		Private Shared Sub Main()
			Application.EnableVisualStyles()
			Application.SetCompatibleTextRenderingDefault(False)
			Application.Run(New QuanLy2())
		End Sub
	End Class
End Namespace
