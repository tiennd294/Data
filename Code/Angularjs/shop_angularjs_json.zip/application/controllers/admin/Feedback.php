<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Feedback extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Feedback_Model');
    }

    public function Index()
    {
        $input = array();
        $tblfeedback=$this->Feedback_Model->get_list($input);
        $tblmenu=$this->Feedback_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Feedback/feedback',
            'tblfeedback' => $tblfeedback,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);

        
    }

    public function Add()
    {
        $data = array(
            'Name' => $this->input->post('atextdata1'),
            'Phone' => $this->input->post('atextdata2'),
            'Email' => $this->input->post('atextdata3'),
            'Address' => $this->input->post('atextdata4'),
            'Content' => $this->input->post('atextdata5'),
            'Createdate' => date("Y/m/d H:i:s"),
            'Startus' => $this->input->post('atextdata6')
        );
        $this->Feedback_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Phone' => $this->input->post('etextdata2'),
            'Email' => $this->input->post('etextdata3'),
            'Address' => $this->input->post('etextdata4'),
            'Content' => $this->input->post('etextdata5'),

            'Startus' => $this->input->post('etextdata6')
        );
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Feedback_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Feedback_Model->delete($Id);
       
        }
    }
}