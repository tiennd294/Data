Namespace TestQuanbLyBanHang
	Partial Class QuanLy2
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.menuStrip1 = New System.Windows.Forms.MenuStrip()
			Me.heThongToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.cauHinhHeThongToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.quanLyNguoiDungToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.dangNhapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.doiMatKhauToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.thoatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.xemDanhMucToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucThanhPhoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucKhacHangToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucNhanVienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucSanPhamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucHoaDonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.quanLyDanhMucDonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucThanhPhoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucKhachHangToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucNhanVienToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucSanPhamToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
			Me.hoaDonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.danhMucChiTietHoaDonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.quanLyDanhMucTheoNhomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.khachHangTheoThanhPhoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.hoaDonTheoKhachHangToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.hoaDonTheoSanPhamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.hoaDonTheoNhanVienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.chiTietHoaDonTheoHoaDonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.giupDoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.huongDanSuDungToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.tacGiaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.pictureBox1 = New System.Windows.Forms.PictureBox()
			Me.dangXuatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
			Me.menuStrip1.SuspendLayout()
			DirectCast(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' menuStrip1
			' 
			Me.menuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.heThongToolStripMenuItem, Me.xemDanhMucToolStripMenuItem, Me.quanLyDanhMucDonToolStripMenuItem, Me.quanLyDanhMucTheoNhomToolStripMenuItem, Me.giupDoToolStripMenuItem})
			Me.menuStrip1.Location = New System.Drawing.Point(0, 0)
			Me.menuStrip1.Name = "menuStrip1"
			Me.menuStrip1.Size = New System.Drawing.Size(732, 24)
			Me.menuStrip1.TabIndex = 0
			Me.menuStrip1.Text = "menuStrip1"
			' 
			' heThongToolStripMenuItem
			' 
			Me.heThongToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cauHinhHeThongToolStripMenuItem, Me.quanLyNguoiDungToolStripMenuItem, Me.dangNhapToolStripMenuItem, Me.dangXuatToolStripMenuItem, Me.doiMatKhauToolStripMenuItem, Me.thoatToolStripMenuItem})
			Me.heThongToolStripMenuItem.Name = "heThongToolStripMenuItem"
			Me.heThongToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
			Me.heThongToolStripMenuItem.Text = "He Thong"
			AddHandler Me.heThongToolStripMenuItem.Click, New System.EventHandler(Me.heThongToolStripMenuItem_Click)
			' 
			' cauHinhHeThongToolStripMenuItem
			' 
			Me.cauHinhHeThongToolStripMenuItem.Name = "cauHinhHeThongToolStripMenuItem"
			Me.cauHinhHeThongToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
			Me.cauHinhHeThongToolStripMenuItem.Text = "Cau Hinh He Thong"
			' 
			' quanLyNguoiDungToolStripMenuItem
			' 
			Me.quanLyNguoiDungToolStripMenuItem.Name = "quanLyNguoiDungToolStripMenuItem"
			Me.quanLyNguoiDungToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
			Me.quanLyNguoiDungToolStripMenuItem.Text = "Quan Ly Nguoi Dung"
			' 
			' dangNhapToolStripMenuItem
			' 
			Me.dangNhapToolStripMenuItem.Image = Global.TestQuanbLyBanHang.Properties.Resources.login
			Me.dangNhapToolStripMenuItem.Name = "dangNhapToolStripMenuItem"
			Me.dangNhapToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
			Me.dangNhapToolStripMenuItem.Text = "Dang Nhap"
			AddHandler Me.dangNhapToolStripMenuItem.Click, New System.EventHandler(Me.dangNhapToolStripMenuItem_Click)
			' 
			' doiMatKhauToolStripMenuItem
			' 
			Me.doiMatKhauToolStripMenuItem.Name = "doiMatKhauToolStripMenuItem"
			Me.doiMatKhauToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
			Me.doiMatKhauToolStripMenuItem.Text = "Doi Mat Khau"
			AddHandler Me.doiMatKhauToolStripMenuItem.Click, New System.EventHandler(Me.doiMatKhauToolStripMenuItem_Click)
			' 
			' thoatToolStripMenuItem
			' 
			Me.thoatToolStripMenuItem.Image = Global.TestQuanbLyBanHang.Properties.Resources.deletered
			Me.thoatToolStripMenuItem.Name = "thoatToolStripMenuItem"
			Me.thoatToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
			Me.thoatToolStripMenuItem.Text = "Thoat"
			AddHandler Me.thoatToolStripMenuItem.Click, New System.EventHandler(Me.thoatToolStripMenuItem_Click)
			' 
			' xemDanhMucToolStripMenuItem
			' 
			Me.xemDanhMucToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.danhMucThanhPhoToolStripMenuItem, Me.danhMucKhacHangToolStripMenuItem, Me.danhMucNhanVienToolStripMenuItem, Me.danhMucSanPhamToolStripMenuItem, Me.danhMucHoaDonToolStripMenuItem, Me.danhMucToolStripMenuItem})
			Me.xemDanhMucToolStripMenuItem.Name = "xemDanhMucToolStripMenuItem"
			Me.xemDanhMucToolStripMenuItem.Size = New System.Drawing.Size(89, 20)
			Me.xemDanhMucToolStripMenuItem.Text = "Xem Danh Muc"
			' 
			' danhMucThanhPhoToolStripMenuItem
			' 
			Me.danhMucThanhPhoToolStripMenuItem.Name = "danhMucThanhPhoToolStripMenuItem"
			Me.danhMucThanhPhoToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucThanhPhoToolStripMenuItem.Text = "Danh Muc Thanh Pho"
			AddHandler Me.danhMucThanhPhoToolStripMenuItem.Click, New System.EventHandler(Me.danhMucThanhPhoToolStripMenuItem_Click)
			' 
			' danhMucKhacHangToolStripMenuItem
			' 
			Me.danhMucKhacHangToolStripMenuItem.Name = "danhMucKhacHangToolStripMenuItem"
			Me.danhMucKhacHangToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucKhacHangToolStripMenuItem.Text = "Danh Muc Khac Hang"
			AddHandler Me.danhMucKhacHangToolStripMenuItem.Click, New System.EventHandler(Me.danhMucKhacHangToolStripMenuItem_Click)
			' 
			' danhMucNhanVienToolStripMenuItem
			' 
			Me.danhMucNhanVienToolStripMenuItem.Name = "danhMucNhanVienToolStripMenuItem"
			Me.danhMucNhanVienToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucNhanVienToolStripMenuItem.Text = "Danh Muc Nhan Vien"
			AddHandler Me.danhMucNhanVienToolStripMenuItem.Click, New System.EventHandler(Me.danhMucNhanVienToolStripMenuItem_Click)
			' 
			' danhMucSanPhamToolStripMenuItem
			' 
			Me.danhMucSanPhamToolStripMenuItem.Name = "danhMucSanPhamToolStripMenuItem"
			Me.danhMucSanPhamToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucSanPhamToolStripMenuItem.Text = "Danh Muc San Pham"
			AddHandler Me.danhMucSanPhamToolStripMenuItem.Click, New System.EventHandler(Me.danhMucSanPhamToolStripMenuItem_Click)
			' 
			' danhMucHoaDonToolStripMenuItem
			' 
			Me.danhMucHoaDonToolStripMenuItem.Name = "danhMucHoaDonToolStripMenuItem"
			Me.danhMucHoaDonToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucHoaDonToolStripMenuItem.Text = "Danh Muc Hoa Don"
			AddHandler Me.danhMucHoaDonToolStripMenuItem.Click, New System.EventHandler(Me.danhMucHoaDonToolStripMenuItem_Click)
			' 
			' danhMucToolStripMenuItem
			' 
			Me.danhMucToolStripMenuItem.Name = "danhMucToolStripMenuItem"
			Me.danhMucToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucToolStripMenuItem.Text = "Danh Muc Chi Tiet Hoa Don"
			AddHandler Me.danhMucToolStripMenuItem.Click, New System.EventHandler(Me.danhMucToolStripMenuItem_Click)
			' 
			' quanLyDanhMucDonToolStripMenuItem
			' 
			Me.quanLyDanhMucDonToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.danhMucThanhPhoToolStripMenuItem1, Me.danhMucKhachHangToolStripMenuItem, Me.danhMucNhanVienToolStripMenuItem1, Me.danhMucSanPhamToolStripMenuItem1, Me.hoaDonToolStripMenuItem, Me.danhMucChiTietHoaDonToolStripMenuItem})
			Me.quanLyDanhMucDonToolStripMenuItem.Name = "quanLyDanhMucDonToolStripMenuItem"
			Me.quanLyDanhMucDonToolStripMenuItem.Size = New System.Drawing.Size(131, 20)
			Me.quanLyDanhMucDonToolStripMenuItem.Text = "Quan Ly Danh Muc Don"
			AddHandler Me.quanLyDanhMucDonToolStripMenuItem.Click, New System.EventHandler(Me.quanLyDanhMucDonToolStripMenuItem_Click)
			' 
			' danhMucThanhPhoToolStripMenuItem1
			' 
			Me.danhMucThanhPhoToolStripMenuItem1.Name = "danhMucThanhPhoToolStripMenuItem1"
			Me.danhMucThanhPhoToolStripMenuItem1.Size = New System.Drawing.Size(215, 22)
			Me.danhMucThanhPhoToolStripMenuItem1.Text = "Danh Muc Thanh Pho"
			AddHandler Me.danhMucThanhPhoToolStripMenuItem1.Click, New System.EventHandler(Me.danhMucThanhPhoToolStripMenuItem1_Click)
			' 
			' danhMucKhachHangToolStripMenuItem
			' 
			Me.danhMucKhachHangToolStripMenuItem.Name = "danhMucKhachHangToolStripMenuItem"
			Me.danhMucKhachHangToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucKhachHangToolStripMenuItem.Text = "Danh Muc Khach Hang"
			AddHandler Me.danhMucKhachHangToolStripMenuItem.Click, New System.EventHandler(Me.danhMucKhachHangToolStripMenuItem_Click)
			' 
			' danhMucNhanVienToolStripMenuItem1
			' 
			Me.danhMucNhanVienToolStripMenuItem1.Name = "danhMucNhanVienToolStripMenuItem1"
			Me.danhMucNhanVienToolStripMenuItem1.Size = New System.Drawing.Size(215, 22)
			Me.danhMucNhanVienToolStripMenuItem1.Text = "Danh Muc Nhan Vien"
			AddHandler Me.danhMucNhanVienToolStripMenuItem1.Click, New System.EventHandler(Me.danhMucNhanVienToolStripMenuItem1_Click)
			' 
			' danhMucSanPhamToolStripMenuItem1
			' 
			Me.danhMucSanPhamToolStripMenuItem1.Name = "danhMucSanPhamToolStripMenuItem1"
			Me.danhMucSanPhamToolStripMenuItem1.Size = New System.Drawing.Size(215, 22)
			Me.danhMucSanPhamToolStripMenuItem1.Text = "Danh Muc San Pham"
			AddHandler Me.danhMucSanPhamToolStripMenuItem1.Click, New System.EventHandler(Me.danhMucSanPhamToolStripMenuItem1_Click)
			' 
			' hoaDonToolStripMenuItem
			' 
			Me.hoaDonToolStripMenuItem.Name = "hoaDonToolStripMenuItem"
			Me.hoaDonToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.hoaDonToolStripMenuItem.Text = "Danh Muc Hoa Don"
			AddHandler Me.hoaDonToolStripMenuItem.Click, New System.EventHandler(Me.hoaDonToolStripMenuItem_Click)
			' 
			' danhMucChiTietHoaDonToolStripMenuItem
			' 
			Me.danhMucChiTietHoaDonToolStripMenuItem.Name = "danhMucChiTietHoaDonToolStripMenuItem"
			Me.danhMucChiTietHoaDonToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
			Me.danhMucChiTietHoaDonToolStripMenuItem.Text = "Danh Muc Chi Tiet Hoa Don"
			AddHandler Me.danhMucChiTietHoaDonToolStripMenuItem.Click, New System.EventHandler(Me.danhMucChiTietHoaDonToolStripMenuItem_Click)
			' 
			' quanLyDanhMucTheoNhomToolStripMenuItem
			' 
			Me.quanLyDanhMucTheoNhomToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.khachHangTheoThanhPhoToolStripMenuItem, Me.hoaDonTheoKhachHangToolStripMenuItem, Me.hoaDonTheoSanPhamToolStripMenuItem, Me.hoaDonTheoNhanVienToolStripMenuItem, Me.chiTietHoaDonTheoHoaDonToolStripMenuItem})
			Me.quanLyDanhMucTheoNhomToolStripMenuItem.Name = "quanLyDanhMucTheoNhomToolStripMenuItem"
			Me.quanLyDanhMucTheoNhomToolStripMenuItem.Size = New System.Drawing.Size(166, 20)
			Me.quanLyDanhMucTheoNhomToolStripMenuItem.Text = "Quan Ly Danh Muc Theo Nhom"
			' 
			' khachHangTheoThanhPhoToolStripMenuItem
			' 
			Me.khachHangTheoThanhPhoToolStripMenuItem.Name = "khachHangTheoThanhPhoToolStripMenuItem"
			Me.khachHangTheoThanhPhoToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
			Me.khachHangTheoThanhPhoToolStripMenuItem.Text = "Khach Hang Theo Thanh Pho"
			AddHandler Me.khachHangTheoThanhPhoToolStripMenuItem.Click, New System.EventHandler(Me.khachHangTheoThanhPhoToolStripMenuItem_Click)
			' 
			' hoaDonTheoKhachHangToolStripMenuItem
			' 
			Me.hoaDonTheoKhachHangToolStripMenuItem.Name = "hoaDonTheoKhachHangToolStripMenuItem"
			Me.hoaDonTheoKhachHangToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
			Me.hoaDonTheoKhachHangToolStripMenuItem.Text = "Hoa Don Theo Khach Hang"
			AddHandler Me.hoaDonTheoKhachHangToolStripMenuItem.Click, New System.EventHandler(Me.hoaDonTheoKhachHangToolStripMenuItem_Click)
			' 
			' hoaDonTheoSanPhamToolStripMenuItem
			' 
			Me.hoaDonTheoSanPhamToolStripMenuItem.Name = "hoaDonTheoSanPhamToolStripMenuItem"
			Me.hoaDonTheoSanPhamToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
			Me.hoaDonTheoSanPhamToolStripMenuItem.Text = "Hoa Don Theo San Pham"
			AddHandler Me.hoaDonTheoSanPhamToolStripMenuItem.Click, New System.EventHandler(Me.hoaDonTheoSanPhamToolStripMenuItem_Click)
			' 
			' hoaDonTheoNhanVienToolStripMenuItem
			' 
			Me.hoaDonTheoNhanVienToolStripMenuItem.Name = "hoaDonTheoNhanVienToolStripMenuItem"
			Me.hoaDonTheoNhanVienToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
			Me.hoaDonTheoNhanVienToolStripMenuItem.Text = "Hoa Don Theo Nhan Vien"
			' 
			' chiTietHoaDonTheoHoaDonToolStripMenuItem
			' 
			Me.chiTietHoaDonTheoHoaDonToolStripMenuItem.Name = "chiTietHoaDonTheoHoaDonToolStripMenuItem"
			Me.chiTietHoaDonTheoHoaDonToolStripMenuItem.Size = New System.Drawing.Size(236, 22)
			Me.chiTietHoaDonTheoHoaDonToolStripMenuItem.Text = "Chi Tiet Hoa Don Theo Hoa Don"
			' 
			' giupDoToolStripMenuItem
			' 
			Me.giupDoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.huongDanSuDungToolStripMenuItem, Me.tacGiaToolStripMenuItem})
			Me.giupDoToolStripMenuItem.Name = "giupDoToolStripMenuItem"
			Me.giupDoToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
			Me.giupDoToolStripMenuItem.Text = "Giup do"
			' 
			' huongDanSuDungToolStripMenuItem
			' 
			Me.huongDanSuDungToolStripMenuItem.Name = "huongDanSuDungToolStripMenuItem"
			Me.huongDanSuDungToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
			Me.huongDanSuDungToolStripMenuItem.Text = "Huong Dan Su Dung"
			' 
			' tacGiaToolStripMenuItem
			' 
			Me.tacGiaToolStripMenuItem.Name = "tacGiaToolStripMenuItem"
			Me.tacGiaToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
			Me.tacGiaToolStripMenuItem.Text = "Tac Gia"
			' 
			' pictureBox1
			' 
			Me.pictureBox1.Image = Global.TestQuanbLyBanHang.Properties.Resources._8_9_2013_6_06_37_PM
			Me.pictureBox1.Location = New System.Drawing.Point(12, 38)
			Me.pictureBox1.Name = "pictureBox1"
			Me.pictureBox1.Size = New System.Drawing.Size(709, 185)
			Me.pictureBox1.TabIndex = 1
			Me.pictureBox1.TabStop = False
			' 
			' dangXuatToolStripMenuItem
			' 
			Me.dangXuatToolStripMenuItem.Name = "dangXuatToolStripMenuItem"
			Me.dangXuatToolStripMenuItem.Size = New System.Drawing.Size(183, 22)
			Me.dangXuatToolStripMenuItem.Text = "Dang Xuat"
			AddHandler Me.dangXuatToolStripMenuItem.Click, New System.EventHandler(Me.dangXuatToolStripMenuItem_Click)
			' 
			' QuanLy2
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = System.Drawing.Color.White
			Me.ClientSize = New System.Drawing.Size(732, 371)
			Me.Controls.Add(Me.pictureBox1)
			Me.Controls.Add(Me.menuStrip1)
			Me.MainMenuStrip = Me.menuStrip1
			Me.Name = "QuanLy2"
			Me.Text = "Quan Ly Ban Hang"
			Me.FormClosing += New System.Windows.Forms.FormClosingEventHandler(Me.QuanLy_FormClosing)
			Me.Load += New System.EventHandler(Me.Form1_Load)
			Me.menuStrip1.ResumeLayout(False)
			Me.menuStrip1.PerformLayout()
			DirectCast(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private menuStrip1 As System.Windows.Forms.MenuStrip
		Private heThongToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private cauHinhHeThongToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private quanLyNguoiDungToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private dangNhapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private doiMatKhauToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private thoatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private xemDanhMucToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucThanhPhoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucKhacHangToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucNhanVienToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucSanPhamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucHoaDonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private quanLyDanhMucDonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucThanhPhoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
		Private danhMucKhachHangToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucNhanVienToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
		Private danhMucSanPhamToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
		Private hoaDonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private danhMucChiTietHoaDonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private quanLyDanhMucTheoNhomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private khachHangTheoThanhPhoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private hoaDonTheoKhachHangToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private hoaDonTheoSanPhamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private hoaDonTheoNhanVienToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private chiTietHoaDonTheoHoaDonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private giupDoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private huongDanSuDungToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private tacGiaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
		Private pictureBox1 As System.Windows.Forms.PictureBox
		Private dangXuatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	End Class
End Namespace

