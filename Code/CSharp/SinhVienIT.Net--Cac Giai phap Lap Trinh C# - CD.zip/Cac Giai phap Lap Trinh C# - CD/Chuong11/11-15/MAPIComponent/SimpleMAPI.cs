using System;
using System.Runtime.InteropServices;
using System.Text;//For StringBuilder

namespace SimpleMAPI
{
	/// <summary>
	/// A wrapper class for Simple MAPI.
	/// Microsoft provides programming examples for illustration only, without warranty either 
	/// expressed or implied, including, but not limited to, the implied warranties of merchantability 
	/// and/or fitness for a particular purpose. This article assumes that you are familiar with the 
	/// programming language being demonstrated and the tools used to create and debug 
	/// procedures. Microsoft support professionals can help explain the functionality of a 
	/// particular procedure, but they will not modify these examples to provide added functionality 
	/// or construct procedures to meet your specific needs. If you have limited programming 
	/// experience, you may want to contact a Microsoft Certified Partner or the Microsoft fee-
	/// based consulting line at (800) 936-5200. For more information about Microsoft Certified 
	/// Partners, please see the following page on the World Wide Web: 

	/// 	http://www.microsoft.com/partner/referral/
	/// For more information about the support options available from Microsoft, please see the 
	/// following page on the World Wide Web: 
	/// 	http://support.microsoft.com/directory/overview.asp
	/// </summary>
	public class SimpleMAPI 
	{
		//You can force a particular MAPI implementation by changing this line
		private const string MAPIDLL = "mapi32.dll";
		//private const string MAPIDLL = @"c:\Program Files\Outlook Express\msoe.dll";
		//private const string MAPIDLL = @"c:\Program Files\INTERN~1\hmmapi.dll";
		//private const string MAPIDLL = @"c:\Program Files\Common Files\System\Mapi\1033\msmapi32.dll";
		

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public struct MapiFileTagExt
		{
			public int Reserved;		/* Reserved, must be zero.                  */
			public int cbTag;			/* Size (in bytes) of                       */
			public String szTag;		/* X.400 OID for this attachment type       */
			public int cbEncoding;		/* Size (in bytes) of                       */
			public String szEncoding;	/* X.400 OID for this attachment's encoding */
		};

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			private struct privMapiFileDesc
		{
			public int Reserved;            /* Reserved for future use (must be 0)     */
			public int Flags;               /* Flags                                   */
			public int nPosition;             /* character in text to be replaced by attachment */
			public String szPathName;          /* Full path name of attachment file       */
			public String szFileName;          /* Original file name (optional)           */
			public IntPtr /*MapiFileTagExt[]*/ lpFileType;           /* Attachment file type (can be lpMapiFileTagExt) */
		};

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public struct MapiFileDesc
		{
			public int Reserved;				/* Reserved for future use (must be 0)     */
			public int Flags;					/* Flags                                   */
			public int nPosition;				/* character in text to be replaced by attachment */
			public String szPathName;			/* Full path name of attachment file       */
			public String szFileName;			/* Original file name (optional)           */
			public MapiFileTagExt[] lpFileType;	/* Attachment file type (can be lpMapiFileTagExt) */
		};

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			private struct privMapiRecipDesc
		{
			public int Reserved;           /* Reserved for future use                  */
			public int RecipClass;         /* Recipient class                          */
			/* MAPI_TO, MAPI_CC, MAPI_BCC, MAPI_ORIG    */
			public String szName;             /* Recipient name                           */
			public String szAddress;          /* Recipient address (optional)             */
			public int cbEID;            /* Count in bytes of size of pEntryID       */
			public IntPtr /*Byte[]*/ lpEID;           /* System-specific recipient reference      */
		};

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			public struct MapiRecipDesc
		{
			public int Reserved;           /* Reserved for future use                  */
			public int RecipClass;         /* Recipient class                          */
			/* MAPI_TO, MAPI_CC, MAPI_BCC, MAPI_ORIG    */
			public String szName;             /* Recipient name                           */
			public String szAddress;          /* Recipient address (optional)             */
			public int cbEID;            /* Count in bytes of size of pEntryID       */
			public Byte[] lpEID;           /* System-specific recipient reference      */
		};
		
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			private struct privMapiMessage
		{
			public int Reserved;             /* Reserved for future use (M.B. 0)       */
			public String szSubject;            /* Message Subject                        */
			public String szNoteText;           /* Message Text                           */
			public String szMessageType;        /* Message Class                          */
			public String szDateReceived;       /* in YYYY/MM/DD HH:MM format             */
			public String szConversationID;     /* conversation thread ID                 */
			public int Flags;                /* unread,return receipt                  */
			public IntPtr /*MapiRecipDesc[]*/ lpOriginator; /* Originator descriptor                  */
			public int nRecipCount;            /* Number of recipients                   */
			public IntPtr /*MapiRecipDesc[]*/ lpRecips;     /* Recipient descriptors                  */
			public int nFileCount;             /* # of file attachments                  */
			public IntPtr /*MapiFileDesc[]*/ lpFiles;       /* Attachment descriptors                 */
		};

		public struct MapiMessage
		{
			public int Reserved;             /* Reserved for future use (M.B. 0)       */
			public String szSubject;            /* Message Subject                        */
			public String szNoteText;           /* Message Text                           */
			public String szMessageType;        /* Message Class                          */
			public String szDateReceived;       /* in YYYY/MM/DD HH:MM format             */
			public String szConversationID;     /* conversation thread ID                 */
			public int Flags;                /* unread,return receipt                  */
			public MapiRecipDesc[] lpOriginator; /* Originator descriptor                  */
			public int nRecipCount;            /* Number of recipients                   */
			public MapiRecipDesc[] lpRecips;     /* Recipient descriptors                  */
			public int nFileCount;             /* # of file attachments                  */
			public MapiFileDesc[] lpFiles;       /* Attachment descriptors                 */
		};

		//These imports are private so we can call them only from the public wrappers
		//This way the public wrappers can hide the marshalling details
		[DllImport(MAPIDLL, EntryPoint = "MAPILogon", CharSet=CharSet.Ansi)]
		private static extern int privMAPILogon(
			int UIParam,
			string ProfileName,
			string Password,
			int  Flags,
			int Reserved,
			out int Session
			);

		[DllImport(MAPIDLL, EntryPoint = "MAPILogoff", CharSet=CharSet.Ansi)]
		private static extern int privMAPILogoff(
			int Session, 
			int UIParam, 
			int Flags, 
			int Reserved);

		[DllImport(MAPIDLL, EntryPoint = "MAPIReadMail", CharSet=CharSet.Ansi)]
		private static extern int privMAPIReadMail(
			int Session, 
			int UIParam, 
			String MessageID, 
			int Flags, 
			int Reserved,
			out IntPtr /*privMapiMessage*/ Message);

		[DllImport(MAPIDLL, EntryPoint = "MAPIFindNext", CharSet=CharSet.Ansi)]
		private static extern int privMAPIFindNext(
			int Session, 
			int UIParam, 
			string MsgType, 
			string SeedMsgID, 
			int Flag, 
			int Reserved,
			StringBuilder MsgID);

		[DllImport(MAPIDLL, EntryPoint = "MAPISendDocuments", CharSet=CharSet.Ansi)]
		private static extern int privMAPISendDocuments(
			int UIParam, 
			String DelimStr, 
			String FilePaths, 
			String FileNames,
			int Reserved);

		[DllImport(MAPIDLL, EntryPoint = "MAPIDeleteMail", CharSet=CharSet.Ansi)]
		private static extern int privMAPIDeleteMail(
			int Session, 
			int UIParam, 
			String MsgID,
			int Flags, 
			int Reserved);

		[DllImport(MAPIDLL, EntryPoint = "MAPISendMail", CharSet=CharSet.Ansi)]
		private static extern int privMAPISendMail(
			int Session, 
			int UIParam, 
			IntPtr /*privMapiMessage*/ Message, 
			int Flags, 
			int Reserved);

		[DllImport(MAPIDLL, EntryPoint = "MAPISaveMail", CharSet=CharSet.Ansi)]
		private static extern int privMAPISaveMail(
			int Session, 
			int UIParam, 
			IntPtr /*privMapiMessage*/ Message, 
			int Flags, 
			int Reserved, 
			StringBuilder MsgID);

		[DllImport(MAPIDLL, EntryPoint = "MAPIAddress", CharSet=CharSet.Ansi)]
		private static extern int privMAPIAddress(
			int Session, 
			int UIParam, 
			String Caption, 
			int nEditFields, 
			String Label, 
			int nRecipients, 
			IntPtr/*privMapiRecipDesc[]*/ Recips, 
			int Flags, 
			int Reserved,
			out int ulNewRecips,
			out IntPtr /*privMapiRecipDesc[]*/ NewRecips);

		[DllImport(MAPIDLL, EntryPoint = "MAPIDetails", CharSet=CharSet.Ansi)]
		private static extern int privMAPIDetails(
			int Session, 
			int UIParam, 
			IntPtr /*privMapiRecipDesc*/ Recipient,
			int Flags, 
			int Reserved);

		[DllImport(MAPIDLL, EntryPoint = "MAPIResolveName", CharSet=CharSet.Ansi)]
		private static extern int privMAPIResolveName(
			int Session, 
			int UIParam, 
			String UserName, 
			int Flags, 
			int Reserved, 
			out IntPtr /*privMapiRecipDesc*/ Recipient);

		[DllImport(MAPIDLL, EntryPoint = "MAPIFreeBuffer", CharSet=CharSet.Ansi)]
		private static extern int privMAPIFreeBuffer(
			IntPtr pv);

		public const int SUCCESS_SUCCESS = 0;
		public const int MAPI_USER_ABORT = 1;
		public const int MAPI_E_FAILURE = 2;
		public const int MAPI_E_LOGIN_FAILURE = 3;
		public const int MAPI_E_DISK_FULL = 4;
		public const int MAPI_E_INSUFFICIENT_MEMORY = 5;
		public const int MAPI_E_BLK_TOO_SMALL = 6;
		public const int MAPI_E_TOO_MANY_SESSIONS = 8;
		public const int MAPI_E_TOO_MANY_FILES = 9;
		public const int MAPI_E_TOO_MANY_RECIPIENTS = 10;
		public const int MAPI_E_ATTACHMENT_NOT_FOUND = 11;
		public const int MAPI_E_ATTACHMENT_OPEN_FAILURE = 12;
		public const int MAPI_E_ATTACHMENT_WRITE_FAILURE = 13;
		public const int MAPI_E_UNKNOWN_RECIPIENT = 14;
		public const int MAPI_E_BAD_RECIPTYPE = 15;
		public const int MAPI_E_NO_MESSAGES = 16;
		public const int MAPI_E_INVALID_MESSAGE = 17;
		public const int MAPI_E_TEXT_TOO_LARGE = 18;
		public const int MAPI_E_INVALID_SESSION = 19;
		public const int MAPI_E_TYPE_NOT_SUPPORTED = 20;
		public const int MAPI_E_AMBIGUOUS_RECIPIENT = 21;
		public const int MAPI_E_MESSAGE_IN_USE = 22;
		public const int MAPI_E_NETWORK_FAILURE = 23;
		public const int MAPI_E_INVALID_EDITFIELDS = 24;
		public const int MAPI_E_INVALID_RECIPS = 25;
		public const int MAPI_E_NOT_SUPPORTED = 26;
	
		public const int MAPI_E_NO_LIBRARY = 999;
		public const int MAPI_E_INVALID_PARAMETER = 998;
	
		public const int MAPI_ORIG = 0;
		public const int MAPI_TO = 1;
		public const int MAPI_CC = 2;
		public const int MAPI_BCC = 3;
	
		public const int MAPI_UNREAD = 1;
		public const int MAPI_RECEIPT_REQUESTED = 2;
		public const int MAPI_SENT = 4;

		public const int MAPI_LOGON_UI = 0x1;
		public const int MAPI_NEW_SESSION = 0x2;
		public const int MAPI_DIALOG = 0x8;
		public const int MAPI_UNREAD_ONLY = 0x20;
		public const int MAPI_EXTENDED = 0x20;
		public const int MAPI_ENVELOPE_ONLY = 0x40;
		public const int MAPI_PEEK = 0x80;
		public const int MAPI_GUARANTEE_FIFO = 0x100;
		public const int MAPI_BODY_AS_FILE = 0x200;
		public const int MAPI_AB_NOMODIFY = 0x400;
		public const int MAPI_SUPPRESS_ATTACH = 0x800;
		public const int MAPI_FORCE_DOWNLOAD = 0x1000;
		public const int MAPI_LONG_MSGID = 0x4000;
		public const int MAPI_PASSWORD_UI = 0x20000;

		public const int MAPI_OLE = 0x1;
		public const int MAPI_OLE_STATIC = 0x2;

		//Helpful utility functions needed for working from managed code

		//Copies public structure MapiMessage into the private privMapiMessage
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The following must be freed by the caller:
		//privMapiMessage.lpRecips
		//privMapiMessage.lpFiles
		//privMapiMessage.lpOriginator
		//See notes at the package steps
		private static privMapiMessage MessageToPrivMessage(MapiMessage MyMessage)
		{
			privMapiMessage privMyMessage;

			//Package lpRecips
			//Possible memory leak here:
			//RecipsToPrivRecips allocates unmanaged memory in privMyRecips
			//We can't free it now (can we?) since it's pointed to by our RecipBuf and we need to pass it to Simple MAPI
			//We'll free the OriginatorBuf external to this call, first we must crack it
			//open with UnMarshalRecips and free the memory in the szEID members
			//Since we're only called internally, this is nto a horrible solution
			//A better solution would be to write a custom memory deallocator for privMapiMessage
			privMapiRecipDesc[] privMyRecips= RecipsToPrivRecips(MyMessage.lpRecips);
			IntPtr RecipBuf = MarshalRecipients(privMyRecips);

			//Package lpOriginator
			//Possible memory leak here:
			//RecipsToPrivRecips allocates unmanaged memory in privMyOriginator
			//We can't free it now (can we?) since it's pointed to by our OriginatorBuf and we need to pass it to Simple MAPI
			//We'll free the OriginatorBuf external to this call, first we must crack it
			//open with UnMarshalRecips and free the memory in the szEID members
			//Since we're only called internally, this is nto a horrible solution
			//A better solution would be to write a custom memory deallocator for privMapiMessage
			privMapiRecipDesc[] privMyOriginator= RecipsToPrivRecips(MyMessage.lpOriginator);
			IntPtr OriginatorBuf = MarshalRecipients(privMyOriginator);

			//Package lpFiles
			//Possible memory leak here:
			//FilesToPrivFiles allocates unmanaged memory in privMyFiles
			//We can't free it now (can we?) since it's pointed to by our FileBuf and we need to pass it to Simple MAPI
			//We'll free the FileBuf external to this call, first we must crack it
			//open with UnMarshalFiles and free the memory in the lpFileType members
			//Since we're only called internally, this is nto a horrible solution
			//A better solution would be to write a custom memory deallocator for privMapiMessage
			privMapiFileDesc[] privMyFiles = FilesToPrivFiles(MyMessage.lpFiles);
			IntPtr FileBuf = MarshalFiles(privMyFiles);

			privMyMessage.Flags = MyMessage.Flags;

			privMyMessage.nFileCount = MyMessage.nFileCount;
			privMyMessage.lpFiles = FileBuf;

			privMyMessage.lpOriginator = OriginatorBuf;

			privMyMessage.nRecipCount = MyMessage.nRecipCount;
			privMyMessage.lpRecips = RecipBuf;

			privMyMessage.szConversationID = MyMessage.szConversationID;
			privMyMessage.szDateReceived = MyMessage.szDateReceived;
			privMyMessage.szMessageType = MyMessage.szMessageType;
			privMyMessage.szNoteText = MyMessage.szNoteText;
			privMyMessage.szSubject = MyMessage.szSubject;
			privMyMessage.Reserved = MyMessage.Reserved;

			return privMyMessage;
		}

		//Copies private structure privMapiMessage into the public MapiMessage
		//All memory here is managed
		private static MapiMessage PrivMessageToMessage(privMapiMessage privMyMessage)
		{
			MapiMessage MyMessage;

			MyMessage.Flags = privMyMessage.Flags;

			MyMessage.nFileCount = privMyMessage.nFileCount;
			privMapiFileDesc[] privMyFiles = UnMarshalFiles(privMyMessage.nFileCount,privMyMessage.lpFiles);
			MyMessage.lpFiles = PrivFilesToFiles(privMyFiles);

			privMapiRecipDesc[] privOriginator= UnMarshalRecipients(1,privMyMessage.lpOriginator);
			MyMessage.lpOriginator = PrivRecipsToRecips(privOriginator);

			MyMessage.nRecipCount = privMyMessage.nRecipCount;
			privMapiRecipDesc[] privMyRecips= UnMarshalRecipients(privMyMessage.nRecipCount,privMyMessage.lpRecips);
			MyMessage.lpRecips = PrivRecipsToRecips(privMyRecips);

			MyMessage.szConversationID = privMyMessage.szConversationID;
			MyMessage.szDateReceived = privMyMessage.szDateReceived;
			MyMessage.szMessageType = privMyMessage.szMessageType;
			MyMessage.szNoteText = privMyMessage.szNoteText;
			MyMessage.szSubject = privMyMessage.szSubject;
			MyMessage.Reserved = privMyMessage.Reserved;

			return MyMessage;
		}

		//Package the managed array into an unmanaged buffer that Simple MAPI can handle.
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The returned buffer must be freed by the caller.
		private static IntPtr MarshalMessage(privMapiMessage MyMessage)
		{
			IntPtr MsgBuf= Marshal.AllocCoTaskMem(
				Marshal.SizeOf(MyMessage)
				);

			Marshal.StructureToPtr( MyMessage, MsgBuf, false );
			return MsgBuf;
		}

		//Package the unmanaged buffer into a managed structure
		private static privMapiMessage UnMarshalMessage(IntPtr MsgBuf)
		{
			if (MsgBuf == IntPtr.Zero)
			{
//				return null;
			}
			privMapiMessage privMyMessage;
			privMyMessage = (privMapiMessage)Marshal.PtrToStructure(
				MsgBuf,
				typeof(privMapiMessage));

			return privMyMessage;
		}

		//Copies public structure MapiRecipDesc[] into the private privMapiRecipDesc[]
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The following must be freed by the caller:
		//privMapiRecipDesc.szEID
		//for each element of the array
		private static privMapiRecipDesc[] RecipsToPrivRecips(MapiRecipDesc[] MyRecips)
		{
			if (MyRecips == null)
			{
				return null;
			}
			privMapiRecipDesc[] privMyRecips;
			int iNumRecips = MyRecips.Length;

			privMyRecips = new privMapiRecipDesc[iNumRecips];

			int i;
			for (i=0;i<iNumRecips;i++)
			{
				privMyRecips[i] = RecipToPrivRecip(MyRecips[i]);
			}
			return privMyRecips;
		}

		private static void FreeEIDOnRecipBuf(privMapiRecipDesc[] MyRecips)
		{
			int i;
			for (i=0;i<MyRecips.Length;i++)
			{
				Marshal.FreeCoTaskMem(MyRecips[i].lpEID);
			}
		}

		//Copies public structure MapiRecipDesc[] into the private privMapiRecipDesc[]
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The following must be freed by the caller:
		//szEID
		private static privMapiRecipDesc RecipToPrivRecip(MapiRecipDesc MyRecip)
		{
			privMapiRecipDesc privMyRecip;

			//			privMyRecip = new privMapiRecipDesc[iNumRecips];

			privMyRecip.cbEID = MyRecip.cbEID;
			privMyRecip.RecipClass = MyRecip.RecipClass;
			privMyRecip.Reserved = MyRecip.Reserved;
			privMyRecip.szAddress= MyRecip.szAddress;
			privMyRecip.szName = MyRecip.szName;
			if (MyRecip.cbEID != 0)
			{
				privMyRecip.lpEID = Marshal.AllocCoTaskMem(
					MyRecip.cbEID
					);
				//turn byte array into buffer
				Marshal.Copy(
					MyRecip.lpEID,//Byte Array
					0,
					privMyRecip.lpEID, 
					MyRecip.cbEID);
			}
			else
			{
				privMyRecip.lpEID = IntPtr.Zero;
			}
			return privMyRecip;
		}

		//Copies private structure privMapiRecipDesc[] into the public MapiRecipDesc[]
		//All memory here is managed
		private static MapiRecipDesc[] PrivRecipsToRecips(privMapiRecipDesc[] privMyRecips)
		{
			if (privMyRecips == null)
			{
				return null;
			}
			MapiRecipDesc[] MyRecips;
			int iNumRecips = privMyRecips.Length;

			MyRecips = new MapiRecipDesc[iNumRecips];

			int i;
			for (i=0;i<iNumRecips;i++)
			{
				MyRecips[i] = PrivRecipToRecip(privMyRecips[i]);
			}
			return MyRecips;
		}

		//Copies private structure privMapiRecipDesc[] into the public MapiRecipDesc[]
		//All memory here is managed
		private static MapiRecipDesc PrivRecipToRecip(privMapiRecipDesc privMyRecip)
		{
			MapiRecipDesc MyRecip;

			MyRecip.cbEID = privMyRecip.cbEID;
			MyRecip.RecipClass = privMyRecip.RecipClass;
			MyRecip.Reserved = privMyRecip.Reserved;
			MyRecip.szAddress= privMyRecip.szAddress;
			MyRecip.szName = privMyRecip.szName;
			if (privMyRecip.cbEID != 0)
			{
				//We have a buffer..turn it into a byte array
				MyRecip.lpEID = new byte[privMyRecip.cbEID];
				Marshal.Copy(privMyRecip.lpEID,MyRecip.lpEID,0,privMyRecip.cbEID);
			}
			else
			{
				MyRecip.lpEID = null;
			}

			return MyRecip;
		}
		//Package the managed array into an unmanaged array pointer that Simple MAPI can handle.
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The returned buffer must be freed by the caller.
		private static IntPtr MarshalRecipients(privMapiRecipDesc[] MyRecips)
		{
			if (null == MyRecips)
			{
				return IntPtr.Zero;
			}
			//Compute our size and allocate memory
			int iStructSize = Marshal.SizeOf(MyRecips[0]);
			IntPtr RecipBuf = Marshal.AllocCoTaskMem(
				MyRecips.Length * iStructSize
				);

			//Copy each recipient into our allocated block
			//iCurOffset tracks how deep into the block we need to copy
			int iCurOffset = 0;
			foreach(privMapiRecipDesc Recipient in MyRecips)
			{
				Marshal.StructureToPtr( Recipient, (IntPtr)(RecipBuf.ToInt32()+iCurOffset), false );
				iCurOffset += iStructSize;
			}
			return RecipBuf;
		}

		//Package the managed array into an unmanaged array pointer that Simple MAPI can handle.
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The returned buffer must be freed by the caller.
		private static IntPtr MarshalRecipient(privMapiRecipDesc MyRecip)
		{
			//Compute our size and allocate memory
			IntPtr RecipBuf = Marshal.AllocCoTaskMem(
				Marshal.SizeOf(MyRecip)
				);

			Marshal.StructureToPtr( 
				MyRecip, 
				RecipBuf, 
				false );

			return RecipBuf;
		}

		//Unpack the IntPtr into a Recipient array
		private static privMapiRecipDesc[] UnMarshalRecipients(int iNumRecips, IntPtr Buf)
		{
			if (iNumRecips == 0)
			{
				return null;
			}
			//Compute our size and allocate memory
			privMapiRecipDesc[] MyRecips = new privMapiRecipDesc[iNumRecips];

			int iStructSize = Marshal.SizeOf(MyRecips[0]);

			//Copy each recipient from the block into a recipient structure
			//iCurOffset tracks how deep into the block we need to copy
			int iCurOffset = 0;
			int i;
			for (i=0;i<iNumRecips;i++)
			{
				MyRecips[i] = (privMapiRecipDesc)Marshal.PtrToStructure(
					(IntPtr)(Buf.ToInt32()+iCurOffset),
					typeof(privMapiRecipDesc));
				iCurOffset += iStructSize;
			}
			return MyRecips;
		}
		
		//Copies public structure MapiFileDesc[] into the private privMapiFileDesc[]
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The following must be freed by the caller:
		//privMapiFileDesc.lpFileType
		//for each element of the array
		private static privMapiFileDesc[] FilesToPrivFiles(MapiFileDesc[] MyFiles)
		{
			privMapiFileDesc[] privMyFiles;
			int iNumFiles = MyFiles.Length;

			privMyFiles = new privMapiFileDesc[iNumFiles];

			int i;
			for (i=0;i<iNumFiles;i++)
			{
				privMyFiles[i].Flags = MyFiles[i].Flags;
				privMyFiles[i].nPosition = MyFiles[i].nPosition;
				privMyFiles[i].Reserved = MyFiles[i].Reserved;
				privMyFiles[i].szFileName= MyFiles[i].szFileName;
				privMyFiles[i].szPathName = MyFiles[i].szPathName;
				if (MyFiles[i].lpFileType != null)
				{
					privMyFiles[i].lpFileType = Marshal.AllocCoTaskMem(
						Marshal.SizeOf(MyFiles[i].lpFileType[0])
						);
					Marshal.StructureToPtr( 
						MyFiles[i].lpFileType[0], 
						privMyFiles[i].lpFileType, 
						false );
				}
				else
				{
					privMyFiles[i].lpFileType = IntPtr.Zero;
				}
				
			}
			return privMyFiles;
		}

		//Copies private structure privMapiFileDesc[] into the public MapiFileDesc[]
		//All memory here is managed
		private static MapiFileDesc[] PrivFilesToFiles(privMapiFileDesc[] privMyFiles)
		{
			if (privMyFiles == null)
			{
				return null;
			}
			MapiFileDesc[] MyFiles;
			int iNumFiles = privMyFiles.Length;

			MyFiles = new MapiFileDesc[iNumFiles];

			int i;
			for (i=0;i<iNumFiles;i++)
			{
				MyFiles[i].Flags = privMyFiles[i].Flags;
				MyFiles[i].nPosition = privMyFiles[i].nPosition;
				MyFiles[i].Reserved = privMyFiles[i].Reserved;
				MyFiles[i].szFileName= privMyFiles[i].szFileName;
				MyFiles[i].szPathName = privMyFiles[i].szPathName;
				if (privMyFiles[i].lpFileType != IntPtr.Zero)
				{
					MyFiles[i].lpFileType = new MapiFileTagExt[1];
					MyFiles[i].lpFileType[0] = (MapiFileTagExt)Marshal.PtrToStructure(
						privMyFiles[i].lpFileType,
						typeof(MapiFileTagExt));
				}
				else
				{
					MyFiles[i].lpFileType = null;
				}

			}
			return MyFiles;
		}

		//Package the managed array into an unmanaged array pointer that Simple MAPI can handle.
		//Allocates memory which must be freed by Marshal.FreeCoTaskMem
		//Failure to free memory will cause a leak
		//The returned buffer must be freed by the caller.
		private static IntPtr MarshalFiles(privMapiFileDesc[] privMyFiles)
		{
			//Compute our size and allocate memory
			int iStructSize = Marshal.SizeOf(privMyFiles[0]);
			IntPtr RecipBuf = Marshal.AllocCoTaskMem(
				privMyFiles.Length * iStructSize
				);

			//Copy each recipient into our allocated block
			//iCurOffset tracks how deep into the block we need to copy
			int iCurOffset = 0;
			foreach(privMapiFileDesc File in privMyFiles)
			{
				Marshal.StructureToPtr( File, (IntPtr)(RecipBuf.ToInt32()+iCurOffset), false );
				iCurOffset += iStructSize;
			}
			return RecipBuf;
		}

		//Unpack the IntPtr into a private File array
		private static privMapiFileDesc[] UnMarshalFiles(int iNumFiles, IntPtr Buf)
		{
			if (iNumFiles == 0)
			{
				return null;
			}
			//Compute our size and allocate memory
			privMapiFileDesc[] privMyFiles = new privMapiFileDesc[iNumFiles];

			int iStructSize = Marshal.SizeOf(privMyFiles[0]);

			//Copy each recipient from the block into a recipient structure
			//iCurOffset tracks how deep into the block we need to copy
			int iCurOffset = 0;
			int i;
			for (i=0;i<iNumFiles;i++)
			{
				privMyFiles[i] = (privMapiFileDesc)Marshal.PtrToStructure(
					(IntPtr)(Buf.ToInt32()+iCurOffset),
					typeof(privMapiFileDesc));
				iCurOffset += iStructSize;
			}
			return privMyFiles;
		}

		//These are the public implementations of the Simple MAPI functions.
		//These wrappers hide the marshalling code

		public static int MAPILogon(
			int ulUIParam,
			string szProfileName,
			string szPassword,
			int  Flags,
			int Reserved,
			out int lplhSession
			)
		{
			return privMAPILogon(
				ulUIParam,
				szProfileName,
				szPassword,
				Flags,
				Reserved,
				out lplhSession);
		}

		public static int MAPILogoff(
			int Session, 
			int UIParam, 
			int Flags, 
			int Reserved)
		{
			return privMAPILogoff(
				Session,
				UIParam,
				Flags,
				Reserved);
		}

		public static int MAPIReadMail(
			int Session, 
			int UIParam, 
			String MessageID, 
			int Flags, 
			int Reserved,
			out MapiMessage Message)
		{
			int iRet = 0;

			IntPtr Buf = IntPtr.Zero;

			iRet = privMAPIReadMail(
				Session,
				UIParam,
				MessageID,
				Flags,
				Reserved,
				out Buf);
			if (iRet != 0)
			{
				Message = new MapiMessage();
				return iRet;
			}

			privMapiMessage privMyMessage= UnMarshalMessage(Buf);

			Message = PrivMessageToMessage(privMyMessage);

			iRet = privMAPIFreeBuffer(Buf);
			return iRet;
		}

		public static int MAPIFindNext(
			int Session, 
			int UIParam, 
			string MsgType, 
			string SeedMsgID, 
			int Flag, 
			int Reserved,
			out String MsgID)
		{
			int iRet = 0;
			StringBuilder sbEID = new StringBuilder(512);;
			iRet = privMAPIFindNext(
				Session, 
				UIParam, 
				MsgType, 
				SeedMsgID, 
				Flag, 
				Reserved,
				sbEID);
			MsgID = sbEID.ToString();
			return iRet;
		}

		public static int MAPISendDocuments(
			int UIParam, 
			String DelimStr, 
			String FilePaths, 
			String FileNames,
			int Reserved)
		{
			return privMAPISendDocuments(
				UIParam, 
				DelimStr, 
				FilePaths, 
				FileNames,
				Reserved);
		}

		public static int MAPIDeleteMail(
			int Session, 
			int UIParam, 
			String MsgID,
			int Flags, 
			int Reserved)
		{
			return privMAPIDeleteMail(
				Session, 
				UIParam, 
				MsgID,
				Flags, 
				Reserved);
		}

		public static int MAPISendMail(
			int Session, 
			int UIParam, 
			MapiMessage Message, 
			int Flags, 
			int Reserved)
		{
			int iRet = 0;
			privMapiMessage privMyMessage = MessageToPrivMessage(Message);

			IntPtr MsgBuf = MarshalMessage(privMyMessage);

			iRet = privMAPISendMail(
				Session, 
				UIParam, 
				MsgBuf, 
				Flags, 
				Reserved);

			Marshal.FreeCoTaskMem(MsgBuf);
			if (privMyMessage.nFileCount != 0)
			{
				int i;
				//crack open lpFiles buffer and clean up the file tag memory
				privMapiFileDesc[] privMyFiles = UnMarshalFiles(
					privMyMessage.nFileCount,
					privMyMessage.lpFiles);

				for (i=0;i<privMyFiles.Length;i++)
				{
					Marshal.FreeCoTaskMem(privMyFiles[i].lpFileType);
				}
			}
			Marshal.FreeCoTaskMem(privMyMessage.lpFiles);
			if (privMyMessage.lpOriginator != IntPtr.Zero)
			{
				//crack open lpOriginator buffer and clean up the file tag memory
				privMapiRecipDesc[] privMyOriginator = UnMarshalRecipients(
					1,
					privMyMessage.lpOriginator);
				FreeEIDOnRecipBuf(privMyOriginator);
			}
			Marshal.FreeCoTaskMem(privMyMessage.lpOriginator);
			if (privMyMessage.nRecipCount != 0)
			{
				//crack open lpRecips buffer and clean up the file tag memory
				privMapiRecipDesc[] privMyRecips = UnMarshalRecipients(
					privMyMessage.nRecipCount,
					privMyMessage.lpRecips);

				FreeEIDOnRecipBuf(privMyRecips);
			}
			Marshal.FreeCoTaskMem(privMyMessage.lpRecips);
			return iRet;
		}

		public static int MAPISaveMail(
			int Session, 
			int UIParam, 
			MapiMessage Message, 
			int Flags, 
			int Reserved, 
			out string MsgID)
		{
			int iRet = 0;
			StringBuilder sbEID = new StringBuilder(512);;
			privMapiMessage privMyMessage = MessageToPrivMessage(Message);

			IntPtr MsgBuf = MarshalMessage(privMyMessage);

			iRet = privMAPISaveMail(
				Session, 
				UIParam, 
				MsgBuf, 
				Flags, 
				Reserved, 
				sbEID);

			Marshal.FreeCoTaskMem(MsgBuf);
			Marshal.FreeCoTaskMem(privMyMessage.lpFiles);
			Marshal.FreeCoTaskMem(privMyMessage.lpOriginator);
			Marshal.FreeCoTaskMem(privMyMessage.lpRecips);
			MsgID = sbEID.ToString();
			return iRet;
		}

		public static int MAPIAddress(
			int Session, 
			int UIParam, 
			String Caption, 
			int iEditFields, 
			String Label, 
			int iInRecipients, 
			MapiRecipDesc[] InRecips, 
			int Flags, 
			int Reserved,
			out int iOutRecips,
			out MapiRecipDesc[] OutRecips)
		{
			int iRet = 0;

			IntPtr OutRecipBuf = IntPtr.Zero;
			privMapiRecipDesc[] privInRecips = RecipsToPrivRecips(InRecips);
			IntPtr InRecipBuf = MarshalRecipients(privInRecips);

			iRet = privMAPIAddress(
				Session, 
				UIParam, 
				Caption, 
				iEditFields, 
				Label, 
				iInRecipients, 
				InRecipBuf, 
				Flags, 
				Reserved,
				out iOutRecips,
				out OutRecipBuf);

			//Since we called RecipsToPrivRecips, we have extra memory to free
			FreeEIDOnRecipBuf(privInRecips);
			Marshal.FreeCoTaskMem( InRecipBuf );

			privMapiRecipDesc[] privOutRecips;
			privOutRecips = UnMarshalRecipients(iOutRecips,OutRecipBuf);
			OutRecips = PrivRecipsToRecips(privOutRecips);
			
			iRet = privMAPIFreeBuffer(
				OutRecipBuf);

			return iRet;
		}

		public static int MAPIDetails(
			int Session, 
			int UIParam, 
			MapiRecipDesc Recipient,
			int Flags, 
			int Reserved)
		{
			int iRet = 0;

			privMapiRecipDesc privRecipient = RecipToPrivRecip(Recipient);

			IntPtr buf = MarshalRecipient(privRecipient);

			iRet = privMAPIDetails(
				Session, 
				UIParam, 
				buf,
				Flags, 
				Reserved);

			Marshal.FreeCoTaskMem(privRecipient.lpEID);
			Marshal.FreeCoTaskMem(buf);

			return iRet;
		}

		public static int MAPIResolveName(
			int Session, 
			int UIParam, 
			String UserName, 
			int Flags, 
			int Reserved, 
			out MapiRecipDesc Recipient)
		{
			int iRet = 0;
			IntPtr Buf = IntPtr.Zero;

			iRet = privMAPIResolveName(
				Session, 
				UIParam, 
				UserName, 
				Flags, 
				Reserved, 
				out Buf);
			if (iRet != 0)
			{
				Recipient = new MapiRecipDesc();
				return iRet;
			}

			privMapiRecipDesc privRecipient;
			privRecipient = (privMapiRecipDesc)Marshal.PtrToStructure(
				Buf,
				typeof(privMapiRecipDesc));

			Recipient = PrivRecipToRecip(privRecipient);

			iRet = privMAPIFreeBuffer(Buf);

			return iRet;
		}
	}
}