<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_Model');
    }

    public function Index()
    {
        $input = array();
        $input['order'] = array('Createdate','asc');
        $tbluser=$this->User_Model->get_list($input);
        $tblmenu=$this->User_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/User/user',
            'tbluser' => $tbluser,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }


    public function Add()
    {
        $data = array(
            'Email' => $this->input->post('atextdata1'),
            'Name' => $this->input->post('atextdata2'),
            'Pass' => $this->input->post('atextdata3'),
            'Phone' => $this->input->post('atextdata4'),
            'Address' => $this->input->post('atextdata5'),
            'Discription' => $this->input->post('atextdata6'),
            'Startus' => $this->input->post('atextdata7'),
            'Createdate' => date("Y/m/d H:i:s")
        );
        $this->User_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Pass' => $this->input->post('etextdata2'),
            'Phone' => $this->input->post('etextdata3'),
            'Address' => $this->input->post('etextdata4'),
            'Discription' => $this->input->post('etextdata5'),
            'Startus' => $this->input->post('etextdata6'),

        );
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->User_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->User_Model->delete($Id);
       
        }
    }
}