-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2016 at 09:37 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testshopweb`
--
CREATE DATABASE IF NOT EXISTS `testshopweb` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `testshopweb`;

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `Ida` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metatile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Images` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Discription` longtext COLLATE utf8_unicode_ci,
  `Detail` longtext COLLATE utf8_unicode_ci,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Modifydate` datetime DEFAULT NULL,
  `Modifyby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metakeywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metadiscriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Ida`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`Ida`, `Name`, `Metatile`, `Images`, `Discription`, `Detail`, `Startus`, `Createdate`, `Createby`, `Modifydate`, `Modifyby`, `Metakeywords`, `Metadiscriptions`) VALUES
(14, 'Giới thiệu về Công ty Cổ phần Eastern Sun Việt Nam', NULL, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-15-1024x576.jpg', ' Công ty Cổ phần Eastern Sun Việt Nam (ESVN) - tên giao dịch quốc tế: Vietnam Eastern Sun Joint Stock Company, được thành lập ngày 25/03/2011.\r\n\r\nVới đội ngũ lãnh đạo đầy sức trẻ, sáng tạo và tận tụy, cùng với sự quan tâm chiến lược của nhiều cá nhân và tổ chức trong lĩnh vực công nghệ thông tin và kinh doanh, ESVN tham gia vào nhiều lĩnh vực mũi nhọn như:\r\n\r\n    Tư vấn giải pháp và thiết kế website cho doanh nghiệp\r\n    Cung cấp dịch vụ thương mại điện tử\r\n    Dịch vụ thanh toán trực tuyến và tích hợp dịch vụ SMS\r\n    Dịch vụ cung cấp giải pháp cổng thông tin cho doanh nghiệp\r\n    Dịch vụ SEO website theo yêu cầu\r\n', '<p>Một số thế mạnh nổi trội của ESVN: được thể hiện ở vị tr&iacute; đứng đầu về ứng dụng c&ocirc;ng nghệ th&ocirc;ng tin trong lĩnh vực <a href="http://esvn.com.vn/8/Giai-phap/Giai-phap-thuong-mai-dien-tu.html">thương mại điện tử</a> v&agrave; <a href="http://esvn.com.vn/giai-phap.html">giải ph&aacute;p</a> cho doanh nghiệp; C&ocirc;ng ty c&oacute; tầm nh&igrave;n chiến lược; C&oacute; vị tr&iacute; văn ph&ograve;ng giao dịch đặt tại một số trung t&acirc;m c&ocirc;ng nghệ của Việt Nam. Nhằm mang lại cho kh&aacute;ch h&agrave;ng những sản phẩm tốt nhất v&agrave; <a href="http://esvn.com.vn/san-pham-dich-vu.html">dịch vụ</a> tốt nhất. Đặc biệt, ESVN rất coi trọng tới đội ngũ nh&acirc;n sự. Hiện nay, C&ocirc;ng ty đ&atilde; tuyển dụng được đội ngũ c&aacute;n bộ gi&agrave;u kinh nghiệm trong lĩnh vực c&ocirc;ng nghệ th&ocirc;ng tin v&agrave; thương mại điện tử, được đ&agrave;o tạo từ c&aacute;c trường đại học danh tiếng.</p><p>Bằng sức mạnh tr&iacute; tuệ, c&ocirc;ng nghệ th&ocirc;ng tin hiện đại, vốn v&agrave; tinh thần đo&agrave;n kết của tập thể c&aacute;n bộ c&ocirc;ng nh&acirc;n vi&ecirc;n, ESVN sẽ kh&ocirc;ng ngừng phấn đấu để mang lại cho kh&aacute;ch h&agrave;ng những gi&aacute; trị nổi trội th&ocirc;ng qua c&aacute;c <a href="http://esvn.com.vn/san-pham-dich-vu.html">dịch vụ</a> ho&agrave;n hảo nhất với phương ch&acirc;m th&agrave;nh c&ocirc;ng của kh&aacute;c h&agrave;ng l&agrave; sự th&agrave;nh c&ocirc;ng của ESVN.</p><p><strong>Sứ mệnh của ESVN</strong>&nbsp;:<br />- Phục vụ kh&aacute;ch h&agrave;ng nhanh nhất v&agrave; tốt nhất.<br />- Kh&ocirc;ng ngừng duy tr&igrave;, ph&aacute;t triển v&agrave; mở rộng <a href="http://esvn.com.vn/san-pham-dich-vu.html">dịch vụ</a> cả về quy m&ocirc; v&agrave; chất lượng.</p><p><strong>Phong c&aacute;ch</strong>:<br />- Với đội ngũ nh&acirc;n vi&ecirc;n chuy&ecirc;n nghiệp, ch&uacute;ng t&ocirc;i phục vụ kh&aacute;ch h&agrave;ng tận tụy.</p><p><strong>Tầm nh&igrave;n</strong>:<br />- X&acirc;y dựng một tổ chức kiểu mới mang phong c&aacute;ch trẻ trung năng động c&oacute; văn h&oacute;a doanh nghiệp đặc trưng khiến cho nh&acirc;n vi&ecirc;n cảm thấy tự h&agrave;o v&agrave; kh&aacute;ch h&agrave;ng cảm thấy h&agrave;i l&ograve;ng khi nhắc tới ESVN.<br />- Mang lại những gi&aacute; trị thiết thực cho kh&aacute;ch h&agrave;ng v&agrave; đem lại cho nh&acirc;n vi&ecirc;n một m&ocirc;i trường tốt nhất để x&acirc;y dựng tương lại vững chắc.</p>', 'on', NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'bn', NULL, '', 'ào nhiều lĩnh vực mũi nhọn như:\r\n\r\n    Tư vấn giải pháp và thiết kế website cho doanh nghiệp\r\n    Cung cấp dịch vụ thương mại điện tử\r\n    Dịch vụ thanh toán trực tuyến và tích hợp dịch vụ SMS\r\n    Dịch vụ cung cấp giải pháp cổng thông tin cho doanh nghiệ', '', '', NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'nbbn', NULL, NULL, 'nbnb', '<p>bnnb</p>', '', NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'sdsd', NULL, NULL, 'sdsd', '<p>dssd</p>', '', NULL, NULL, NULL, NULL, NULL, NULL),
(25, 'sadasd', NULL, '/test/public/access/upload/images/Products/hinh-nen-ca-choi-dep-cho-iphone-6s-1.jpg', 'zxczxc', '<p>zxcxc</p>', 'on', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `Idc` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metatile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Parentid` bigint(20) DEFAULT NULL,
  `Display` int(11) DEFAULT '11',
  `Seotile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Linkurl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Classify` varchar(255) COLLATE utf8_unicode_ci DEFAULT '1',
  `Level` int(11) DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Modifydate` datetime DEFAULT NULL,
  `Modifyby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metakeywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metadiscriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idc`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=88 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Idc`, `Name`, `Metatile`, `Parentid`, `Display`, `Seotile`, `Linkurl`, `Classify`, `Level`, `Startus`, `Createdate`, `Createby`, `Modifydate`, `Modifyby`, `Metakeywords`, `Metadiscriptions`) VALUES
(1, 'Tủ làm mát ', NULL, 9, 0, NULL, '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(2, ' Phụ kiện Mobile ', NULL, 8, 0, NULL, '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(3, 'Máy tính bàn', NULL, 7, 0, NULL, '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(4, 'Quạt mát', NULL, 0, 3, NULL, '12', '1', 1, 'on', '0000-00-00 00:00:00', 'nguyentien24', '0000-00-00 00:00:00', '', NULL, NULL),
(6, 'Quạt điều hòa', NULL, 4, 0, NULL, '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(7, 'Thiết bị văn phòng', '<p><span style="color:#FF0000">nvbnvbn</span></p>', 0, 1, 'on', '', '1', 1, 'on', NULL, NULL, '2016-07-03 22:16:37', 'nguyentien24', NULL, NULL),
(8, 'Phụ kiện', '', 0, 12, '', '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(9, 'Tủ lạnh', '', 0, 2, '', '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(10, 'Điều hòa', NULL, 0, 1, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', 'nguyentien24', '0000-00-00 00:00:00', '', NULL, NULL),
(11, 'Audio', NULL, 0, 234, NULL, '', '1', 1, 'on', NULL, NULL, '0000-00-00 00:00:00', '', NULL, NULL),
(26, 'đ', NULL, 25, 0, NULL, 'đ', '1', 1, 'on', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL, NULL, NULL),
(27, 'Tuyen dung', NULL, 0, 1, NULL, '', '2', 2, 'on', NULL, NULL, '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL),
(29, 'Chinh sach', NULL, 0, 2, NULL, '11', '2', 2, 'on', '0000-00-00 00:00:00', 'nguyentien24', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL),
(32, 'Gioi thieu', NULL, 0, 3, NULL, '', '2', 2, 'on', '0000-00-00 00:00:00', 'nguyentien24', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL),
(33, 'Ban quyen', NULL, 0, 4, NULL, '', '2', 2, 'on', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL, NULL, NULL),
(37, 'Quạt phun sương', NULL, 4, 1, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(38, 'Quạt cây', NULL, 4, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(39, 'Quạt treo tường', NULL, 4, 3, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(40, 'Màn hình máy tính', NULL, 7, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(41, 'Máy in', NULL, 7, 3, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(42, 'Máy đếm tiền', NULL, 7, 4, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(43, 'Máy chiếu', NULL, 7, 5, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(44, 'Máy scan', NULL, 7, 6, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(45, 'Máy hủy tài liệu', NULL, 7, 7, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(46, 'Máy photocopy', NULL, 7, 8, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(47, ' Camera hành trình', NULL, 8, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(48, 'USB Flash', NULL, 8, 3, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(49, 'Đế tản nhiệt ', NULL, 8, 4, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(50, 'Phần mềm ', NULL, 8, 5, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(51, 'Bàn phím ', NULL, 8, 6, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(52, 'Sạc / Pin laptop ', NULL, 8, 7, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(53, 'Tủ đông', NULL, 9, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(55, 'Tủ rượu', NULL, 9, 4, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(56, 'Điều hòa tủ đứng', NULL, 10, 0, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(57, 'Điều hòa VRV ', NULL, 10, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(59, 'Điều hòa treo tường', NULL, 10, 3, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(60, 'Karaoke ', NULL, 11, 0, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(61, 'Loa Sound Bar', NULL, 11, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(62, 'Amply Hiend-Hifi', NULL, 11, 3, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(63, 'Loa Hiend-Hifi', NULL, 11, 4, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(64, 'Micro', NULL, 11, 5, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(65, 'Điều hòa âm trần ', NULL, 10, 2, NULL, '', '1', 1, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(73, 'demo', NULL, 0, 11, NULL, '', '3', NULL, 'on', NULL, NULL, '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL),
(78, 'nnn', NULL, 0, 333, NULL, 'qqq', '3', NULL, 'on', '2016-07-03 09:05:45', 'nguyentien24', NULL, NULL, NULL, NULL),
(79, 'sdfsdf', NULL, 73, 0, NULL, '', '3', NULL, 'on', '2016-07-03 16:36:55', 'nguyentien24', NULL, NULL, NULL, NULL),
(80, 'bnvn', NULL, 78, 0, NULL, '', '3', NULL, 'on', '2016-07-03 16:37:08', 'nguyentien24', NULL, NULL, NULL, NULL),
(81, 'fdgdgdgdg', NULL, 78, 0, NULL, '', '3', NULL, 'on', '2016-07-03 16:47:45', 'nguyentien24', NULL, NULL, NULL, NULL),
(82, 'dead', NULL, 0, 3, NULL, 'eda', '3', NULL, 'on', '2016-07-03 21:51:51', 'nguyentien24', '2016-07-03 22:47:57', 'nguyentien24', NULL, NULL),
(86, 'test', NULL, 82, 0, NULL, '34', '3', NULL, 'on', '2016-07-03 22:48:51', 'nguyentien24', NULL, NULL, NULL, NULL),
(87, 'nguyenhung', NULL, 0, 1, NULL, '121', '3', NULL, 'on', '2016-07-03 22:49:15', 'nguyentien24', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `Idct` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Addressmap` longtext COLLATE utf8_unicode_ci,
  `Content` longtext COLLATE utf8_unicode_ci,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`Idct`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Idct`, `Name`, `Phone`, `Email`, `Address`, `Addressmap`, `Content`, `Startus`) VALUES
(1, 'cgfg', '45', 'fg', 'asd', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d55977.47369775501!2d104.82452522511345!3d21.717121003945007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbe9e518f95f75081!2zQsOhbyDEkGnhu4duIHThu60gWcOqbiBCw6Fp!5e0!3m2!1svi!2s!4v1467439814791" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>', '<p>As&aacute;</p><p>adasd</p><p>ad</p><p>đ&aacute;</p><p>ad</p><p>&aacute;dadasd</p>', 'on'),
(2, 'aaa', '222', 'aa', NULL, NULL, '<p><span style="color:#FF0000">1111111111</span></p>', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `Idf` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Content` text COLLATE utf8_unicode_ci,
  `Createdate` datetime DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`Idf`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Idf`, `Name`, `Phone`, `Email`, `Address`, `Content`, `Createdate`, `Startus`) VALUES
(1, 'xcx', '4334', 'dfdf', 'dfdf', '<p><span style="color:#FF0000">111111</span></p>', NULL, 'on'),
(2, 'lumia', '1231', '13123', '12312313', '123123', '2016-07-03 18:40:38', 'on'),
(3, 'lumia13213', '123112313', '1312313123', '12312313123', '123123131312', '2016-07-03 18:41:19', 'on'),
(4, 'dfg', '656', 'gfdf', 'gfdfg', 'gdg', '2016-07-03 18:42:58', 'on'),
(5, 'demo ', '3333333333', 'demo ', 'test', 'ádsdsad\nsadasd', '2016-07-03 18:45:35', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE IF NOT EXISTS `footer` (
  `Idft` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Content` longtext COLLATE utf8_unicode_ci,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`Idft`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`Idft`, `Content`, `Startus`) VALUES
('tets', '133', 'on'),
('vb', '<p>bv</p>', 'on'),
('vbvb', '<p>vbvb</p>', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `Idn` int(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metatile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Discription` longtext COLLATE utf8_unicode_ci,
  `Images` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Idc` int(11) DEFAULT NULL,
  `Detail` longtext COLLATE utf8_unicode_ci,
  `Viewcount` int(11) DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Modifydate` datetime DEFAULT NULL,
  `Modifyby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metakeywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metadiscriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idn`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`Idn`, `Name`, `Metatile`, `Discription`, `Images`, `Idc`, `Detail`, `Viewcount`, `Startus`, `Createdate`, `Createby`, `Modifydate`, `Modifyby`, `Metakeywords`, `Metadiscriptions`) VALUES
(1, 'nn', NULL, 'nnnnnnn', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-11-1024x576.jpg', 27, '', NULL, 'on', '2016-07-14 00:34:51', 'nguyentien24', '2016-07-03 20:47:33', 'nguyentien24', NULL, NULL),
(4, '2', NULL, '12', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-11-1024x576.jpg', 29, '', NULL, 'on', '0000-00-00 00:00:00', 'nguyentien24', '2016-07-03 20:47:45', 'nguyentien24', NULL, NULL),
(5, 'hghg', NULL, 'hghg', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-11-1024x576.jpg', 32, '', NULL, 'on', '0000-00-00 00:00:00', 'nguyentien24', '2016-07-03 20:47:56', 'nguyentien24', NULL, NULL),
(7, 'test', NULL, 'test', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-11-1024x576.jpg', 33, '', NULL, 'on', '0000-00-00 00:00:00', 'nguyentien24', '2016-07-03 20:48:07', 'nguyentien24', NULL, NULL),
(11, 'fddf', NULL, 'dfdf', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-11-1024x576.jpg', 27, '', NULL, 'on', '0000-00-00 00:00:00', 'admin', '2016-07-03 20:48:18', 'nguyentien24', NULL, NULL),
(12, 'sfsd', NULL, 'sfsdf', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-1-1024x640.jpg', 29, '', NULL, 'on', NULL, NULL, '2016-07-03 20:48:48', 'nguyentien24', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `Idp` int(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metatile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Discription` longtext COLLATE utf8_unicode_ci,
  `Images` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Promotion` decimal(10,0) DEFAULT NULL,
  `Price` decimal(10,0) DEFAULT NULL,
  `Cost` decimal(10,0) DEFAULT NULL,
  `IncludeVAT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Idc` int(11) DEFAULT NULL,
  `Detail` longtext COLLATE utf8_unicode_ci,
  `Warranty` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Tophot` datetime DEFAULT NULL,
  `Viewcount` int(11) DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Modifydate` datetime DEFAULT NULL,
  `Modifyby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metakeywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Metadiscriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Idp`, `Name`, `Code`, `Metatile`, `Discription`, `Images`, `Promotion`, `Price`, `Cost`, `IncludeVAT`, `Quantity`, `Idc`, `Detail`, `Warranty`, `Tophot`, `Viewcount`, `Startus`, `Createdate`, `Createby`, `Modifydate`, `Modifyby`, `Metakeywords`, `Metadiscriptions`) VALUES
(1, 'xczx', 'zxcxzc', NULL, 'xzcxc', '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '3434', '434', '3434', '3434', 34, 0, '', 'dfdf', '2016-10-10 00:00:00', NULL, 'on', NULL, NULL, '2016-07-02 22:03:36', 'nguyentien24', NULL, NULL),
(12, 'tert', 'demo', NULL, 'test', 'admin/accessdata/upload/images/Products/hinh-nen-mua-thu-3.jpg', '12', '21', '13', '1', 12, 3, '<p><span style="color:#0000FF">demo</span></p>', '24thang', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL, NULL, NULL),
(13, 'demo2', 'demo2', NULL, 'demo2', 'admin/accessdata/upload/images/Products/muathu.jpg', '21', '12', '31', '1', 24, 6, '<p><span style="color:#FFA500">demo</span></p>', '12 thang', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL, NULL, NULL),
(14, 'demo', 'test', NULL, 'test', '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '32000000', '10000000', '1', '1', 1, 3, '<p>1</p>', '1', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(15, 'test2', 'demo2', NULL, 'ed', '/test/public/access/upload/images/Products/hinh-nen-mua-thu-7.jpg', '12', '1', '131', '1', 1, 3, '<p><span style="color:#FF0000">111</span></p>', '1', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', '', NULL, NULL, NULL, NULL),
(16, '111111', 'sss', NULL, 'ddd', '/test/public/access/upload/images/Products/12006379_1719023511688467_677731682656957962_n.jpg', '111', '111', '111', '11', 111, 3, '', '1', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', 'admin', '2016-07-03 11:44:06', 'nguyentien24', NULL, NULL),
(17, 'samsung clt', '0201321', NULL, 'test images', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-1-1024x640.jpg', '100000', '90000', '50000', '1', 15, 40, '', '24 thang', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', 'admin', '0000-00-00 00:00:00', 'admin', NULL, NULL),
(18, '111', '111', NULL, '111', '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-1-1024x640.jpg', '1', '1', '1', '1', 1, 40, '<p>1</p>', '1', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', 'admin', NULL, NULL, NULL, NULL),
(19, 'Apple iPhone 5S (16G) Silver', '507256', NULL, 'Thiết kế mới nguyên khối mỏng nhất trong các siêu phẩm của Apple\r\nCamera được nâng độ phân giải 8MP\r\nTính năng Touch ID mới lạ, độc đáo', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-10-1024x640.jpg', '6789000', '7888000', '5000000', '1', 10, 46, '<p>H&igrave;nh ảnh tham khảo: Apple iPhone 5S (16G) Silver</p><div class="pd-gallery" id="pd-gallery"><div class="pdg_slideshow owl-carousel owl-theme" style="display: block; opacity: 1;"><div class="owl-wrapper-outer"><div class="owl-wrapper" style="width: 9940px; left: 0px; display: block;"><div class="owl-item" style="width: 710px;"><div class="g_item"><img alt="Apple iPhone 5S (16G) Silver" class="lazyOwl" src="http://cdn.mediamart.vn/Product/apple-iphone-5s-16g-silver-I907OZ.jpg" style="display:inline; height:400px; width:548px" /></div></div><div class="owl-item loading" style="width: 710px;"><div class="g_item">&nbsp;</div></div><div class="owl-item loading" style="width: 710px;"><div class="g_item">&nbsp;</div></div><div class="owl-item loading" style="width: 710px;"><div class="g_item">&nbsp;</div></div><div class="owl-item loading" style="width: 710px;"><div class="g_item">&nbsp;</div></div><div class="owl-item loading" style="width: 710px;"><div class="g_item">&nbsp;</div></div><div class="owl-item loading" style="width: 710px;"><div class="g_item">&nbsp;</div></div></div></div></div></div><div class="pd-gallery" id="pd-gallery"><div class="cl">&nbsp;</div></div><div class="cl">&nbsp;</div><div id="pd-special">&nbsp;</div><p>Th&ocirc;ng số kỹ thuật: Apple iPhone 5S (16G) Silver</p><div class="pd-news-content"><div class="pd-attrvalue"><div class="pd-attrvalue-item pd-atv-col-full">M&agrave;n h&igrave;nh</div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">C&ocirc;ng nghệ m&agrave;n h&igrave;nh</div><div class="pd-atv-col-r">LED-backlit IPS LCD</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Độ ph&acirc;n giải</div><div class="pd-atv-col-r">640 x 1136 pixels</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">M&agrave;n h&igrave;nh rộng</div><div class="pd-atv-col-r">Khoảng 4 inch</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Cảm ứng</div><div class="pd-atv-col-r">Cảm ứng điện dung, Đa điểm</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Mặt k&iacute;nh cảm ứng</div><div class="pd-atv-col-r">K&iacute;nh cường lực Gorilla Glass</div></div><div class="pd-attrvalue-item pd-atv-col-full">Camera sau</div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Độ ph&acirc;n giải</div><div class="pd-atv-col-r">8.0 MP</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Quay phim</div><div class="pd-atv-col-r">Quay phim FullHD 1080p@30fps</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Đ&egrave;n Flash</div><div class="pd-atv-col-r">C&oacute;</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Chụp ảnh n&acirc;ng cao</div><div class="pd-atv-col-r">HDR, Nhận diện nụ cười, Tự động lấy n&eacute;t, Nhận diện khu&ocirc;n mặt, Chạm lấy n&eacute;t, Panorama</div></div><div class="pd-attrvalue-item pd-atv-col-full">Camera trước</div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Độ ph&acirc;n giải</div><div class="pd-atv-col-r">1.2 MP</div></div><div class="pd-attrvalue-item"><div class="pd-atv-col-l">Quay phim</div><div class="pd-atv-col-r">C&oacute;</div></div><div class="viewfull">Xem đầy đủ bảng th&ocirc;ng số kỹ thuật +</div></div><div class="cl">&nbsp;</div></div><div class="cl">&nbsp;</div><h3>Th&ocirc;ng tin: Apple iPhone 5S (16G) Silver</h3><p style="text-align:justify"><span style="font-size:14px"><strong>Thiết kế mới nguy&ecirc;n khối mỏng nhất trong c&aacute;c si&ecirc;u phẩm của Apple</strong></span></p><p style="text-align:justify"><span style="font-size:14px">Ngay từ buổi lễ ra mắt, c&aacute;c nh&agrave; thiết kế của Apple đ&atilde; khẳng định đ&acirc;y l&agrave; chiếc điện thoại mỏng nhất m&agrave; họ từng l&agrave;m,&nbsp;iPhone 5S sở hữu những th&ocirc;ng số về k&iacute;ch thước thật đ&aacute;ng kinh ngạc, m&aacute;y&nbsp;mỏng chỉ 7.6 mm&nbsp;v&agrave; trọng lượng&nbsp;chưa tới 112g,&nbsp;nếu đem ra so s&aacute;nh với c&aacute;c smartphone hiện nay th&igrave; iPhone 5S &nbsp;thực sự l&agrave; một trong những chiếc điện thoại mỏng nhất, nhẹ nhất.</span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/V5cT61YYTmFLmY3.jpg" style="display:block; height:480px; width:473px" /><br />Để c&oacute; được những th&ocirc;ng số k&iacute;ch thước cực kỳ tốt như tr&ecirc;n, Apple đ&atilde; sử dụng thiết kế mới cho&nbsp;iPhone 5&nbsp;, to&agrave;n bộ vỏ iPhone 5&nbsp; l&agrave; một hộp kim nguy&ecirc;n khối, được gia c&ocirc;ng v&agrave; chạm khắc trực tiếp c&aacute;c bộ phận l&ecirc;n vỏ m&aacute;y, c&aacute;c bộ phận được sắp xếp hợp l&yacute; với nhau b&ecirc;n trong vỏ m&aacute;y. Thiết kế nguy&ecirc;n khối đem đến cho iPhone 5&nbsp; d&aacute;ng vẻ ho&agrave;n to&agrave;n kh&aacute;c so với người tiền nhiệm l&agrave; Iphone 4 v&agrave; 4S. M&aacute;y tr&ocirc; ng rất tinh tế v&agrave; sang trọng, cảm gi&aacute;c cầm tr&ecirc;n tay rất tuyệt vời.</span></p><p style="text-align:justify"><span style="font-size:14px"><strong>M&agrave;n h&igrave;nh</strong></span></p><p style="text-align:justify"><span style="font-size:14px">Người d&ugrave;ng iPhone lu&ocirc;n thấy &ldquo;chạnh l&ograve;ng&rdquo; v&igrave; thiết bị của m&igrave;nh c&oacute; m&agrave;n h&igrave;nh &ldquo;t&iacute; hon&rdquo; nếu so với những con khủng long của thế giới Android (hay thậm ch&iacute; l&agrave; Windows Phone). Tuy nhi&ecirc;n, việc iPhone 5S chưa ra tăng k&iacute;ch cỡ cũng c&oacute; c&aacute;i l&yacute; của n&oacute;: liệu người d&ugrave;ng c&oacute; c&ograve;n thoải m&aacute;i, c&oacute; thể sử dụng iPhone bằng 1 tay hay kh&ocirc;ng khi gia tăng k&iacute;ch cỡ, dẫn đến chiều rộng m&agrave;n h&igrave;nh lớn hơn? C&acirc;u trả lời c&oacute; lẽ l&agrave; kh&ocirc;ng. Vả chăng, th&ocirc;ng tin về một thiết bị phablet của Apple đang bắt đầu c&oacute; mặt tr&ecirc;n c&aacute;c k&ecirc;nh kh&ocirc;ng ch&iacute;nh thức. Nếu đ&atilde; c&oacute; một sản phẩm như vậy, l&yacute; g&igrave; Apple lại phải tăng k&iacute;ch cỡ iPhone cho tốn k&eacute;m v&agrave; phức tạp trong chế tạo?</span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/0qum761qT1sS9T1.jpg" style="display:block; height:563px; width:384px" /></span></p><p style="text-align:justify"><span style="font-size:14px">M&agrave;n h&igrave;nh iPhone 5S kết hợp với hệ điều h&agrave;nh tối ưu sẽ vẫn đảm bảo &quot;phần nh&igrave;n&quot;</span></p><p style="text-align:justify"><span style="font-size:14px">M&agrave;n h&igrave;nh của c&aacute;c thiết bị iPhone lu&ocirc;n c&oacute; tiếng l&agrave; &ldquo;nhỏ m&agrave; c&oacute; v&otilde;&rdquo;. Quả thực vậy, m&agrave;n h&igrave;nh tr&ecirc;n iPhone 5S vẫn giữ được sự trung thực về m&agrave;u sắc như tr&ecirc;n c&aacute;c phi&ecirc;n bản tiền nhiệm. Độ ph&acirc;n giải c&oacute; thể l&agrave; điểm yếu, tuy nhi&ecirc;n với hệ điều h&agrave;nh được tối ưu tốt, iPhone 5S vẫn cho ra những h&igrave;nh ảnh sắc n&eacute;t, kh&ocirc;ng hề c&oacute; hiện tượng vỡ h&igrave;nh.</span></p><p style="text-align:justify"><span style="font-size:14px"><strong>Hiệu năng - Cấu h&igrave;nh</strong></span></p><p style="text-align:justify"><span style="font-size:14px">Như thường lệ, mỗi khi một sản phẩm mới của Apple ra mắt, người ta sẽ &ldquo;đ&oacute;i&rdquo; th&ocirc;ng số cụ thể của n&oacute;, m&agrave; chỉ biết rằng n&oacute; sẽ nhanh hơn thế hệ trước l&agrave; bao nhi&ecirc;u. Ở chiếc iPhone 5S, Apple cũng chỉ cung cấp th&ocirc;ng tin rằng con chip A7 sẽ nhanh hơn 31% so với con chip A6 thế hệ trước, đủ đảm bảo một hiệu năng đ&aacute;p ứng được những t&iacute;nh năng mới được th&ecirc;m v&agrave;o tr&ecirc;n chiếc điện thoại n&agrave;y. Chip A7 sẽ l&agrave; con chip đầu ti&ecirc;n tr&ecirc;n thiết bị di động hỗ trợ c&aacute;c tập lệnh 64bit, l&agrave; một sự đ&oacute;n đầu tương lai khi bộ nhớ của c&aacute;c thiết bị di động sẽ gia tăng ch&oacute;ng mặt. Tuy nhi&ecirc;n, ở thời điểm hiện tại, c&oacute; lẽ đ&acirc;y chỉ l&agrave; một th&ocirc;ng số mang t&iacute;nh quảng c&aacute;o l&agrave; ch&iacute;nh.</span></p><p style="text-align:justify"><span style="font-size:14px">Hiệu năng của 5S c&ograve;n được tối ưu với con chip đồng h&agrave;nh M7. Con chip n&agrave;y đảm nhận việc xử l&yacute; th&ocirc;ng tin từ c&aacute;c cảm biến chuyển động, gia tốc kế, cảm biến s&aacute;ng,&hellip; giảm tải cho chip A7 v&agrave; gi&uacute;p c&aacute;c c&ocirc;ng việc li&ecirc;n quan đến c&aacute;c cảm biến n&agrave;y diễn ra nhanh ch&oacute;ng hơn.</span></p><p style="text-align:justify">&nbsp;</p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/Ppza982rTMX7zW4.jpg" style="display:block; height:533px; width:499px" /></span></p><p style="text-align:justify"><span style="font-size:14px">Chip M7 xử l&yacute; c&aacute;c th&ocirc;ng tin từ c&aacute;c cảm biến</span></p><p style="text-align:justify"><span style="font-size:14px">M&aacute;y cũng được trang bị dung lượng RAM 1GB, hơi thất vọng một ch&uacute;t v&igrave; đa phần c&aacute;c smartphone cao cấp tr&ecirc;n thị trường đều đ&atilde; c&oacute; RAM 2GB thậm ch&iacute; l&agrave; hơn.</span></p><p style="text-align:justify"><span style="font-size:14px">N&oacute;i chung, với những thiết bị chạy iOS, do hệ điều h&agrave;nh n&agrave;y c&oacute; t&iacute;nh tối ưu rất cao, n&ecirc;n kh&ocirc;ng cần th&agrave;nh phần cấu h&igrave;nh qu&aacute; cao, c&aacute;c thiết bị vẫn c&oacute; thể chạy một c&aacute;ch rất mượt m&agrave;.</span></p><p style="text-align:justify"><span style="font-size:14px"><strong>Camera</strong></span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/0WMeq42Y63s4T5R.jpg" style="display:block; height:362px; width:491px" /></span></p><p style="text-align:justify"><span style="font-size:14px">Camera iPhone 5S c&oacute; nhiều cải tiến đ&aacute;ng gi&aacute;</span></p><p style="text-align:justify"><span style="font-size:14px">Camera iSight l&agrave; một trong những điểm được tập trung quảng c&aacute;o tr&ecirc;n chiếc iPhone 5S n&agrave;y. Mặc d&ugrave; &ldquo;số chấm&rdquo; kh&ocirc;ng được gia tăng, nhưng những người c&oacute; kiến thức một ch&uacute;t về chụp ảnh đều biết rằng, th&ocirc;ng số n&agrave;y chẳng c&oacute; ảnh hưởng g&igrave; tới chất lượng h&igrave;nh ảnh thu được, đặc biệt l&agrave; với một thiết bị m&agrave; &ldquo;chụp ảnh l&agrave; niềm vui&rdquo; chứ kh&ocirc;ng phải để kiếm tiền (in, ph&oacute;ng ra k&iacute;ch thước lớn) như iPhone.</span></p><p style="text-align:justify"><span style="font-size:14px">Apple đ&atilde; cải tiến một c&aacute;ch nghi&ecirc;m t&uacute;c camera tr&ecirc;n iPhone 5S: gia tăng k&iacute;ch cỡ cảm biến l&ecirc;n 15%, sử dụng hệ ống k&iacute;nh 5 th&agrave;nh phần chất lượng cao, khẩu độ lớn đến 2.2, cung cấp 2 đ&egrave;n flash với chế độ m&agrave;u kh&aacute;c nhau. Với những th&agrave;nh phần cấu h&igrave;nh rất ấn tượng như thế n&agrave;y, iPhone 5S tự tin cho khả năng chụp đ&ecirc;m kh&ocirc;ng thua k&eacute;m c&aacute;c si&ecirc;u phẩm tr&ecirc;n thị trường.</span></p><p style="text-align:justify"><span style="font-size:14px"><strong>Phần mềm</strong></span></p><p style="text-align:justify"><span style="font-size:14px">Hệ điều h&agrave;nh n&agrave;y l&agrave; một bản thiết kế lại gần như ho&agrave;n to&agrave;n về mặt giao diện, n&oacute; mang một phong c&aacute;ch ho&agrave;n to&agrave;n kh&aacute;c, mang tư duy &ldquo;thiết kế phẳng&rdquo; đang rất thịnh h&agrave;nh trong giới c&ocirc;ng nghệ ng&agrave;y nay. Với đầy m&agrave;u sắc, iOS 7 c&oacute; thể thỏa m&atilde;n những người d&ugrave;ng muốn c&oacute; một c&aacute;i g&igrave; đ&oacute; mới lạ so với giao diện iOS cũ đ&atilde; 7 năm tuổi. Dĩ nhi&ecirc;n, với lượng theme rất lớn v&agrave; một cộng đồng nh&agrave; ph&aacute;t triển qu&aacute; đ&ocirc;ng đảo, việc thay đổi giao diện, icon hay m&agrave;u sắc chẳng phải l&agrave; điều kh&oacute; đối với c&aacute;c t&iacute;n đồ T&aacute;o khuyết.</span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/2RJA797Pp2B3G8A.jpg" style="display:block; height:390px; width:533px" /><br />iOS 7 với triết l&yacute; &quot;thiết kế phẳng&quot; v&agrave; đầy m&agrave;u sắc</span></p><p style="text-align:justify"><span style="font-size:14px">Touch ID l&agrave; một t&iacute;nh năng mới nhất v&agrave; được ch&uacute; &yacute; nhất trong đợt ra mắt lần n&agrave;y của Apple, v&igrave; n&oacute; sẽ tận dụng bộ qu&eacute;t v&acirc;n tay lần đầu được t&iacute;ch hợp v&agrave;o iPhone. H&atilde;y tưởng tượng, bạn kh&ocirc;ng cần nhớ bất kỳ mật khẩu n&agrave;o để đăng nhập v&agrave;o c&aacute;c t&agrave;i khoản của m&igrave;nh hay đơn giản để mở kh&oacute;a m&agrave;n h&igrave;nh. Điều đ&oacute; sẽ thuận tiện v&agrave; an to&agrave;n biết bao so với c&aacute;ch &ldquo;truyền thống&rdquo; b&acirc;y giờ.</span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/QS9ki6bX06tV85W.jpg" style="display:block; height:584px; width:540px" /></span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/61TpP2nchq8F2ml.jpg" style="display:block" /></span></p><p style="text-align:justify"><span style="font-size:14px">C&oacute; thể d&ugrave;ng TouchID để đăng nhập t&agrave;i khoản iCloud</span></p><p style="text-align:justify"><span style="font-size:14px">Với TouchID, người d&ugrave;ng c&oacute; thể cấu h&igrave;nh để ghi nhớ tối đa 5 mẫu v&acirc;n tay v&agrave; sử dụng ch&uacute;ng lu&acirc;n phi&ecirc;n từng ng&agrave;y trong tuần l&agrave;m mật khẩu cho chiếc m&aacute;y của m&igrave;nh.</span></p><p style="text-align:justify"><span style="font-size:14px"><img class="lazy" src="http://cdn.mediamart.vn/Upload/download/2016-4-News/d1UNLMAtlYpNF1h.jpg" style="display:block" /></span></p><p style="text-align:justify"><span style="font-size:14px">Người d&ugrave;ng c&oacute; thể đăng k&yacute; đến 5 mẫu v&acirc;n tay</span></p><p style="text-align:justify"><span style="font-size:14px">Tương lai xa hơn, TouchID c&oacute; thể gi&uacute;p đăng nhập v&agrave;o bất kỳ trang web, ứng dụng n&agrave;o, sử dụng cho c&aacute;c mục đ&iacute;ch thương mại điện tử ,&hellip; tuy nhi&ecirc;n, hiện tại, bạn h&atilde;y tạm h&agrave;i l&ograve;ng với những t&iacute;nh năng m&agrave; Apple trang bị.</span></p>', '12 tháng', '0000-00-00 00:00:00', NULL, 'on', '0000-00-00 00:00:00', 'nguyentien24', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL),
(20, '55', 'qqq', NULL, 'qqq', '/test/public/access/upload/images/Products/12006379_1719023511688467_677731682656957962_n.jpg', '1000000', '1000000', '1000000', '1', 111, 44, '', '12 tháng', '0000-00-00 00:00:00', NULL, 'on', '2016-07-03 10:21:00', 'nguyentien24', '2016-07-03 11:43:16', 'nguyentien24', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `productsima`
--

CREATE TABLE IF NOT EXISTS `productsima` (
  `Idi` int(11) NOT NULL AUTO_INCREMENT,
  `Urllink` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Idp` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idi`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `productsima`
--

INSERT INTO `productsima` (`Idi`, `Urllink`, `Idp`) VALUES
(1, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-12-1024x640.jpg', 14),
(2, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-14-1024x576.jpg', 14),
(3, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-13-1024x576.jpg', 14),
(4, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-12-1024x640.jpg', 12),
(5, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-14-1024x576.jpg', 12),
(6, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-13-1024x576.jpg', 12),
(7, '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-4-1024x576.jpg', 17),
(8, '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-15-1024x576.jpg', 17),
(9, '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-4-1024x576.jpg', 17),
(10, '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-3-1024x640.jpg', 18),
(11, '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-4-1024x576.jpg', 18),
(12, '/test/public/access/upload/images/News/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-9-1024x576.jpg', 18),
(13, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-10-1024x640.jpg', 20),
(14, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-3-1024x640.jpg', 20),
(15, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-1-1024x640.jpg', 20);

-- --------------------------------------------------------

--
-- Table structure for table `products_cart`
--

CREATE TABLE IF NOT EXISTS `products_cart` (
  `Idct` int(11) NOT NULL AUTO_INCREMENT,
  `Idp` int(11) DEFAULT NULL,
  `Product_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Product_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Product_desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Product_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Product_price` decimal(10,0) DEFAULT NULL,
  `Product_quantity` int(11) DEFAULT NULL,
  `Product_note` text COLLATE utf8_unicode_ci,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Createdate` datetime DEFAULT NULL,
  PRIMARY KEY (`Idct`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `products_cart`
--

INSERT INTO `products_cart` (`Idct`, `Idp`, `Product_code`, `Product_name`, `Product_desc`, `Product_img`, `Product_price`, `Product_quantity`, `Product_note`, `Createby`, `Createdate`) VALUES
(1, 14, 'test', '1111111111111', NULL, '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '10000000', 2, 'Som nhat nhe', 'nguyentien24@gmail.com', NULL),
(2, 7, 'test', 'demo', NULL, '/test/public/access/upload/images/Products/muathu.jpg', '0', 1, '', 'nguyentien24@gmail.com', NULL),
(3, 14, 'test', '1111111111111', NULL, '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '10000000', 2, 'dsfsdf', 'ádasdasd', NULL),
(4, 7, 'test', 'demo', NULL, '/test/public/access/upload/images/Products/muathu.jpg', '0', 1, '', 'ádasdasd', NULL),
(7, 19, '507256', 'Array', NULL, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-10-1024x640.jpg', '7888000', 1, 'zss', 'aaa', '0000-00-00 00:00:00'),
(8, 14, 'test', 'demo', NULL, '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '10000000', 1, '', 'aaa', '0000-00-00 00:00:00'),
(9, 19, '507256', 'Array', NULL, '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-10-1024x640.jpg', '7888000', 1, 'asas', 'assa', '2016-07-02 21:47:15'),
(10, 14, 'test', 'demo', NULL, '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '10000000', 1, '', 'assa', '2016-07-02 21:47:15'),
(11, 14, 'test', 'demo', NULL, '/test/public/access/upload/images/Products/hinh-nen-mua-thu-3.jpg', '10000000', 1, 'asdasd', 'asd', '2016-07-03 09:06:53'),
(12, 15, 'demo2', 'test2', NULL, '/test/public/access/upload/images/Products/hinh-nen-mua-thu-7.jpg', '1', 1, 'dfsdf', 'qưe', '2016-07-03 23:32:25');

-- --------------------------------------------------------

--
-- Table structure for table `setmenua`
--

CREATE TABLE IF NOT EXISTS `setmenua` (
  `Idset` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Classify` int(11) DEFAULT '0',
  `Display` int(11) DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `setmenua`
--

INSERT INTO `setmenua` (`Idset`, `Name`, `Icon`, `Classify`, `Display`, `Startus`) VALUES
('about', 'Giới thiệu', 'book', 1, NULL, 'on'),
('category', 'Danh mục', 'survey', 1, NULL, 'on'),
('contact', 'Liên hệ', 'book', 1, NULL, 'on'),
('feedback', 'Phản hồi', 'user', 1, NULL, 'on'),
('feedbacklist', 'Danh sách phản hồi', 'cabinet', 0, NULL, 'on'),
('footer', 'Footer', 'database', 1, NULL, 'on'),
('news', 'Tin tức', 'book', 1, NULL, 'on'),
('products', 'Sản phẩm', 'book', 1, NULL, 'on'),
('products_cart', 'Giỏ hàng', 'shopping-bag', 1, NULL, 'on'),
('productsima', 'Ảnh sản phẩm', 'graph', 1, NULL, 'on'),
('purchase_order_ok', 'Đơn hàng', 'survey', 0, NULL, 'on'),
('setmenua', 'Menu Admin', 'book', 1, NULL, 'on'),
('slides', 'Slides', 'web', 1, NULL, 'on'),
('user', 'Người dùng', 'user', 1, NULL, 'on'),
('users', 'Quản trị', 'people', 1, NULL, 'on');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE IF NOT EXISTS `slides` (
  `Ids` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Detail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Images` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Links` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Displayorder` int(11) DEFAULT NULL,
  `Classify` int(11) DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Modifydate` datetime DEFAULT NULL,
  `Modifyby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Ids`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`Ids`, `Name`, `Detail`, `Images`, `Links`, `Displayorder`, `Classify`, `Startus`, `Createdate`, `Createby`, `Modifydate`, `Modifyby`) VALUES
(2, NULL, NULL, '/test/public/access/upload/images/Products/hinh-nen-ca-choi-dep-cho-iphone-6s-1.jpg', '', 1, 1, 'on', NULL, NULL, NULL, NULL),
(3, 'bvvb', 'vbvb', '/test/public/access/upload/images/Products/hinh-nen-ca-choi-dep-cho-iphone-6s-1.jpg', '', 1, 1, 'on', NULL, NULL, NULL, NULL),
(4, 'test2', 'adas', '/test/public/access/upload/images/Products/12006379_1719023511688467_677731682656957962_n.jpg', '', 2, 1, 'on', NULL, NULL, NULL, NULL),
(5, '', '', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-14-1024x576.jpg', '', 0, 2, 'on', NULL, NULL, NULL, NULL),
(6, '', '', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-2-1024x640.jpg', '', 0, 2, 'on', NULL, NULL, NULL, NULL),
(7, '', '', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-10-1024x640.jpg', '', 0, 2, 'on', NULL, NULL, NULL, NULL),
(8, '', '', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-15-1024x576.jpg', '', 0, 2, 'on', NULL, NULL, NULL, NULL),
(9, '', '', '/test/public/access/upload/images/Products/tai-hinh-nen-dien-thoai-de-thuong-ve-tinh-yeu-dep-nhat-13-1024x576.jpg', '', 0, 2, 'on', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Pass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Discription` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Email`, `Name`, `Pass`, `Phone`, `Address`, `Discription`, `Startus`, `Createdate`) VALUES
('aaa', 'aaa', NULL, '222', 'ssss', NULL, 'on', NULL),
('ádasdasd', 'sdfsf', NULL, '5454', 'dfsdf', NULL, 'on', NULL),
('asd', 'sad', NULL, '34', '343', NULL, 'on', NULL),
('assa', 'asas', NULL, '223', 'sas', NULL, 'on', NULL),
('nguyentien24@gmail.com', 'nguyen hung', NULL, '25251324', 'Yen bai', NULL, 'on', NULL),
('qưe', 'qưe', NULL, '334', '24324', NULL, 'on', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `Idus` int(11) NOT NULL AUTO_INCREMENT,
  `Usersnames` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Passwords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Level` int(11) DEFAULT NULL,
  `Startus` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `Createdate` datetime DEFAULT NULL,
  `Createby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Modifydate` datetime DEFAULT NULL,
  `Modifyby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idus`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Idus`, `Usersnames`, `Passwords`, `Name`, `Phone`, `Email`, `Avatar`, `Address`, `Level`, `Startus`, `Createdate`, `Createby`, `Modifydate`, `Modifyby`) VALUES
(1, 'nguyentien24', '0feecec7d53226201a77b7ec5c0ed68a', 'Nguyen Tien', '0961560038', 'sweetlove10071991@gmail.com', NULL, 'Ha noi', 1, 'on', '2016-06-22 15:43:07', 'Administrator', '2016-06-22 15:43:07', 'Administrator'),
(2, 'df', '9300a91a11f6ffe7cdc7ab4db976833e', 'fd', 'gf', 'gf', NULL, 'fg', 2, 'on', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL),
(21, '', '', '', '', '', NULL, '', 0, '', NULL, NULL, NULL, NULL),
(23, 'admin', 'admin', '', '', '', NULL, '', 0, '', NULL, NULL, NULL, NULL),
(24, 'admin', '0feecec7d53226201a77b7ec5c0ed68a', 'admin', '0123456789', 'admin@gmail.com', NULL, 'hà nội', 2, 'on', '0000-00-00 00:00:00', 'nguyentien24', NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
