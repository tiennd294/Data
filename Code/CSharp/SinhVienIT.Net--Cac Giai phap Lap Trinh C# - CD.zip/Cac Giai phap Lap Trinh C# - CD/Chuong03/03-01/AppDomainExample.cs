using System;

class AppDomainExample {

    public static void Main() {        

        AppDomainSetup setupInfo = new AppDomainSetup();

        setupInfo.ApplicationBase = @"C:\MyRootDirectory";
        setupInfo.ConfigurationFile = "MyApp.config";
        setupInfo.PrivateBinPath = "bin;plugins;external";

        AppDomain newDomain = AppDomain.CreateDomain(
            "My New AppDomain",
            new System.Security.Policy.Evidence(),
            setupInfo);

        Console.ReadLine();
    }
}

