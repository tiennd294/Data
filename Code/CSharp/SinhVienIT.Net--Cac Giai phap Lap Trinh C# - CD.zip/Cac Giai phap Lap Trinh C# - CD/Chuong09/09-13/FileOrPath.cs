using System;
using System.IO;

public class FileOrPath
{
	private	static void Main(string[] args)
	{
		foreach (string arg in args)
		{
			Console.Write(arg);

			if (Directory.Exists(arg))
			{
				Console.WriteLine(" is a directory");
			}
			else if (File.Exists(arg))
			{
				Console.WriteLine(" is a file");
			}
			else
			{
				Console.WriteLine(" does not exist");
			}
		}

		Console.ReadLine();
	}
}