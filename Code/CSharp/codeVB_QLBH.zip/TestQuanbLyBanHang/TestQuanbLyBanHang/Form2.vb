Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class Form2
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub


		Private Sub Form2_Load(sender As Object, e As EventArgs)

		End Sub

		Private Sub button1_Click(sender As Object, e As EventArgs)
			Try
				'string tg="dung";
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM DangNhap ", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)

				' Đưa dữ liệu lên textbox1
				'textBox1.Text = dt.Rows[0][0].ToString();

				If (Me.textBox1.Text = dt.Rows(0)(0).ToString()) AndAlso (Me.textBox2.Text = dt.Rows(0)(1).ToString()) Then

					Dim dt2 As New DataTable()
					'int r = dataGridView1.CurrentCell.RowIndex;
					' MaKH hiện hành 
					'string str = dataGridView1.Rows[r].Cells[0].Value.ToString();
					' Câu lệnh SQL
					cmd.CommandText = System.[String].Concat("UPDATE DangNhap SET TG='dung'")
					cmd.CommandType = CommandType.Text
					cmd.ExecuteNonQuery()

					Me.Close()
				Else

					MessageBox.Show("Không đúng tên người dùng / mật khẩu !!!", "Thông báo")
					Me.textBox1.Focus()
				End If
			Catch
			End Try


		End Sub

		Private Sub button2_Click(sender As Object, e As EventArgs)
			Dim traloi As DialogResult
			traloi = MessageBox.Show("Chắc không?", "Trả lời", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
			If traloi = DialogResult.OK Then
				Dim Ql As New QuanLy()
				Ql.Huy()
				Application.[Exit]()
			End If
		End Sub

		Private Sub textBox2_KeyDown(sender As Object, e As KeyEventArgs)
			If e.KeyCode = Keys.Enter Then
				Try
					'string tg="dung";
					Dim cmd As New SqlCommand()
					Dim kn As New ketnoi()
					kn.ket_noi()
					cmd.Connection = kn.con

					Dim da As New SqlDataAdapter("SELECT * FROM DangNhap ", kn.con)
					Dim dt As New DataTable()
					dt.Clear()
					da.Fill(dt)
					' Đưa dữ liệu lên textbox1
					'textBox1.Text = dt.Rows[0][0].ToString();

					If (Me.textBox1.Text = dt.Rows(0)(0).ToString()) AndAlso (Me.textBox2.Text = dt.Rows(0)(1).ToString()) Then

						Dim dt2 As New DataTable()
						'int r = dataGridView1.CurrentCell.RowIndex;
						' MaKH hiện hành 
						'string str = dataGridView1.Rows[r].Cells[0].Value.ToString();
						' Câu lệnh SQL
						cmd.CommandText = System.[String].Concat("UPDATE DangNhap SET TG='dung'")
						cmd.CommandType = CommandType.Text
						cmd.ExecuteNonQuery()

						Me.Close()
					Else

						MessageBox.Show("Không đúng tên người dùng / mật khẩu !!!", "Thông báo")
						Me.textBox1.Focus()
					End If
				Catch


				End Try
			End If
		End Sub
	End Class
End Namespace
