using System;
using System.Web;
using System.Web.UI.WebControls;
using System.IO;

/// <summary>
/// Summary description for UploadPage.
/// </summary>
public class UploadPage : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.Label lblInfo;
	protected System.Web.UI.WebControls.Button cmdUpload;
	protected System.Web.UI.HtmlControls.HtmlInputFile FileInput;

	private void Page_Load(object sender, System.EventArgs e)
	{
		// Put user code to initialize the page here
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.cmdUpload.Click += new System.EventHandler(this.cmdUpload_Click);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private void cmdUpload_Click(object sender, System.EventArgs e) {
	
		if (FileInput.PostedFile.FileName == "") {
		
			lblInfo.Text = "No file specified.";
		}
		else {
			
			try	
			{
			
				if (FileInput.PostedFile.ContentLength > 1048576) 
				{
				
					lblInfo.Text = "File is too large.";
				}
				else {
                
					string fileName = Path.GetFileName(FileInput.PostedFile.FileName);
					// fileName = "C:\\" + fileName;

					FileInput.PostedFile.SaveAs(fileName);
					lblInfo.Text = "File " + fileName + " uploaded.";
				}
			}
			catch (Exception err) {
			
				lblInfo.Text = err.Message;
			}
		}


	}
}