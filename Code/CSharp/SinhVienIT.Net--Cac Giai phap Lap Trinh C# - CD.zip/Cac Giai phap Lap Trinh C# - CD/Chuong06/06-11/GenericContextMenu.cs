using System;
using System.Drawing;
using System.Windows.Forms;

public class GenericContextMenu : System.Windows.Forms.Form
{
	internal System.Windows.Forms.Label Label1;
	internal System.Windows.Forms.PictureBox PictureBox1;
	internal System.Windows.Forms.TextBox TextBox1;
	internal System.Windows.Forms.ContextMenu ContextMenu3;
	internal System.Windows.Forms.MenuItem MenuItem1;
	internal System.Windows.Forms.ContextMenu ContextMenu1;
	internal System.Windows.Forms.MenuItem MenuItem3;
	internal System.Windows.Forms.ContextMenu ContextMenu2;
	internal System.Windows.Forms.MenuItem MenuItem2;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public GenericContextMenu()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.Label1 = new System.Windows.Forms.Label();
		this.PictureBox1 = new System.Windows.Forms.PictureBox();
		this.TextBox1 = new System.Windows.Forms.TextBox();
		this.ContextMenu3 = new System.Windows.Forms.ContextMenu();
		this.MenuItem1 = new System.Windows.Forms.MenuItem();
		this.ContextMenu1 = new System.Windows.Forms.ContextMenu();
		this.MenuItem3 = new System.Windows.Forms.MenuItem();
		this.ContextMenu2 = new System.Windows.Forms.ContextMenu();
		this.MenuItem2 = new System.Windows.Forms.MenuItem();
		this.SuspendLayout();
		// 
		// Label1
		// 
		this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.Label1.ContextMenu = this.ContextMenu3;
		this.Label1.Location = new System.Drawing.Point(34, 167);
		this.Label1.Name = "Label1";
		this.Label1.Size = new System.Drawing.Size(104, 64);
		this.Label1.TabIndex = 5;
		this.Label1.Text = "Label1";
		this.Label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Control_MouseDown);
		// 
		// PictureBox1
		// 
		this.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.PictureBox1.ContextMenu = this.ContextMenu2;
		this.PictureBox1.Location = new System.Drawing.Point(134, 71);
		this.PictureBox1.Name = "PictureBox1";
		this.PictureBox1.Size = new System.Drawing.Size(128, 80);
		this.PictureBox1.TabIndex = 4;
		this.PictureBox1.TabStop = false;
		this.PictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Control_MouseDown);
		// 
		// TextBox1
		// 
		this.TextBox1.ContextMenu = this.ContextMenu1;
		this.TextBox1.Location = new System.Drawing.Point(30, 35);
		this.TextBox1.Name = "TextBox1";
		this.TextBox1.Size = new System.Drawing.Size(152, 20);
		this.TextBox1.TabIndex = 3;
		this.TextBox1.Text = "TextBox1";
		this.TextBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Control_MouseDown);
		// 
		// ContextMenu3
		// 
		this.ContextMenu3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.MenuItem1});
		// 
		// MenuItem1
		// 
		this.MenuItem1.Index = 0;
		this.MenuItem1.Text = "3";
		// 
		// ContextMenu1
		// 
		this.ContextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.MenuItem3});
		// 
		// MenuItem3
		// 
		this.MenuItem3.Index = 0;
		this.MenuItem3.Text = "1";
		// 
		// ContextMenu2
		// 
		this.ContextMenu2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.MenuItem2});
		// 
		// MenuItem2
		// 
		this.MenuItem2.Index = 0;
		this.MenuItem2.Text = "2";
		// 
		// Form1
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.Label1,
																		this.PictureBox1,
																		this.TextBox1});
		this.Name = "Form1";
		this.Text = "Form1";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new GenericContextMenu());
	}

	private void Control_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			Control ctrl = (Control)sender;

			if (ctrl.ContextMenu != null)
			{
				ctrl.ContextMenu.Show(ctrl, new Point(e.X, e.Y));
			}
		}
	}
}