using System;
using System.Runtime.InteropServices;

public class TestError
{
	[DllImport("kernel32.dll")]
	private unsafe static extern int FormatMessage(int dwFlags, int lpSource, 
		int dwMessageId, int dwLanguageId, ref String lpBuffer, int nSize, int Arguments);

	[DllImport("user32.dll", SetLastError=true)]
	public static extern int MessageBox(int hWnd, 
		string pText ,
		string pCaption ,
		int uType);

	private static void Main()
	{
		int badWindowHandle = 453;
		MessageBox(badWindowHandle, "Message", "Caption", 0);
		
		int errorCode = Marshal.GetLastWin32Error();
		Console.WriteLine(errorCode);
		Console.WriteLine(GetErrorMessage(errorCode));

		Console.ReadLine();
	}

	public static string GetErrorMessage(int errorCode)
	{
		int FORMAT_MESSAGE_ALLOCATE_BUFFER = 0x00000100;
		int FORMAT_MESSAGE_IGNORE_INSERTS = 0x00000200;
		int FORMAT_MESSAGE_FROM_SYSTEM  = 0x00001000;

		int messageSize = 255;
		string lpMsgBuf = "";
		int dwFlags = FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS;
    
		int retVal = FormatMessage(dwFlags, 0, errorCode, 0, ref lpMsgBuf, messageSize, 0);
		if (0 == retVal) 
		{
			return null;
		}
		else
		{
			return lpMsgBuf;
		}
	}

}