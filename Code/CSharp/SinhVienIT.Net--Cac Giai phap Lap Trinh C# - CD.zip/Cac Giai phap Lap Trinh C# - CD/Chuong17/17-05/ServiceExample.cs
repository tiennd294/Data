using System;
using System.Timers;
using System.ServiceProcess;

public class ServiceExample : ServiceBase {
	
    private System.Timers.Timer timer;

    public ServiceExample() {

        ServiceName = "ServiceExample";

        CanStop = true;
        CanPauseAndContinue = true;

        AutoLog = true;
    }
	
    private void WriteLogEntry(object sender, ElapsedEventArgs e) {

        EventLog.WriteEntry("ServiceExample active : " + e.SignalTime);
    }					

    protected override void OnStart(string[] args) {

        double interval;

        try {
            interval = System.Double.Parse(args[0]);
            interval = Math.Max(1000, interval);
        } catch {
            interval = 5000;
        }

        EventLog.WriteEntry(String.Format("ServiceExample starting. " +
            "Writing log entries every {0} milliseconds...", interval));

        timer = new Timer();
        timer.Interval = interval;
        timer.AutoReset = true;
        timer.Elapsed += new ElapsedEventHandler(WriteLogEntry);
        timer.Start();
    }
	
    protected override void OnStop() {

        EventLog.WriteEntry("ServiceExample stopping...");
        timer.Stop();

        timer.Dispose();
        timer = null;
    }
		
    protected override void OnPause() {

        if (timer != null) {
            EventLog.WriteEntry("ServiceExample pausing...");
            timer.Stop();
        }
    }
			
    protected override void OnContinue() {

        if (timer != null) {
            EventLog.WriteEntry("ServiceExample resuming...");
            timer.Start();
        }
    }
		
    public static void Main() {

        ServiceBase.Run(new ServiceExample());
    }	
}