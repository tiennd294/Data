using System;
using System.Text;
using System.Security.Cryptography;

public class KeyedHashMessageExample {
    
    public static void Main(string[] args) {

        byte[] key = Encoding.Unicode.GetBytes(args[1]);

        using (HMACSHA1 hashAlg = new HMACSHA1(key)) {

            byte[] msgData = Encoding.Unicode.GetBytes(args[0]);
    
            byte[] hash = hashAlg.ComputeHash(msgData);
    
            Console.WriteLine(BitConverter.ToString(hash));
        }

        Console.ReadLine();
    }
}
