using System;
using System.Threading;

public class EventExecutionExample {

    private static void EventHandler(object state, bool timedout) {

        if (timedout) {
            
            Console.WriteLine("{0} : Wait timed out.",
                DateTime.Now.ToString("HH:mm:ss.ffff"));
        } else {

            Console.WriteLine("{0} : {1}", 
                DateTime.Now.ToString("HH:mm:ss.ffff"), state);
        }
    }

    public static void Main() {

        AutoResetEvent autoEvent = new AutoResetEvent(false);

        WaitOrTimerCallback handler = 
            new WaitOrTimerCallback(EventHandler);

        string state = "AutoResetEvent signaled.";

        RegisteredWaitHandle handle = 
            ThreadPool.RegisterWaitForSingleObject(autoEvent, handler, 
            state, 3000, false);

        Console.WriteLine("Press ENTER to signal the AutoResetEvent" +
            " or enter \"Cancel\" to unregister the wait operation.");

        while (Console.ReadLine().ToUpper() != "CANCEL") {

            autoEvent.Set();
        }

        Console.WriteLine("Unregistering wait operation.");
        handle.Unregister(null);

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}
