using System;
using IWshRuntimeLibrary;

public class ShortcutExample {

    public static void Main() {

        CreateShortcut("Desktop");

        CreateShortcut("StartMenu");

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }

    public static void CreateShortcut(string destination) {

        WshShell wshShell = new WshShell();

        object destFolder = (object)destination;
        string fileName = 
            (string)wshShell.SpecialFolders.Item(ref destFolder) 
            + @"\Notepad.lnk";

        IWshShortcut shortcut = 
            (IWshShortcut)wshShell.CreateShortcut(fileName);

        shortcut.TargetPath = 
            Environment.GetFolderPath(Environment.SpecialFolder.System) 
            + @"\notepad.exe";

        shortcut.WorkingDirectory =
            Environment.GetFolderPath(Environment.SpecialFolder.Personal);

        shortcut.Description = "Notepad Text Editor";

        shortcut.Hotkey = "CTRL+ALT+N";

        shortcut.WindowStyle = 3;

        shortcut.IconLocation = "notepad.exe, 0"; 

        shortcut.Save();
    }
}
