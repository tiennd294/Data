using System;
using System.Xml;

public class SelectNodesByNamespace
{
	[STAThread]
	private static void Main()
	{
		XmlDocument doc = new XmlDocument();
		doc.Load("Order.xml");

		XmlNodeList matches = doc.GetElementsByTagName("*", "http://mycompany/OrderML");

		Console.WriteLine("Element \tAttributes");
		Console.WriteLine("******* \t**********");
		foreach (XmlNode node in matches)
		{
			Console.Write(node.Name + "\t");
			foreach (XmlAttribute attribute in node.Attributes)
			{
				Console.Write(attribute.Value + "  ");
			}
			Console.WriteLine();
		}

		Console.ReadLine();
	}
}