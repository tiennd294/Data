using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using SharedComponent;

public class TcpClientTest
{
	private static void Main()
	{
		TcpClient client = new TcpClient();
		
		try
		{
			Console.WriteLine("Attempting to connect to the server " +
				"on port 8000.");
			client.Connect(IPAddress.Parse("127.0.0.1"), 8000);
			Console.WriteLine("Connection established.");
			
			NetworkStream networkStream = client.GetStream();
			
			BinaryWriter w = new BinaryWriter(networkStream);
            
			BinaryReader r = new BinaryReader(networkStream);
            
			w.Write(ClientMessages.RequestConnect);
			
			if (r.ReadString() == ServerMessages.AcknowledgeOK)
			{
				Console.WriteLine("Connected.");
				
				Console.WriteLine("Press Enter to request data.");
				Console.ReadLine();
				w.Write(ClientMessages.RequestData);
				
				int fileSize = int.Parse(r.ReadString());

				for (int i=0; i < fileSize/3; i++)
				{
					Console.Write(networkStream.ReadByte());
				}
				Console.WriteLine();
				Console.WriteLine();

				Console.WriteLine("Press Enter to disconnect.");
				Console.ReadLine();
				Console.WriteLine("Disconnecting...");
				w.Write(ClientMessages.Disconnect);
			}
			else
			{
				Console.WriteLine("Connection not completed.");
			}

			client.Close();
			Console.WriteLine("Port closed.");
		}
		catch (Exception err)
		{
			Console.WriteLine(err.ToString());
		}
    
		Console.ReadLine();

	}
}