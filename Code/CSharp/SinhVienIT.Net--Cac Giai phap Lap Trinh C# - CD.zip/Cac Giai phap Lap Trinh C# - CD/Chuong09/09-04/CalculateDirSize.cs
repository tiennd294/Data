using System;
using System.IO;

public class CalculateDirSize
{
	private static void Main(string[] args)
	{
		if (args.Length == 0)
		{
			Console.WriteLine("Please supply a directory path.");
			return;
		}

		DirectoryInfo dir = new DirectoryInfo(args[0]);
		Console.WriteLine("Total size: " + FileSystemUtil.CalculateDirectorySize(dir, true).ToString() + " bytes.");
		Console.ReadLine();
	}
}

public class FileSystemUtil 
{

	public static long CalculateDirectorySize(DirectoryInfo directory,
		bool includeSubdirectories) 
	{

		long totalSize = 0;

		FileInfo[] files = directory.GetFiles();
		foreach (FileInfo file in files) 
		{
			totalSize += file.Length;
		}

		if (includeSubdirectories) 
		{

			DirectoryInfo[] dirs = directory.GetDirectories();
			foreach (DirectoryInfo dir in dirs) 
			{
				totalSize += CalculateDirectorySize(dir, true);
			}
		}

		return totalSize;
	}
}
