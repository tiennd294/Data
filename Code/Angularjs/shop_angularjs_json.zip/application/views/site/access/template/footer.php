<div class="sixteen columns">
      <div class="brands">

        <div class="box_head">
          <h3>Liên kết</h3>
          <div class="pagers center">
            <a class="prev brand_prev" href="#prev">Prev</a>
            <a class="nxt brand_nxt" href="#nxt">Next</a>
          </div>
        </div><!--end box_head -->

        <div class="brandOuter">
          <ul>
            

<?php

            
            foreach ($tbnslide as $row):
              if($row->Classify==2 &&  $row->Startus='on'){
?>
            
            <li>
              <a href="<?php echo $row->Links;?>">
                <img src="<?php echo base_url().$row->Images;?>" style='width:130;height:130px;' alt="brand">
              </a>
            </li>
<?php
              }
            endforeach;
?>           
       

          </ul>
        </div>
      </div><!--end brands-->
    </div><!--end sixteen-->


  </div><!--end container-->
  <!-- end the main content area -->

  


  <!-- start the footer area-->
  <footer>
    <div class="container">


          <?php
             
              foreach ($tblcatagory as $row):
                if($row->Parentid==0 &&  $row->Startus=='on' &&  $row->Classify==3){
                
              ?>
                    <div class="three columns">
                      <div id="info">
                        <h3><?php echo $row->Name;?></h3>
                        <ul>
              <?php
                
                 foreach ($tblcatagory as $row2):
                    if($row2->Parentid==$row->Idc &&  $row2->Startus=='on' &&  $row2->Classify==3){
                    
              ?>
                   <li><a href="<?php  echo $row->Linkurl;?>"><?php echo $row2->Name;?></a></li>
                   
               <?php
                    }
                  endforeach;
               ?> 
                           </ul>
                  </div>
                </div><!--end three-->
               <?php
                }
              endforeach;
          ?>

    </div><!--end container-->


    <div class="tweets">
      <div class="container">
        <div class="sixteen columns">

          <div class="tweet2">&copy; Lovenovel 2016
            
          </div>
        </div>
      </div>
    </div>


    <div class="container">
      <div class="sixteen">
        
        <ul class="socials">
          <li><a class="twitter" href="https://twitter.com">twitter</a></li>
          <li><a class="facebook" href="https://facebook.com">face</a></li>
          <li><a class="googlep" href="#">google+</a></li>
          <li><a class="vimeo" href="#">vimeo</a></li>
          <li><a class="skype" href="#">skype</a></li>
          <li><a class="linked" href="#">linked</a></li>
        </ul>
      </div><!--end sixteen-->
    </div><!--end container-->

  </footer>
  <!--end the footer area -->




 
</body>
</html>

       