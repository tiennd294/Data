using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

public class DirectoryTree : System.Windows.Forms.Form
{
	private System.Windows.Forms.TreeView treeDirectory;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DirectoryTree()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.treeDirectory = new System.Windows.Forms.TreeView();
		this.SuspendLayout();
		// 
		// treeDirectory
		// 
		this.treeDirectory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.treeDirectory.ImageIndex = -1;
		this.treeDirectory.Location = new System.Drawing.Point(8, 4);
		this.treeDirectory.Name = "treeDirectory";
		this.treeDirectory.SelectedImageIndex = -1;
		this.treeDirectory.Size = new System.Drawing.Size(276, 248);
		this.treeDirectory.TabIndex = 0;
		this.treeDirectory.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeDirectory_BeforeExpand);
		// 
		// DirectoryTree
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.Add(this.treeDirectory);
		this.Name = "DirectoryTree";
		this.Text = "Browser";
		this.Load += new System.EventHandler(this.DirectoryTree_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void treeDirectory_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
	{
		
		if (e.Node.Nodes[0].Text == "*")
		{
			e.Node.Nodes.Clear();
			Fill(e.Node);
		}
	}

	private void Fill(TreeNode dirNode)
	{
		DirectoryInfo dir = new DirectoryInfo(dirNode.FullPath);
        
		foreach (DirectoryInfo dirItem in dir.GetDirectories())
		{
			TreeNode newNode = new TreeNode(dirItem.Name);
			dirNode.Nodes.Add(newNode);
			newNode.Nodes.Add("*");
		}
	}

	private void DirectoryTree_Load(object sender, System.EventArgs e)
	{
		TreeNode rootNode = new TreeNode("C:\\");
		treeDirectory.Nodes.Add(rootNode);
		
		Fill(rootNode);
		treeDirectory.Nodes[0].Expand();
	}

	private static void Main()
	{
		Application.Run(new DirectoryTree());
	}
}