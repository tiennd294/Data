namespace Bansachnangcao
{
    partial class frmbansachnc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpinput = new System.Windows.Forms.GroupBox();
            this.grpoutput = new System.Windows.Forms.GroupBox();
            this.grpsummary = new System.Windows.Forms.GroupBox();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.txtextended = new System.Windows.Forms.TextBox();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.txtdiscounted = new System.Windows.Forms.TextBox();
            this.txttnob = new System.Windows.Forms.TextBox();
            this.txttdg = new System.Windows.Forms.TextBox();
            this.txttda = new System.Windows.Forms.TextBox();
            this.txtad = new System.Windows.Forms.TextBox();
            this.lblquantity = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.lblextended = new System.Windows.Forms.Label();
            this.lbldiscount = new System.Windows.Forms.Label();
            this.lbldiscounted = new System.Windows.Forms.Label();
            this.lbltnob = new System.Windows.Forms.Label();
            this.lbltdg = new System.Windows.Forms.Label();
            this.lbltda = new System.Windows.Forms.Label();
            this.lblad = new System.Windows.Forms.Label();
            this.btncalculate = new System.Windows.Forms.Button();
            this.btnclearsale = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.grpinput.SuspendLayout();
            this.grpoutput.SuspendLayout();
            this.grpsummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpinput
            // 
            this.grpinput.Controls.Add(this.lblprice);
            this.grpinput.Controls.Add(this.lbltitle);
            this.grpinput.Controls.Add(this.lblquantity);
            this.grpinput.Controls.Add(this.txtprice);
            this.grpinput.Controls.Add(this.txttitle);
            this.grpinput.Controls.Add(this.txtquantity);
            this.grpinput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpinput.Location = new System.Drawing.Point(36, 25);
            this.grpinput.Name = "grpinput";
            this.grpinput.Size = new System.Drawing.Size(426, 116);
            this.grpinput.TabIndex = 0;
            this.grpinput.TabStop = false;
            this.grpinput.Text = "Input";
            // 
            // grpoutput
            // 
            this.grpoutput.Controls.Add(this.lbldiscounted);
            this.grpoutput.Controls.Add(this.lbldiscount);
            this.grpoutput.Controls.Add(this.lblextended);
            this.grpoutput.Controls.Add(this.txtdiscounted);
            this.grpoutput.Controls.Add(this.txtdiscount);
            this.grpoutput.Controls.Add(this.txtextended);
            this.grpoutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpoutput.Location = new System.Drawing.Point(36, 147);
            this.grpoutput.Name = "grpoutput";
            this.grpoutput.Size = new System.Drawing.Size(426, 116);
            this.grpoutput.TabIndex = 0;
            this.grpoutput.TabStop = false;
            this.grpoutput.Text = "Output";
            // 
            // grpsummary
            // 
            this.grpsummary.Controls.Add(this.lblad);
            this.grpsummary.Controls.Add(this.lbltda);
            this.grpsummary.Controls.Add(this.lbltdg);
            this.grpsummary.Controls.Add(this.lbltnob);
            this.grpsummary.Controls.Add(this.txtad);
            this.grpsummary.Controls.Add(this.txttda);
            this.grpsummary.Controls.Add(this.txttdg);
            this.grpsummary.Controls.Add(this.txttnob);
            this.grpsummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpsummary.Location = new System.Drawing.Point(36, 269);
            this.grpsummary.Name = "grpsummary";
            this.grpsummary.Size = new System.Drawing.Size(426, 134);
            this.grpsummary.TabIndex = 0;
            this.grpsummary.TabStop = false;
            this.grpsummary.Text = "Summary";
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(155, 20);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(248, 23);
            this.txtquantity.TabIndex = 0;
            this.txtquantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txttitle
            // 
            this.txttitle.Location = new System.Drawing.Point(155, 46);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(248, 23);
            this.txttitle.TabIndex = 0;
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(155, 72);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(248, 23);
            this.txtprice.TabIndex = 0;
            this.txtprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtextended
            // 
            this.txtextended.Enabled = false;
            this.txtextended.Location = new System.Drawing.Point(155, 22);
            this.txtextended.Name = "txtextended";
            this.txtextended.Size = new System.Drawing.Size(248, 23);
            this.txtextended.TabIndex = 0;
            this.txtextended.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtdiscount
            // 
            this.txtdiscount.Enabled = false;
            this.txtdiscount.Location = new System.Drawing.Point(155, 48);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(248, 23);
            this.txtdiscount.TabIndex = 0;
            this.txtdiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtdiscounted
            // 
            this.txtdiscounted.Enabled = false;
            this.txtdiscounted.Location = new System.Drawing.Point(155, 77);
            this.txtdiscounted.Name = "txtdiscounted";
            this.txtdiscounted.Size = new System.Drawing.Size(248, 23);
            this.txtdiscounted.TabIndex = 0;
            this.txtdiscounted.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txttnob
            // 
            this.txttnob.Enabled = false;
            this.txttnob.Location = new System.Drawing.Point(189, 19);
            this.txttnob.Name = "txttnob";
            this.txttnob.Size = new System.Drawing.Size(214, 23);
            this.txttnob.TabIndex = 0;
            this.txttnob.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txttdg
            // 
            this.txttdg.Enabled = false;
            this.txttdg.Location = new System.Drawing.Point(189, 45);
            this.txttdg.Name = "txttdg";
            this.txttdg.Size = new System.Drawing.Size(214, 23);
            this.txttdg.TabIndex = 0;
            this.txttdg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txttda
            // 
            this.txttda.Enabled = false;
            this.txttda.Location = new System.Drawing.Point(189, 71);
            this.txttda.Name = "txttda";
            this.txttda.Size = new System.Drawing.Size(214, 23);
            this.txttda.TabIndex = 0;
            this.txttda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtad
            // 
            this.txtad.Enabled = false;
            this.txtad.Location = new System.Drawing.Point(189, 97);
            this.txtad.Name = "txtad";
            this.txtad.Size = new System.Drawing.Size(214, 23);
            this.txtad.TabIndex = 0;
            this.txtad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblquantity
            // 
            this.lblquantity.AutoSize = true;
            this.lblquantity.Location = new System.Drawing.Point(7, 23);
            this.lblquantity.Name = "lblquantity";
            this.lblquantity.Size = new System.Drawing.Size(61, 17);
            this.lblquantity.TabIndex = 1;
            this.lblquantity.Text = "Quantity";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Location = new System.Drawing.Point(7, 49);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(35, 17);
            this.lbltitle.TabIndex = 1;
            this.lbltitle.Text = "Title";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Location = new System.Drawing.Point(6, 75);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(40, 17);
            this.lblprice.TabIndex = 1;
            this.lblprice.Text = "Price";
            // 
            // lblextended
            // 
            this.lblextended.AutoSize = true;
            this.lblextended.Location = new System.Drawing.Point(7, 25);
            this.lblextended.Name = "lblextended";
            this.lblextended.Size = new System.Drawing.Size(103, 17);
            this.lblextended.TabIndex = 1;
            this.lblextended.Text = "Extended Price";
            // 
            // lbldiscount
            // 
            this.lbldiscount.AutoSize = true;
            this.lbldiscount.Location = new System.Drawing.Point(7, 51);
            this.lbldiscount.Name = "lbldiscount";
            this.lbldiscount.Size = new System.Drawing.Size(95, 17);
            this.lbldiscount.TabIndex = 1;
            this.lbldiscount.Text = "15% Discount";
            // 
            // lbldiscounted
            // 
            this.lbldiscounted.AutoSize = true;
            this.lbldiscounted.Location = new System.Drawing.Point(7, 80);
            this.lbldiscounted.Name = "lbldiscounted";
            this.lbldiscounted.Size = new System.Drawing.Size(115, 17);
            this.lbldiscounted.TabIndex = 1;
            this.lbldiscounted.Text = "Discounted Price";
            // 
            // lbltnob
            // 
            this.lbltnob.AutoSize = true;
            this.lbltnob.Location = new System.Drawing.Point(7, 22);
            this.lbltnob.Name = "lbltnob";
            this.lbltnob.Size = new System.Drawing.Size(156, 17);
            this.lbltnob.TabIndex = 1;
            this.lbltnob.Text = "Total Number Of Books";
            // 
            // lbltdg
            // 
            this.lbltdg.AutoSize = true;
            this.lbltdg.Location = new System.Drawing.Point(7, 48);
            this.lbltdg.Name = "lbltdg";
            this.lbltdg.Size = new System.Drawing.Size(140, 17);
            this.lbltdg.TabIndex = 1;
            this.lbltdg.Text = "Total Discount Given";
            // 
            // lbltda
            // 
            this.lbltda.AutoSize = true;
            this.lbltda.Location = new System.Drawing.Point(7, 74);
            this.lbltda.Name = "lbltda";
            this.lbltda.Size = new System.Drawing.Size(167, 17);
            this.lbltda.TabIndex = 1;
            this.lbltda.Text = "Total Discounted Amount";
            // 
            // lblad
            // 
            this.lblad.AutoSize = true;
            this.lblad.Location = new System.Drawing.Point(7, 100);
            this.lblad.Name = "lblad";
            this.lblad.Size = new System.Drawing.Size(120, 17);
            this.lblad.TabIndex = 1;
            this.lblad.Text = "Average Discount";
            // 
            // btncalculate
            // 
            this.btncalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.Location = new System.Drawing.Point(36, 424);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(85, 27);
            this.btncalculate.TabIndex = 1;
            this.btncalculate.Text = "&Calculate";
            this.btncalculate.UseVisualStyleBackColor = true;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // btnclearsale
            // 
            this.btnclearsale.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclearsale.Location = new System.Drawing.Point(143, 424);
            this.btnclearsale.Name = "btnclearsale";
            this.btnclearsale.Size = new System.Drawing.Size(85, 27);
            this.btnclearsale.TabIndex = 1;
            this.btnclearsale.Text = "Clear Sale";
            this.btnclearsale.UseVisualStyleBackColor = true;
            this.btnclearsale.Click += new System.EventHandler(this.btnclearsale_Click);
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(377, 424);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(85, 27);
            this.btnexit.TabIndex = 1;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // frmbansachnc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 485);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnclearsale);
            this.Controls.Add(this.btncalculate);
            this.Controls.Add(this.grpsummary);
            this.Controls.Add(this.grpoutput);
            this.Controls.Add(this.grpinput);
            this.Name = "frmbansachnc";
            this.Text = "Ban Sach Luyen Bien";
            this.grpinput.ResumeLayout(false);
            this.grpinput.PerformLayout();
            this.grpoutput.ResumeLayout(false);
            this.grpoutput.PerformLayout();
            this.grpsummary.ResumeLayout(false);
            this.grpsummary.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpinput;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Label lblquantity;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.GroupBox grpoutput;
        private System.Windows.Forms.Label lbldiscounted;
        private System.Windows.Forms.Label lbldiscount;
        private System.Windows.Forms.Label lblextended;
        private System.Windows.Forms.TextBox txtdiscounted;
        private System.Windows.Forms.TextBox txtdiscount;
        private System.Windows.Forms.TextBox txtextended;
        private System.Windows.Forms.GroupBox grpsummary;
        private System.Windows.Forms.Label lblad;
        private System.Windows.Forms.Label lbltda;
        private System.Windows.Forms.Label lbltdg;
        private System.Windows.Forms.Label lbltnob;
        private System.Windows.Forms.TextBox txtad;
        private System.Windows.Forms.TextBox txttda;
        private System.Windows.Forms.TextBox txttdg;
        private System.Windows.Forms.TextBox txttnob;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.Button btnclearsale;
        private System.Windows.Forms.Button btnexit;
    }
}

