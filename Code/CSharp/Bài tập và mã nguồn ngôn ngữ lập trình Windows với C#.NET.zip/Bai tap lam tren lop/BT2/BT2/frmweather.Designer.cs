namespace BT2
{
    partial class frmweather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.grpchoose = new System.Windows.Forms.GroupBox();
            this.radsunny = new System.Windows.Forms.RadioButton();
            this.radsnowy = new System.Windows.Forms.RadioButton();
            this.radrainy = new System.Windows.Forms.RadioButton();
            this.radcloudy = new System.Windows.Forms.RadioButton();
            this.lbldisplay = new System.Windows.Forms.Label();
            this.btnprint = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.picsunny = new System.Windows.Forms.PictureBox();
            this.picsnowy = new System.Windows.Forms.PictureBox();
            this.picrainy = new System.Windows.Forms.PictureBox();
            this.piccloudy = new System.Windows.Forms.PictureBox();
            this.grpchoose.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsunny)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picsnowy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picrainy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccloudy)).BeginInit();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BackColor = System.Drawing.Color.Maroon;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblname.Location = new System.Drawing.Point(19, 25);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(145, 15);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Enter your name here";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(173, 25);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(191, 20);
            this.txtname.TabIndex = 1;
            // 
            // grpchoose
            // 
            this.grpchoose.Controls.Add(this.radsunny);
            this.grpchoose.Controls.Add(this.radsnowy);
            this.grpchoose.Controls.Add(this.radrainy);
            this.grpchoose.Controls.Add(this.radcloudy);
            this.grpchoose.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.grpchoose.Location = new System.Drawing.Point(19, 62);
            this.grpchoose.Name = "grpchoose";
            this.grpchoose.Size = new System.Drawing.Size(110, 147);
            this.grpchoose.TabIndex = 2;
            this.grpchoose.TabStop = false;
            this.grpchoose.Text = "Choose";
            // 
            // radsunny
            // 
            this.radsunny.AutoSize = true;
            this.radsunny.Location = new System.Drawing.Point(22, 108);
            this.radsunny.Name = "radsunny";
            this.radsunny.Size = new System.Drawing.Size(49, 17);
            this.radsunny.TabIndex = 0;
            this.radsunny.TabStop = true;
            this.radsunny.Text = "S&uny";
            this.radsunny.UseVisualStyleBackColor = true;
            this.radsunny.CheckedChanged += new System.EventHandler(this.radsunny_CheckedChanged);
            // 
            // radsnowy
            // 
            this.radsnowy.AutoSize = true;
            this.radsnowy.Location = new System.Drawing.Point(22, 78);
            this.radsnowy.Name = "radsnowy";
            this.radsnowy.Size = new System.Drawing.Size(57, 17);
            this.radsnowy.TabIndex = 0;
            this.radsnowy.TabStop = true;
            this.radsnowy.Text = "&Snowy";
            this.radsnowy.UseVisualStyleBackColor = true;
            this.radsnowy.CheckedChanged += new System.EventHandler(this.radsnowy_CheckedChanged);
            // 
            // radrainy
            // 
            this.radrainy.AutoSize = true;
            this.radrainy.Location = new System.Drawing.Point(22, 50);
            this.radrainy.Name = "radrainy";
            this.radrainy.Size = new System.Drawing.Size(52, 17);
            this.radrainy.TabIndex = 0;
            this.radrainy.TabStop = true;
            this.radrainy.Text = "&Rainy";
            this.radrainy.UseVisualStyleBackColor = true;
            this.radrainy.CheckedChanged += new System.EventHandler(this.radrainy_CheckedChanged);
            // 
            // radcloudy
            // 
            this.radcloudy.AutoSize = true;
            this.radcloudy.Location = new System.Drawing.Point(22, 20);
            this.radcloudy.Name = "radcloudy";
            this.radcloudy.Size = new System.Drawing.Size(57, 17);
            this.radcloudy.TabIndex = 0;
            this.radcloudy.TabStop = true;
            this.radcloudy.Text = "&Cloudy";
            this.radcloudy.UseVisualStyleBackColor = true;
            this.radcloudy.CheckedChanged += new System.EventHandler(this.radcloudy_CheckedChanged);
            // 
            // lbldisplay
            // 
            this.lbldisplay.BackColor = System.Drawing.SystemColors.InfoText;
            this.lbldisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldisplay.ForeColor = System.Drawing.SystemColors.Info;
            this.lbldisplay.Location = new System.Drawing.Point(19, 221);
            this.lbldisplay.Name = "lbldisplay";
            this.lbldisplay.Size = new System.Drawing.Size(249, 85);
            this.lbldisplay.TabIndex = 3;
            this.lbldisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnprint
            // 
            this.btnprint.ForeColor = System.Drawing.Color.Thistle;
            this.btnprint.Location = new System.Drawing.Point(289, 221);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(75, 34);
            this.btnprint.TabIndex = 4;
            this.btnprint.Text = "&Print";
            this.btnprint.UseVisualStyleBackColor = true;
            // 
            // btnexit
            // 
            this.btnexit.ForeColor = System.Drawing.Color.Thistle;
            this.btnexit.Location = new System.Drawing.Point(289, 265);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(75, 34);
            this.btnexit.TabIndex = 4;
            this.btnexit.Text = "&Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.button2_Click);
            // 
            // picsunny
            // 
            this.picsunny.Image = global::BT2.Properties.Resources.Sunset;
            this.picsunny.Location = new System.Drawing.Point(267, 139);
            this.picsunny.Name = "picsunny";
            this.picsunny.Size = new System.Drawing.Size(97, 70);
            this.picsunny.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picsunny.TabIndex = 5;
            this.picsunny.TabStop = false;
            this.picsunny.Visible = false;
            // 
            // picsnowy
            // 
            this.picsnowy.Image = global::BT2.Properties.Resources.Winter;
            this.picsnowy.Location = new System.Drawing.Point(149, 139);
            this.picsnowy.Name = "picsnowy";
            this.picsnowy.Size = new System.Drawing.Size(97, 70);
            this.picsnowy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picsnowy.TabIndex = 5;
            this.picsnowy.TabStop = false;
            this.picsnowy.Visible = false;
            // 
            // picrainy
            // 
            this.picrainy.Image = global::BT2.Properties.Resources.Water_lilies;
            this.picrainy.Location = new System.Drawing.Point(267, 61);
            this.picrainy.Name = "picrainy";
            this.picrainy.Size = new System.Drawing.Size(97, 70);
            this.picrainy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picrainy.TabIndex = 5;
            this.picrainy.TabStop = false;
            this.picrainy.Visible = false;
            // 
            // piccloudy
            // 
            this.piccloudy.Image = global::BT2.Properties.Resources.Blue_hills;
            this.piccloudy.Location = new System.Drawing.Point(150, 61);
            this.piccloudy.Name = "piccloudy";
            this.piccloudy.Size = new System.Drawing.Size(97, 70);
            this.piccloudy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.piccloudy.TabIndex = 5;
            this.piccloudy.TabStop = false;
            this.piccloudy.Visible = false;
            // 
            // frmweather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(385, 328);
            this.Controls.Add(this.picsunny);
            this.Controls.Add(this.picsnowy);
            this.Controls.Add(this.picrainy);
            this.Controls.Add(this.piccloudy);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnprint);
            this.Controls.Add(this.lbldisplay);
            this.Controls.Add(this.grpchoose);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblname);
            this.Name = "frmweather";
            this.Text = "Weather Report";
            this.grpchoose.ResumeLayout(false);
            this.grpchoose.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picsunny)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picsnowy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picrainy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccloudy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.GroupBox grpchoose;
        private System.Windows.Forms.RadioButton radrainy;
        private System.Windows.Forms.RadioButton radcloudy;
        private System.Windows.Forms.Label lbldisplay;
        private System.Windows.Forms.Button btnprint;
        private System.Windows.Forms.PictureBox piccloudy;
        private System.Windows.Forms.PictureBox picsnowy;
        private System.Windows.Forms.PictureBox picsunny;
        private System.Windows.Forms.PictureBox picrainy;
        private System.Windows.Forms.RadioButton radsunny;
        private System.Windows.Forms.RadioButton radsnowy;
        private System.Windows.Forms.Button btnexit;
    }
}

