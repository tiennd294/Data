using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

public class HitTesting : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	
	public HitTesting()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		// 
		// HitTesting
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(324, 306);
		this.Name = "HitTesting";
		this.Text = "Hit Testing";
		this.Load += new System.EventHandler(this.HitTesting_Load);
		this.Paint += new System.Windows.Forms.PaintEventHandler(this.HitTesting_Paint);
		this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HitTesting_MouseMove);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new HitTesting());
	}

	private GraphicsPath path;
	private Rectangle rectangle;

	private bool inPath = false;
	private bool inRectangle = false;

	Brush highlightBrush = Brushes.HotPink;
	Brush defaultBrush = Brushes.LightBlue;

	private void HitTesting_Load(object sender, System.EventArgs e)
	{
		path = new GraphicsPath();
		path.AddEllipse(10, 10, 100, 60);
		path.AddCurve(new Point[]{new Point(50, 50),new Point(10,33), new Point(80,43)});
		path.AddLine(50, 120, 250, 80);
		path.AddLine(120, 40, 110, 50);
		
		path.CloseFigure();
	
		rectangle = new Rectangle(100, 170, 220, 120);		
	}

	private void HitTesting_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
	{
		Graphics g = e.Graphics;

		if (inPath)
		{
			g.FillPath(highlightBrush, path);
			g.FillRectangle(defaultBrush, rectangle);
		}
		else if (inRectangle)
		{
			g.FillRectangle(highlightBrush, rectangle);
			g.FillPath(defaultBrush, path);
		}
		else
		{
			g.FillPath(defaultBrush, path);
			g.FillRectangle(defaultBrush, rectangle);
		}

		g.DrawPath(Pens.Black, path);
		g.DrawRectangle(Pens.Black, rectangle);
	}


	private void HitTesting_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
	{
		Graphics g = this.CreateGraphics();

		if (rectangle.Contains(e.X, e.Y))
		{
			if (!inRectangle)
			{
				inRectangle = true;
				
				g.FillRectangle(highlightBrush, rectangle);
				g.DrawRectangle(Pens.Black, rectangle);
			}
		}
		else if (inRectangle)
		{
			inRectangle = false;
			
			g.FillRectangle(defaultBrush, rectangle);
			g.DrawRectangle(Pens.Black, rectangle);
		}

		if (path.IsVisible(e.X, e.Y))
		{
			if (!inPath)
			{
				inPath = true;

				g.FillPath(highlightBrush, path);
				g.DrawPath(Pens.Black, path);
			}
		}
		else if (inPath)
		{
			inPath = false;
			
			g.FillPath(defaultBrush, path);
			g.DrawPath(Pens.Black, path);
		}

		g.Dispose();
	}

	
}