using System;

public class DateTimeCreationExample
{
	public static void Main(string[] args) {

        DateTime dt1 = DateTime.Parse("Sep 2004");
        DateTime dt2 = DateTime.Parse("Sun 5 September 2004 14:15:33");
        DateTime dt3 = DateTime.Parse("5,9,04");
        DateTime dt4 = DateTime.Parse("5/9/2004 14:15:33");
        DateTime dt5 = DateTime.Parse("2:15 PM");

        Console.WriteLine(dt1);
        Console.WriteLine(dt2);
        Console.WriteLine(dt3);
        Console.WriteLine(dt4);
        Console.WriteLine(dt5);

        DateTime dt6 = DateTime.ParseExact("2:13:30 PM",
            "h:mm:ss tt", null);

        DateTime dt7 = DateTime.ParseExact(
            "Sun, 05 Sep 2004 14:13:30 GMT",
            "ddd, dd MMM yyyy HH':'mm':'ss 'GMT'", null);

        DateTime dt8 = DateTime.ParseExact("September 03",
            "MMMM dd", null);

		Console.WriteLine(dt6);
		Console.WriteLine(dt7);
		Console.WriteLine(dt8);

		Console.ReadLine();
    }
}
