public class TemperatureChangeEventArgs : System.EventArgs {

    private readonly int oldTemperature, newTemperature;
    
    public TemperatureChangeEventArgs(int oldTemp, int newTemp) {
    
        oldTemperature = oldTemp;
        newTemperature = newTemp;
    }
    
    public int OldTemperature { get { return oldTemperature; } }
    public int NewTemperature { get { return newTemperature; } }
}
           
public delegate void TemperatureEventHandler(Thermostat s, 
    TemperatureChangeEventArgs e);

public class TemperatureChangeObserver {
    
    public TemperatureChangeObserver(Thermostat t) {
        
        t.TemperatureChange += 
            new TemperatureEventHandler(this.TemperatureChange);
    }
        
    public void TemperatureChange(Thermostat sender, 
        TemperatureChangeEventArgs temp) {
            
        System.Console.WriteLine
            ("ChangeObserver: Old={0}, New={1}, Change={2}",
            temp.OldTemperature, temp.NewTemperature, 
            temp.NewTemperature - temp.OldTemperature);
    }
}

public class TemperatureAverageObserver {
    
    private int sum = 0, count = 0;
    
    public TemperatureAverageObserver (Thermostat t) {
        
        t.TemperatureChange += 
            new TemperatureEventHandler(this.TemperatureChange);
    }
        
    public void TemperatureChange(Thermostat sender, 
        TemperatureChangeEventArgs temp) {
            
        count++;
        sum += temp.NewTemperature;
            
        System.Console.WriteLine
            ("AverageObserver: Average={0:F}", (double)sum/(double)count);
    }
}

public class Thermostat {
    
    private int temperature = 0;
    
    public event TemperatureEventHandler TemperatureChange;

    virtual protected void RaiseTemperatureEvent
        (TemperatureChangeEventArgs e) {
        
        if (TemperatureChange != null) {
            
            TemperatureChange(this, e);
        }
    }
        
    public int Temperature {
        
        get { return temperature; }
        
        set {
            TemperatureChangeEventArgs e = 
                new TemperatureChangeEventArgs(temperature, value);
            
            temperature = value;
            
            RaiseTemperatureEvent(e);
        }
    }
        
    public static void Main() {

        Thermostat t = new Thermostat();
        
        new TemperatureChangeObserver(t);
        new TemperatureAverageObserver(t);
        
        do {
            
            System.Console.Write("\n\rEnter current temperature: ");
            
            try {
                t.Temperature = 
                    System.Int32.Parse(System.Console.ReadLine());
                
            } catch (System.Exception) {
                System.Console.WriteLine("Terminating ObserverExample.");
                return;
            }
        } while (true);
    }
}
