Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class Form11
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Public Sub hienthi()
			Dim cmd1 As New SqlCommand()
			Dim kn1 As New ketnoi()
			kn1.ket_noi()
			cmd1.Connection = kn1.con
			Dim da As New SqlDataAdapter("SELECT MaKH FROM KhachHang", kn1.con)
			Dim ds As New DataSet()
			da.Fill(ds)
			Dim dt As New DataTable()
			da.Fill(dt)
			comboBox1.DataSource = ds.Tables(0)
			comboBox1.DisplayMember = "MaKH"

		End Sub

		Public Sub loaddata2()
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM HoaDon WHERE MaKH='" & comboBox1.Text.ToString() & "'", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				' Đưa dữ liệu lên DataGridView
				dataGridView1.DataSource = dt
				' Thay đổi độ rộng cột


				dataGridView1.AutoResizeColumns()
			Catch
			End Try
		End Sub

		Public Sub loaddata()
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT Count(*) FROM HoaDon WHERE MaKH='" & comboBox1.Text.ToString() & "'", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				' Đưa dữ liệu lên textbox1


				textBox1.Text = dt.Rows(0)(0).ToString()
			Catch
			End Try
		End Sub


		Private Sub Form11_Load(sender As Object, e As EventArgs)
			hienthi()
		End Sub

		Private Sub button1_Click(sender As Object, e As EventArgs)
			loaddata2()
			loaddata()
		End Sub

		Private Sub button2_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub
	End Class
End Namespace
