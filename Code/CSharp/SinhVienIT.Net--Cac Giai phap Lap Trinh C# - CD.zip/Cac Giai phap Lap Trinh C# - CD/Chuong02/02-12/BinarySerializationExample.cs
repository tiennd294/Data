using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;

public class BinarySerializationExample {

    public static void Main() {
        
        ArrayList people = new ArrayList();
        people.Add("Phuong");
        people.Add("Phong");                    
        people.Add("Nam");

        FileStream str = File.Create("people.bin");
        BinaryFormatter bf = new BinaryFormatter();
        bf.Serialize(str, people);
        str.Close();
        
        str = File.OpenRead("people.bin");
        bf = new BinaryFormatter();
        people = (ArrayList)bf.Deserialize(str);
        str.Close();
        
        foreach (string s in people) {
            
            System.Console.WriteLine(s);
        }

		System.Console.ReadLine();
    }   
}