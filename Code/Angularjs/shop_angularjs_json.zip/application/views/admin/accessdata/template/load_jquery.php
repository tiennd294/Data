<link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/bootstrap-responsive.min.css" /> 
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/maruti-style.css" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/maruti-media.css" class="skin-color" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/select2.css" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/jquery.gritter.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/colorpicker.css" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/template/css/uniform.css" />
    <link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/styles/animate.min.css" />
    
        <script src="<?php echo public_url();?>/admin/accessdata/scripts/angular.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.ui.custom.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquerymenu.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.validate.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.uniform.js" type="text/javascript"></script> 
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/select2.min.js" type="text/javascript"></script> 
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/maruti.js" type="text/javascript"></script> 
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.ui.custom.js" type="text/javascript"></script> 
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/bootstrap-colorpicker.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/bootstrap-datepicker.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/maruti.form_common.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.peity.min.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.gritter.min.js" type="text/javascript"></script>
        <!-- <script src="<?php echo public_url();?>/admin/accessdata/template/js/maruti.tables.js" type="text/javascript"></script> -->
        <script src="<?php echo public_url();?>/admin/accessdata/scripts/seach.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/scripts/paging.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/ckeditor/ckeditor.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/ckfinder/ckfinder.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.form.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/jquery.twbsPagination.min.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/template/js/dirPagination.js" type="text/javascript"></script>

