using System;
using System.Runtime.Remoting;
using System.Data;
using RemoteObject;

namespace Client
{
	public class Client
	{
		private static void Main()
		{
			RemotingConfiguration.Configure("Client.exe.config");
			
			ProductsDB proxy = new ProductsDB();
        
			Console.WriteLine("Object executing in: " + proxy.GetHostLocation());

			DataTable dt = proxy.GetProducts();
        
			foreach (DataRow row in dt.Rows)
			{
				Console.WriteLine(row[1]);
			}
			
			Console.ReadLine();
		}
	}
}
