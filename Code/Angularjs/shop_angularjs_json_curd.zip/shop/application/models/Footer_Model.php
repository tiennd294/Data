<?php
Class Footer_Model extends MY_Model
{
    var $table = 'footer';
    var $key = 'Idft';
}