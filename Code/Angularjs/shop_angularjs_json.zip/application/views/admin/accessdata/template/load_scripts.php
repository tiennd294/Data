<link rel="stylesheet" href="<?php echo public_url();?>/admin/accessdata/styles/users_styles.css" />

        <script src="<?php echo public_url();?>/admin/accessdata/scripts/ajax_jquery.js" type="text/javascript"></script>
        <script src="<?php echo public_url();?>/admin/accessdata/scripts/app.js" type="text/javascript"></script>
		
		
		