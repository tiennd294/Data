<script type='text/javascript'>
    $(function(){
    $('#atextdata1Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#atextdata1').val(fileUrl.replace('/test/admin',''));
            $('#atextdata1').attr('readonly', true);
        };
        ckfinder.popup();
    })

    $('#etextdata1Brows').click(function(){
        var ckfinder=new CKFinder();
        ckfinder.selectActionFunction=function(fileUrl){
            $('#etextdata1').val(fileUrl.replace('/test/admin',''));
            $('#etextdata1').attr('readonly', true);
        };
        ckfinder.popup();
    })

    });
</script> 
<?php
        $this->load->view('admin/accessdata/template/messenger');
?>
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                        <div class='table-action'>
                            <a href='#' class='btnadd tip-top' data-original-title='Add'><i class='icon-plus'></i> Thêm mới</a>
                        </div>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã ID</th>  
                                    <th>Link</th>  
                                    <th>ID sản phẩm</th>  
                                    <th>Hình ảnh</th> 
                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                $i=0;
                                foreach ($tblimg as $row):
                                    $i++;
                            ?>
                                <tr class='gradeU items_' id='<?php echo $row->Idi; ?>'>
                                    <td><?php echo $row->Idi; ?></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Urllink; ?></div></td>
                                    <td><?php echo $row->Idp; ?></td>
                                    <td><img src="<?php echo base_url().$row->Urllink; ?>" style='width: 55px;height: 55px;' alt=""></td>
                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Thêm mới</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='<?php echo admin_url();?>/productsima/Add'>


									<div class='control-group'>
										<label class='control-label'>Link :</label>
										<div class='controls'>
                                            <input id='atextdata1'  name='atextdata1' type='text' class='span3 atextdata1' placeholder='Link' />
                                            <button id='atextdata1Brows' class='atextdata1Brows'>...</button>
										</div>
									</div>

								<div class='control-group'>
									<label class='control-label'>ID sản phẩm</label>
									<div class='controls '>
									     <select name='atextdata2' id='atextdata2'>
 									         <option>ID sản phẩm</option>
									     </select>
									</div>
								</div>

								<div class='form-actions'   align='center'>
									<button id='btnadd' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	<div class='frmedit' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-pencil'></i>
									</span>
									<h5>Cập nhật</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form3' class='form-horizontal' name='form3' method='post' action='<?php echo admin_url();?>/productsima/Edit'>
								<div class='control-group'>
										<label class='control-label'>Mã ID :</label>
										<div class='controls'><input id='etextid' name='etextid' type='text' class='span20 etextid'/></div>
								</div>
									<div class='control-group'>
										<label class='control-label'>Link :</label>
										<div class='controls'>
                                            <input id='etextdata1'  name='etextdata1' type='text' class='span3 etextdata1' placeholder='Link' />
                                            <button id='etextdata1Brows' class='etextdata1Brows'>...</button>
										</div>
									</div>

								<div class='control-group'>
									<label class='control-label'>ID sản phẩm</label>
									<div class='controls '>
									     <select name='etextdata2' id='etextdata2'>
 									         <option>ID sản phẩm</option>
									     </select>
									</div>
								</div>

								<div class='form-actions'   align='center'>
									<button id='btnedit' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>







	<div class='frmdelete' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-trash'></i>
									</span>
									<h5>Xóa</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form2' class='form-horizontal' name='form2' method='post' action='<?php echo admin_url();?>/productsima/Delete'>
								<div class='controls'>                                   <label id='Label2' class='control-label'> Bạn có chắc chắn muốn xóa không?</label>                               </div>                               <div class='control-group' style='padding-left:5px; padding-top:5px;'>                                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:13px;height:13px;overflow:auto;'>                                        <div class='control-group'>                                               <label class='control-label'>ID dstaikhoan:</label>                                           <div class='controls'>                                               <input id='textid' class='textid' name='textid' type='text' class='span20' />                                           </div>                                       </div>                                   </div>                               </div>								<div class='form-actions  txtc'   align='center'>
									<button id='btndelete' class='btn btnyes btn-success'>Có</button>
									<button id='btnhuy'  class='btn btn-success btncancel' style='margin-left:10px'> Không</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
