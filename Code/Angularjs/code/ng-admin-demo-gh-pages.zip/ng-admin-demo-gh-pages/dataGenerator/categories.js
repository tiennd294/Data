export default function(db) {
    return [
        { id: 0, name: 'abstract' },
        { id: 1, name: 'animals' },
        { id: 2, name: 'business' },
        { id: 3, name: 'cats' },
        { id: 4, name: 'city' },
        { id: 5, name: 'food' },
        { id: 6, name: 'nightlife' },
        { id: 7, name: 'fashion' },
        { id: 8, name: 'people' },
        { id: 9, name: 'nature' },
        { id: 10, name: 'sports' },
        { id: 11, name: 'technics' },
        { id: 12, name: 'transport' },
    ];
}
