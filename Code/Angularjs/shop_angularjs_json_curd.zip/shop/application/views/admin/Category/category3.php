
<script type='text/javascript'>
      
     function AddCategory($Parentid)
     {

        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Classify:$('.aClassify'+$Parentid).val(),
            Parentid:$('.aParentid'+$Parentid).val(),
            Name:$('.aName'+$Parentid).val(),
            Linkurl:$('.aLinkurl'+$Parentid).val(),
            Display:$('.aDisplay'+$Parentid).val(),
            Startus:$('.aStartus'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '?c=category&a=add',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                              $('#result').html(result);
                              window.location.reload();
                              //alert('Successfuly!');
                         }
                    });
     }


      function Add2Category($Parentid)
     {
        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Classify:$('.a2Classify'+$Parentid).val(),
            Parentid:$('.a2Parentid'+$Parentid).val(),
            Name:$('.a2Name'+$Parentid).val(),
            Linkurl:$('.a2Linkurl'+$Parentid).val(),
            Display:$('.a2Display'+$Parentid).val(),
            Startus:$('.a2Startus'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '?c=category&a=add',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                              $('#result').html(result);
                              window.location.reload();
                              //alert('Successfuly!');
                         }
                    });
     }

    function EditCategory($Parentid)
    {
        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Idc:$('.eIdc'+$Parentid).val(),
            Name:$('.eName'+$Parentid).val(),
            Linkurl:$('.eLinkurl'+$Parentid).val(),
            Display:$('.eDisplay'+$Parentid).val(),
            Startus:$('.eStartus'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '?c=category&a=edit',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                              $('#result').html(result);
                              window.location.reload();
                              //alert('Successfuly!');
                         }
                    });
    }

    function DeleteCategory($Parentid)
    {
        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Idc:$('.dIdc'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '?c=category&a=delete',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                              $('#result').html(result);
                              window.location.reload();
                         }
                    });
    }


</script> 


    
<div class="container-fluid" >
            
    <div class="row-fluid">
        <div class="span12">
    <?php

    if ( ! defined('PATH_SYSTEM')) die ('Bad requested!');
    function connect()
    {
            $link = mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die(mysql_error());
            $db = mysql_select_db(DB_DATA,$link)or die(mysql_error());
    }


        function testmenu($Id)
        {
            connect();
            $sqlmy=mysql_query("select count(*) from category where Parentid='$Id'");
            $data=mysql_fetch_array($sqlmy);
            if($data[0]==0)
            {
                return "Khong";
            }
            else return "Co";
        }
        
        function Recursive($Idcd)
        {
            connect();
            $tv=mysql_query("select * from category where Parentid='$Idcd'");
              
            while($tv2=mysql_fetch_array($tv))
            {
    ?>
                 <div class="widget-title">
                                <a href=".add<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus addc"></i></span>
                                </a>
                                <a href=".category<?php echo $tv2["Idc"]; ?>" id='<?php echo $tv2["Idc"]; ?>' data-toggle="collapse">
                                <?php 
                                    if ($tv2["Startus"]=='on'){
                                ?>
                                    <span class="icon"><i class="icon-ok"></i></span>
                                <?php 
                                    }else {
                                ?>
                                    <span class="icon"><i class="icon-lock"></i></span>
                                <?php 
                                    }
                                ?>
                                    <h5><?php echo $tv2["Name"]; ?></h5>
                                </a>
                                <a href=".addnew<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus"></i></span>
                                </a>
                                <a href=".edit<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-pencil"></i></span>
                                </a>
                                <a href=".delete<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-trash"></i></span>
                                </a>
                            </div>
                            
                            <div class="collapse add<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    
                                    <h5>Thêm danh mục cùng hạng mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                    <label class='control-label'>Classify :</label>
                                            <input  name='aClassify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aClassify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            
                                            <label class='control-label'>Parent id :</label>
                                            <input name='aParentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aParentid<?php echo $tv2["Idc"]; ?>' placeholder='Parent id' value='<?php echo $tv2["Parentid"]; ?>' readonly />
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input name='aName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input name='aLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input name='aDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                           

                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select name='aStartus<?php echo $tv2["Idc"]; ?>' class='aStartus<?php echo $tv2["Idc"]; ?> atextdata3cb'  id='aStartus<?php echo $tv2["Idc"]; ?>'>
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>

                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="AddCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse addnew<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Thêm danh mục trong hạng mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='a2Classify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Classify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>'  readonly/>
                                            <label class='control-label'>Parent id :</label>
                                            <input  name='a2Parentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Parentid<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly />
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='a2Name<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Name<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='a2Linkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Linkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='addtextthutu<?php echo $tv2["Idc"]; ?>' type='text' class='span5 addtextthutu<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                            
                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select name='a2Startus<?php echo $tv2["Idc"]; ?>' class='a2Startus<?php echo $tv2["Idc"]; ?> atextdata3cb' >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="Add2Category(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse edit<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Sửa danh mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Mã danh mục :</label>
                                            <input  name='eIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eIdc<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='eName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục'  value='<?php echo $tv2["Name"]; ?>' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='eLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link'  value='<?php echo $tv2["Linkurl"]; ?>' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='a2Display<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Display<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Display"]; ?>' />
                                            
                                            
                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select  name='eStartus<?php echo $tv2["Idc"]; ?>' class='eStartus<?php echo $tv2["Idc"]; ?> atextdata3cb'  >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="EditCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse delete<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    <h5>Xóa danh mục :</h5>
                                    <label class='control-label'>Bạn có chắc chắn muốn xóa không?</label>
                                         <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">   
                                            <input  name='dIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 dIdc<?php echo $tv2["Idc"]; ?>' placeholder='id'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                         </div>   
                                            <label class='control-label'></label>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="DeleteCategory(<?php echo $tv2['Idc']; ?>)">Delete</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>
    <?php
                    $menucon=testmenu($tv2["Idc"]);
                    if($menucon=="Co")
                    {
    ?>
                        <div class="collapse category<?php echo $tv2["Idc"]; ?>">
                        <div class="widget-content">
                            <div class="widget-box collapsible">
                                <?php Recursive($tv2["Idc"]);?>
                            </div>
                        </div>
                    </div>
    <?php
                    }
                    ?>
                        
                    <?php   
                
            }
        }
    ?>
<div class="widget-box collapsible">
    <div class="widget-title">
        <a href=".Products" id='1' data-toggle="collapse">
        <span class="icon"><i class="icon-star"></i></span>
            <h5>Sản phẩm</h5>
        </a>
        </div>
    <div class="collapse Products">
    <div class="widget-content">
        <div class="widget-box collapsible">
    <?php

    connect();
        $tv=mysql_query("select * from category where Parentid=0 and Classify=1 ORDER BY Display ASC");
        
        while($tv2=mysql_fetch_array($tv))
        {
    ?>
            
                            

                            <div class="widget-title">
                                <a href=".add<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus addc"></i></span>
                                </a>
                                <a href=".category<?php echo $tv2["Idc"]; ?>" id='<?php echo $tv2["Idc"]; ?>' data-toggle="collapse">
                                <?php 
                                    if ($tv2["Startus"]=='on'){
                                ?>
                                    <span class="icon"><i class="icon-ok"></i></span>
                                <?php 
                                    }else {
                                ?>
                                    <span class="icon"><i class="icon-lock"></i></span>
                                <?php 
                                    }
                                ?>
                                    <h5><?php echo $tv2["Name"]; ?></h5>
                                </a>
                                <a href=".addnew<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus"></i></span>
                                </a>
                                <a href=".edit<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-pencil"></i></span>
                                </a>
                                <a href=".delete<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-trash"></i></span>
                                </a>
                            </div>
                            
                            <div class="collapse add<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    
                                    <h5>Thêm danh mục cùng hạng mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='aClassify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aClassify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            <label class='control-label'>Parent id :</label>
                                            <input name='aParentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aParentid<?php echo $tv2["Idc"]; ?>' placeholder='Parent id' value='<?php echo $tv2["Parentid"]; ?>' readonly/>
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input name='aName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input name='aLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input name='aDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                           
                                             <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select  name='aStartus<?php echo $tv2["Idc"]; ?>' class='aStartus<?php echo $tv2["Idc"]; ?> atextdata3cb'  >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="AddCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse addnew<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Thêm danh mục trong hạng mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='a2Classify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Classify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            <label class='control-label'>Parent id :</label>
                                            <input  name='a2Parentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Parentid<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly />
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='a2Name<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Name<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='a2Linkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Linkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='addtextthutu<?php echo $tv2["Idc"]; ?>' type='text' class='span5 addtextthutu<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                           
                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select   name='a2Startus<?php echo $tv2["Idc"]; ?>' class='a2Startus<?php echo $tv2["Idc"]; ?> atextdata3cb'  >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="Add2Category(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse edit<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Sửa danh mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Mã danh mục :</label>
                                            <input  name='eIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eIdc<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                    </div>        
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='eName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục'  value='<?php echo $tv2["Name"]; ?>' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='eLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link'  value='<?php echo $tv2["Linkurl"]; ?>' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='eDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Display"]; ?>' />
                                            
                                            
                                             <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select  name='eStartus<?php echo $tv2["Idc"]; ?>' class='eStartus<?php echo $tv2["Idc"]; ?> atextdata3cb' >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success' onclick="EditCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse delete<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    <h5>Xóa danh mục :</h5>
                                        <label class='control-label'>Bạn có chắc chắn muốn xóa không?</label>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <input  name='dIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 dIdc<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                    </div>
                                            <label class='control-label'></label>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="DeleteCategory(<?php echo $tv2['Idc']; ?>)">Delete</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>
                        


    <?php
            
                $menucon=testmenu($tv2["Idc"]);
                if($menucon=="Co")
                {
    ?>
                    <div class="collapse category<?php echo $tv2["Idc"]; ?>">
                        <div class="widget-content">
                            <div class="widget-box collapsible">
                                <?php Recursive($tv2["Idc"]);?>
                            </div>
                        </div>
                    </div>
     <?php
                }
     ?> 
                       
     <?php 
        }
       
    ?> 
    </div>
    </div>
</div>
                            
  <div class="widget-title">
   <a href=".News" id='1' data-toggle="collapse">
    <span class="icon"><i class="icon-star"></i></span>
    <h5>Tin tức</h5>
    </a>
    </div>
    <div class="collapse News">
     <div class="widget-content">




 <div class="widget-box collapsible">
    <?php

    connect();
        $tv=mysql_query("select * from category where Parentid=0 and Classify=2 ORDER BY Display ASC");
        
        while($tv2=mysql_fetch_array($tv))
        {
    ?>
            
                            

                            <div class="widget-title">
                                <a href=".add<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus addc"></i></span>
                                </a>
                                <a href=".category<?php echo $tv2["Idc"]; ?>" id='<?php echo $tv2["Idc"]; ?>' data-toggle="collapse">
                                <?php 
                                    if ($tv2["Startus"]=='on'){
                                ?>
                                    <span class="icon"><i class="icon-ok"></i></span>
                                <?php 
                                    }else {
                                ?>
                                    <span class="icon"><i class="icon-lock"></i></span>
                                <?php 
                                    }
                                ?>
                                    <h5><?php echo $tv2["Name"]; ?></h5>
                                </a>
                                <a href=".addnew<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus"></i></span>
                                </a>
                                <a href=".edit<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-pencil"></i></span>
                                </a>
                                <a href=".delete<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-trash"></i></span>
                                </a>
                            </div>
                            
                            <div class="collapse add<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    
                                    <h5>Thêm danh mục cùng hạng mục :</h5>
                                        <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='aClassify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aClassify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            
                                            <label class='control-label'>Parent id :</label>
                                            <input name='aParentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aParentid<?php echo $tv2["Idc"]; ?>' placeholder='Parent id' value='<?php echo $tv2["Parentid"]; ?>' readonly/>
                                        </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input name='aName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input name='aLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input name='aDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                           
                                             <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select name='aStartus<?php echo $tv2["Idc"]; ?>' class='aStartus<?php echo $tv2["Idc"]; ?> atextdata3cb'  >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="AddCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse addnew<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Thêm danh mục trong hạng mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='a2Classify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Classify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            
                                            <label class='control-label'>Parent id :</label>
                                            <input  name='a2Parentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Parentid<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly  />
                                     </div>       
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='a2Name<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Name<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='a2Linkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Linkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='addtextthutu<?php echo $tv2["Idc"]; ?>' type='text' class='span5 addtextthutu<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls'>
                                                    <label><input type='checkbox' name='a2Startus<?php echo $tv2["Idc"]; ?>' class='a2Startus<?php echo $tv2["Idc"]; ?> atextdata3cb' />On/Off</label>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="Add2Category(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse edit<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Sửa danh mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Mã danh mục :</label>
                                            <input  name='eIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eIdc<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='eName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục'  value='<?php echo $tv2["Name"]; ?>' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='eLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link'  value='<?php echo $tv2["Linkurl"]; ?>' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='eDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Display"]; ?>' />
                                            
                                            
                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select name='eStartus<?php echo $tv2["Idc"]; ?>' class='eStartus<?php echo $tv2["Idc"]; ?> atextdata3cb'   >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success' onclick="EditCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse delete<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    <h5>Xóa danh mục :</h5>
                                        <label class='control-label'>Bạn có chắc chắn muốn xóa không?</label>
                                        <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">    
                                            <input  name='dIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 dIdc<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                        </div>    
                                            <label class='control-label'></label>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="DeleteCategory(<?php echo $tv2['Idc']; ?>)">Delete</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>
                        


    <?php
            
                $menucon=testmenu($tv2["Idc"]);
                if($menucon=="Co")
                {
    ?>
                    <div class="collapse category<?php echo $tv2["Idc"]; ?>">
                        <div class="widget-content">
                            <div class="widget-box collapsible">
                                <?php Recursive($tv2["Idc"]);?>
                            </div>
                        </div>
                    </div>
     <?php
                }
     ?> 
                       
     <?php 
        }
       
    ?> 
    </div>


</div>
 </div>










   <div class="widget-title">
   <a href=".footer" id='1' data-toggle="collapse">
    <span class="icon"><i class="icon-star"></i></span>
    <h5>Footer</h5>
    </a>
    </div>




    <div class="collapse footer">
     <div class="widget-content">




 <div class="widget-box collapsible">
    <?php

    connect();
        $tv=mysql_query("select * from category where Parentid=0 and Classify=3 ORDER BY Display ASC");
        
        while($tv2=mysql_fetch_array($tv))
        {


    ?>
            
                            

                            <div class="widget-title">
                                <a href=".add<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus addc"></i></span>
                                </a>
                                <a href=".category<?php echo $tv2["Idc"]; ?>" id='<?php echo $tv2["Idc"]; ?>' data-toggle="collapse">
                                <?php 
                                    if ($tv2["Startus"]=='on'){
                                ?>
                                    <span class="icon"><i class="icon-ok"></i></span>
                                <?php 
                                    }else {
                                ?>
                                    <span class="icon"><i class="icon-lock"></i></span>
                                <?php 
                                    }
                                ?>
                                    <h5><?php echo $tv2["Name"]; ?></h5>
                                </a>
                                <a href=".addnew<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-plus"></i></span>
                                </a>
                                <a href=".edit<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-pencil"></i></span>
                                </a>
                                <a href=".delete<?php echo $tv2["Idc"]; ?>" data-toggle="collapse">
                                    <span class="icon"><i class="icon-trash"></i></span>
                                </a>
                            </div>

                             

                             <div class="collapse add<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    
                                    <h5>Thêm danh mục cùng hạng mục :</h5>
                                        <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='aClassify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aClassify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            
                                            <label class='control-label'>Parent id :</label>
                                            <input name='aParentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aParentid<?php echo $tv2["Idc"]; ?>' placeholder='Parent id' value='<?php echo $tv2["Parentid"]; ?>' readonly/>
                                        </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input name='aName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input name='aLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input name='aDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 aDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                            
                                             <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select name='aStartus<?php echo $tv2["Idc"]; ?>' class='aStartus<?php echo $tv2["Idc"]; ?> atextdata3cb' >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>'   onclick="AddCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse addnew<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Thêm danh mục trong hạng mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Classify :</label>
                                            <input  name='a2Classify<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Classify<?php echo $tv2["Idc"]; ?>' placeholder='Classify'  value='<?php echo $tv2["Classify"]; ?>' readonly />
                                            
                                            <label class='control-label'>Parent id :</label>
                                            <input  name='a2Parentid<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Parentid<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly  />
                                     </div>       
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='a2Name<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Name<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='a2Linkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 a2Linkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='addtextthutu<?php echo $tv2["Idc"]; ?>' type='text' class='span5 addtextthutu<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự' />
                                            
                                           

                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select name='a2Startus<?php echo $tv2["Idc"]; ?>' class='a2Startus<?php echo $tv2["Idc"]; ?> atextdata3cb'>
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="Add2Category(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse edit<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                <h5>Sửa danh mục :</h5>
                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
                                            <label class='control-label'>Mã danh mục :</label>
                                            <input  name='eIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eIdc<?php echo $tv2["Idc"]; ?>' placeholder='Mã danh mục'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                    </div>
                                            <label class='control-label'>Tên danh mục :</label>
                                            <input  name='eName<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eName<?php echo $tv2["Idc"]; ?>' placeholder='Tên danh mục'  value='<?php echo $tv2["Name"]; ?>' />
                                            <label class='control-label'>Link :</label>
                                            <input  name='eLinkurl<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eLinkurl<?php echo $tv2["Idc"]; ?>' placeholder='Link'  value='<?php echo $tv2["Linkurl"]; ?>' />
                                            <label class='control-label'>Thứ tự :</label>
                                            <input  name='eDisplay<?php echo $tv2["Idc"]; ?>' type='text' class='span5 eDisplay<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Display"]; ?>' />
                                            
                                        
                                            <div class='control-group'>
                                                <label class='control-label'>Trạng thái</label>
                                                <div class='controls '>
                                                     <select  name='eStartus<?php echo $tv2["Idc"]; ?>' class='eStartus<?php echo $tv2["Idc"]; ?> atextdata3cb' >
                                                         <option value="on">Show</option>
                                                         <option value="">Hide</option>
                                                         
                                                     </select>
                                                </div>
                                            </div>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="EditCategory(<?php echo $tv2['Idc']; ?>)">Save</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>

                            <div class="collapse delete<?php echo $tv2["Idc"]; ?>">
                                <div class="widget-content">
                                    <h5>Xóa danh mục :</h5>
                                        <label class='control-label'>Bạn có chắc chắn muốn xóa không?</label>
                                        <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">    
                                            <input  name='dIdc<?php echo $tv2["Idc"]; ?>' type='text' class='span5 dIdc<?php echo $tv2["Idc"]; ?>' placeholder='Thứ tự'  value='<?php echo $tv2["Idc"]; ?>' readonly/>
                                        </div>    
                                            <label class='control-label'></label>
                                            <button id='btnadd' class='btn btn-success btnadd<?php echo $tv2["Idc"]; ?>' onclick="DeleteCategory(<?php echo $tv2['Idc']; ?>)">Delete</button>
                                            <i class='reload reload<?php echo $tv2["Idc"]; ?>' style='display: none;'></i>
                                </div>
                            </div>
                        


    <?php
            
                $menucon=testmenu($tv2["Idc"]);
                if($menucon=="Co")
                {
    ?>
                    <div class="collapse category<?php echo $tv2["Idc"]; ?>">
                        <div class="widget-content">
                            <div class="widget-box collapsible">
                                <?php Recursive($tv2["Idc"]);?>
                            </div>
                        </div>
                    </div>
     <?php
                }
     ?> 
                       
     <?php 
        }
       
    ?> 
    </div>


</div>
 </div>



































            </div>
        </div>  
    </div>




		</div>
	

	
</div>
