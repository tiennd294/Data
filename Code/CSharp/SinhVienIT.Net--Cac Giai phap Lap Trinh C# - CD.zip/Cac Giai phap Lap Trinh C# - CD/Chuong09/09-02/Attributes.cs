using System;
using System.IO;

public class Attributes
{
	private static void Main()
	{
		FileInfo file = new FileInfo("data.txt");
		
		Console.WriteLine(file.Attributes.ToString());
		
		if (file.Attributes == FileAttributes.ReadOnly)
		{
			Console.WriteLine("File is read-only (faulty test).");
		}

        if ((file.Attributes & FileAttributes.ReadOnly) ==
			FileAttributes.ReadOnly)
		{
			Console.WriteLine("File is read-only (correct test).");
		}

		Console.ReadLine();
	}
}