using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;

namespace Mapcolor
{
    public sealed class Class_Map
    {
        //ham doc file dua vao mang
        public bool ReadFromFile(string FileName, ArrayList ArrObj)
        {
            bool t_bool = true;
            try
            {
                using (StreamReader rd = new StreamReader(FileName))
                {
                    string line;
                    while ((line = rd.ReadLine()) != null)
                    {
                        ArrObj.Add(line);
                    }

                }
            }
            catch (Exception)
            {
                t_bool = false;

            }
            return t_bool;
        }


    }
}
