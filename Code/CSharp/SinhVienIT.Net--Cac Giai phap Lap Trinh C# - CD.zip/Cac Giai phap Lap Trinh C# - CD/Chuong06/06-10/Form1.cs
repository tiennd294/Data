using System;
using System.Collections;
using System.Windows.Forms;

public class ListBoxSort : System.Windows.Forms.Form
{
	internal System.Windows.Forms.ListView ListView1;
	internal System.Windows.Forms.ColumnHeader ColumnHeader1;
	internal System.Windows.Forms.ColumnHeader ColumnHeader2;
	internal System.Windows.Forms.ColumnHeader ColumnHeader3;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ListBoxSort()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "1", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)))),
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "B"),
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "A")}, -1);
		System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "2", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)))),
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "A"),
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "E")}, -1);
		System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "3", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)))),
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "C"),
																																							new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "B")}, -1);
		this.ListView1 = new System.Windows.Forms.ListView();
		this.ColumnHeader1 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader2 = new System.Windows.Forms.ColumnHeader();
		this.ColumnHeader3 = new System.Windows.Forms.ColumnHeader();
		this.SuspendLayout();
		// 
		// ListView1
		// 
		this.ListView1.Activation = System.Windows.Forms.ItemActivation.OneClick;
		this.ListView1.AllowColumnReorder = true;
		this.ListView1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.ListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					this.ColumnHeader1,
																					this.ColumnHeader2,
																					this.ColumnHeader3});
		this.ListView1.GridLines = true;
		this.ListView1.HoverSelection = true;
		this.ListView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
																					listViewItem1,
																					listViewItem2,
																					listViewItem3});
		this.ListView1.Location = new System.Drawing.Point(22, 33);
		this.ListView1.Name = "ListView1";
		this.ListView1.Size = new System.Drawing.Size(392, 296);
		this.ListView1.Sorting = System.Windows.Forms.SortOrder.Ascending;
		this.ListView1.TabIndex = 2;
		this.ListView1.View = System.Windows.Forms.View.Details;
		this.ListView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.ListView1_ColumnClick);
		// 
		// ListBoxSort
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(436, 362);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.ListView1});
		this.Name = "ListBoxSort";
		this.Text = "Form1";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new ListBoxSort());
	}

	private void ListView1_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
	{
		ListViewItemComparer sorter = new ListViewItemComparer(e.Column);
        ListView1.ListViewItemSorter = sorter;
		ListView1.Sort();
	}
}

public class ListViewItemComparer : IComparer
{
	private int column;
	private bool numeric = false;
	
	public int Column
	{
		get {return column;}
		set {column = value;}
	}
    
	public bool Numeric
	{
		get {return numeric;}
		set 
		{
			numeric = value;}
	}
    
	public ListViewItemComparer(int columnIndex)
	{
		Column = columnIndex;
	}

	public int Compare(object x, object y)
	{
		ListViewItem listX = (ListViewItem)x;
		ListViewItem listY = (ListViewItem)y;

		if (Numeric)
		{
			decimal listXVal, listYVal;
			try
			{
				listXVal = Decimal.Parse(listX.SubItems[Column].Text);
			}
			catch
			{
				listXVal = 0;
			}

			try
			{
				listYVal = Decimal.Parse(listY.SubItems[Column].Text);
			}
			catch
			{
				listYVal = 0;
			}

			return Decimal.Compare(listXVal, listYVal);
		}
		else
		{
			string listXText = listX.SubItems[Column].Text;
			string listYText = listY.SubItems[Column].Text;

			return String.Compare(listXText, listYText);
		}
	}

}