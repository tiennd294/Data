namespace bai_tap_ven_nha
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncong = new System.Windows.Forms.Button();
            this.lbltuso = new System.Windows.Forms.Label();
            this.txttuso = new System.Windows.Forms.MaskedTextBox();
            this.btntru = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.lblmauso = new System.Windows.Forms.Label();
            this.txtmauso = new System.Windows.Forms.MaskedTextBox();
            this.btnthoat = new System.Windows.Forms.Button();
            this.txtkq = new System.Windows.Forms.MaskedTextBox();
            this.lblkq = new System.Windows.Forms.Label();
            this.txttuso1 = new System.Windows.Forms.MaskedTextBox();
            this.txtmauso2 = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btncong
            // 
            this.btncong.Location = new System.Drawing.Point(22, 315);
            this.btncong.Margin = new System.Windows.Forms.Padding(4);
            this.btncong.Name = "btncong";
            this.btncong.Size = new System.Drawing.Size(112, 28);
            this.btncong.TabIndex = 0;
            this.btncong.Text = "Cong";
            this.btncong.UseVisualStyleBackColor = true;
            this.btncong.Click += new System.EventHandler(this.btncong_Click);
            // 
            // lbltuso
            // 
            this.lbltuso.AutoSize = true;
            this.lbltuso.Location = new System.Drawing.Point(18, 39);
            this.lbltuso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltuso.Name = "lbltuso";
            this.lbltuso.Size = new System.Drawing.Size(49, 17);
            this.lbltuso.TabIndex = 1;
            this.lbltuso.Text = "Tu so";
            // 
            // txttuso
            // 
            this.txttuso.Location = new System.Drawing.Point(141, 31);
            this.txttuso.Margin = new System.Windows.Forms.Padding(4);
            this.txttuso.Name = "txttuso";
            this.txttuso.Size = new System.Drawing.Size(101, 23);
            this.txttuso.TabIndex = 2;
            // 
            // btntru
            // 
            this.btntru.Location = new System.Drawing.Point(163, 315);
            this.btntru.Margin = new System.Windows.Forms.Padding(4);
            this.btntru.Name = "btntru";
            this.btntru.Size = new System.Drawing.Size(112, 28);
            this.btntru.TabIndex = 0;
            this.btntru.Text = "Tru";
            this.btntru.UseVisualStyleBackColor = true;
            this.btntru.Click += new System.EventHandler(this.btntru_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(307, 315);
            this.btnxoa.Margin = new System.Windows.Forms.Padding(4);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(112, 28);
            this.btnxoa.TabIndex = 0;
            this.btnxoa.Text = "Xoa";
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnrutgon_Click);
            // 
            // lblmauso
            // 
            this.lblmauso.AutoSize = true;
            this.lblmauso.Location = new System.Drawing.Point(18, 98);
            this.lblmauso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmauso.Name = "lblmauso";
            this.lblmauso.Size = new System.Drawing.Size(60, 17);
            this.lblmauso.TabIndex = 1;
            this.lblmauso.Text = "Mau so";
            // 
            // txtmauso
            // 
            this.txtmauso.Location = new System.Drawing.Point(141, 90);
            this.txtmauso.Margin = new System.Windows.Forms.Padding(4);
            this.txtmauso.Name = "txtmauso";
            this.txtmauso.Size = new System.Drawing.Size(101, 23);
            this.txtmauso.TabIndex = 2;
            // 
            // btnthoat
            // 
            this.btnthoat.Location = new System.Drawing.Point(141, 218);
            this.btnthoat.Margin = new System.Windows.Forms.Padding(4);
            this.btnthoat.Name = "btnthoat";
            this.btnthoat.Size = new System.Drawing.Size(112, 57);
            this.btnthoat.TabIndex = 0;
            this.btnthoat.Text = "Exit";
            this.btnthoat.UseVisualStyleBackColor = true;
            this.btnthoat.Click += new System.EventHandler(this.btnthoat_Click);
            // 
            // txtkq
            // 
            this.txtkq.Location = new System.Drawing.Point(141, 152);
            this.txtkq.Margin = new System.Windows.Forms.Padding(4);
            this.txtkq.Name = "txtkq";
            this.txtkq.Size = new System.Drawing.Size(267, 23);
            this.txtkq.TabIndex = 2;
            // 
            // lblkq
            // 
            this.lblkq.AutoSize = true;
            this.lblkq.Location = new System.Drawing.Point(18, 158);
            this.lblkq.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblkq.Name = "lblkq";
            this.lblkq.Size = new System.Drawing.Size(64, 17);
            this.lblkq.TabIndex = 1;
            this.lblkq.Text = "Ket qua";
            // 
            // txttuso1
            // 
            this.txttuso1.Location = new System.Drawing.Point(307, 31);
            this.txttuso1.Margin = new System.Windows.Forms.Padding(4);
            this.txttuso1.Name = "txttuso1";
            this.txttuso1.Size = new System.Drawing.Size(101, 23);
            this.txttuso1.TabIndex = 2;
            // 
            // txtmauso2
            // 
            this.txtmauso2.Location = new System.Drawing.Point(307, 90);
            this.txtmauso2.Margin = new System.Windows.Forms.Padding(4);
            this.txtmauso2.Name = "txtmauso2";
            this.txtmauso2.Size = new System.Drawing.Size(101, 23);
            this.txtmauso2.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 374);
            this.Controls.Add(this.txtkq);
            this.Controls.Add(this.txtmauso2);
            this.Controls.Add(this.txtmauso);
            this.Controls.Add(this.txttuso1);
            this.Controls.Add(this.txttuso);
            this.Controls.Add(this.lblkq);
            this.Controls.Add(this.lblmauso);
            this.Controls.Add(this.lbltuso);
            this.Controls.Add(this.btnxoa);
            this.Controls.Add(this.btntru);
            this.Controls.Add(this.btnthoat);
            this.Controls.Add(this.btncong);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncong;
        private System.Windows.Forms.Label lbltuso;
        private System.Windows.Forms.MaskedTextBox txttuso;
        private System.Windows.Forms.Button btntru;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Label lblmauso;
        private System.Windows.Forms.MaskedTextBox txtmauso;
        private System.Windows.Forms.Button btnthoat;
        private System.Windows.Forms.MaskedTextBox txtkq;
        private System.Windows.Forms.Label lblkq;
        private System.Windows.Forms.MaskedTextBox txttuso1;
        private System.Windows.Forms.MaskedTextBox txtmauso2;
    }
}

