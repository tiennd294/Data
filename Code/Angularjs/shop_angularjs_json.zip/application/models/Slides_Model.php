<?php
Class Slides_Model extends MY_Model
{
    var $table = 'slides';
    var $key = 'Ids';
}
