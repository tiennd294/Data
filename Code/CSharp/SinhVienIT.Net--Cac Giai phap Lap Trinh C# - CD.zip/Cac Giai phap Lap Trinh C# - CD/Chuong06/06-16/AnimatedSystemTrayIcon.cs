using System;
using System.Drawing;
using System.Windows.Forms;

public class AnimatedSystemTrayIcon : System.Windows.Forms.Form
{
	private System.Windows.Forms.NotifyIcon notifyIcon;
	private System.Timers.Timer timer;
	private System.ComponentModel.IContainer components;

	public AnimatedSystemTrayIcon()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
		this.timer = new System.Timers.Timer();
		((System.ComponentModel.ISupportInitialize)(this.timer)).BeginInit();
		// 
		// notifyIcon
		// 
		this.notifyIcon.Text = "notifyIcon1";
		this.notifyIcon.Visible = true;
		// 
		// timer
		// 
		this.timer.Enabled = true;
		this.timer.Interval = 1000;
		this.timer.SynchronizingObject = this;
		this.timer.Elapsed += new System.Timers.ElapsedEventHandler(this.timer_Elapsed);
		// 
		// AnimatedSystemTrayIcon
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(340, 174);
		this.Name = "AnimatedSystemTrayIcon";
		this.Text = "Form1";
		this.Load += new System.EventHandler(this.Form1_Load);
		((System.ComponentModel.ISupportInitialize)(this.timer)).EndInit();

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new AnimatedSystemTrayIcon());
	}
	
	Icon[] images;
	int offset = 0;

	private void Form1_Load(object sender, System.EventArgs e)
	{
		images = new Icon[8];
		images[0] = new Icon("moon01.ico");
		images[1] = new Icon("moon02.ico");
		images[2] = new Icon("moon03.ico");
		images[3] = new Icon("moon04.ico");
		images[4] = new Icon("moon05.ico");
		images[5] = new Icon("moon06.ico");
		images[6] = new Icon("moon07.ico");
		images[7] = new Icon("moon08.ico");
	}

	private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
	{
		notifyIcon.Icon = images[offset];
		offset++;
		if (offset > 7) offset = 0;
	}
}