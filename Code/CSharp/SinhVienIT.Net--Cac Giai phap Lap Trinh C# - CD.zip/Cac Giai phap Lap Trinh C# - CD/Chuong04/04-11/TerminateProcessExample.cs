using System;
using System.Threading;
using System.Diagnostics;

public class TerminateProcessExample {

    public static void Main () {

        using (Process process = Process.Start("notepad.exe")) {

            Console.WriteLine("Waiting 5 seconds before terminating" +
                " notepad.exe.");
            Thread.Sleep(5000);

            Console.WriteLine("Terminating Notepad with CloseMainWindow.");

            if (!process.CloseMainWindow()) {

                Console.WriteLine("CloseMainWindow returned false - " +
                    " terminating Notepad with Kill.");
                process.Kill();

            } else {

                if (!process.WaitForExit(2000)) {

                    Console.WriteLine("CloseMainWindow failed to" +
                        " terminate - terminating Notepad with Kill.");
                    process.Kill();
                }
            }
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}
