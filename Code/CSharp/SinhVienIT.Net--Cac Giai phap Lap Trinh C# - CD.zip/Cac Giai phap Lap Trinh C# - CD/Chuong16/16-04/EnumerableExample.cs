using System;
using System.Collections;

public class TeamMember {
    
	public string Name;
	public string Title;

	public TeamMember(string name, string title) {

		Name = name;
		Title = title;
	}
        
	public override string ToString() {
        
		return string.Format("{0} ({1})", Name, Title);
	}        
}

public class Team : IEnumerable {

	private class TeamMemberEnumerator : IEnumerator {

		private Team sourceTeam;

		private bool teamInvalid = false;

		private int currentMember = -1;

		internal TeamMemberEnumerator(Team team) {

			this.sourceTeam = team;

			sourceTeam.TeamChange += 
				new TeamChangedEventHandler(this.TeamChange);
		}

		public object Current {
			get { 

				if (currentMember == -1 ||
					currentMember > (sourceTeam.teamMembers.Count-1)) {

					throw new InvalidOperationException();
				}

				return sourceTeam.teamMembers[currentMember];
			}
		}

		public bool MoveNext() {

			if (teamInvalid) {
                
				throw new InvalidOperationException("Team modified");
			}
            
			currentMember++;

			if (currentMember > (sourceTeam.teamMembers.Count-1)) {
				return false;
			} else {
				return true;
			}
		}

		public void Reset() {

			if (teamInvalid) {
                
				throw new InvalidOperationException("Team modified");
			}

			currentMember = -1;
		}

		internal void TeamChange(Team t, EventArgs e) {
            
			teamInvalid = true;
		}
	}

	public delegate void TeamChangedEventHandler(Team t, EventArgs e);

	private ArrayList teamMembers;

	public event TeamChangedEventHandler TeamChange;

	public Team() {
        
		teamMembers = new ArrayList();
	}

	public IEnumerator GetEnumerator() {
		return new TeamMemberEnumerator(this);
	}

	public void AddMember(TeamMember member) {
    
		teamMembers.Add(member);

		if (TeamChange != null) {
            
			TeamChange(this, null);
		}
	}

	public static void Main() {

		// Tạo một Team mới.
		Team team = new Team();
		team.AddMember(new TeamMember("Curly", "Clown"));
		team.AddMember(new TeamMember("Nick", "Knife Thrower"));
		team.AddMember(new TeamMember("Nancy", "Strong Man"));

		// Liệt kê Team.
		foreach (TeamMember member in team) {

			Console.WriteLine(member.ToString());
		}

		// Liệt kê bằng vòng lặp while.
		IEnumerator e = team.GetEnumerator();
		while (e.MoveNext()) {

			Console.WriteLine(e.Current);
		}

		// Liệt kê Team và thêm một TeamMember
		// (khiến một ngoại lệ sẽ bị ném).
		foreach (TeamMember member in team) {

			Console.WriteLine(member.ToString());
			team.AddMember(new TeamMember("Stumpy", "Lion Tamer"));
		}
	}
}
