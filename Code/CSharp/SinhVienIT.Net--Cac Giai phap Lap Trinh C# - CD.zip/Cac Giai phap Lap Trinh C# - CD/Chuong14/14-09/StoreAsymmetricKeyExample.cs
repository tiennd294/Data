public class StoreAsymmetricKeyExample {

    public static void Main(string[] args) {
        
        switch (args[0].ToUpper()) {

            case "LOAD":
                LoadKeys(args[1]);
                break;
                                
            case "DEL":
                DeleteKeys(args[1]);
                break;
        }

        System.Console.ReadLine();
    }

    public static void LoadKeys(string container) {

        System.Security.Cryptography.CspParameters cspParams = 
            new System.Security.Cryptography.CspParameters();
        cspParams.KeyContainerName = container;
        
        using (System.Security.Cryptography.RSACryptoServiceProvider rsaAlg = 
         new System.Security.Cryptography.RSACryptoServiceProvider(cspParams)){

            rsaAlg.PersistKeyInCsp = true;

            System.Console.WriteLine(rsaAlg.ToXmlString(false));
            
        }
    }
    
    public static void DeleteKeys(string container) {
        
        System.Security.Cryptography.CspParameters cspParams = 
            new System.Security.Cryptography.CspParameters();
        cspParams.KeyContainerName = container;
        
        using (System.Security.Cryptography.RSACryptoServiceProvider rsaAlg = 
         new System.Security.Cryptography.RSACryptoServiceProvider(cspParams)){

            rsaAlg.PersistKeyInCsp = false;

            System.Console.WriteLine(rsaAlg.ToXmlString(false));

        }
    }
}