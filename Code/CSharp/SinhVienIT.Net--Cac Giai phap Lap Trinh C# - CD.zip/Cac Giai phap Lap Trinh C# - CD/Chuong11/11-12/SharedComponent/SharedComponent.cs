namespace SharedComponent
{
	public class ServerMessages
	{
		public const string AcknowledgeOK = "OK";
		public const string AcknowledgeCancel = "Cancel";
		public const string Disconnect = "Bye";
	}

	public class ClientMessages
	{
		public const string RequestConnect = "Hello";
		public const string Disconnect = "Bye";
		public const string RequestData = "GetData";
	}
}
