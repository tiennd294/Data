using System;
using System.Collections.Generic;
using System.Text;

namespace Baitap25      
{
    class nhanvien
    {
        string ho;

        public string Ho
        {
            get { return ho; }
            set { ho = value; }
        }
        string ten;

        public string Ten
        {
            get { return ten; }
            set { ten = value; }
        }
        int sosp;

        public int Sosp
        {
            get { return sosp; }
            set { sosp = value; }
        }
        public nhanvien()
        {
            ho = "";
            ten = "";
            sosp = 0;
        }
        public nhanvien(string honv, string tennv, int soluong)
        {
            ho = honv;
            ten = tennv;
            sosp = soluong;
        }
        public double tinhluong()
        {           
            double luong = 0;
            if (sosp <= 199)
                luong = sosp * 0.5;
            else
                if (sosp <= 399)
                    luong = sosp * 0.55;
                else
                    if (sosp <= 599)
                        luong = sosp * 0.6;
                    else
                        luong = sosp * 0.65;
            return luong;          
        }
        public bool sosanh(nhanvien nv)
        {
            bool ss = true;
            if (this.sosp < nv.sosp)
                ss = false;
            return ss;
        }
    }
}

 