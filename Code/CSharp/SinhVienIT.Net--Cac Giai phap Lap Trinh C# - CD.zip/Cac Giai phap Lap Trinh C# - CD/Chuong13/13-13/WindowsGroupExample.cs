using System;
using System.Security.Principal;

public class WindowsGroupExample {

    public static void Main (string[] args) {
    
        WindowsIdentity identity = WindowsIdentity.GetCurrent();
        
        WindowsPrincipal principal = new WindowsPrincipal(identity);
        
        foreach (string role in args) {
        
            Console.WriteLine("Is {0} a member of {1}? = {2}", 
                identity.Name, role, principal.IsInRole(role));
        }

        Console.ReadLine();
    }
}