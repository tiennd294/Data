using System;
using System.Text;
using System.Security.Cryptography;

public class HashPasswordExample {
    
    public static void Main(string[] args) {

        using (HashAlgorithm hashAlg = HashAlgorithm.Create(args[0])) {

            byte[] pwordData = Encoding.Default.GetBytes(args[1]);
    
            byte[] hash = hashAlg.ComputeHash(pwordData);
    
            Console.WriteLine(BitConverter.ToString(hash));
        }

        Console.ReadLine();
    }
}
