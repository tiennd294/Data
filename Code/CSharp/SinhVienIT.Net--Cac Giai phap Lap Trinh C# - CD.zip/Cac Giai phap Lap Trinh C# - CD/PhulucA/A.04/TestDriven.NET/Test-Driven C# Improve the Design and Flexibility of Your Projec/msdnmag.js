function Go(value)
{
   if(value!="0" && value!=null)
   {
      return true;     
   }
   else
   {
      return false;
   }
}

/*
function Jump(value)
{
var re = /\d{6}/

   if(re.test(value)&&value.length==6)
   {
      return true;     
   }
   else
   {
	alert("Please enter a valid QuickJump Code");
      return false;
   }
}
*/

function OnPrintPage(){
	var oWnd = window;
	var oDoc = oWnd.document;

	strLoc = "default.aspx?print=true";
	if (window.navigator.userAgent.indexOf("MSIE ")!=-1 && navigator.appVersion.substr(0, 1) >= 4){

	if( typeof(frmRatings)=="object" ){
		var oPrint = frmRatings.document.getElementById("Print");
		if(oPrint != null) oPrint.click();
	}
	else{
		if( oWnd.printHiddenFrame == null){
			oDoc.body.insertAdjacentHTML("beforeEnd", "<iframe name='printHiddenFrame' width='0' height='0'></iframe>");
			framedoc = oWnd.printHiddenFrame.document;
			framedoc.open();
			framedoc.write(
				"<frameset name=test onload='printMe.focus();printMe.print();' rows=\"100%\">" +
				"<frame name=printMe src=\""+strLoc+"\">" +
				"</frameset>");
			framedoc.close();
		}
		else{
			oWnd.printHiddenFrame.printMe.focus();
			oWnd.printHiddenFrame.printMe.print();
		}
	}		
	}
	else{
		oWnd.location.href = strLoc;
	}
	return true;
}

function AuthorSearch(author)
{
	var reSpace = /\s/
	author=author.replace(reSpace,"%20");
	window.location.href="/msdnmag/find/default.aspx?type=Au&phrase=" + author;
}

function OpenUrl(url)
{
var childWin;
childWin = window.open(url,'window','height=300,width=640,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');
childWin.focus();
//return false;
}

function ToggleDisplay(oButton, oItems)
{
	if (oItems.style.display == "none")	{
		oItems.style.display = "";
		oButton.src = "/msdnmag/images/minus.gif";
	}	else {
		oItems.style.display = "none";
		oButton.src = "/msdnmag/images/plus.gif";
	}
	return;
}

var x=0;

function change()	{
	var coll = document.all.tags("DIV");
	if (x!=1){
	{for (i=0; i<coll.length; i++)
		if (coll[i].style.display=='none' && coll[i].id.indexOf("menu")>-1){
			coll[i].style.display='';
		}
	}
	button1.value=" Collapse All "
	x=1
	var coll2 = document.all.tags("IMG");
	{for (i=0; i<coll2.length; i++)
		if (coll2[i].id.indexOf("btns")>-1){
			coll2[i].src='/msdnmag/images/minus.gif';
		}
	}

	}
	else {
	{for (i=0; i<coll.length; i++)
		if (coll[i].style.display=='' && coll[i].id.indexOf("menu")>-1){
			coll[i].style.display='none';
		}
	}
	button1.value=" Expand All "
	x=0
	var coll2 = document.all.tags("IMG");
	{for (i=0; i<coll2.length; i++)
		if (coll2[i].id.indexOf("btns")>-1){
			coll2[i].src='/msdnmag/images/plus.gif';
		}
	}
	}
}