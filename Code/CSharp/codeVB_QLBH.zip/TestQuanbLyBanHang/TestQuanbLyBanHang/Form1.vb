Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class QuanLy2
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub
		Private Ql As New QuanLy()
		Public Sub login()
			Dim frm As New Form2()
			frm.Text = "Dang Nhap"
			frm.ShowDialog()
		End Sub

		' Hàm xemm danh mục
		Private Sub XemDanhMuc(intDanhMuc As Integer)
			Dim frm As New Form3()
			frm.Text = intDanhMuc.ToString()
			frm.ShowDialog()
		End Sub

		Private Sub Form1_Load(sender As Object, e As EventArgs)
			'login();
		End Sub

		Private Sub dangNhapToolStripMenuItem_Click(sender As Object, e As EventArgs)
			login()
		End Sub

		Private Sub thoatToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Dim traloi As DialogResult
			traloi = MessageBox.Show("ban co muon dung lai khong?", "Tra loi", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
			If traloi = DialogResult.OK Then

				Ql.Huy()

				Application.[Exit]()
			End If
		End Sub

		Private Sub danhMucThanhPhoToolStripMenuItem_Click(sender As Object, e As EventArgs)
			XemDanhMuc(1)
		End Sub

		Private Sub danhMucKhacHangToolStripMenuItem_Click(sender As Object, e As EventArgs)
			XemDanhMuc(2)
		End Sub

		Private Sub danhMucNhanVienToolStripMenuItem_Click(sender As Object, e As EventArgs)
			XemDanhMuc(3)

		End Sub

		Private Sub danhMucSanPhamToolStripMenuItem_Click(sender As Object, e As EventArgs)
			XemDanhMuc(4)
		End Sub

		Private Sub danhMucHoaDonToolStripMenuItem_Click(sender As Object, e As EventArgs)
			XemDanhMuc(5)
		End Sub

		Private Sub danhMucToolStripMenuItem_Click(sender As Object, e As EventArgs)
			XemDanhMuc(6)
		End Sub

		Private Sub danhMucThanhPhoToolStripMenuItem1_Click(sender As Object, e As EventArgs)

			Ql.XuLy(1)
		End Sub

		Private Sub danhMucKhachHangToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Ql.XuLy(2)
		End Sub

		Private Sub hoaDonToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Ql.XuLy(3)
		End Sub

		Private Sub danhMucNhanVienToolStripMenuItem1_Click(sender As Object, e As EventArgs)
			Ql.XuLy(4)
		End Sub

		Private Sub danhMucSanPhamToolStripMenuItem1_Click(sender As Object, e As EventArgs)
			Ql.XuLy(5)
		End Sub

		Private Sub danhMucChiTietHoaDonToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Ql.XuLy(6)
		End Sub

		Private Sub khachHangTheoThanhPhoToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Dim frm As New Form10()
			frm.Text = "Quan Ly Khach Hang Theo Thanh Pho"
			frm.ShowDialog()
		End Sub

		Private Sub hoaDonTheoKhachHangToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Dim frm As New Form11()
			frm.Text = "Quan Ly Hoa Don Theo Khach Hang"
			frm.ShowDialog()
		End Sub

		Private Sub hoaDonTheoSanPhamToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Dim frm As New Form12()
			frm.Text = "Quan Ly Hoa Don Theo San Pham"
			frm.ShowDialog()
		End Sub

		Private Sub quanLyDanhMucDonToolStripMenuItem_Click(sender As Object, e As EventArgs)

		End Sub

		Private Sub heThongToolStripMenuItem_Click(sender As Object, e As EventArgs)

		End Sub

		Private Sub QuanLy_FormClosing(sender As Object, e As FormClosingEventArgs)
			Ql.Huy()
		End Sub

		Private Sub dangXuatToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Ql.Huy()
		End Sub

		Private Sub doiMatKhauToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Ql.XuLy(7)
		End Sub
	End Class
End Namespace
