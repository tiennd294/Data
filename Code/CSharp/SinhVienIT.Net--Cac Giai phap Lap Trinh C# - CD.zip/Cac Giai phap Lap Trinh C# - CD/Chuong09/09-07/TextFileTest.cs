using System;
using System.IO;
using System.Text;

public class TextFileTest
{
	private static void Main()
	{
		FileStream fs = new FileStream("test.txt", FileMode.Create);

		StreamWriter w = new StreamWriter(fs, Encoding.UTF8);

		w.WriteLine(124.23M);
		w.WriteLine("Test string");
		w.WriteLine('!');

		w.Flush();

		w.Close();
		fs.Close();

		Console.WriteLine("Press Enter to read the information.");
		Console.ReadLine();

		fs = new FileStream("test.txt", FileMode.Open);
		StreamReader r = new StreamReader(fs, Encoding.UTF8);

		Console.WriteLine(Decimal.Parse(r.ReadLine()));
		Console.WriteLine(r.ReadLine());
		Console.WriteLine(Char.Parse(r.ReadLine()));
		
		r.Close();
		fs.Close();

		Console.ReadLine();
	}
}
