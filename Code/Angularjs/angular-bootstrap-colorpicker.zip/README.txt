A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/GWXZzm.

 No jQuery dependendencies, just an AngularJS directive based on the bootstrap-colorpicker jQuery library.

Forked from [Michael Calkins](http://codepen.io/michaeljcalkins/)'s Pen [angular-bootstrap-colorpicker](http://codepen.io/michaeljcalkins/pen/tyKGL/).