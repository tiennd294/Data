using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Dien_tich_hinh_tron_Cs
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmhinhtron());
        }
    }
}