using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Web.Services;
using System.Web;

public class DataCachingTest : System.Web.Services.WebService
{
	public DataCachingTest()
	{
		//CODEGEN: This call is required by the ASP.NET Web Services Designer
		InitializeComponent();
	}

	#region Component Designer generated code
	
	//Required by the Web Services Designer 
	private IContainer components = null;
			
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if(disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);		
	}
	
	#endregion


	private static string connectionString = "Data Source=localhost;" +
		"Initial Catalog=Northwind;user ID=sa";

	[WebMethod()] 
	public DataSet GetProductCatalog()
	{
		return GetCustomerDataSet();
	}

	[WebMethod()]
	public string[] GetProductList()
	{
		DataTable dt = GetCustomerDataSet().Tables[0];
        
		string[] names = new string[dt.Rows.Count];

		int i = 0;
		foreach (DataRow row in dt.Rows)
		{
			names[i] = row["ProductName"].ToString();
			i += 1;
		}

		return names;
	}

	private DataSet GetCustomerDataSet()
	{
		DataSet ds = HttpContext.Current.Cache["Products"] as DataSet;
		
		if (ds == null)
		{
			string SQL = "SELECT * FROM Products";

			SqlConnection con = new SqlConnection(connectionString);
			SqlCommand com = new SqlCommand(SQL, con);
			SqlDataAdapter adapter = new SqlDataAdapter(com);
			ds = new DataSet();

			try
			{
				con.Open();
				adapter.Fill(ds, "Products");

				HttpContext.Current.Cache.Insert("Products", ds, null,
					DateTime.Now.AddSeconds(60), TimeSpan.Zero);
			}
			catch (Exception err)
			{
				System.Diagnostics.Debug.WriteLine(err.ToString());
			}
			finally
			{
				con.Close();
			}
		}
		return ds;
	}
}