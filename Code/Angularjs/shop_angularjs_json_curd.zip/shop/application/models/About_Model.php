<?php
Class About_Model extends MY_Model
{
    var $table = 'about';
    var $key = 'Ida';
}

