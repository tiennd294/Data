Namespace TestQuanbLyBanHang
	Partial Class Form8
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.btnXoa = New System.Windows.Forms.Button()
			Me.btnSua = New System.Windows.Forms.Button()
			Me.textBox4 = New System.Windows.Forms.TextBox()
			Me.btnThem = New System.Windows.Forms.Button()
			Me.textBox3 = New System.Windows.Forms.TextBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.btnLuu = New System.Windows.Forms.Button()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.btnHuyBo = New System.Windows.Forms.Button()
			Me.btnReLoad = New System.Windows.Forms.Button()
			Me.label4 = New System.Windows.Forms.Label()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.pictureBox2 = New System.Windows.Forms.PictureBox()
			Me.pictureBox1 = New System.Windows.Forms.PictureBox()
			Me.label5 = New System.Windows.Forms.Label()
			Me.button1 = New System.Windows.Forms.Button()
			Me.label3 = New System.Windows.Forms.Label()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.btnTroVe = New System.Windows.Forms.Button()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.groupBox1.SuspendLayout()
			DirectCast(Me.pictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
			DirectCast(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' btnXoa
			' 
			Me.btnXoa.Location = New System.Drawing.Point(255, 367)
			Me.btnXoa.Name = "btnXoa"
			Me.btnXoa.Size = New System.Drawing.Size(37, 28)
			Me.btnXoa.TabIndex = 16
			Me.btnXoa.Text = "Xoa"
			Me.btnXoa.UseVisualStyleBackColor = True
			AddHandler Me.btnXoa.Click, New System.EventHandler(Me.btnXoa_Click)
			' 
			' btnSua
			' 
			Me.btnSua.Location = New System.Drawing.Point(118, 367)
			Me.btnSua.Name = "btnSua"
			Me.btnSua.Size = New System.Drawing.Size(35, 28)
			Me.btnSua.TabIndex = 13
			Me.btnSua.Text = "Sua"
			Me.btnSua.UseVisualStyleBackColor = True
			AddHandler Me.btnSua.Click, New System.EventHandler(Me.btnSua_Click)
			' 
			' textBox4
			' 
			Me.textBox4.Location = New System.Drawing.Point(276, 53)
			Me.textBox4.Name = "textBox4"
			Me.textBox4.Size = New System.Drawing.Size(103, 20)
			Me.textBox4.TabIndex = 9
			' 
			' btnThem
			' 
			Me.btnThem.Location = New System.Drawing.Point(69, 367)
			Me.btnThem.Name = "btnThem"
			Me.btnThem.Size = New System.Drawing.Size(43, 28)
			Me.btnThem.TabIndex = 12
			Me.btnThem.Text = "Them"
			Me.btnThem.UseVisualStyleBackColor = True
			AddHandler Me.btnThem.Click, New System.EventHandler(Me.btnThem_Click)
			' 
			' textBox3
			' 
			Me.textBox3.Location = New System.Drawing.Point(276, 27)
			Me.textBox3.Name = "textBox3"
			Me.textBox3.Size = New System.Drawing.Size(103, 20)
			Me.textBox3.TabIndex = 7
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(87, 53)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.Size = New System.Drawing.Size(114, 20)
			Me.textBox2.TabIndex = 6
			' 
			' btnLuu
			' 
			Me.btnLuu.Location = New System.Drawing.Point(159, 367)
			Me.btnLuu.Name = "btnLuu"
			Me.btnLuu.Size = New System.Drawing.Size(35, 28)
			Me.btnLuu.TabIndex = 14
			Me.btnLuu.Text = "Luu"
			Me.btnLuu.UseVisualStyleBackColor = True
			AddHandler Me.btnLuu.Click, New System.EventHandler(Me.btnLuu_Click)
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(86, 27)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(115, 20)
			Me.textBox1.TabIndex = 5
			' 
			' btnHuyBo
			' 
			Me.btnHuyBo.Location = New System.Drawing.Point(200, 367)
			Me.btnHuyBo.Name = "btnHuyBo"
			Me.btnHuyBo.Size = New System.Drawing.Size(51, 28)
			Me.btnHuyBo.TabIndex = 15
			Me.btnHuyBo.Text = "Huy Bo"
			Me.btnHuyBo.UseVisualStyleBackColor = True
			AddHandler Me.btnHuyBo.Click, New System.EventHandler(Me.btnHuyBo_Click)
			' 
			' btnReLoad
			' 
			Me.btnReLoad.Location = New System.Drawing.Point(10, 367)
			Me.btnReLoad.Name = "btnReLoad"
			Me.btnReLoad.Size = New System.Drawing.Size(53, 28)
			Me.btnReLoad.TabIndex = 11
			Me.btnReLoad.Text = "ReLoad"
			Me.btnReLoad.UseVisualStyleBackColor = True
			AddHandler Me.btnReLoad.Click, New System.EventHandler(Me.btnReLoad_Click)
			' 
			' label4
			' 
			Me.label4.AutoSize = True
			Me.label4.Location = New System.Drawing.Point(207, 56)
			Me.label4.Name = "label4"
			Me.label4.Size = New System.Drawing.Size(46, 13)
			Me.label4.TabIndex = 3
			Me.label4.Text = "Don Gia"
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(7, 199)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(390, 149)
			Me.dataGridView1.TabIndex = 10
			AddHandler Me.dataGridView1.CellClick, New System.Windows.Forms.DataGridViewCellEventHandler(Me.dataGridView1_CellClick)
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me.pictureBox2)
			Me.groupBox1.Controls.Add(Me.pictureBox1)
			Me.groupBox1.Controls.Add(Me.label5)
			Me.groupBox1.Controls.Add(Me.button1)
			Me.groupBox1.Controls.Add(Me.textBox4)
			Me.groupBox1.Controls.Add(Me.textBox3)
			Me.groupBox1.Controls.Add(Me.textBox2)
			Me.groupBox1.Controls.Add(Me.textBox1)
			Me.groupBox1.Controls.Add(Me.label4)
			Me.groupBox1.Controls.Add(Me.label3)
			Me.groupBox1.Controls.Add(Me.label2)
			Me.groupBox1.Controls.Add(Me.label1)
			Me.groupBox1.Location = New System.Drawing.Point(8, 1)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(389, 192)
			Me.groupBox1.TabIndex = 9
			Me.groupBox1.TabStop = False
			' 
			' pictureBox2
			' 
			Me.pictureBox2.Location = New System.Drawing.Point(9, 79)
			Me.pictureBox2.Name = "pictureBox2"
			Me.pictureBox2.Size = New System.Drawing.Size(124, 107)
			Me.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
			Me.pictureBox2.TabIndex = 13
			Me.pictureBox2.TabStop = False
			' 
			' pictureBox1
			' 
			Me.pictureBox1.Location = New System.Drawing.Point(256, 79)
			Me.pictureBox1.Name = "pictureBox1"
			Me.pictureBox1.Size = New System.Drawing.Size(123, 107)
			Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
			Me.pictureBox1.TabIndex = 12
			Me.pictureBox1.TabStop = False
			' 
			' label5
			' 
			Me.label5.AutoSize = True
			Me.label5.Location = New System.Drawing.Point(172, 90)
			Me.label5.Name = "label5"
			Me.label5.Size = New System.Drawing.Size(51, 13)
			Me.label5.TabIndex = 11
			Me.label5.Text = "Hinh Anh"
			' 
			' button1
			' 
			Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(0))
			Me.button1.Location = New System.Drawing.Point(178, 106)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(36, 23)
			Me.button1.TabIndex = 10
			Me.button1.Text = " ..."
			Me.button1.UseVisualStyleBackColor = True
			AddHandler Me.button1.Click, New System.EventHandler(Me.button1_Click)
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Location = New System.Drawing.Point(207, 30)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(63, 13)
			Me.label3.TabIndex = 2
			Me.label3.Text = "Don Vi Tinh"
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(6, 56)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(78, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Ten San Pham"
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(6, 30)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(74, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Ma San Pham"
			' 
			' btnTroVe
			' 
			Me.btnTroVe.Location = New System.Drawing.Point(327, 367)
			Me.btnTroVe.Name = "btnTroVe"
			Me.btnTroVe.Size = New System.Drawing.Size(60, 28)
			Me.btnTroVe.TabIndex = 17
			Me.btnTroVe.Text = "Tro Ve"
			Me.btnTroVe.UseVisualStyleBackColor = True
			AddHandler Me.btnTroVe.Click, New System.EventHandler(Me.btnTroVe_Click)
			' 
			' Form8
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(407, 404)
			Me.Controls.Add(Me.btnXoa)
			Me.Controls.Add(Me.btnSua)
			Me.Controls.Add(Me.btnThem)
			Me.Controls.Add(Me.btnLuu)
			Me.Controls.Add(Me.btnHuyBo)
			Me.Controls.Add(Me.btnReLoad)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.groupBox1)
			Me.Controls.Add(Me.btnTroVe)
			Me.Name = "Form8"
			Me.Text = "Quan Ly Danh Muc San Pham"
			Me.Load += New System.EventHandler(Me.Form8_Load)
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			DirectCast(Me.pictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
			DirectCast(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private btnXoa As System.Windows.Forms.Button
		Private btnSua As System.Windows.Forms.Button
		Private textBox4 As System.Windows.Forms.TextBox
		Private btnThem As System.Windows.Forms.Button
		Private textBox3 As System.Windows.Forms.TextBox
		Private textBox2 As System.Windows.Forms.TextBox
		Private btnLuu As System.Windows.Forms.Button
		Private textBox1 As System.Windows.Forms.TextBox
		Private btnHuyBo As System.Windows.Forms.Button
		Private btnReLoad As System.Windows.Forms.Button
		Private label4 As System.Windows.Forms.Label
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private groupBox1 As System.Windows.Forms.GroupBox
		Private label3 As System.Windows.Forms.Label
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private btnTroVe As System.Windows.Forms.Button
		Private pictureBox1 As System.Windows.Forms.PictureBox
		Private label5 As System.Windows.Forms.Label
		Private button1 As System.Windows.Forms.Button
		Private pictureBox2 As System.Windows.Forms.PictureBox
	End Class
End Namespace
