<div class="container">
		<div class="sixteen columns">
			
			<div id="pageName">
				<div class="name_tag">
					<p>
						You're Here :: <a href="#">home</a> :: My Account
					</p>
					<div class="shapLeft"></div>
					<div class="shapRight"></div>
				</div>
			</div><!--end pageName-->

		</div>
	</div><!-- container -->



	<!-- strat the main content area -->
	
	<div class="container">
		
		<div class="eleven columns">
			<div class="my_account">

				<div>
					<h4>My Account</h4>

					<ul>
						<li><a href="#">Edit Your Account Infornation</a></li>
						<li><a href="#">Change Your Password</a></li>
						<li><a href="#">Modify Your Address book entries</a></li>
						<li><a href="#">Modify Your Wish List</a></li>
					</ul>
				</div>

				<div>
					<h4>My Orders</h4>

					<ul>
						<li><a href="#">View Your Order History</a></li>
						<li><a href="#">View Your Downloads</a></li>
						<li><a href="#">View Your Review Points</a></li>
						<li><a href="#">View Your Return Requests</a></li>
						<li><a href="#">Your Transations</a></li>
					</ul>
				</div>

				<div>
					<h4>Newslatter</h4>

					<ul>
						<li><a href="#">Subscribe Our Newslatter</a></li>
						<li><a href="#">Unsubscribe Our Newslatter</a></li>
					</ul>
				</div>

			</div><!--end my_account-->
		</div><!--end eleven-->


		<div class="five columns">
			<div class="account_list">

				<div class="box_head">
					<h3>Account</h3>
				</div><!--end box_head -->

					<ul>
						<li><a href="#">Account</a></li>
						<li><a href="#">Edit Account</a></li>
						<li><a href="#">Password</a></li>
						<li><a href="#">Wish List</a></li>
						<li><a href="#">Order History</a></li>
						<li><a href="#">DownLoads</a></li>
						<li><a href="#">Returns</a></li>
						<li><a href="#">Transactions</a></li>
						<li><a href="#">Newslatter</a></li>
						<li><a href="#">Logout</a></li>
					</ul>

			</div><!--end account_list-->
		</div><!--end five-->

	</div><!--end container-->
	<!-- end the main content area -->
