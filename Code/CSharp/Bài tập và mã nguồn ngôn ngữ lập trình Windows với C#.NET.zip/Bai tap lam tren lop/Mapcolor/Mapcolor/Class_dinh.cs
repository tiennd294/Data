using System;
using System.Collections.Generic;
using System.Text;

namespace Mapcolor
{
    public sealed class Class_dinh
    {
        public string Ten;
        public int Bac;
        public byte Mauto;
        public byte[] Camto;
        public byte x;
        public byte y;
    }
}
