using System;
using System.Collections;

public class Newspaper : IComparable {

    private string name;
    private int circulation;

    private class AscendingCirculationComparer : IComparer {
        
        int IComparer.Compare(object x, object y) {
            
            if (x == null && y == null) return 0;
            else if (x == null) return -1;
            else if (y == null) return 1;
            
            if (x == y) return 0;
            
            Newspaper newspaperX = x as Newspaper;
            if (newspaperX == null) {
                
                throw new ArgumentException("Invalid object type", "x");
            }
            
            Newspaper newspaperY = y as Newspaper;
            if (newspaperY == null) {
                
                throw new ArgumentException("Invalid object type", "y");
            }
            
            return newspaperX.circulation - newspaperY.circulation;
        }
    }
            
    public Newspaper(string name, int circulation) {
    
        this.name = name;
        this.circulation = circulation;
    }

    public static IComparer CirculationSorter{
        get { return new AscendingCirculationComparer(); }
    }
    
    public override string ToString() {
        
        return string.Format("{0}: Circulation = {1}", name, circulation);
    }
    
    public int CompareTo(object obj) {
                
        if (obj == null) return 1;

        if (obj == this) return 0;
                 
        Newspaper other = obj as Newspaper;
        
        if (other == null) {
            
            throw new ArgumentException("Invalid object type", "obj");
            
        } else {
            
            return string.Compare(this.name, other.name, true);
        }
    }
    
    public static void Main() {
        
        ArrayList newspapers = new ArrayList();
        
        newspapers.Add(new Newspaper("Tuoi Tre", 125780));
        newspapers.Add(new Newspaper("Echip", 55230));
        newspapers.Add(new Newspaper("Thanh Nien", 235950));
        newspapers.Add(new Newspaper("Phu Nu", 88760));
        newspapers.Add(new Newspaper("Tiep Thi", 5670));
        
        Console.WriteLine("Unsorted newspaper list:");
        foreach (Newspaper n in newspapers) {
            
            Console.WriteLine(n);
        }
        
        Console.WriteLine(Environment.NewLine);
        Console.WriteLine("Newspaper list sorted by name (default order):");
        newspapers.Sort();
        foreach (Newspaper n in newspapers) {
            
            Console.WriteLine(n);
        }

        Console.WriteLine(Environment.NewLine);
        Console.WriteLine("Newspaper list sorted by circulation:");
        newspapers.Sort(Newspaper.CirculationSorter);
        foreach (Newspaper n in newspapers) {
            
            Console.WriteLine(n);
        }

		Console.ReadLine();
    }
}
