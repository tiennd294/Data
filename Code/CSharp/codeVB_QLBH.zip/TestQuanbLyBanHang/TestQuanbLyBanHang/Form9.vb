Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class Form9
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Public Them2 As Boolean
		Public Sub loaddata2()
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM ChiTietHoaDon", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				' Đưa dữ liệu lên DataGridView
				dataGridView1.DataSource = dt
				' Thay đổi độ rộng cột
				dataGridView1.AutoResizeColumns()
				' Xóa trống các đối tượng trong Panel
				Me.textBox1.ResetText()
				Me.textBox2.ResetText()
				' Không cho thao tác trên các nút Lưu / Hủy
				Me.btnLuu.Enabled = False
				Me.btnHuyBo.Enabled = False
				'this.panel.Enabled = false;
				' Cho thao tác trên các nút Thêm / Sửa / Xóa /Thoát
				Me.btnThem.Enabled = True
				Me.btnSua.Enabled = True
				Me.btnXoa.Enabled = True
				Me.btnTroVe.Enabled = True

				' Không cho thao tác trên Panel

				Me.groupBox1.Enabled = False
			Catch
			End Try
		End Sub

		Public Sub hienthi()
			Dim cmd1 As New SqlCommand()
			Dim kn1 As New ketnoi()
			kn1.ket_noi()
			cmd1.Connection = kn1.con
			Dim da As New SqlDataAdapter("SELECT MaSP, MaHD FROM SanPham, HoaDon", kn1.con)
			Dim ds As New DataSet()
			da.Fill(ds)
			Dim dt As New DataTable()
			da.Fill(dt)
			comboBox1.DataSource = ds.Tables(0)
			comboBox1.DisplayMember = "MaHD"
			comboBox2.DataSource = ds.Tables(0)
			comboBox2.DisplayMember = "MaSP"

		End Sub

		Private Sub Form9_Load(sender As Object, e As EventArgs)
			loaddata2()
			hienthi()
		End Sub

		Private Sub btnThem_Click(sender As Object, e As EventArgs)
			Them2 = True
			' Xóa trống các đối tượng trong Panel
			Me.textBox1.ResetText()
			' Cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = True
			Me.btnHuyBo.Enabled = True
			Me.groupBox1.Enabled = True
			' Không cho thao tác trên các nút Thêm / Xóa / Thoát
			Me.btnThem.Enabled = False
			Me.btnSua.Enabled = False
			Me.btnXoa.Enabled = False
			Me.btnTroVe.Enabled = False
			' Đưa con trỏ đến TextField txtThanhPho
			Me.textBox2.Focus()
		End Sub

		Private Sub btnSua_Click(sender As Object, e As EventArgs)
			Try
				Them2 = False
				' Cho phép thao tác trên Panel this.panel.Enabled = true;
				' Thứ tự dòng hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Chuyển thông tin lên panel 
				Me.textBox2.Text = dataGridView1.Rows(r).Cells(0).Value.ToString()
				Me.textBox1.Text = dataGridView1.Rows(r).Cells(3).Value.ToString()
				' Cho thao tác trên các nút Lưu / Hủy / Panel
				Me.btnLuu.Enabled = True
				Me.btnHuyBo.Enabled = True
				Me.groupBox1.Enabled = True
				' Không cho thao tác trên các nút Thêm / Xóa / Thoát
				Me.btnThem.Enabled = False
				Me.btnSua.Enabled = False
				Me.btnXoa.Enabled = False
				Me.btnTroVe.Enabled = False
				' Đưa con trỏ đến TextField txtMaKH
				Me.textBox2.Focus()
			Catch
			End Try
		End Sub

		Private Sub btnReLoad_Click(sender As Object, e As EventArgs)
			loaddata2()
		End Sub

		Private Sub btnLuu_Click(sender As Object, e As EventArgs)
			Dim cmd As New SqlCommand()
			Dim kn As New ketnoi()
			kn.ket_noi()
			cmd.Connection = kn.con
			If Them2 Then
				Try
					' Thực hiện lệnh

					cmd.CommandType = CommandType.Text
					' Lệnh Insert InTo
					cmd.CommandText = System.[String].Concat("Insert Into ChiTietHoaDon(MaCT ,MaHD, MaSP, SoLuong) Values(" & "'" & Me.textBox2.Text.ToString() & "','" & comboBox1.Text.ToString() & "','" & comboBox2.Text.ToString() & "','" & Me.textBox1.Text.ToString() & "')")
					cmd.CommandType = CommandType.Text
					cmd.ExecuteNonQuery()
					' Load lại dữ liệu trên DataGridView
						' Thông báo
						'MessageBox.Show("Đã thêm xong!");
					loaddata2()
				Catch generatedExceptionName As SqlException
					MessageBox.Show("Không thêm được. Lỗi rồi!")
				End Try
			End If
			If Not Them2 Then
				' Thực hiện lệnh

				cmd.CommandType = CommandType.Text
				' Thứ tự dòng hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' MaKH hiện hành 
				Dim str As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Câu lệnh SQL
				Dim text As Integer = Convert.ToInt32(comboBox1.Text.ToString())
				Dim text2 As Integer = Convert.ToInt32(comboBox2.Text.ToString())
				cmd.CommandText = System.[String].Concat("Update ChiTietHoaDon Set MaHD='" & text & "', MaSP='" & text2 & "', SoLuong='" & Me.textBox1.Text.ToString() & "' WHERE MaCT='" & str & "'")
				' Cập nhật

				cmd.CommandType = CommandType.Text
				cmd.ExecuteNonQuery()
				' Load lại dữ liệu trên DataGridView
					' Thông báo
					'MessageBox.Show("Đã sửa xong!");
				loaddata2()
			End If
			' Đóng kết nối
			kn.con.Close()
		End Sub

		Private Sub btnHuyBo_Click(sender As Object, e As EventArgs)
			Me.btnThem.Enabled = True
			Me.btnSua.Enabled = True
			Me.btnXoa.Enabled = True
			Me.btnTroVe.Enabled = True
			' Không cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = False
			Me.btnHuyBo.Enabled = False
			Me.groupBox1.Enabled = False
		End Sub

		Private Sub btnXoa_Click(sender As Object, e As EventArgs)
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con
				cmd.CommandType = CommandType.Text
				' Lấy thứ tự record hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Lấy MaKH của record hiện hành 
				Dim str As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Viết câu lệnh SQL
				cmd.CommandText = System.[String].Concat("Delete From ChiTietHoaDon Where MaCT='" & str & "'")
				cmd.CommandType = CommandType.Text
				' Thực hiện câu lệnh SQL
				cmd.ExecuteNonQuery()
				' Cập nhật lại DataGridView
				loaddata2()
				' Thông báo

				MessageBox.Show("Đã xóa xong!")
			Catch
			End Try
		End Sub

		Private Sub btnTroVe_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub
	End Class
End Namespace
