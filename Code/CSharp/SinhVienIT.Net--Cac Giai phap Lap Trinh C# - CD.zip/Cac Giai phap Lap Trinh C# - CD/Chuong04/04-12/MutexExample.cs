using System;
using System.Threading;

public class MutexExample {

    public static void Main() {

        bool ownsMutex;

        using (Mutex mutex = 
                   new Mutex(true, "MutexExample", out ownsMutex)) {

            if (ownsMutex) {

                Console.WriteLine("This application currently owns the" +
                    " mutex named MutexExample. Additional instances of" +
                    " this application will not run until you release" +
                    " the mutex by pressing Enter.");

                Console.ReadLine();

                mutex.ReleaseMutex();

            } else {

                Console.WriteLine("Another instance of this application " +
                    " already owns the mutex named MutexExample. This" +
                    " instance of the application will terminate.");
            }
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}