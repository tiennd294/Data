using System.Net;
using System.Security.Permissions;

[assembly:SocketPermission(SecurityAction.RequestMinimum, 
    Unrestricted = true)]

[assembly:SecurityPermission(SecurityAction.RequestOptional,
    Unrestricted = true)]

[assembly:SecurityPermission(SecurityAction.RequestRefuse, 
    Unrestricted = true)]

public class PermissionViewExample {
    public static void Main() {   
        // ...
    }
}