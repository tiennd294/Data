using System.Security.Permissions;

[assembly:PermissionSet(SecurityAction.RequestOptional, Name = "Internet")]

public class OptionalRequestExample {

    public static void Main() {
    
        // ...
    }
}