using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using SharedComponent;


public class TcpClientTest
{
	private static void Main()
	{
		TcpClient client = new TcpClient();
		
		try
		{
			Console.WriteLine("Attempting to connect to the server " +
				"on port 8000.");
			client.Connect(IPAddress.Parse("127.0.0.1"), 8000);
			Console.WriteLine("Connection established.");
			
			NetworkStream stream = client.GetStream();
			
			BinaryWriter w = new BinaryWriter(stream);
            
			BinaryReader r = new BinaryReader(stream);
            
			w.Write(ClientMessages.RequestConnect);
			
			if (r.ReadString() == ServerMessages.AcknowledgeOK)
			{
				Console.WriteLine("Connected.");
				Console.WriteLine("Press Enter to disconnect.");
				Console.ReadLine();
				Console.WriteLine("Disconnecting...");
				w.Write(ClientMessages.Disconnect);
			}
			else
			{
				Console.WriteLine("Connection not completed.");
			}

			client.Close();
			Console.WriteLine("Port closed.");
		}
		catch (Exception err)
		{
			Console.WriteLine(err.ToString());
		}
    
		Console.ReadLine();

	}
}