<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Users_Model');
    }

    public function Index()
    {

        $input = array();
        $tblusers=$this->Users_Model->get_list($input);
        $tblmenu=$this->Users_Model->loadmenu();

        $input['where'] = array('Usersnames' => $this->session->userdata('Administrator'));
        $level=$this->Users_Model->get_list($input);
        $link='admin/Error/error';
        $levelus=0;
        foreach ($level as $row) {
            if ($row->Level==1 || $row->Level==10) {
                $link='admin/Users/users';
                $levelus=$row->Level;
            }
        }
        

        
        $data = array(
            'urldata' => $link,
            'tblusers' => $tblusers,
            'tblmenu' => $tblmenu,
            'levelus' => $levelus
         );
        $this->load->view('admin/layout',$data);
    }

    public function Add()
    {
        $data = array(
            'Usersnames' => $this->input->post('atextdata1'),
            'Passwords' => md5(md5($this->input->post('atextdata2'))),
            'Name' => $this->input->post('atextdata3'),
            'Phone' => $this->input->post('atextdata4'),
            'Email' => $this->input->post('atextdata5'),
            'Address' => $this->input->post('atextdata6'),
            'Level' => $this->input->post('atextdata7'),
            'Startus' => $this->input->post('atextdata8'),
            'Createby' => $this->session->userdata('Administrator'),
            'Createdate' => date("Y/m/d H:i:s")

        );
        $this->Users_Model->create($data);
    }


    public function Edit()
    {
        $Startus=$this->input->post('etextdata8');
        $Level = $this->input->post('etextdata7');
        $input = array();
        $tblusers=$this->Users_Model->get_list($input);

        $input['where'] = array('Usersnames' => $this->session->userdata('Administrator'));
        $levela=$this->Users_Model->get_list($input);
        foreach ($levela as $row) {
            if ($row->Level==10) {
                $Startus='on';
                $Level=10;
            }
        }

        $data = array(
            'Usersnames' => $this->input->post('etextdata1'),
            'Passwords' => md5(md5($this->input->post('etextdata2'))),
            'Name' => $this->input->post('etextdata3'),
            'Phone' => $this->input->post('etextdata4'),
            'Email' => $this->input->post('etextdata5'),
            'Address' => $this->input->post('etextdata6'),
            'Level' => $Level,
            'Startus' => $Startus,
            'Modifyby' => $this->session->userdata('Administrator'),
            'Modifydate' => date("Y/m/d H:i:s")

        );
        
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Users_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        $input = array();
        $tblusers=$this->Users_Model->get_list($input);

        $input['where'] = array('Usersnames' => $this->session->userdata('Administrator'));
        $levela=$this->Users_Model->get_list($input);
        foreach ($levela as $row) {
            if ($row->Level!=10) {
                if($this->input->post('textid')){
                     $Id  = $this->input->post('textid');
                     $this->Users_Model->delete($Id);
               
                }
            }
        }
        
    }

    public function logout()
    {
        if ($this->session->userdata('Administrator')) {
            $this->session->unset_userdata('Administrator');
        }
        redirect(admin_url('login'));
    }

    public function __error()
    {
        echo "string";
    }
}