using System;
using System.IO;

public class RelativeDirTest
{
	private static void Main()
	{
		Console.WriteLine("Using: " + Directory.GetCurrentDirectory());
		
		Console.WriteLine("The relative path 'file.txt' " +
		    "will automatically become: '" + 
			Path.GetFullPath("file.txt") + "'");

		Console.WriteLine();

        Console.WriteLine("Changing current directory to C:\\");
		Directory.SetCurrentDirectory("C:\\");
		
		Console.WriteLine("Now the relative path 'file.txt' " +
			"will automatically become '" +
			Path.GetFullPath("file.txt") + "'");

		Console.ReadLine();
	}
}