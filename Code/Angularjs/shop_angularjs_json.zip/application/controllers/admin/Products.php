<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Products_Model');
        $this->load->model('Category_Model');
        $this->load->model('Productsima_Model');
    }

    public function Index()
    {
        $input = array();
        $tblproducts=$this->Products_Model->get_list($input);
        $input['where'] = array(
            'Parentid' => 0,
            'Classify' => 1
            );
        $tblcategory=$this->Category_Model->get_list($input);
        $tblmenu=$this->Products_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Products/products',
            'tblproducts' => $tblproducts,
            'tblcategory' => $tblcategory,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }


    public function Add()
    {
        $Images=str_replace(base_url(), '', $this->input->post('atextdata4'));
        $data = array(
            'Name' => $this->input->post('atextdata1'),
            'Code' => $this->input->post('atextdata2'),
            'Discription' => $this->input->post('atextdata3'),
            'Images' => $Images,
            'Promotion' => $this->input->post('atextdata5'),
            'Price' => $this->input->post('atextdata6'),
            'Cost' => $this->input->post('atextdata7'),
            'IncludeVAT' => $this->input->post('atextdata8'),
            'Quantity' => $this->input->post('atextdata9'),
            'Idc' => $this->input->post('atextdata10'),
            'Detail' => $this->input->post('atextdata11'),
            'Warranty' => $this->input->post('atextdata12'),
            'Tophot' => $this->input->post('atextdata13'),
            'Startus' => $this->input->post('atextdata14'),
            'Createby' => $this->session->userdata('Administrator'),
            'Createdate' => date("Y/m/d H:i:s")

        );
        $this->Products_Model->create($data);

        $idproduct = $this->db->query("SELECT Idp FROM products ORDER BY Idp DESC LIMIT 1");
        
        $idp=0;
        
        foreach ($idproduct->result() as $row):
            $idp=$row->Idp;
            if ($idp>0) {
                $datai = array(
                'Urllink' => str_replace(base_url(), '',$this->input->post('aitextdata1')),
                'Idp' => $idp
                );
                $datai2 = array(
                    'Urllink' => str_replace(base_url(), '',$this->input->post('aitextdata2')),
                    'Idp' => $idp
                );
                $datai3 = array(
                    'Urllink' => str_replace(base_url(), '',$this->input->post('aitextdata3')),
                    'Idp' => $idp
                );

                $this->Productsima_Model->create($datai);
                $this->Productsima_Model->create($datai2);
                $this->Productsima_Model->create($datai3);
               
            }
        endforeach;

    }


    public function Edit()
    {
        
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Code' => $this->input->post('etextdata2'),
            'Discription' => $this->input->post('etextdata3'),
            'Images' => str_replace(base_url(), '',$this->input->post('etextdata4')),
            'Promotion' => $this->input->post('etextdata5'),
            'Price' => $this->input->post('etextdata6'),
            'Cost' => $this->input->post('etextdata7'),
            'IncludeVAT' => $this->input->post('etextdata8'),
            'Quantity' => $this->input->post('etextdata9'),
            'Idc' => $this->input->post('etextdata10'),
            'Detail' => $this->input->post('etextdata11'),
            'Warranty' => $this->input->post('etextdata12'),
            'Tophot' => $this->input->post('etextdata13'),

            'Startus' => $this->input->post('etextdata14'),
            'Modifyby' => $this->session->userdata('Administrator'),
            'Modifydate' => date("Y/m/d H:i:s")

        );
        if($this->input->post('etextid')){
            $Id = $this->input->post('etextid');
            $this->Products_Model->update($Id,$data);
        }

        $productsima = $this->db->query("SELECT Idi FROM productsima WHERE Idp=".$this->input->post('etextid'));
           
                $Idi=0;$tid=0;
                
                foreach ($productsima->result() as $row):
                    $Idi=$row->Idi;
                    if ($Idi>0) {
                        $tid+=1;
                        
                        if ($tid==1) {
                            $datai = array(
                            'Urllink' => str_replace(base_url(), '',$this->input->post('eitextdata1'))
                            );
                        }
                        if ($tid==2) {
                            $datai = array(
                            'Urllink' => str_replace(base_url(), '',$this->input->post('eitextdata2'))
                            );
                        }
                        if ($tid==3) {
                            $datai = array(
                            'Urllink' => str_replace(base_url(), '',$this->input->post('eitextdata3'))
                            );
                        }
                        
                       if($this->input->post('etextid')){
                            $Id=$row->Idi;
                            $this->Productsima_Model->update($Id,$datai);
                        }

                    }
                endforeach;
        
        
        
    }


   public function Delete()
   {
        
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Products_Model->delete($Id);
       
        }
        
        $productsima = $this->db->query("SELECT * FROM productsima WHERE IDP=".$this->input->post('textid'));
        
                foreach ($productsima->result() as $row):
                    $Id  = $row->Idi;
                    $this->Productsima_Model->delete($Id);
                endforeach;
    }

    public function Loadcategory()
    {
        
       
        $input['where'] = array(
            'Parentid' => $this->input->post('get_Parentid')
            );
        $tblcategory=$this->Category_Model->get_list($input);
        foreach ($tblcategory as $row):
            echo "<option value='".$row->Idc."'>".$row->Name."</option>";
        endforeach;
        

    }
    
}