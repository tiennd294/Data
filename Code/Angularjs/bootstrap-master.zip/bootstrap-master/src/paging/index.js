require('./paging');

var MODULE_NAME = 'ui.bootstrap.module.paging';

angular.module(MODULE_NAME, ['ui.bootstrap.paging']);

module.exports = MODULE_NAME;
