using System.ServiceProcess;
using System.Configuration.Install;
using System.ComponentModel;

[RunInstaller(true)]
public class ServiceInstallerExample : Installer {
	
    public ServiceInstallerExample() {
		
        ServiceProcessInstaller ServiceExampleProcess = 
            new ServiceProcessInstaller();
        ServiceExampleProcess.Account = ServiceAccount.LocalSystem;
	
        ServiceInstaller ServiceExampleInstaller = 
            new ServiceInstaller();
        ServiceExampleInstaller.DisplayName = 
            "C# Service Example";
        ServiceExampleInstaller.ServiceName = "ServiceExample";
        ServiceExampleInstaller.StartType = ServiceStartMode.Automatic;	
	
        Installers.Add(ServiceExampleInstaller);
        Installers.Add(ServiceExampleProcess);
    }
}
