using System;
using QuartzTypeLib;
using System.Windows.Forms;

public class ShowMovie : System.Windows.Forms.Form
{
	private System.Windows.Forms.PictureBox pictureBox1;
	private System.Windows.Forms.Button cmdOpen;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ShowMovie()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.cmdOpen = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// pictureBox1
		// 
		this.pictureBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.pictureBox1.Location = new System.Drawing.Point(8, 8);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(276, 244);
		this.pictureBox1.TabIndex = 0;
		this.pictureBox1.TabStop = false;
		this.pictureBox1.SizeChanged += new System.EventHandler(this.pictureBox1_SizeChanged);
		// 
		// cmdOpen
		// 
		this.cmdOpen.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.cmdOpen.Location = new System.Drawing.Point(188, 260);
		this.cmdOpen.Name = "cmdOpen";
		this.cmdOpen.Size = new System.Drawing.Size(96, 28);
		this.cmdOpen.TabIndex = 1;
		this.cmdOpen.Text = "Open";
		this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
		// 
		// ShowMovie
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 298);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.cmdOpen,
																		this.pictureBox1});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "ShowMovie";
		this.Text = "Show Movie";
		this.Closing += new System.ComponentModel.CancelEventHandler(this.ShowMovie_Closing);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new ShowMovie());
	}

	private const int WM_APP = 0x8000;
	private const int WM_GRAPHNOTIFY = WM_APP + 1;
	private const int EC_COMPLETE = 0x01;
	private const int WS_CHILD = 0x40000000;
	private const int WS_CLIPCHILDREN = 0x2000000;

	private IMediaControl mc = null;

	private IVideoWindow videoWindow = null;
	
	private void cmdOpen_Click(object sender, System.EventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = "Media Files|*.mpg;*.avi;*.wma;*.mov;*.wav;*.mp2;*.mp3|All Files|*.*";

		if (DialogResult.OK == openFileDialog.ShowDialog())
		{
			if (mc != null) mc.Stop();

			FilgraphManager graphManager = new FilgraphManager();
			graphManager.RenderFile(openFileDialog.FileName);

			try
			{
				videoWindow = (IVideoWindow)graphManager;
				videoWindow.Owner = (int) pictureBox1.Handle;
				videoWindow.WindowStyle = WS_CHILD | WS_CLIPCHILDREN;
				videoWindow.SetWindowPosition(pictureBox1.ClientRectangle.Left,
					pictureBox1.ClientRectangle.Top,
					pictureBox1.ClientRectangle.Width,
					pictureBox1.ClientRectangle.Height);
			}
			catch
			{
			}

			mc = (IMediaControl)graphManager;
			mc.Run();
		}
	}

	private void ShowMovie_Closing(object sender, System.ComponentModel.CancelEventArgs e)
	{
		if (mc != null) mc.Stop();
	}

	private void pictureBox1_SizeChanged(object sender, System.EventArgs e)
	{
		if (videoWindow != null)
		{
			try
			{
				videoWindow.SetWindowPosition(
					pictureBox1.ClientRectangle.Left,
					pictureBox1.ClientRectangle.Top,
					pictureBox1.ClientRectangle.Width,
					pictureBox1.ClientRectangle.Height);
			}
			catch 
			{
			}
		}
	}
}