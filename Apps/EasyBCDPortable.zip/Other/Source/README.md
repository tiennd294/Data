
### FOREMOST

This was originally created and developed by FukenGruven. FukenGruven is no longer active and/or has decided to retire. This package is now being maintained/developed by demon.devin ([Softables.tk/](http://softables.tk/))

--------------------

### NOTES -- BEST PRACTICES

1. Do **not** restart if prompted. _Always_ exit EasyBCDPortable first, then restart manually.

2. EasyBCD does not support Network or UNC Paths. All bootloader configurations must be done locally.

3. Some functions can only be accomplished in DOS, Safe Mode, or Offline; all of which are unsupported by PortableApps.

4. Windows XP does not have a bootloader. You'll have to download it and install it.

5. Backups has been redirected into: _..\Data\Backups_
   - Location can be changed in: _..\App\AppInfo\Launcher\EasyBCDPortable.ini_
   - Find `[FileWrite6]` and change `Value=%PAL:DataDir%\Backups`
   - Simply edit `%PAL:DataDir%\Backups` to desired, new location.

6. EasyBCD requires Microsoft .NET Framework 2.0 or 4.0.

--------------------

### TO RECOMPILE

**Launcher:**  
If you would like to recompile this portable, you will need to use the [PortableApps Compiler](https://github.com/demondevin/pac-man). Just copy and paste the `Languages.nsh` file located at _..\Other\Source_ into the following folder _..\PortableAppsCompiler\Other\Source_ and compile as you normally would.

**Installer:**  
If you would like to recompile the installer, the source code is located in _..\Other\Source\Installer_. You'll need some knowledge of NSIS to make any customizations.

--------------------

### PERSERVE
If there are any directories and/or files that you would like to preserve during reinstall or upgrades, you can do so by adding each file and/or folder in the `..\App\AppInfo\installer.ini` configuration file.

**Files Example:**
```ini
[FilesToPreserve]
PreserveFile1=App\file
```

**Directories Example:**
```ini	
[DirectoriesToPreserve]
PreserveDirectory1=App\directory
```

In addition, `[DirectoriesToPreserve]` & `[FilesToPreserve]` configurations are preserved.
