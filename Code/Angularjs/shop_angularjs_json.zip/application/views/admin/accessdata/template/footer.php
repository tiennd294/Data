
</div>
<div class="row-fluid">
  <div id="footer" class="span12"> 2016 &copy; Lovenovel </div>
</div>

</body>
</html>