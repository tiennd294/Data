using System.Reflection;
using System.Text.RegularExpressions;

public class CompiledRegexExample {

    public static void Main() {

        RegexCompilationInfo[] regexInfo = new RegexCompilationInfo[2];

        regexInfo[0] = new RegexCompilationInfo(@"^\d{4}$", 
            RegexOptions.Compiled, "PinRegex", "", true);

        regexInfo[1] = new RegexCompilationInfo( 
            @"^\d{4}-?\d{4}-?\d{4}-?\d{4}$", 
            RegexOptions.Compiled, "CreditCardRegex", "", true);

        AssemblyName assembly = new AssemblyName();
        assembly.Name = "MyRegEx";

        Regex.CompileToAssembly(regexInfo, assembly);
    }
}