<?php
 echo    '<div id=\'msSuccess\' style=\'margin-left: 24%;display:none;\'>'.
                '<form id="msSuccess" name="msError" method="post" action="">'.
                '<div class="alert alert-success alert-block" style=\'  width: 67%;\'>'.
                '<input type="submit" name="btnError" value="×" class="close"/>'.
                '<h4 class="alert-heading">Cập nhật dữ liệu thành công!</h4>'.
                'Dữ liệu đã được cập nhât. Click (x) để trở lại trang trước.'. 
                '</div>'.
                '</form>'.
                '</div>';

echo    '<div id=\'msWarning\' style=\'margin-left: 24%;display:none;\'>'.
                '<form id="msWarning" name="msError" method="post" action="">'.
                '<div class="alert alert-block" style=\'  width: 67%;\'> '.
                '<input type="submit" name="btnError" value="×" class="close"/>'.
                '<h4 class="alert-heading">Cảnh báo!</h4>'.
                'Chương trình chưa hoàn tất thực thi, đã có một vài câu lệnh chưa được xử lý. '.
                'Vui lòng liên hệ với quản trị viên để được trợ giúp! '.
                '</div>'.
                '</form>'.
                '</div>';

 echo    '<div id=\'msInfo\' style=\'margin-left: 24%;display:none;\'>'.
                '<form id="msInfo" name="msError" method="post" action="">'.
                '<div class="alert alert-info alert-block" style=\'  width: 67%;\'> '.
                '<input type="submit" name="btnError" value="×" class="close"/>'.
                '<h4 class="alert-heading">Infomation!</h4>'.
                'Bạn vui lòng liên hệ sweetlove10071991@gmail.com để được tư vấn về dịch vụ.'.
                ' </div>'.
                '</form>'.
                '</div>';

 echo    '<div id=\'msError\' style=\'margin-left: 24%;display:none;\'>'.
                '<form id="msError" name="msError" method="post" action="">'.
                '<div class="alert alert-error alert-block" style=\'  width: 67%;\'> '.
                '<input type="submit" name="btnError" value="×" class="close"/>'.
                '<h4 class="alert-heading">Cập nhật dữ liệu thất bại!</h4>'.
                'Dữ liệu chưa được cập nhật. Vui lòng thử nhập lai! '.
                '</div>'.
                '</form>'.
                '</div>';