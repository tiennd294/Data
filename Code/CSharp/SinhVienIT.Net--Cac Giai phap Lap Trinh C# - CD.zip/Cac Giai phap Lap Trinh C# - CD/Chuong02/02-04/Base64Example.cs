using System;
using System.IO;
using System.Text;

public class Base64Example {

    public static byte[] DecimalToByteArray (decimal src) {

        using (MemoryStream stream = new MemoryStream()) {

            using (BinaryWriter writer = new BinaryWriter(stream)) {

                writer.Write(src);

                return stream.ToArray();
            }
        }
    }

    public static decimal ByteArrayToDecimal (byte[] src) {

        using (MemoryStream stream = new MemoryStream(src)) {

            using (BinaryReader reader = new BinaryReader(stream)) {

                return reader.ReadDecimal();
            }
        }
    }

public static string StringToBase64 (string src) {

    byte[] b = Encoding.Unicode.GetBytes(src);

    return Convert.ToBase64String(b);
}

public static string Base64ToString (string src) {

    byte[] b = Convert.FromBase64String(src);

    return Encoding.Unicode.GetString(b);
}

public static string DecimalToBase64 (decimal src) {

    byte[] b = DecimalToByteArray(src);

    return Convert.ToBase64String(b);
}

public static decimal Base64ToDecimal (string src) {

    byte[] b = Convert.FromBase64String(src);

    return ByteArrayToDecimal(b);
}

public static string IntToBase64 (int src) {

    byte[] b = BitConverter.GetBytes(src);

    return Convert.ToBase64String(b);
}

public static int Base64ToInt (string src) {

    byte[] b = Convert.FromBase64String(src);

    return BitConverter.ToInt32(b,0);
}

    public static void Main() {

        Console.WriteLine(StringToBase64
            ("Welcome to .NET Framework"));
        Console.WriteLine(Base64ToString("VwBlAGwAYwBvAG0AZQAgAHQAbwAgAC4ATgBFAFQAIABGAHIAYQBtAGUAdwBvAHIAawA="));

        Console.WriteLine(DecimalToBase64(285998345545.563846696m));
        Console.WriteLine(Base64ToDecimal("KDjBUP07BoEPAAAAAAAJAA=="));

        Console.WriteLine(IntToBase64(35789));
        Console.WriteLine(Base64ToInt("zYsAAA=="));

		Console.Read();
    }
}