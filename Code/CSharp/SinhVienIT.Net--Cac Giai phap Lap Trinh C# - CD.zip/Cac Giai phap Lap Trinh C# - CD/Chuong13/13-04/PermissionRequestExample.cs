using System.Net;
using System.Security.Permissions;

[assembly:SocketPermission(SecurityAction.RequestMinimum, 
    Access = "Connect", Host = "www.fabrikam.com",
    Port = "3538", Transport = "Tcp")]

[assembly:SecurityPermission(SecurityAction.RequestMinimum, 
    UnmanagedCode = true)]

public class PermissionRequestExample {

    public static void Main() {   
        // ...
    }
}