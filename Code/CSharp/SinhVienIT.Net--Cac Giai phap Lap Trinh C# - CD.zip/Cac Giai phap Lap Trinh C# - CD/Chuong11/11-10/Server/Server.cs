using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using SharedComponent;

public class TcpServerTest
{
	private static void Main()
	{
		CustomTcpListener listener = new CustomTcpListener(IPAddress.Parse(
			"127.0.0.1"), 8000);

		listener.Socket.SetSocketOption(SocketOptionLevel.Socket,
			SocketOptionName.ReceiveTimeout, 1000);
        
		Console.WriteLine("About to initialize port.");
		listener.Start();
        Console.WriteLine("Listening for a connection...");
        
		try
		{
			Socket socket = listener.AcceptSocket();

			Console.WriteLine("Connection accepted.");
            
			NetworkStream stream = new NetworkStream(socket);
			
			BinaryWriter w = new BinaryWriter(stream);
            
			BinaryReader r = new BinaryReader(stream);
            
			if (r.ReadString() == ClientMessages.RequestConnect)
			{
				w.Write(ServerMessages.AcknowledgeOK);
				Console.WriteLine("Connection completed.");
                
				Console.Write("The client is from IP address: ");
				Console.WriteLine(((IPEndPoint)socket.RemoteEndPoint).Address.ToString());
				Console.Write("The client uses local port: ");
				Console.WriteLine(((IPEndPoint)socket.RemoteEndPoint).Port.ToString());

				while (r.ReadString() != ClientMessages.Disconnect)
				{}
				
				Console.WriteLine();
				Console.WriteLine("Disconnect request received.");
				w.Write(ServerMessages.Disconnect);
			}
			else
			{
				Console.WriteLine("Could not complete connection.");
			}
			
			socket.Close();
			Console.WriteLine("Connection closed.");
			
			listener.Stop();
			Console.WriteLine("Listener stopped.");
		}
		catch (Exception err)
		{
			Console.WriteLine(err.ToString());
		}
    
		Console.ReadLine();
	}
}

public class CustomTcpListener : TcpListener
{
	public Socket Socket
	{
		get
		{
			return base.Server;
		}
	}

	public CustomTcpListener(IPAddress ip, int port) : base(ip, port)
	{}
}