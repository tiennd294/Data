<?php
defined('BASEPATH') OR exit('No direct script access allowed');

Class Defaults extends MY_Controller 
{
	public function __construct()
    {
        parent::__construct();
        $this->load->model('Products_Model');
        $this->load->library('cart');
        $carts=$this->cart->contents();
        $total_items = $this->cart->total_items();
        
        $this->data['carts'] = $carts;
        $this->data['total_items']  =$total_items;
        
        $this->load->model('Category_Model');
        $input = array();
        $input['where'] = array(
            'Startus' => 'on',
            'Classify' => 2
        );
        $input['order'] = array('Display','asc');
        $tblcategory=$this->Category_Model->get_list($input);
        $this->data['tblcategory'] = $tblcategory;

    }
	public function index()
	{
		
		$input = array();
        $tblproduct=$this->Products_Model->get_list($input);
        $this->data['tblproduct'] = $tblproduct;
		$this->data['urldata'] = 'site/defaults/index';
		$this->load->view('site/layout', $this->data);
	}

	public function SetCart()
	{

		
		if($this->input->post('Idp'))
        $id = $this->input->post('Idp');
        $product = $this->Products_Model->get_info($id);
        if(!$product)
        {
            redirect();
        }
        //tong so san pham
        $qty = 1;
        $Price = $product->Price;
        
        
        //thong tin them vao gio hang
        $data = array();
        $data['id'] = $product->Idp;
        $data['qty'] = $qty;
        $data['name'] = url_title($product->Name);
        $data['image_link']  = $product->Images;
        $data['price'] = $Price;
        //$data['Subtotal') = $Subtotal;
        $this->cart->insert($data);

	}

	public function showcart()
    {
        $this->data['urldata']  ='site/defaults/cart';
        $this->load->view('site/layout', $this->data);
    }

    public function UpdateCart()
    {
        
        $carts = $this->cart->contents();
        foreach ($carts as $key => $row)
        {
        	
        	if ( $row['id'] == $this->input->post('Idp') ) {
        	
        		
	            $total_qty = $this->input->post('Quantity');
	            $data = array();
	            $data['rowid'] = $key;
	            $data['qty'] = $total_qty;
	            if($this->cart->update($data))
	            {
	            	echo 'true';break;
	            }else echo "false";
        	}
        }
    }

    public function RemoveCart()
    {
        
        $carts = $this->cart->contents();
        foreach ($carts as $key => $row)
        {
        	
        	if ( $row['id'] == $this->input->post('Idp') ) {

	            $data = array();
	            $data['rowid'] = $key;
	            $data['qty'] = 0;
	            if($this->cart->update($data))
	            {
	            	echo 'true';break;
	            }else echo "false";
        	}
        }
    }


    public function Checkout()
    {
    	$this->data['urldata']  ='site/defaults/checkout';
        $this->load->view('site/layout', $this->data);   
    }

    public function AddCart()
    {
       

    	$tg='';
    	if ( $this->input->post('Email') ) {
            $data = array(
            'Email' => $this->input->post('Email'),
            'Name' => $this->input->post('Name'),
            'Phone' => $this->input->post('Phone'),
            'Address' => $this->input->post('Address'),
            'Startus' => 'on'
            );
            
            if ($this->input->post('Email')!=''&&$this->input->post('Name')!=''&&$this->input->post('Phone')!=''&&$this->input->post('Address')!='') {

            	$this->load->model('User_Model');
		        $Email = $this->input->post('Email');
		        $user = $this->User_Model->get_info($Email);
		        if(!$user)
                {
		            $this->User_Model->create($data);
		            
		        }
                
                    $code=substr(strtoupper(md5((time().$this->input->post('Email')))),3,13);

                    $carts = $this->cart->contents();
                    $total_items = $this->cart->total_items();
                if ($total_items>0) {
                        
                    
                    $i=0;
			        foreach ($carts as $key => $row)
			        {
                            $Discription='';

                            if ($i==0) {
                                $Discription=$this->input->post('Discription');
                             } 
                            $data2 = array(
                                'Idp' => $row['id'],
                                'Product_name' => $row['name'],
                                'Product_code' => $code,
                                'Product_price' => $row['price'],
                                'Product_img' => $row['image_link'],
                                'Product_quantity' => $row['qty'],
                                'Product_note' => $Discription,
                                'Createby' => $this->input->post('Email'),
                                'Createdate' => date("Y/m/d H:i:s")
                                );
                            $this->load->model('Products_Cart_Model');
                            $this->Products_Cart_Model->create($data2);
                            $i++;
                    }
                }
                
            }
            $this->cart->destroy();
        }     
        //echo $tg;
    }

    public function ShowProduct()
    {
        if ((int)$this->uri->rsegment(3)>0){
            
            $this->load->model('Category_Model');
            $input = array();
            $input['where'] = array(
            'Idc' => $this->uri->rsegment(3)
            );

            $total_rows = $this->Products_Model->get_total($input);
            
            //load ra thu vien phan trang
            $this->load->library('pagination');
            $config = array();
            $config['total_rows'] = $total_rows;//tong tat ca cac san pham tren website
            $config['base_url']   = base_url('defaults/ShowProduct/'.$this->uri->rsegment(3)); //link hien thi ra danh sach san pham
            $config['per_page']   = 40;//so luong san pham hien thi tren 1 trang
            $config['uri_segment'] = 4;//phan doan hien thi ra so trang tren url
            $config['next_link']   = 'Next';
            $config['last_link']   = 'Last';
            $config['prev_link']   = 'Previous';
            $config['first_link']   = 'First';
            //khoi tao cac cau hinh phan trang
            $this->pagination->initialize($config);
            
            $segment = $this->uri->segment(4);
            $segment = intval($segment);
            
            $input['limit'] = array($config['per_page'], $segment);

            $tblproduct=$this->Products_Model->get_list($input);
            $maxtotal=$this->Products_Model->get_total($input);
             $input['where'] = array(
            'Idc' => $this->uri->rsegment(3),
            'Classify' => 1
            );
            $category=$this->Category_Model->get_list($input);
            $this->data['category'] = $category;
            $this->data['maxtotal'] = $maxtotal;
            $this->data['tblproduct'] = $tblproduct;
            $this->data['urldata']  ='site/defaults/product';
            $this->load->view('site/layout', $this->data);   
        }
    }


    public function ShowProductid()
    {
        if ((int)$this->uri->rsegment(3)>0){
            
            $this->load->model('Productsima_Model');
            $input = array();
            $input['where'] = array(
            'Idp' => $this->uri->rsegment(3)
            );
            $tblproduct=$this->Products_Model->get_list($input);
            $maxtotal=$this->Products_Model->get_total($input);
            $tbnimage=$this->Productsima_Model->get_list($input);
            
            $this->data['tbnimage'] = $tbnimage;
            $this->data['tblproduct'] = $tblproduct;
            $this->data['urldata']  ='site/defaults/productid';
            $this->load->view('site/layout', $this->data);   
        }
    }


    public function About()
    {
        
        $this->load->model('About_Model');

        $input = array();
        $input['where'] = array('Startus' => 'on');
        $input['limit'] = array(1,0);
        $tblabout=$this->About_Model->get_list($input);

        $this->data['tblabout'] = $tblabout;
        $this->data['urldata'] = 'site/defaults/about';
        $this->load->view('site/layout', $this->data);
    }

    public function Contact()
    {
        
        $this->load->model('Contact_Model');

        $input = array();
        $input['where'] = array('Startus' => 'on');
        $input['limit'] = array(1,0);
        $tblcontact=$this->Contact_Model->get_list($input);

        $this->data['tblcontact'] = $tblcontact;
        $this->data['urldata'] = 'site/defaults/contact';
        $this->load->view('site/layout', $this->data);
    }

    public function AddContact()
    {
        $data = array(
            'Name' => $this->input->post('Name'),
            'Phone' => $this->input->post('Phone'),
            'Email' => $this->input->post('Email'),
            'Address' => $this->input->post('Address'),
            'Content' => $this->input->post('Content'),
            'Startus' => '',
            'Createdate' => date("Y/m/d H:i:s")
        );
        $this->load->model('Feedback_Model');   
        if($this->Feedback_Model->create($data))
            echo "true";           
    }


    public function Blog()
    {
        
        $this->load->model('News_Model');

        $input = array();
        $input['where'] = array('Startus' => 'on');
        $input['limit'] = array(10,0);
        $tblnews=$this->News_Model->get_list($input);

        $this->data['tblnews'] = $tblnews;
        $this->data['urldata'] = 'site/defaults/blog';
        $this->load->view('site/layout', $this->data);
    }


    public function Blogct()
    {
        
        if ((int)$this->uri->rsegment(3)>0){
        $this->load->model('News_Model');
        $input['where'] = array(
            'Idc' => $this->uri->rsegment(3)
        );
        $total_rows = $this->News_Model->get_total($input);
        
        //load ra thu vien phan trang
        $this->load->library('pagination');
        $config = array();
        $config['total_rows'] = $total_rows;//tong tat ca cac san pham tren website
        $config['base_url']   = base_url('defaults/blogct/'.$this->uri->rsegment(3)); //link hien thi ra danh sach san pham
        $config['per_page']   = 10;//so luong san pham hien thi tren 1 trang
        $config['uri_segment'] = 4;//phan doan hien thi ra so trang tren url
        $config['next_link']   = 'Next';
        $config['last_link']   = 'Last';
        $config['prev_link']   = 'Previous';
        $config['first_link']   = 'First';
        //khoi tao cac cau hinh phan trang
        $this->pagination->initialize($config);
        
        $segment = $this->uri->segment(4);
        $segment = intval($segment);
        
        $input = array();
        $input['limit'] = array($config['per_page'], $segment);


        $input['where'] = array(
            'Idc' => $this->uri->rsegment(3),
            'Startus' => 'on'
        );
        $tblnews=$this->News_Model->get_list($input);
        
        $this->data['tblnews'] = $tblnews;
        $this->data['urldata'] = 'site/defaults/blogct';
        $this->load->view('site/layout', $this->data);
        }

    }



    public function Blogpost()
    {
        $this->load->model('News_Model');
        
        if ((int)$this->uri->rsegment(3)>0){
        

        $input = array();
        $input['where'] = array(
            'Idn' => $this->uri->rsegment(3),
            'Startus' => 'on'
        );
        $tblnews=$this->News_Model->get_list($input);
        
        $this->data['tblnews'] = $tblnews;
        $this->data['urldata'] = 'site/defaults/blogpost';
        $this->load->view('site/layout', $this->data);
        }
    }

}
