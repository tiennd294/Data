using System;
using System.Threading;

public class RunAtExample {

    private static void TimerHandler(object state) {

        Console.WriteLine("{0} : Timer expired",
            DateTime.Now.ToString("HH:mm:ss.ffff"));
    }

    public static void RunAt(DateTime execTime) {

        TimeSpan waitTime = execTime - DateTime.Now;

        if (waitTime < new TimeSpan(0)) waitTime = new TimeSpan(0);

        TimerCallback handler = new TimerCallback(TimerHandler);

        new Timer(handler, null, waitTime, new TimeSpan(-1));
    }

    public static void Main(string[] args) {

        DateTime execTime;

        if (args.Length > 0) {

            try {

                execTime = DateTime.ParseExact(args[0],"r", null);

                Console.WriteLine("Current time   : " +
                    DateTime.Now.ToString("r"));

                Console.WriteLine("Execution time : " +
                    execTime.ToString("r"));

                RunAt(execTime);

            } catch (FormatException) {
 
                Console.WriteLine("Execution time must be of the format:" +
                    " ddd, dd MMM yyyy HH':'mm':'ss 'GMT'");
            }

            Console.WriteLine("Main method complete. Press Enter.");
            Console.ReadLine();

        } else {

            Console.WriteLine("Specify the time you want the method to" +
                " execute using the format : " + 
                " ddd, dd MMM yyyy HH':'mm':'ss 'GMT'");
			Console.ReadLine();
        }
    }
}