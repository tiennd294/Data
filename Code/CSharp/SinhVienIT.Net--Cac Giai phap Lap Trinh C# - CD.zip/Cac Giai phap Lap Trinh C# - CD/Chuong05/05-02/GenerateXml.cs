using System;
using System.Xml;

public class GenerateXml
{
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	private static void Main(string[] args)
	{
		XmlDocument doc = new XmlDocument();
		XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
		doc.AppendChild(docNode);

		XmlNode productsNode = doc.CreateElement("products");
		doc.AppendChild(productsNode);

		XmlNode productNode = doc.CreateElement("product");
		XmlAttribute productAttribute = doc.CreateAttribute("id");
		productAttribute.Value = "1001";
		productNode.Attributes.Append(productAttribute);
	    productsNode.AppendChild(productNode);

		XmlNode nameNode = doc.CreateElement("productName");
		nameNode.AppendChild(doc.CreateTextNode("Gourmet Coffee"));
		productNode.AppendChild(nameNode);
		XmlNode priceNode = doc.CreateElement("productPrice");
		priceNode.AppendChild(doc.CreateTextNode("0.99"));
		productNode.AppendChild(priceNode);

		productNode = doc.CreateElement("product");
		productAttribute = doc.CreateAttribute("id");
		productAttribute.Value = "1002";
		productNode.Attributes.Append(productAttribute);
		productsNode.AppendChild(productNode);
		nameNode = doc.CreateElement("productName");
		nameNode.AppendChild(doc.CreateTextNode("Blue China Tea Pot"));
		productNode.AppendChild(nameNode);
		priceNode = doc.CreateElement("productPrice");
		priceNode.AppendChild(doc.CreateTextNode("102.99"));
		productNode.AppendChild(priceNode);

		doc.Save(Console.Out);
		Console.ReadLine();
	}
}