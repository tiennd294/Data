function PrintButtonClick()
{
	if( typeof(frmRatings)=="object" ){
		var oPrint = frmRatings.document.getElementById("Print");
		if(oPrint != null) oPrint.click();
	}
	else
	{
		OnPrintPage();
	}
}
function ToggleMenu(oButton, oItems)
{
	if (oItems.style.display == "none")	
	{
		oItems.style.display = "block";
		oButton.src = "/msdnmag/images/minus.gif";
	}	
	else 
	{
		oItems.style.display = "none";
		oButton.src = "/msdnmag/images/plus.gif";
	}
	return;
}

function OpenMenu(oButton, oItems)
{
	if (oItems.style.display == "none")	
	{
		oItems.style.display = "block";
		oButton.src = "/msdnmag/images/minus.gif";
	}
	return;
}

function OnPrintPage(){
	var oWnd = window;
	var oDoc = oWnd.document;
	var strLoc = "default.aspx?print=true";
	if (window.navigator.userAgent.indexOf("MSIE ")!=-1 && navigator.appVersion.substr(0, 1) >= 4){
		if( oWnd.printHiddenFrame == null){
			oDoc.body.insertAdjacentHTML("beforeEnd", "<iframe name='printHiddenFrame' width='0' height='0'></iframe>");
			framedoc = oWnd.printHiddenFrame.document;
			framedoc.open();
			framedoc.write(
				"<frameset name=test onload='printMe.focus();printMe.print();' rows=\"100%\">" +
				"<frame name=printMe src=\""+strLoc+"\">" +
				"</frameset>");
			framedoc.close();
		}
		else{
			oWnd.printHiddenFrame.printMe.focus();
			oWnd.printHiddenFrame.printMe.print();
		}
	}		
	else{
		oWnd.location.href = strLoc;
	}
	return true;
}

function OpenUrl(url)
{
	var childWin;
	childWin = window.open(url,'window','height=300,width=640,status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');
	childWin.focus();
	//return false;
}

var x=0;
function change()
{
	var coll = document.body.getElementsByTagName("DIV");
	var coll2 = document.body.getElementsByTagName("IMG");
	if (x!=1)
	{
		for (i=0; i<coll.length; i++)
		{
			if (coll[i].style.display=='none' && coll[i].id.indexOf("menu")>-1)
				coll[i].style.display='block';
		}
		button1.value=" Collapse All "
		x=1
		for (i=0; i<coll2.length; i++)
		{
			if (coll2[i].id.indexOf("btns")>-1)
				coll2[i].src='/msdnmag/images/minus.gif';
		}
	}
	else 
	{
		for (i=0; i<coll.length; i++)
		{
			if (coll[i].style.display=='block' && coll[i].id.indexOf("menu")>-1)
				coll[i].style.display='none';
		}
		button1.value=" Expand All "
		x=0
		for (i=0; i<coll2.length; i++)
		{
			if (coll2[i].id.indexOf("btns")>-1)
				coll2[i].src='/msdnmag/images/plus.gif';
		}
	}
}

/*
function AuthorSearch(author)
{
	var reSpace = /\s/
	author=author.replace(reSpace,"%20");
	window.location.href="/msdnmag/find/default.aspx?type=Au&phrase=" + author;
}

function Go(value)
{
   if(value!="0" && value!=null)
   {
      return true;     
   }
   else
   {
      return false;
   }
}

function Jump(value)
{
	var re = /\d{6}/

   if(re.test(value)&&value.length==6)
   {
      return true;     
   }
   else
   {
		alert("Please enter a valid QuickJump Code");
		return false;
   }
}
*/