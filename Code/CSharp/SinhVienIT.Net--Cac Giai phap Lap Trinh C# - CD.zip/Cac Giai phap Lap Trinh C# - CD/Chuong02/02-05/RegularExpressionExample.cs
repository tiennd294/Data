using System;
using System.Text.RegularExpressions;

public class RegularExpressionExample
{

    public static bool ValidateInput(string regex, string input) {

        Regex r = new Regex(regex);

        return r.IsMatch(input);
    }

    public static void Main(string[] args) {

        Console.WriteLine("Regular Expression: {0}", args[0]);
        Console.WriteLine("Input: {0}", args[1]); 
        Console.WriteLine("Valid = {0}", ValidateInput(args[0], args[1]));

		Console.Read();
    }
}
