public class CASOnOffExample {

    public static void Main() {
    
        System.Security.SecurityManager.SecurityEnabled = false;
        
        System.Security.SecurityManager.SavePolicy();
        
        System.Security.SecurityManager.SecurityEnabled = true;
        
        System.Security.SecurityManager.SavePolicy();
    }
}
