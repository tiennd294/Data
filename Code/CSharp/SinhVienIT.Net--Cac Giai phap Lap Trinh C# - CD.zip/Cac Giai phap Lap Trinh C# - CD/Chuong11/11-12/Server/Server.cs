using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using SharedComponent;

public class TcpServerTest
{
	private static void Main()
	{
		FileStream fs = new FileStream("test.bin", FileMode.Create);
		fs.SetLength(100000);
		fs.Close();

		TcpListener listener = new TcpListener(8000);
        
		Console.WriteLine("About to initialize port.");
		listener.Start();
        Console.WriteLine("Listening for a connection...");
        
		int clientNum = 0;
		while (true)
		{
			try 
			{
				TcpClient client = listener.AcceptTcpClient();
				Console.WriteLine("Server: Connection accepted.");

				clientNum++;
				ClientHandler handler = new ClientHandler(client, "Client " +
					clientNum.ToString());

				Thread handlerThread = 
					new Thread(new ThreadStart(handler.Start));
				handlerThread.IsBackground = true;
				handlerThread.Start();

			}
			catch (Exception err) 
			{
				Console.WriteLine(err.ToString());
			}
		}
	}
}

public class ClientHandler 
{
	private TcpClient client;
	private string ID;

	private int bufferSize = 2048;

	private byte[] buffer;

	private FileStream fileStream;

	private NetworkStream networkStream;

	private bool fileStop = false;

	public ClientHandler(TcpClient client, string ID) 
	{
		this.buffer = new byte[bufferSize];
		this.client = client;
		this.ID = ID;
	}

	public void Start() 
	{
		networkStream = client.GetStream();

		BinaryWriter w = new BinaryWriter(networkStream);
		BinaryReader r = new BinaryReader(networkStream);

		if (r.ReadString() == ClientMessages.RequestConnect) 
		{
			w.Write(ServerMessages.AcknowledgeOK);
			Console.WriteLine(ID + ": Connection completed.");

			string message = "";
			while (message != ClientMessages.Disconnect)
			{
				message = r.ReadString();
				if (message == ClientMessages.RequestData)
				{
					fileStream = new FileStream("test.bin", FileMode.Open);

					w.Write(fileStream.Length.ToString());

					StreamData(null);						
				}
			}
			fileStop = true;
			Console.WriteLine(ID + ": Disconnect request received.");
		}
		else 
		{
			Console.WriteLine(ID + ": Could not complete connection.");
		}

		client.Close();
		Console.WriteLine(ID + ": Client connection closed.");

		Console.ReadLine();
	}


	private void StreamData(IAsyncResult asyncResult) 
	{
		if (fileStop == true) {
			fileStop = false;
			return;
		}

		if (asyncResult != null)
		{
			networkStream.EndWrite(asyncResult);
		}

		int bytesRead = fileStream.Read(buffer, 0, buffer.Length);

		if (bytesRead > 0) 
		{
			Console.WriteLine("Streaming new block.");

			networkStream.BeginWrite(buffer, 0, buffer.Length,
				new AsyncCallback(StreamData), null);
		}
		else 
		{
			Console.WriteLine("File streaming complete.");
			fileStream.Close();
		}
	}

}