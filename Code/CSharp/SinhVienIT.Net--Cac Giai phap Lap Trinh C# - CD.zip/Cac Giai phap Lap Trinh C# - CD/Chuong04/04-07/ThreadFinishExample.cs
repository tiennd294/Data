using System;
using System.Threading;

public class ThreadFinishExample {

    private static void DisplayMessage() {

        for (int count = 0; count < 5; count++) {

            Console.WriteLine("{0} : Second thread",  
                DateTime.Now.ToString("HH:mm:ss.ffff"));

            Thread.Sleep(1000);
        }
    }

    public static void Main() {

        ThreadStart method = new ThreadStart(DisplayMessage);

        Thread thread = new Thread(method);

        Console.WriteLine("{0} : Starting second thread.",  
            DateTime.Now.ToString("HH:mm:ss.ffff"));

        thread.Start();

        if (!thread.Join(3000)) {

            Console.WriteLine("{0} : Join timed out !!",  
                DateTime.Now.ToString("HH:mm:ss.ffff"));
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}