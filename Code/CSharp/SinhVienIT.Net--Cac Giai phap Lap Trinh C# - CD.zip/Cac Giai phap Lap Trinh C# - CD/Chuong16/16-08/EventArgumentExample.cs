using System;

[Serializable]
public sealed class MailReceivedEventArgs : EventArgs {

    private readonly string from;
    private readonly string subject;

    public MailReceivedEventArgs(string from, string subject) {

        this.from = from;
        this.subject = subject;
	}

    public string From { get { return from; } }
    public string Subject { get { return subject; } }

    public static void Main() {

        MailReceivedEventArgs args = new MailReceivedEventArgs("Bluewind Thai", "Your book");

        Console.WriteLine("From: {0}, Subject: {1}", args.From, args.Subject);
		Console.ReadLine();
    }
}
