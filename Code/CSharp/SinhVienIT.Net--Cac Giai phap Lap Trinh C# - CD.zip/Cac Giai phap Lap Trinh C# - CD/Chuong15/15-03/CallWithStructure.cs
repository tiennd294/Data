using System;
using System.Runtime.InteropServices;

public class CallWithStructure
{
	[StructLayout(LayoutKind.Sequential)]
	public class OSVersionInfo 
	{
		public int dwOSVersionInfoSize;
		public int dwMajorVersion;
		public int dwMinorVersion;
		public int dwBuildNumber;
		public int dwPlatformId;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=128)]    
		public String szCSDVersion;
	}


	[DllImport("kernel32.dll")]
	public static extern bool GetVersionEx([In, Out] OSVersionInfo osvi);
	
	private static void Main()
	{
		OSVersionInfo osvi = new OSVersionInfo();
		osvi.dwOSVersionInfoSize = Marshal.SizeOf(osvi);

		GetVersionEx(osvi);
		
		Console.WriteLine("Class size: " + osvi.dwOSVersionInfoSize);
		Console.WriteLine("Major Version: " + osvi.dwMajorVersion);
		Console.WriteLine("Minor Version: " + osvi.dwMinorVersion);
		Console.WriteLine("Build Number: " + osvi.dwBuildNumber);
		Console.WriteLine("Platform Id: " + osvi.dwPlatformId);
		Console.WriteLine("CSD Version: " + osvi.szCSDVersion);
		Console.WriteLine("Platform: " + Environment.OSVersion.Platform);
		Console.WriteLine( "Version: " + Environment.OSVersion.Version);
		Console.ReadLine();
	}
}