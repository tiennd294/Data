public class AssemblyEvidenceExample {

    public static void Main() {
            	
        System.Security.Policy.Site siteEvidence = 
            new System.Security.Policy.Site("www.microsoft.com");
        System.Security.Policy.Zone zoneEvidence = 
            new System.Security.Policy.Zone(System.Security.SecurityZone.Trusted);

        System.Security.Policy.Evidence evidence = 
            new System.Security.Policy.Evidence();

        evidence.AddHost(siteEvidence);
        evidence.AddHost(zoneEvidence);

        System.Reflection.Assembly assembly = 
            System.Reflection.Assembly.Load("SomeAssembly", evidence);
            
        System.Collections.IEnumerator x = assembly.Evidence.GetHostEnumerator();		
        System.Console.WriteLine("HOST EVIDENCE COLLECTION:");
        while(x.MoveNext()) {
            System.Console.WriteLine(x.Current.ToString());
        }

        System.Console.ReadLine();
    }
}
