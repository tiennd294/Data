using System;
using System.IO;
using System.Text;

public class CharacterEncodingExample {

    public static void Main() {
        
        using (StreamWriter output = new StreamWriter("output.txt")) {

            string srcString = "Area = \u03A0r^2";
            output.WriteLine("Source Text : " + srcString);

            byte[] utf16String = Encoding.Unicode.GetBytes(srcString);
            output.WriteLine("UTF-16 Bytes: {0}", 
                BitConverter.ToString(utf16String));

            byte[] utf8String = Encoding.UTF8.GetBytes(srcString);
            byte[] asciiString = Encoding.ASCII.GetBytes(srcString);
   
            output.WriteLine("UTF-8  Bytes: {0}", 
                BitConverter.ToString(utf8String));
            output.WriteLine("ASCII  Bytes: {0}", 
                BitConverter.ToString(asciiString));

            output.WriteLine("UTF-8  Text : {0}", 
                Encoding.UTF8.GetString(utf8String));
            output.WriteLine("ASCII  Text : {0}", 
                Encoding.ASCII.GetString(asciiString));

            output.Flush();
            output.Close();
        }
    }
}
