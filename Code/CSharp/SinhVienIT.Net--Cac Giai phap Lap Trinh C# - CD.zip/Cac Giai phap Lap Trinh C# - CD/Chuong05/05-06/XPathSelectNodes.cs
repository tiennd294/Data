using System;
using System.Xml;

public class XPathSelectNodes
{
	[STAThread]
	private static void Main()
	{
		XmlDocument doc = new XmlDocument();
		doc.Load("orders.xml");

		XmlNodeList nodes = doc.SelectNodes("/Order/Items/Item/Name");
        
		foreach (XmlNode node in nodes)
		{
			Console.WriteLine(node.InnerText);
		}
    
		Console.ReadLine();
	}
}
