<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Slides extends MY_Controller
{
     public function __construct()
    {
        parent::__construct();
        $this->load->model('Slides_Model');
    }

    public function Index()
    {
        $input = array();
        $tblslides=$this->Slides_Model->get_list($input);
        $tblmenu=$this->Slides_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Slides/slides',
            'tblslides' => $tblslides,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }


    public function Add()
    {
        $data = array(
            'Name' => $this->input->post('atextdata1'),
            'Detail' => $this->input->post('atextdata2'),
            'Images' => str_replace(base_url(), '',$this->input->post('atextdata3')),
            'Links' => $this->input->post('atextdata4'),
            'Display' => $this->input->post('atextdata5'),
            'Classify' => $this->input->post('atextdata6'),
            'Startus' => $this->input->post('atextdata7')
        );
       $this->Slides_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Detail' => $this->input->post('etextdata2'),
            'Images' => str_replace(base_url(), '',$this->input->post('etextdata3')),
            'Links' => $this->input->post('etextdata4'),
            'Display' => $this->input->post('etextdata5'),
            'Classify' => $this->input->post('etextdata6'),
            'Startus' => $this->input->post('etextdata7')
        );
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Slides_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Slides_Model->delete($Id);
       
        }
    }
}