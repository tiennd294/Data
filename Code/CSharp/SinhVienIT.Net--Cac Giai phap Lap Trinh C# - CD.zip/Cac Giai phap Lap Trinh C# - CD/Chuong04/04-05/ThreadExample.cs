using System;
using System.Threading;

public class ThreadExample {

    private int iterations;
    private string message;
    private int delay;

    public ThreadExample(int iterations, string message, int delay) {

        this.iterations = iterations;
        this.message = message;
        this.delay = delay;
    }

	public void Start() {

        ThreadStart method = new ThreadStart(this.DisplayMessage);

        Thread thread = new Thread(method);

        Console.WriteLine("{0} : Starting new thread.",  
            DateTime.Now.ToString("HH:mm:ss.ffff"));

        thread.Start();
    }

    private void DisplayMessage() {

        for (int count = 0; count < iterations; count++) {

            Console.WriteLine("{0} : {1}",  
                DateTime.Now.ToString("HH:mm:ss.ffff"), message);

            Thread.Sleep(delay);
        }
    }

    public static void Main() {

        ThreadExample example = 
            new ThreadExample(5, "A thread example.", 500);

        example.Start();

        for (int count = 0; count < 13; count++) {
            Console.WriteLine("{0} : Continue processing...", 
                DateTime.Now.ToString("HH:mm:ss.ffff"));
            Thread.Sleep(200);
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}
