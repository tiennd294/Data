<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Products_Cart extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Products_Cart_Model');
    }

    public function Index()
    {
        $input = array();
        $tblcart=$this->Products_Cart_Model->get_list($input);
        $tblmenu=$this->Products_Cart_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Products_Cart/products_cart',
            'tblcart' => $tblcart,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

  

    public function Add()
    {
        $data = array(
            'Idp' => $this->input->post('atextdata1'),
            'Product_code' => $this->input->post('atextdata2'),
            'Product_name' => $this->input->post('atextdata3'),

            'Product_img' => str_replace(base_url(), '',$this->input->post('atextdata4')),
            'Product_price' => $this->input->post('atextdata5'),
            'Product_quantity' => $this->input->post('atextdata6'),
            'Product_note' => $this->input->post('atextdata7'),
            'Createby' => $this->session->userdata('Administrator'),
            'Createdate' => date("Y/m/d H:i:s")

        );
        $this->Products_Cart_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Idp' => $this->input->post('etextdata1'),
            'Product_code' => $this->input->post('etextdata2'),
            'Product_name' => $this->input->post('etextdata3'),

            'Product_img' => str_replace(base_url(), '',$this->input->post('etextdata4')),
            'Product_price' => $this->input->post('etextdata5'),
            'Product_quantity' => $this->input->post('etextdata6'),
            'Product_note' => $this->input->post('etextdata7')

        );
       if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Products_Cart_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Products_Cart_Model->delete($Id);
       
        }
    }
}