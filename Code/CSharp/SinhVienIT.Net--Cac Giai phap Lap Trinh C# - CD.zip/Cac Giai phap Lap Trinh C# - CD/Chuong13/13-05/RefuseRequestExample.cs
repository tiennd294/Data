using System.Security.Permissions;

[assembly:FileIOPermission(SecurityAction.RequestRefuse, Write = @"C:\")]

public class RefuseRequestExample {

    public static void Main() {
    
        // ...
    }
}