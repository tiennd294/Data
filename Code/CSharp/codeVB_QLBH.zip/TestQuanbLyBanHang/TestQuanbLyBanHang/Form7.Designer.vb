Namespace TestQuanbLyBanHang
	Partial Class Form7
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.btnTroVe = New System.Windows.Forms.Button()
			Me.btnXoa = New System.Windows.Forms.Button()
			Me.btnHuyBo = New System.Windows.Forms.Button()
			Me.btnLuu = New System.Windows.Forms.Button()
			Me.btnSua = New System.Windows.Forms.Button()
			Me.btnThem = New System.Windows.Forms.Button()
			Me.btnReLoad = New System.Windows.Forms.Button()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label5 = New System.Windows.Forms.Label()
			Me.label4 = New System.Windows.Forms.Label()
			Me.label3 = New System.Windows.Forms.Label()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.textBox5 = New System.Windows.Forms.TextBox()
			Me.label7 = New System.Windows.Forms.Label()
			Me.textBox4 = New System.Windows.Forms.TextBox()
			Me.label6 = New System.Windows.Forms.Label()
			Me.maskedTextBox1 = New System.Windows.Forms.MaskedTextBox()
			Me.comboBox1 = New System.Windows.Forms.ComboBox()
			Me.textBox3 = New System.Windows.Forms.TextBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.groupBox1.SuspendLayout()
			Me.SuspendLayout()
			' 
			' btnTroVe
			' 
			Me.btnTroVe.Location = New System.Drawing.Point(607, 373)
			Me.btnTroVe.Name = "btnTroVe"
			Me.btnTroVe.Size = New System.Drawing.Size(68, 25)
			Me.btnTroVe.TabIndex = 17
			Me.btnTroVe.Text = "Tro Ve"
			Me.btnTroVe.UseVisualStyleBackColor = True
			AddHandler Me.btnTroVe.Click, New System.EventHandler(Me.btnTroVe_Click)
			' 
			' btnXoa
			' 
			Me.btnXoa.Location = New System.Drawing.Point(508, 373)
			Me.btnXoa.Name = "btnXoa"
			Me.btnXoa.Size = New System.Drawing.Size(68, 25)
			Me.btnXoa.TabIndex = 16
			Me.btnXoa.Text = "Xoa"
			Me.btnXoa.UseVisualStyleBackColor = True
			AddHandler Me.btnXoa.Click, New System.EventHandler(Me.btnXoa_Click)
			' 
			' btnHuyBo
			' 
			Me.btnHuyBo.Location = New System.Drawing.Point(408, 373)
			Me.btnHuyBo.Name = "btnHuyBo"
			Me.btnHuyBo.Size = New System.Drawing.Size(68, 25)
			Me.btnHuyBo.TabIndex = 15
			Me.btnHuyBo.Text = "Huy Bo"
			Me.btnHuyBo.UseVisualStyleBackColor = True
			AddHandler Me.btnHuyBo.Click, New System.EventHandler(Me.btnHuyBo_Click)
			' 
			' btnLuu
			' 
			Me.btnLuu.Location = New System.Drawing.Point(310, 373)
			Me.btnLuu.Name = "btnLuu"
			Me.btnLuu.Size = New System.Drawing.Size(68, 25)
			Me.btnLuu.TabIndex = 14
			Me.btnLuu.Text = "Luu"
			Me.btnLuu.UseVisualStyleBackColor = True
			AddHandler Me.btnLuu.Click, New System.EventHandler(Me.btnLuu_Click)
			' 
			' btnSua
			' 
			Me.btnSua.Location = New System.Drawing.Point(213, 373)
			Me.btnSua.Name = "btnSua"
			Me.btnSua.Size = New System.Drawing.Size(68, 25)
			Me.btnSua.TabIndex = 13
			Me.btnSua.Text = "Sua"
			Me.btnSua.UseVisualStyleBackColor = True
			AddHandler Me.btnSua.Click, New System.EventHandler(Me.btnSua_Click)
			' 
			' btnThem
			' 
			Me.btnThem.Location = New System.Drawing.Point(114, 373)
			Me.btnThem.Name = "btnThem"
			Me.btnThem.Size = New System.Drawing.Size(68, 25)
			Me.btnThem.TabIndex = 12
			Me.btnThem.Text = "Them"
			Me.btnThem.UseVisualStyleBackColor = True
			AddHandler Me.btnThem.Click, New System.EventHandler(Me.btnThem_Click)
			' 
			' btnReLoad
			' 
			Me.btnReLoad.Location = New System.Drawing.Point(24, 373)
			Me.btnReLoad.Name = "btnReLoad"
			Me.btnReLoad.Size = New System.Drawing.Size(68, 25)
			Me.btnReLoad.TabIndex = 11
			Me.btnReLoad.Text = "ReLoad"
			Me.btnReLoad.UseVisualStyleBackColor = True
			AddHandler Me.btnReLoad.Click, New System.EventHandler(Me.btnReLoad_Click)
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(14, 118)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(661, 241)
			Me.dataGridView1.TabIndex = 10
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(101, 21)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(133, 20)
			Me.textBox1.TabIndex = 5
			' 
			' label5
			' 
			Me.label5.AutoSize = True
			Me.label5.Location = New System.Drawing.Point(315, 51)
			Me.label5.Name = "label5"
			Me.label5.Size = New System.Drawing.Size(50, 13)
			Me.label5.TabIndex = 4
			Me.label5.Text = "Ngay NV"
			' 
			' label4
			' 
			Me.label4.AutoSize = True
			Me.label4.Location = New System.Drawing.Point(315, 19)
			Me.label4.Name = "label4"
			Me.label4.Size = New System.Drawing.Size(49, 13)
			Me.label4.TabIndex = 3
			Me.label4.Text = "Gioi Tinh"
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Location = New System.Drawing.Point(20, 76)
			Me.label3.Name = "label3"
			Me.label3.Size = New System.Drawing.Size(26, 13)
			Me.label3.TabIndex = 2
			Me.label3.Text = "Ten"
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me.textBox5)
			Me.groupBox1.Controls.Add(Me.label7)
			Me.groupBox1.Controls.Add(Me.textBox4)
			Me.groupBox1.Controls.Add(Me.label6)
			Me.groupBox1.Controls.Add(Me.maskedTextBox1)
			Me.groupBox1.Controls.Add(Me.comboBox1)
			Me.groupBox1.Controls.Add(Me.textBox3)
			Me.groupBox1.Controls.Add(Me.textBox2)
			Me.groupBox1.Controls.Add(Me.textBox1)
			Me.groupBox1.Controls.Add(Me.label5)
			Me.groupBox1.Controls.Add(Me.label4)
			Me.groupBox1.Controls.Add(Me.label3)
			Me.groupBox1.Controls.Add(Me.label2)
			Me.groupBox1.Controls.Add(Me.label1)
			Me.groupBox1.Location = New System.Drawing.Point(14, 3)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(662, 106)
			Me.groupBox1.TabIndex = 9
			Me.groupBox1.TabStop = False
			' 
			' textBox5
			' 
			Me.textBox5.Location = New System.Drawing.Point(554, 16)
			Me.textBox5.Name = "textBox5"
			Me.textBox5.Size = New System.Drawing.Size(90, 20)
			Me.textBox5.TabIndex = 13
			' 
			' label7
			' 
			Me.label7.AutoSize = True
			Me.label7.Location = New System.Drawing.Point(489, 19)
			Me.label7.Name = "label7"
			Me.label7.Size = New System.Drawing.Size(59, 13)
			Me.label7.TabIndex = 12
			Me.label7.Text = "Dien Thoai"
			' 
			' textBox4
			' 
			Me.textBox4.Location = New System.Drawing.Point(370, 73)
			Me.textBox4.Name = "textBox4"
			Me.textBox4.Size = New System.Drawing.Size(274, 20)
			Me.textBox4.TabIndex = 11
			' 
			' label6
			' 
			Me.label6.AutoSize = True
			Me.label6.Location = New System.Drawing.Point(315, 76)
			Me.label6.Name = "label6"
			Me.label6.Size = New System.Drawing.Size(41, 13)
			Me.label6.TabIndex = 10
			Me.label6.Text = "Dia Chi"
			' 
			' maskedTextBox1
			' 
			Me.maskedTextBox1.Location = New System.Drawing.Point(370, 48)
			Me.maskedTextBox1.Mask = "00/00/0000"
			Me.maskedTextBox1.Name = "maskedTextBox1"
			Me.maskedTextBox1.Size = New System.Drawing.Size(133, 20)
			Me.maskedTextBox1.TabIndex = 9
			Me.maskedTextBox1.ValidatingType = GetType(System.DateTime)
			' 
			' comboBox1
			' 
			Me.comboBox1.FormattingEnabled = True
			Me.comboBox1.Items.AddRange(New Object() {"Nam", "Nu", "Khong Xac Dinh"})
			Me.comboBox1.Location = New System.Drawing.Point(370, 16)
			Me.comboBox1.Name = "comboBox1"
			Me.comboBox1.Size = New System.Drawing.Size(113, 21)
			Me.comboBox1.TabIndex = 8
			' 
			' textBox3
			' 
			Me.textBox3.Location = New System.Drawing.Point(101, 73)
			Me.textBox3.Name = "textBox3"
			Me.textBox3.Size = New System.Drawing.Size(133, 20)
			Me.textBox3.TabIndex = 7
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(100, 48)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.Size = New System.Drawing.Size(178, 20)
			Me.textBox2.TabIndex = 6
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(20, 51)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(39, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Ho Lot"
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(20, 24)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(75, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Ma Nhan Vien"
			' 
			' Form7
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(690, 415)
			Me.Controls.Add(Me.btnTroVe)
			Me.Controls.Add(Me.btnXoa)
			Me.Controls.Add(Me.btnHuyBo)
			Me.Controls.Add(Me.btnLuu)
			Me.Controls.Add(Me.btnSua)
			Me.Controls.Add(Me.btnThem)
			Me.Controls.Add(Me.btnReLoad)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.groupBox1)
			Me.Name = "Form7"
			Me.Text = "Form7"
			Me.Load += New System.EventHandler(Me.Form7_Load)
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private btnTroVe As System.Windows.Forms.Button
		Private btnXoa As System.Windows.Forms.Button
		Private btnHuyBo As System.Windows.Forms.Button
		Private btnLuu As System.Windows.Forms.Button
		Private btnSua As System.Windows.Forms.Button
		Private btnThem As System.Windows.Forms.Button
		Private btnReLoad As System.Windows.Forms.Button
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private textBox1 As System.Windows.Forms.TextBox
		Private label5 As System.Windows.Forms.Label
		Private label4 As System.Windows.Forms.Label
		Private label3 As System.Windows.Forms.Label
		Private groupBox1 As System.Windows.Forms.GroupBox
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private textBox5 As System.Windows.Forms.TextBox
		Private label7 As System.Windows.Forms.Label
		Private textBox4 As System.Windows.Forms.TextBox
		Private label6 As System.Windows.Forms.Label
		Private maskedTextBox1 As System.Windows.Forms.MaskedTextBox
		Private comboBox1 As System.Windows.Forms.ComboBox
		Private textBox3 As System.Windows.Forms.TextBox
		Private textBox2 As System.Windows.Forms.TextBox
	End Class
End Namespace
