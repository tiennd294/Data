<?php
Class Contact_Model extends MY_Model
{
    var $table = 'contact';
    var $key = 'Idct';
}

