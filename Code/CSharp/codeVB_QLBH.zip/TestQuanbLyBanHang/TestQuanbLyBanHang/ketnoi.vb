Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.SqlClient
Imports System.Windows.Forms

Namespace TestQuanbLyBanHang
	Class ketnoi
		Public con As SqlConnection
		Public Sub ket_noi()
			Try
				con = New SqlConnection("Data Source=.\NGUYENTIEN;Initial Catalog=QLBH;Integrated Security=True")

				con.Open()
			Catch
					'SqlCommand cmd = new SqlCommand();
					'ketnoi kn = new ketnoi();
					'kn.ket_noi();
					'cmd.Connection = kn.con;
				MessageBox.Show("ket noi that bai!")
			End Try
		End Sub
	End Class
End Namespace
