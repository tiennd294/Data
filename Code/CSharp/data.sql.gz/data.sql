-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 30, 2011 at 02:43 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `demo1`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_authors`
-- 

CREATE TABLE `nv3_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL default '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL default '0',
  `edittime` int(11) NOT NULL default '0',
  `is_suspend` tinyint(1) unsigned NOT NULL default '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL default '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_authors`
-- 

INSERT INTO `nv3_authors` VALUES (1, 'ckeditor', 1, 'adobe,application,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '3cba24dce6dcd4bff8212e87402419a16146e047', 1308294830, '117.2.46.237', 'Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_authors_config`
-- 

CREATE TABLE `nv3_authors_config` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `keyname` varchar(32) default NULL,
  `mask` tinyint(4) NOT NULL default '0',
  `begintime` int(11) default NULL,
  `endtime` int(11) default NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_authors_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_banip`
-- 

CREATE TABLE `nv3_banip` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(32) default NULL,
  `mask` tinyint(4) NOT NULL default '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) default NULL,
  `endtime` int(11) default NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_banip`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_banners_click`
-- 

CREATE TABLE `nv3_banners_click` (
  `bid` mediumint(8) NOT NULL default '0',
  `click_time` int(11) unsigned NOT NULL default '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_banners_click`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_banners_clients`
-- 

CREATE TABLE `nv3_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL default '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL default '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL default '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_banners_clients`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_banners_plans`
-- 

CREATE TABLE `nv3_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL default '0',
  `height` smallint(4) unsigned NOT NULL default '0',
  `act` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `nv3_banners_plans`
-- 

INSERT INTO `nv3_banners_plans` VALUES (1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1);
INSERT INTO `nv3_banners_plans` VALUES (2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);
INSERT INTO `nv3_banners_plans` VALUES (3, '', 'Intro - footer', '', 'random', 510, 165, 1);
INSERT INTO `nv3_banners_plans` VALUES (4, '', 'intro - header', '', 'random', 950, 70, 1);
INSERT INTO `nv3_banners_plans` VALUES (5, '', 'Intro - footer - dai', '', 'random', 950, 70, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_banners_rows`
-- 

CREATE TABLE `nv3_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL default '0',
  `clid` mediumint(8) unsigned NOT NULL default '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL default '0',
  `height` int(4) unsigned NOT NULL default '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `publ_time` int(11) unsigned NOT NULL default '0',
  `exp_time` int(11) unsigned NOT NULL default '0',
  `hits_total` mediumint(8) unsigned NOT NULL default '0',
  `act` tinyint(1) unsigned NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_banners_rows`
-- 

INSERT INTO `nv3_banners_rows` VALUES (4, 'Thư Viện', 3, 0, 'intro-ft.swf', 'swf', 'application/x-shockwave-flash', 510, 161, '', 'http://lexuanduan.net', '', '', '', 1308292203, 1308292203, 0, 0, 1, 0);
INSERT INTO `nv3_banners_rows` VALUES (5, 'Đặc Sản Huế', 4, 0, 'dacsanhue.swf', 'swf', 'application/x-shockwave-flash', 950, 70, '', 'http://dacsanhue.net', '', '', '', 1308293024, 1308293024, 0, 0, 1, 0);
INSERT INTO `nv3_banners_rows` VALUES (6, 'Liên Hệ', 5, 0, 'intro-fter.swf', 'swf', 'application/x-shockwave-flash', 950, 70, '', 'http://lexuanduan.net/index.php?language=vi&nv=contact', '', '', '', 1308293488, 1308293488, 0, 0, 1, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_config`
-- 

CREATE TABLE `nv3_config` (
  `lang` char(3) NOT NULL default 'sys',
  `module` varchar(25) NOT NULL default 'global',
  `config_name` varchar(30) NOT NULL default '',
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_config`
-- 

INSERT INTO `nv3_config` VALUES ('sys', 'global', 'closed_site', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'site_keywords', 'Nukeviet, portal, mysql, php');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'site_phone', '');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'site_lang', 'vi');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'admin_theme', 'admin_full');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'date_pattern', 'l, d-m-Y');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'time_pattern', 'H&#x3A;i');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'block_admin_ip', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'admfirewall', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'online_upd', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'statistic', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'dump_autobackup', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'dump_backup_ext', 'gz');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'dump_backup_day', '30');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'gfx_chk', '3');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'file_allowed_ext', 'adobe,application,archives,audio,documents,flash,images,real,video');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'forbid_extensions', 'php');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'forbid_mimes', '');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'nv_max_size', '33554432');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'upload_checking_mode', 'strong');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'str_referer_blocker', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'mailer_mode', '');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'smtp_host', 'smtp.gmail.com');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'smtp_ssl', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'smtp_port', '465');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'smtp_username', 'user@gmail.com');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'smtp_password', 'userpass');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'allowuserreg', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'allowuserlogin', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'allowloginchange', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'useactivate', '2');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'allowmailchange', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'allow_sitelangs', 'vi');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'allow_adminlangs', 'vi,en');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'read_type', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'is_url_rewrite', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'rewrite_optional', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'gzip_method', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'is_user_forum', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'openid_mode', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'authors_detail_main', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'spadmin_add_admin', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'openid_servers', 'yahoo,google,myopenid');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'optActive', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'googleAnalyticsID', '');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'googleAnalyticsSetDomainName', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'revision', '930');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'version', '3.1.03');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'site_name', 'Cửa hàng bán sách trực tuyến giá rẻ');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'site_logo', 'images/logo.png');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'site_description', '');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'site_keywords', '');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'site_theme', 'default');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'site_home_module', 'shops');
INSERT INTO `nv3_config` VALUES ('vi', 'global', 'disable_site_content', '<p> Website đang xây dựng, vui lòng quay lại sau</p><p> Huỳnh Phi Cơ</p><p> 0905041221</p>');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'indexfile', 'viewcat_main_right');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'per_page', '20');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'st_links', '10');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'auto_postcomm', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'homewidth', '100');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'homeheight', '80');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'blockwidth', '52');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'blockheight', '60');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'imagefull', '460');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'setcomm', '2');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'showhometext', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'activecomm', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'news', 'emailcomm', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'site_email', 'admin@lexuanduan.net');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'error_send_email', 'admin@lexuanduan.net');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'my_domains', 'lexuanduan.net');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'cookie_prefix', 'nv3c_Quvh9');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'session_prefix', 'nv3s_Gmm3h2');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'site_timezone', 'Asia&#x002F;Bangkok');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'proxy_blocker', '0');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'lang_multi', '1');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'ftp_server', 'localhost');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'ftp_port', '21');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'ftp_user_name', '');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'ftp_user_pass', '');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'ftp_path', '/');
INSERT INTO `nv3_config` VALUES ('sys', 'global', 'ftp_check_login', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'image_size', '100x100');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'home_view', 'view_home_all');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'per_page', '28');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'per_row', '4');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'comment', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'comment_auto', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'who_comment', 'all');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'money_unit', 'VND');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'post_auto_member', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'auto_check_order', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'format_order_id', 'S%06s');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'active_showhomtext', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'active_order', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'active_price', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'active_order_number', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'active_payment', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'image_size', '100x100');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'homewidth', '100');
INSERT INTO `nv3_config` VALUES ('vi', 'shops', 'homeheight', '100');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'home_view', 'view_home_all');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'per_page', '28');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'per_row', '4');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'comment', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'comment_auto', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'who_comment', 'all');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'money_unit', 'VND');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'post_auto_member', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'auto_check_order', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'format_order_id', 'S%06s');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'active_showhomtext', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'active_order', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'active_price', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'active_order_number', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'active_payment', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'homewidth', '100');
INSERT INTO `nv3_config` VALUES ('vi', 'sach-tieng-anh', 'homeheight', '100');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'image_size', '100x100');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'home_view', 'view_home_all');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'per_page', '20');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'per_row', '4');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'comment', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'comment_auto', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'who_comment', 'all');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'money_unit', 'USD');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'post_auto_member', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'auto_check_order', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'format_order_id', 'M%06s');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'active_showhomtext', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'active_order', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'active_price', '1');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'active_order_number', '0');
INSERT INTO `nv3_config` VALUES ('vi', 'may-doc-sach', 'active_payment', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_cronjobs`
-- 

CREATE TABLE `nv3_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `start_time` int(11) unsigned NOT NULL default '0',
  `interval` int(11) unsigned NOT NULL default '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL default '0',
  `is_sys` tinyint(1) unsigned NOT NULL default '0',
  `act` tinyint(1) unsigned NOT NULL default '0',
  `last_time` int(11) unsigned NOT NULL default '0',
  `last_result` tinyint(1) unsigned NOT NULL default '0',
  `vi_cron_name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `nv3_cronjobs`
-- 

INSERT INTO `nv3_cronjobs` VALUES (1, 1308229805, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1308294914, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL');
INSERT INTO `nv3_cronjobs` VALUES (2, 1308229805, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1308229881, 1, 'Tự động lưu CSDL');
INSERT INTO `nv3_cronjobs` VALUES (3, 1308229805, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1308294620, 1, 'Xóa các file tạm trong thư mục tmp');
INSERT INTO `nv3_cronjobs` VALUES (4, 1308229805, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1308294620, 1, 'Xóa IP log files Xóa các file logo truy cập');
INSERT INTO `nv3_cronjobs` VALUES (5, 1308229805, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1308229881, 1, 'Xóa các file error_log quá hạn');
INSERT INTO `nv3_cronjobs` VALUES (6, 1308229805, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin');
INSERT INTO `nv3_cronjobs` VALUES (7, 1308229805, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1308294620, 1, 'Xóa các referer quá hạn');
INSERT INTO `nv3_cronjobs` VALUES (8, 1308229805, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 1, 1, 1308229903, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_groups`
-- 

CREATE TABLE `nv3_groups` (
  `group_id` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL default '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `nv3_groups`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_language`
-- 

CREATE TABLE `nv3_language` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `idfile` mediumint(8) unsigned NOT NULL default '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_language`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_language_file`
-- 

CREATE TABLE `nv3_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL auto_increment,
  `module` varchar(50) NOT NULL,
  `admin_file` tinyint(1) NOT NULL default '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY  (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_language_file`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_logs`
-- 

CREATE TABLE `nv3_logs` (
  `id` int(11) NOT NULL auto_increment,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=242 ;

-- 
-- Dumping data for table `nv3_logs`
-- 

INSERT INTO `nv3_logs` VALUES (1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308229877);
INSERT INTO `nv3_logs` VALUES (2, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_shop_install_automatic.zip', 'nv3_module_shop_install_automatic.zip', 1, 1308229936);
INSERT INTO `nv3_logs` VALUES (3, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_shop_install_automatic.zip', 'nv3_module_shop_install_automatic.zip', 1, 1308229973);
INSERT INTO `nv3_logs` VALUES (4, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_shop_install_automatic.zip', 'nv3_module_shop_install_automatic.zip', 1, 1308230151);
INSERT INTO `nv3_logs` VALUES (5, 'vi', 'modules', 'Thiết lập module mới shops"', '', '', 1, 1308230177);
INSERT INTO `nv3_logs` VALUES (6, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1308230197);
INSERT INTO `nv3_logs` VALUES (7, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1308230219);
INSERT INTO `nv3_logs` VALUES (8, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308230224);
INSERT INTO `nv3_logs` VALUES (9, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308270622);
INSERT INTO `nv3_logs` VALUES (10, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308276344);
INSERT INTO `nv3_logs` VALUES (11, 'vi', 'modules', 'Kích hoạt module "statistics"', 'Không', 'Không', 1, 1308276755);
INSERT INTO `nv3_logs` VALUES (12, 'vi', 'modules', 'Kích hoạt module "voting"', 'Không', 'Không', 1, 1308276756);
INSERT INTO `nv3_logs` VALUES (13, 'vi', 'modules', 'Kích hoạt module "rss"', 'Không', 'Không', 1, 1308276781);
INSERT INTO `nv3_logs` VALUES (14, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1308276850);
INSERT INTO `nv3_logs` VALUES (15, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308276911);
INSERT INTO `nv3_logs` VALUES (16, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308277662);
INSERT INTO `nv3_logs` VALUES (17, 'vi', 'about', 'log_edit_about', 'aboutid 2', 'aboutid 2', 1, 1308277720);
INSERT INTO `nv3_logs` VALUES (18, 'vi', 'about', 'log_edit_about', 'aboutid 2', 'aboutid 2', 1, 1308277735);
INSERT INTO `nv3_logs` VALUES (19, 'vi', 'about', 'log_del_about', 'aboutid  1', 'aboutid  1', 1, 1308277744);
INSERT INTO `nv3_logs` VALUES (20, 'vi', 'news', 'Xóa Bài viết', ' Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam, Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC, Giới thiệu về mã nguồn mở NukeViet, Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', ' Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam, Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC, Giới thiệu về mã nguồn mở NukeViet, Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 1, 1308277753);
INSERT INTO `nv3_logs` VALUES (21, 'vi', 'voting', 'log_del_vote', 'votingid 2', 'votingid 2', 1, 1308277769);
INSERT INTO `nv3_logs` VALUES (22, 'vi', 'voting', 'log_del_vote', 'votingid 3', 'votingid 3', 1, 1308277775);
INSERT INTO `nv3_logs` VALUES (23, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1308278039);
INSERT INTO `nv3_logs` VALUES (24, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1308278068);
INSERT INTO `nv3_logs` VALUES (25, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1308278096);
INSERT INTO `nv3_logs` VALUES (26, 'vi', 'themes', 'Sửa block', 'Name : Quảng cáo trái', 'Name : Quảng cáo trái', 1, 1308278135);
INSERT INTO `nv3_logs` VALUES (27, 'vi', 'themes', 'Thêm block', 'Name : vvvvvvvvvvvvvvvvvvvvvvvvvvvvv', 'Name : vvvvvvvvvvvvvvvvvvvvvvvvvvvvv', 1, 1308278166);
INSERT INTO `nv3_logs` VALUES (28, 'vi', 'themes', 'Sửa block', 'Name : Sách Tiếng Việt', 'Name : Sách Tiếng Việt', 1, 1308278347);
INSERT INTO `nv3_logs` VALUES (29, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1308278413);
INSERT INTO `nv3_logs` VALUES (30, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1308278436);
INSERT INTO `nv3_logs` VALUES (31, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1308278449);
INSERT INTO `nv3_logs` VALUES (32, 'vi', 'shops', 'log_add_catalog', 'id 7', 'id 7', 1, 1308278462);
INSERT INTO `nv3_logs` VALUES (33, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1308278523);
INSERT INTO `nv3_logs` VALUES (34, 'vi', 'shops', 'log_add_catalog', 'id 8', 'id 8', 1, 1308278540);
INSERT INTO `nv3_logs` VALUES (35, 'vi', 'shops', 'log_add_catalog', 'id 9', 'id 9', 1, 1308278550);
INSERT INTO `nv3_logs` VALUES (36, 'vi', 'shops', 'log_add_catalog', 'id 10', 'id 10', 1, 1308278559);
INSERT INTO `nv3_logs` VALUES (37, 'vi', 'shops', 'log_add_catalog', 'id 11', 'id 11', 1, 1308278580);
INSERT INTO `nv3_logs` VALUES (38, 'vi', 'shops', 'log_add_catalog', 'id 12', 'id 12', 1, 1308278595);
INSERT INTO `nv3_logs` VALUES (39, 'vi', 'shops', 'log_add_catalog', 'id 13', 'id 13', 1, 1308278620);
INSERT INTO `nv3_logs` VALUES (40, 'vi', 'shops', 'log_add_catalog', 'id 14', 'id 14', 1, 1308278637);
INSERT INTO `nv3_logs` VALUES (41, 'vi', 'shops', 'log_add_catalog', 'id 15', 'id 15', 1, 1308278659);
INSERT INTO `nv3_logs` VALUES (42, 'vi', 'shops', 'log_add_catalog', 'id 16', 'id 16', 1, 1308278676);
INSERT INTO `nv3_logs` VALUES (43, 'vi', 'shops', 'log_add_catalog', 'id 17', 'id 17', 1, 1308278715);
INSERT INTO `nv3_logs` VALUES (44, 'vi', 'shops', 'log_add_catalog', 'id 18', 'id 18', 1, 1308278909);
INSERT INTO `nv3_logs` VALUES (45, 'vi', 'shops', 'log_add_catalog', 'id 19', 'id 19', 1, 1308278940);
INSERT INTO `nv3_logs` VALUES (46, 'vi', 'shops', 'log_add_catalog', 'id 20', 'id 20', 1, 1308278956);
INSERT INTO `nv3_logs` VALUES (47, 'vi', 'shops', 'log_add_catalog', 'id 21', 'id 21', 1, 1308278973);
INSERT INTO `nv3_logs` VALUES (48, 'vi', 'shops', 'log_add_catalog', 'id 22', 'id 22', 1, 1308278991);
INSERT INTO `nv3_logs` VALUES (49, 'vi', 'shops', 'log_add_catalog', 'id 23', 'id 23', 1, 1308279012);
INSERT INTO `nv3_logs` VALUES (50, 'vi', 'shops', 'log_add_catalog', 'id 24', 'id 24', 1, 1308279028);
INSERT INTO `nv3_logs` VALUES (51, 'vi', 'shops', 'log_add_catalog', 'id 25', 'id 25', 1, 1308279041);
INSERT INTO `nv3_logs` VALUES (52, 'vi', 'shops', 'log_add_catalog', 'id 26', 'id 26', 1, 1308279054);
INSERT INTO `nv3_logs` VALUES (53, 'vi', 'themes', 'Thêm block', 'Name : global block group', 'Name : global block group', 1, 1308279084);
INSERT INTO `nv3_logs` VALUES (54, 'vi', 'themes', 'Thêm block', 'Name : global block cart', 'Name : global block cart', 1, 1308279096);
INSERT INTO `nv3_logs` VALUES (55, 'vi', 'themes', 'Thêm block', 'Name : global block cart', 'Name : global block cart', 1, 1308279115);
INSERT INTO `nv3_logs` VALUES (56, 'vi', 'themes', 'Thêm block', 'Name : global block relates product', 'Name : global block relates product', 1, 1308279125);
INSERT INTO `nv3_logs` VALUES (57, 'vi', 'themes', 'Thêm block', 'Name : module block product center', 'Name : module block product center', 1, 1308279153);
INSERT INTO `nv3_logs` VALUES (58, 'vi', 'themes', 'Thêm block', 'Name : module block others product', 'Name : module block others product', 1, 1308279174);
INSERT INTO `nv3_logs` VALUES (59, 'vi', 'themes', 'Thêm block', 'Name : module block product center', 'Name : module block product center', 1, 1308279350);
INSERT INTO `nv3_logs` VALUES (60, 'vi', 'themes', 'Thêm block', 'Name : global block relates product', 'Name : global block relates product', 1, 1308279373);
INSERT INTO `nv3_logs` VALUES (61, 'vi', 'themes', 'Thêm block', 'Name : module block others product', 'Name : module block others product', 1, 1308279404);
INSERT INTO `nv3_logs` VALUES (62, 'vi', 'shops', 'log_add_product', 'id 1', 'id 1', 1, 1308280634);
INSERT INTO `nv3_logs` VALUES (63, 'vi', 'shops', 'log_del_product', 'id 1', 'id 1', 1, 1308280641);
INSERT INTO `nv3_logs` VALUES (64, 'vi', 'shops', 'log_add_product', 'id 2', 'id 2', 1, 1308280706);
INSERT INTO `nv3_logs` VALUES (65, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308280750);
INSERT INTO `nv3_logs` VALUES (66, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308280785);
INSERT INTO `nv3_logs` VALUES (67, 'vi', 'banners', 'log_del_banner', 'bannerid 3', 'bannerid 3', 1, 1308280795);
INSERT INTO `nv3_logs` VALUES (68, 'vi', 'banners', 'log_del_banner', 'bannerid 2', 'bannerid 2', 1, 1308280799);
INSERT INTO `nv3_logs` VALUES (69, 'vi', 'banners', 'log_del_banner', 'bannerid 1', 'bannerid 1', 1, 1308280802);
INSERT INTO `nv3_logs` VALUES (70, 'vi', 'modules', 'Kích hoạt module "news"', 'Không', 'Không', 1, 1308280920);
INSERT INTO `nv3_logs` VALUES (71, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1308280985);
INSERT INTO `nv3_logs` VALUES (72, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308281004);
INSERT INTO `nv3_logs` VALUES (73, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308281043);
INSERT INTO `nv3_logs` VALUES (74, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308281186);
INSERT INTO `nv3_logs` VALUES (75, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308281293);
INSERT INTO `nv3_logs` VALUES (76, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.166.36.90', ' Client IP:113.166.36.90', 0, 1308281852);
INSERT INTO `nv3_logs` VALUES (77, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/dht-nghi_nhu_mot_ty_phu.200x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/dht-nghi_nhu_mot_ty_phu.200x300.w.d10.f300.b.jpg', 1, 1308282292);
INSERT INTO `nv3_logs` VALUES (78, 'vi', 'shops', 'log_edit_product', 'id 2', 'id 2', 1, 1308282327);
INSERT INTO `nv3_logs` VALUES (79, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/bia-dan_ong_dan_ba_chuyen.205x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/bia-dan_ong_dan_ba_chuyen.205x300.w.d10.f300.b.jpg', 1, 1308282463);
INSERT INTO `nv3_logs` VALUES (80, 'vi', 'shops', 'log_add_product', 'id 3', 'id 3', 1, 1308282530);
INSERT INTO `nv3_logs` VALUES (81, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.22.182.71', ' Client IP:113.22.182.71', 0, 1308283420);
INSERT INTO `nv3_logs` VALUES (82, 'vi', 'shops', 'log_edit_product', 'id 2', 'id 2', 1, 1308283465);
INSERT INTO `nv3_logs` VALUES (83, 'vi', 'themes', 'Thêm block', 'Name : Sách Tiếng Việt Mới Nhất', 'Name : Sách Tiếng Việt Mới Nhất', 1, 1308283968);
INSERT INTO `nv3_logs` VALUES (84, 'vi', 'shops', 'log_edit_product', 'id 3', 'id 3', 1, 1308284179);
INSERT INTO `nv3_logs` VALUES (85, 'vi', 'shops', 'log_edit_product', 'id 2', 'id 2', 1, 1308284185);
INSERT INTO `nv3_logs` VALUES (86, 'vi', 'themes', 'Sửa block', 'Name : Sách Tiếng Việt Mới Nhất', 'Name : Sách Tiếng Việt Mới Nhất', 1, 1308284210);
INSERT INTO `nv3_logs` VALUES (87, 'vi', 'themes', 'Sửa block', 'Name : Sách Tiếng Việt Mới Nhất', 'Name : Sách Tiếng Việt Mới Nhất', 1, 1308284236);
INSERT INTO `nv3_logs` VALUES (88, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113077665084df2eeec514cb.193x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113077665084df2eeec514cb.193x300.w.d10.f300.b.jpg', 1, 1308284310);
INSERT INTO `nv3_logs` VALUES (89, 'vi', 'shops', 'log_add_product', 'id 4', 'id 4', 1, 1308284368);
INSERT INTO `nv3_logs` VALUES (90, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/phong_than_song_long_10.185x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/phong_than_song_long_10.185x300.w.d10.f300.b.jpg', 1, 1308284515);
INSERT INTO `nv3_logs` VALUES (91, 'vi', 'shops', 'log_add_product', 'id 5', 'id 5', 1, 1308284562);
INSERT INTO `nv3_logs` VALUES (92, 'vi', 'themes', 'Sửa block', 'Name : Giỏ Hàng', 'Name : Giỏ Hàng', 1, 1308284588);
INSERT INTO `nv3_logs` VALUES (93, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113067421744de34d9e1bd10.195x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113067421744de34d9e1bd10.195x300.w.d10.f300.b.jpg', 1, 1308284657);
INSERT INTO `nv3_logs` VALUES (94, 'vi', 'shops', 'log_add_product', 'id 6', 'id 6', 1, 1308284697);
INSERT INTO `nv3_logs` VALUES (95, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/nam_dua_tre_va_con_tien_cat.191x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/nam_dua_tre_va_con_tien_cat.191x300.w.d10.f300.b.jpg', 1, 1308284760);
INSERT INTO `nv3_logs` VALUES (96, 'vi', 'shops', 'log_add_product', 'id 7', 'id 7', 1, 1308284795);
INSERT INTO `nv3_logs` VALUES (97, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/bong_hong_chua_kip_gui.160x250.w.d10.f250.b.jpg', 'uploads/shops/2011_06/bong_hong_chua_kip_gui.160x250.w.d10.f250.b.jpg', 1, 1308284852);
INSERT INTO `nv3_logs` VALUES (98, 'vi', 'shops', 'log_add_product', 'id 8', 'id 8', 1, 1308284884);
INSERT INTO `nv3_logs` VALUES (99, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113012817764d8ffbf0471ec.200x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113012817764d8ffbf0471ec.200x300.w.f300.b.jpg', 1, 1308285029);
INSERT INTO `nv3_logs` VALUES (100, 'vi', 'shops', 'log_add_product', 'id 9', 'id 9', 1, 1308285060);
INSERT INTO `nv3_logs` VALUES (101, 'vi', 'shops', 'log_edit_product', 'id 9', 'id 9', 1, 1308285078);
INSERT INTO `nv3_logs` VALUES (102, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113051033394dca4beb55fa6.201x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113051033394dca4beb55fa6.201x300.w.f300.b.jpg', 1, 1308285129);
INSERT INTO `nv3_logs` VALUES (103, 'vi', 'shops', 'log_add_product', 'id 10', 'id 10', 1, 1308285159);
INSERT INTO `nv3_logs` VALUES (104, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113070033434de749cfe0f8f.215x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113070033434de749cfe0f8f.215x300.w.d10.f300.b.jpg', 1, 1308285243);
INSERT INTO `nv3_logs` VALUES (105, 'vi', 'shops', 'log_add_product', 'id 11', 'id 11', 1, 1308285287);
INSERT INTO `nv3_logs` VALUES (106, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/59369_12803791014c5108dddc7f6.207x300.w.d5.f300.b.jpg', 'uploads/shops/2011_06/59369_12803791014c5108dddc7f6.207x300.w.d5.f300.b.jpg', 1, 1308285331);
INSERT INTO `nv3_logs` VALUES (107, 'vi', 'shops', 'log_add_product', 'id 12', 'id 12', 1, 1308285372);
INSERT INTO `nv3_logs` VALUES (108, 'vi', 'themes', 'Sửa block', 'Name : Sách Nổi Bật', 'Name : Sách Nổi Bật', 1, 1308285416);
INSERT INTO `nv3_logs` VALUES (109, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113047440584dc4d07a8124c.200x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113047440584dc4d07a8124c.200x300.w.f300.b.jpg', 1, 1308285480);
INSERT INTO `nv3_logs` VALUES (110, 'vi', 'shops', 'log_add_product', 'id 13', 'id 13', 1, 1308285513);
INSERT INTO `nv3_logs` VALUES (111, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/dht-tin_tuc_trai_dat_phang.197x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/dht-tin_tuc_trai_dat_phang.197x300.w.d10.f300.b.jpg', 1, 1308285553);
INSERT INTO `nv3_logs` VALUES (112, 'vi', 'shops', 'log_add_product', 'id 14', 'id 14', 1, 1308285592);
INSERT INTO `nv3_logs` VALUES (113, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113067218714de2fe4f049ab.211x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113067218714de2fe4f049ab.211x300.w.d10.f300.b.jpg', 1, 1308285686);
INSERT INTO `nv3_logs` VALUES (114, 'vi', 'shops', 'log_add_product', 'id 15', 'id 15', 1, 1308285718);
INSERT INTO `nv3_logs` VALUES (115, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113059462384dd7287e11bf2.192x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113059462384dd7287e11bf2.192x300.w.d10.f300.b.jpg', 1, 1308285781);
INSERT INTO `nv3_logs` VALUES (116, 'vi', 'shops', 'log_add_product', 'id 16', 'id 16', 1, 1308285814);
INSERT INTO `nv3_logs` VALUES (117, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113002458274d802d43a9e0f.204x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113002458274d802d43a9e0f.204x300.w.f300.b.jpg', 1, 1308285922);
INSERT INTO `nv3_logs` VALUES (118, 'vi', 'shops', 'log_add_product', 'id 17', 'id 17', 1, 1308285960);
INSERT INTO `nv3_logs` VALUES (119, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/dht-viet_nam_dep_nhat_co_ten_bac_ho.253x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/dht-viet_nam_dep_nhat_co_ten_bac_ho.253x300.w.d10.f300.b.jpg', 1, 1308286042);
INSERT INTO `nv3_logs` VALUES (120, 'vi', 'shops', 'log_add_product', 'id 18', 'id 18', 1, 1308286076);
INSERT INTO `nv3_logs` VALUES (121, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113037019344db4e9ae6f9de.180x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113037019344db4e9ae6f9de.180x300.w.f300.b.jpg', 1, 1308286143);
INSERT INTO `nv3_logs` VALUES (122, 'vi', 'shops', 'log_add_product', 'id 19', 'id 19', 1, 1308286173);
INSERT INTO `nv3_logs` VALUES (123, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/dht-sac_mau_to_am_tuyen_tap_thiet_ke_cua_nha_vui_6.216x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/dht-sac_mau_to_am_tuyen_tap_thiet_ke_cua_nha_vui_6.216x300.w.d10.f300.b.jpg', 1, 1308286217);
INSERT INTO `nv3_logs` VALUES (124, 'vi', 'shops', 'log_add_product', 'id 20', 'id 20', 1, 1308286273);
INSERT INTO `nv3_logs` VALUES (125, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113063833344dddd3e607b0e.218x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113063833344dddd3e607b0e.218x300.w.d10.f300.b.jpg', 1, 1308286354);
INSERT INTO `nv3_logs` VALUES (126, 'vi', 'shops', 'log_add_product', 'id 21', 'id 21', 1, 1308286385);
INSERT INTO `nv3_logs` VALUES (127, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113049108704dc75c16609f2.211x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113049108704dc75c16609f2.211x300.w.f300.b.jpg', 1, 1308286437);
INSERT INTO `nv3_logs` VALUES (128, 'vi', 'shops', 'log_add_product', 'id 22', 'id 22', 1, 1308286474);
INSERT INTO `nv3_logs` VALUES (129, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113061204564dd9d1083a0e6.203x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113061204564dd9d1083a0e6.203x300.w.d10.f300.b.jpg', 1, 1308286509);
INSERT INTO `nv3_logs` VALUES (130, 'vi', 'shops', 'log_add_product', 'id 23', 'id 23', 1, 1308286553);
INSERT INTO `nv3_logs` VALUES (131, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113067230334de302d96a121.210x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113067230334de302d96a121.210x300.w.d10.f300.b.jpg', 1, 1308286583);
INSERT INTO `nv3_logs` VALUES (132, 'vi', 'shops', 'log_add_product', 'id 24', 'id 24', 1, 1308286624);
INSERT INTO `nv3_logs` VALUES (133, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113063087884ddcb0b472409.207x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113063087884ddcb0b472409.207x300.w.d10.f300.b.jpg', 1, 1308286658);
INSERT INTO `nv3_logs` VALUES (134, 'vi', 'shops', 'log_add_product', 'id 25', 'id 25', 1, 1308286694);
INSERT INTO `nv3_logs` VALUES (135, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113008551954d89799bee0ec.212x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113008551954d89799bee0ec.212x300.w.f300.b.jpg', 1, 1308286727);
INSERT INTO `nv3_logs` VALUES (136, 'vi', 'shops', 'log_add_product', 'id 26', 'id 26', 1, 1308286759);
INSERT INTO `nv3_logs` VALUES (137, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/12872097644cb943246b678.219x300.w.d20.f300.b.jpg', 'uploads/shops/2011_06/12872097644cb943246b678.219x300.w.d20.f300.b.jpg', 1, 1308286786);
INSERT INTO `nv3_logs` VALUES (138, 'vi', 'shops', 'log_add_product', 'id 27', 'id 27', 1, 1308286822);
INSERT INTO `nv3_logs` VALUES (139, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/201010100423-10_loi_khuyen_khoi_nghiep.192x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/201010100423-10_loi_khuyen_khoi_nghiep.192x300.w.d10.f300.b.jpg', 1, 1308286923);
INSERT INTO `nv3_logs` VALUES (140, 'vi', 'shops', 'log_add_product', 'id 28', 'id 28', 1, 1308286955);
INSERT INTO `nv3_logs` VALUES (141, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113055207554dd0aa73caee2.180x300.w.d10.f300.b.jpg', 'uploads/shops/2011_06/c113055207554dd0aa73caee2.180x300.w.d10.f300.b.jpg', 1, 1308286983);
INSERT INTO `nv3_logs` VALUES (142, 'vi', 'shops', 'log_add_product', 'id 29', 'id 29', 1, 1308287016);
INSERT INTO `nv3_logs` VALUES (143, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c112873842854cbbecdd7e34c.300x173.w.f300.b.jpg', 'uploads/shops/2011_06/c112873842854cbbecdd7e34c.300x173.w.f300.b.jpg', 1, 1308287045);
INSERT INTO `nv3_logs` VALUES (144, 'vi', 'shops', 'log_add_product', 'id 30', 'id 30', 1, 1308287072);
INSERT INTO `nv3_logs` VALUES (145, 'vi', 'upload', 'Upload file', 'uploads/shops/2011_06/c113032803614dae7ae90c926.189x300.w.f300.b.jpg', 'uploads/shops/2011_06/c113032803614dae7ae90c926.189x300.w.f300.b.jpg', 1, 1308287097);
INSERT INTO `nv3_logs` VALUES (146, 'vi', 'shops', 'log_add_product', 'id 31', 'id 31', 1, 1308287124);
INSERT INTO `nv3_logs` VALUES (147, 'vi', 'modules', 'Kích hoạt module "about"', 'Không', 'Không', 1, 1308287346);
INSERT INTO `nv3_logs` VALUES (148, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1308287358);
INSERT INTO `nv3_logs` VALUES (149, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1308287381);
INSERT INTO `nv3_logs` VALUES (150, 'vi', 'shops', 'Cấu hình module', 'setting', 'setting', 1, 1308287404);
INSERT INTO `nv3_logs` VALUES (151, 'vi', 'modules', 'Kích hoạt module "users"', 'Không', 'Không', 1, 1308287469);
INSERT INTO `nv3_logs` VALUES (152, 'vi', 'modules', 'Kích hoạt module "contact"', 'Không', 'Không', 1, 1308287472);
INSERT INTO `nv3_logs` VALUES (153, 'vi', 'modules', 'Thêm module ảo "sach_tieng_anh"', '', '', 1, 1308287526);
INSERT INTO `nv3_logs` VALUES (154, 'vi', 'modules', 'Thiết lập module mới sach-tieng-anh"', '', '', 1, 1308287526);
INSERT INTO `nv3_logs` VALUES (155, 'vi', 'modules', 'Sửa module &ldquo;sach-tieng-anh&rdquo;', '', '', 1, 1308287546);
INSERT INTO `nv3_logs` VALUES (156, 'vi', 'sach-tieng-anh', 'Cấu hình module', 'setting', 'setting', 1, 1308287570);
INSERT INTO `nv3_logs` VALUES (157, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 1', 'id 1', 1, 1308287588);
INSERT INTO `nv3_logs` VALUES (158, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 2', 'id 2', 1, 1308287599);
INSERT INTO `nv3_logs` VALUES (159, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 3', 'id 3', 1, 1308287612);
INSERT INTO `nv3_logs` VALUES (160, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 4', 'id 4', 1, 1308287622);
INSERT INTO `nv3_logs` VALUES (161, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 5', 'id 5', 1, 1308287634);
INSERT INTO `nv3_logs` VALUES (162, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 6', 'id 6', 1, 1308287645);
INSERT INTO `nv3_logs` VALUES (163, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 7', 'id 7', 1, 1308287656);
INSERT INTO `nv3_logs` VALUES (164, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 8', 'id 8', 1, 1308287669);
INSERT INTO `nv3_logs` VALUES (165, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 9', 'id 9', 1, 1308287683);
INSERT INTO `nv3_logs` VALUES (166, 'vi', 'sach-tieng-anh', 'log_add_catalog', 'id 10', 'id 10', 1, 1308287708);
INSERT INTO `nv3_logs` VALUES (167, 'vi', 'themes', 'Thêm block', 'Name : module block catalogs', 'Name : module block catalogs', 1, 1308287741);
INSERT INTO `nv3_logs` VALUES (168, 'vi', 'themes', 'Sửa block', 'Name : Sách Tiếng Anh', 'Name : Sách Tiếng Anh', 1, 1308287759);
INSERT INTO `nv3_logs` VALUES (169, 'vi', 'themes', 'Sửa block', 'Name : Sách Tiếng Anh', 'Name : Sách Tiếng Anh', 1, 1308287759);
INSERT INTO `nv3_logs` VALUES (170, 'vi', 'modules', 'Thêm module ảo "may_doc_sach"', '', '', 1, 1308287801);
INSERT INTO `nv3_logs` VALUES (171, 'vi', 'modules', 'Thiết lập module mới may-doc-sach"', '', '', 1, 1308287802);
INSERT INTO `nv3_logs` VALUES (172, 'vi', 'modules', 'Sửa module &ldquo;may-doc-sach&rdquo;', '', '', 1, 1308287819);
INSERT INTO `nv3_logs` VALUES (173, 'vi', 'may-doc-sach', 'log_add_catalog', 'id 1', 'id 1', 1, 1308287840);
INSERT INTO `nv3_logs` VALUES (174, 'vi', 'may-doc-sach', 'log_add_catalog', 'id 2', 'id 2', 1, 1308287850);
INSERT INTO `nv3_logs` VALUES (175, 'vi', 'may-doc-sach', 'log_add_catalog', 'id 3', 'id 3', 1, 1308287868);
INSERT INTO `nv3_logs` VALUES (176, 'vi', 'themes', 'Thêm block', 'Name : Máy Đọc Sách', 'Name : Máy Đọc Sách', 1, 1308287901);
INSERT INTO `nv3_logs` VALUES (177, 'vi', 'modules', 'Kích hoạt module "may-doc-sach"', 'Không', 'Không', 1, 1308287928);
INSERT INTO `nv3_logs` VALUES (178, 'vi', 'modules', 'Sửa module &ldquo;sach-tieng-anh&rdquo;', '', '', 1, 1308287946);
INSERT INTO `nv3_logs` VALUES (179, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1308287959);
INSERT INTO `nv3_logs` VALUES (180, 'vi', 'modules', 'Sửa module &ldquo;search&rdquo;', '', '', 1, 1308287977);
INSERT INTO `nv3_logs` VALUES (181, 'vi', 'themes', 'Thêm block', 'Name : Hỗ Trợ', 'Name : Hỗ Trợ', 1, 1308288184);
INSERT INTO `nv3_logs` VALUES (182, 'vi', 'modules', 'Kích hoạt module "contact"', 'Có', 'Có', 1, 1308288228);
INSERT INTO `nv3_logs` VALUES (183, 'vi', 'themes', 'Thêm block', 'Name : global html', 'Name : global html', 1, 1308288306);
INSERT INTO `nv3_logs` VALUES (184, 'vi', 'themes', 'Sửa block', 'Name : Hỗ Trợ Truwjc Tuyến', 'Name : Hỗ Trợ Truwjc Tuyến', 1, 1308288330);
INSERT INTO `nv3_logs` VALUES (185, 'vi', 'themes', 'Sửa block', 'Name : Hỗ Trợ Trực Tuyến', 'Name : Hỗ Trợ Trực Tuyến', 1, 1308288365);
INSERT INTO `nv3_logs` VALUES (186, 'vi', 'themes', 'Thêm block', 'Name : Links Liên Kết', 'Name : Links Liên Kết', 1, 1308288645);
INSERT INTO `nv3_logs` VALUES (187, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.22.182.71', ' Client IP:113.22.182.71', 0, 1308288676);
INSERT INTO `nv3_logs` VALUES (188, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.22.182.71', ' Client IP:113.22.182.71', 0, 1308288727);
INSERT INTO `nv3_logs` VALUES (189, 'vi', 'themes', 'Thiết lập layout theme: "default"', '', '', 1, 1308288796);
INSERT INTO `nv3_logs` VALUES (190, 'vi', 'themes', 'Thiết lập layout theme: "default"', '', '', 1, 1308288856);
INSERT INTO `nv3_logs` VALUES (191, 'vi', 'modules', 'Sửa module &ldquo;contact&rdquo;', '', '', 1, 1308288885);
INSERT INTO `nv3_logs` VALUES (192, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.22.182.71', ' Client IP:113.22.182.71', 0, 1308288938);
INSERT INTO `nv3_logs` VALUES (193, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.22.182.71', ' Client IP:113.22.182.71', 0, 1308289071);
INSERT INTO `nv3_logs` VALUES (194, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:113.22.182.71', ' Client IP:113.22.182.71', 0, 1308289101);
INSERT INTO `nv3_logs` VALUES (195, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308291846);
INSERT INTO `nv3_logs` VALUES (196, 'vi', 'banners', 'log_add_plan', 'planid 3', 'planid 3', 1, 1308291877);
INSERT INTO `nv3_logs` VALUES (197, 'vi', 'banners', 'log_add_banner', 'bannerid 4', 'bannerid 4', 1, 1308292203);
INSERT INTO `nv3_logs` VALUES (198, 'vi', 'themes', 'Thêm block', 'Name : Intro - footer', 'Name : Intro - footer', 1, 1308292243);
INSERT INTO `nv3_logs` VALUES (199, 'vi', 'themes', 'Sửa block', 'Name : Hỗ Trợ Trực Tuyến', 'Name : Hỗ Trợ Trực Tuyến', 1, 1308292322);
INSERT INTO `nv3_logs` VALUES (200, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308292351);
INSERT INTO `nv3_logs` VALUES (201, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308292372);
INSERT INTO `nv3_logs` VALUES (202, 'vi', 'banners', 'log_edit_banner', 'bannerid 4', 'bannerid 4', 1, 1308292426);
INSERT INTO `nv3_logs` VALUES (203, 'vi', 'banners', 'log_edit_plan', 'planid 3', 'planid 3', 1, 1308292449);
INSERT INTO `nv3_logs` VALUES (204, 'vi', 'banners', 'log_add_plan', 'planid 4', 'planid 4', 1, 1308293005);
INSERT INTO `nv3_logs` VALUES (205, 'vi', 'banners', 'log_add_banner', 'bannerid 5', 'bannerid 5', 1, 1308293024);
INSERT INTO `nv3_logs` VALUES (206, 'vi', 'themes', 'Thêm block', 'Name : intro-dacsanhue', 'Name : intro-dacsanhue', 1, 1308293054);
INSERT INTO `nv3_logs` VALUES (207, 'vi', 'banners', 'log_add_plan', 'planid 5', 'planid 5', 1, 1308293452);
INSERT INTO `nv3_logs` VALUES (208, 'vi', 'banners', 'log_add_banner', 'bannerid 6', 'bannerid 6', 1, 1308293488);
INSERT INTO `nv3_logs` VALUES (209, 'vi', 'banners', 'log_edit_banner', 'bannerid 5', 'bannerid 5', 1, 1308293505);
INSERT INTO `nv3_logs` VALUES (210, 'vi', 'banners', 'log_edit_banner', 'bannerid 4', 'bannerid 4', 1, 1308293525);
INSERT INTO `nv3_logs` VALUES (211, 'vi', 'themes', 'Thêm block', 'Name : qcd', 'Name : qcd', 1, 1308293553);
INSERT INTO `nv3_logs` VALUES (212, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308293558);
INSERT INTO `nv3_logs` VALUES (213, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308293599);
INSERT INTO `nv3_logs` VALUES (214, 'vi', 'themes', 'Sửa block', 'Name : Intro - footer', 'Name : Intro - footer', 1, 1308293623);
INSERT INTO `nv3_logs` VALUES (215, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308293628);
INSERT INTO `nv3_logs` VALUES (216, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308293877);
INSERT INTO `nv3_logs` VALUES (217, 'vi', 'themes', 'Sửa block', 'Name : Links Liên Kết', 'Name : Links Liên Kết', 1, 1308294027);
INSERT INTO `nv3_logs` VALUES (218, 'vi', 'themes', 'Sửa block', 'Name : Links Liên Kết', 'Name : Links Liên Kết', 1, 1308294109);
INSERT INTO `nv3_logs` VALUES (219, 'vi', 'themes', 'Sửa block', 'Name : Links Liên Kết', 'Name : Links Liên Kết', 1, 1308294288);
INSERT INTO `nv3_logs` VALUES (220, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294292);
INSERT INTO `nv3_logs` VALUES (221, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294370);
INSERT INTO `nv3_logs` VALUES (222, 'vi', 'modules', 'Kích hoạt module "users"', 'Có', 'Có', 1, 1308294380);
INSERT INTO `nv3_logs` VALUES (223, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294409);
INSERT INTO `nv3_logs` VALUES (224, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294426);
INSERT INTO `nv3_logs` VALUES (225, 'vi', 'themes', 'Thiết lập layout theme: "default"', '', '', 1, 1308294469);
INSERT INTO `nv3_logs` VALUES (226, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294486);
INSERT INTO `nv3_logs` VALUES (227, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294508);
INSERT INTO `nv3_logs` VALUES (228, 'vi', 'themes', 'Sửa block', 'Name : Intro - footer', 'Name : Intro - footer', 1, 1308294524);
INSERT INTO `nv3_logs` VALUES (229, 'vi', 'themes', 'Sửa block', 'Name : Intro - footer', 'Name : Intro - footer', 1, 1308294542);
INSERT INTO `nv3_logs` VALUES (230, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294546);
INSERT INTO `nv3_logs` VALUES (231, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294616);
INSERT INTO `nv3_logs` VALUES (232, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294651);
INSERT INTO `nv3_logs` VALUES (233, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294726);
INSERT INTO `nv3_logs` VALUES (234, 'vi', 'modules', 'Sửa module &ldquo;users&rdquo;', '', '', 1, 1308294754);
INSERT INTO `nv3_logs` VALUES (235, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294758);
INSERT INTO `nv3_logs` VALUES (236, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294830);
INSERT INTO `nv3_logs` VALUES (237, 'vi', 'modules', 'Thứ tự module "shops"', '13 -> 2', '13 -> 2', 1, 1308294847);
INSERT INTO `nv3_logs` VALUES (238, 'vi', 'modules', 'Thứ tự module "sach-tieng-anh"', '13 -> 3', '13 -> 3', 1, 1308294851);
INSERT INTO `nv3_logs` VALUES (239, 'vi', 'modules', 'Thứ tự module "contact"', '13 -> 4', '13 -> 4', 1, 1308294860);
INSERT INTO `nv3_logs` VALUES (240, 'vi', 'modules', 'Thứ tự module "search"', '13 -> 5', '13 -> 5', 1, 1308294867);
INSERT INTO `nv3_logs` VALUES (241, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:117.2.46.237', ' Client IP:117.2.46.237', 0, 1308294876);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_block`
-- 

CREATE TABLE `nv3_may_doc_sach_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_may_doc_sach_block`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_block_cat`
-- 

CREATE TABLE `nv3_may_doc_sach_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL auto_increment,
  `adddefault` tinyint(4) NOT NULL default '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_block_cat`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_catalogs`
-- 

CREATE TABLE `nv3_may_doc_sach_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewcat` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL default '0',
  `subcatid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_catalogs`
-- 

INSERT INTO `nv3_may_doc_sach_catalogs` VALUES (1, 0, ' ', ' ', 1, 1, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287840, 1308287840, 1334287840, 0, '', 'Kindle', 'Kindle', '', '');
INSERT INTO `nv3_may_doc_sach_catalogs` VALUES (2, 0, ' ', ' ', 2, 2, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287850, 1308287850, 1334287850, 0, '', 'Sony PRS', 'Sony-PRS', '', '');
INSERT INTO `nv3_may_doc_sach_catalogs` VALUES (3, 0, ' ', ' ', 3, 3, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287869, 1308287869, 1334287869, 0, '', 'Phụ Kiện', 'Phu-Kien', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_comments_vi`
-- 

CREATE TABLE `nv3_may_doc_sach_comments_vi` (
  `cid` mediumint(8) unsigned NOT NULL auto_increment,
  `id` mediumint(8) unsigned NOT NULL default '0',
  `post_time` int(11) unsigned NOT NULL default '0',
  `post_name` varchar(100) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL default '0',
  `photo` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_comments_vi`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_group`
-- 

CREATE TABLE `nv3_may_doc_sach_group` (
  `groupid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewgroup` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL default '0',
  `subgroupid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`groupid`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_group`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_money_vi`
-- 

CREATE TABLE `nv3_may_doc_sach_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_may_doc_sach_money_vi`
-- 

INSERT INTO `nv3_may_doc_sach_money_vi` VALUES (840, 'USD', 'US Dollar', 1);
INSERT INTO `nv3_may_doc_sach_money_vi` VALUES (704, 'VND', 'Vietnam Dong', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_orders`
-- 

CREATE TABLE `nv3_may_doc_sach_orders` (
  `order_id` int(11) unsigned NOT NULL auto_increment,
  `order_code` varchar(30) NOT NULL default '',
  `lang` char(2) NOT NULL default 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_address` text NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_note` text NOT NULL,
  `listid` text NOT NULL,
  `listnum` text NOT NULL,
  `listprice` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL default '0',
  `admin_id` int(11) unsigned NOT NULL default '0',
  `shop_id` int(11) unsigned NOT NULL default '0',
  `who_is` int(2) unsigned NOT NULL default '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL default '0',
  `order_time` int(11) unsigned NOT NULL default '0',
  `postip` varchar(100) NOT NULL,
  `view` tinyint(2) NOT NULL default '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL default '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY  (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_orders`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_payment`
-- 

CREATE TABLE `nv3_may_doc_sach_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY  (`payment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_may_doc_sach_payment`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_rows`
-- 

CREATE TABLE `nv3_may_doc_sach_rows` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` int(11) NOT NULL default '0',
  `topic_id` mediumint(8) NOT NULL default '0',
  `group_id` varchar(255) NOT NULL,
  `com_id` mediumint(8) NOT NULL default '0',
  `shopcat_id` mediumint(8) NOT NULL default '0',
  `user_id` mediumint(8) NOT NULL default '0',
  `source_id` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `product_number` int(11) NOT NULL default '0',
  `product_price` double NOT NULL default '0',
  `product_discounts` int(11) NOT NULL default '0',
  `money_unit` char(3) NOT NULL,
  `product_unit` int(11) NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL,
  `imgposition` tinyint(1) NOT NULL default '1',
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `ratingdetail` varchar(255) NOT NULL default '',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `hitslm` mediumint(8) unsigned NOT NULL default '0',
  `showprice` tinyint(2) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  `vi_note` text NOT NULL,
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_address` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `listcatid` (`listcatid`),
  KEY `topic_id` (`topic_id`),
  KEY `com_id` (`com_id`),
  KEY `shopcat_id` (`shopcat_id`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_rows`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_sources`
-- 

CREATE TABLE `nv3_may_doc_sach_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL auto_increment,
  `link` varchar(255) NOT NULL default '',
  `logo` varchar(255) NOT NULL default '',
  `weight` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  `vi_title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`sourceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_sources`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_topics`
-- 

CREATE TABLE `nv3_may_doc_sach_topics` (
  `topicid` mediumint(8) unsigned NOT NULL auto_increment,
  `catid` int(8) NOT NULL default '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`topicid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_topics`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_transaction`
-- 

CREATE TABLE `nv3_may_doc_sach_transaction` (
  `transaction_id` int(11) NOT NULL auto_increment,
  `transaction_time` int(11) NOT NULL default '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `payment` varchar(22) NOT NULL default '0',
  `payment_id` varchar(22) NOT NULL default '0',
  `payment_time` int(11) NOT NULL default '0',
  `payment_amount` int(11) NOT NULL default '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY  (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_transaction`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_may_doc_sach_units`
-- 

CREATE TABLE `nv3_may_doc_sach_units` (
  `id` int(11) NOT NULL auto_increment,
  `vi_title` varchar(255) NOT NULL default '',
  `vi_note` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_may_doc_sach_units`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_block`
-- 

CREATE TABLE `nv3_sach_tieng_anh_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_block`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_block_cat`
-- 

CREATE TABLE `nv3_sach_tieng_anh_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL auto_increment,
  `adddefault` tinyint(4) NOT NULL default '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_block_cat`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_catalogs`
-- 

CREATE TABLE `nv3_sach_tieng_anh_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewcat` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL default '0',
  `subcatid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_catalogs`
-- 

INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (1, 0, ' ', ' ', 1, 1, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287588, 1308287588, 1334287588, 0, '', 'Kinh Tế - Kinh Doanh', 'Kinh-Te-Kinh-Doanh', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (2, 0, ' ', ' ', 2, 2, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287599, 1308287599, 1334287599, 0, '', 'Văn Học', 'Van-Hoc', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (3, 0, ' ', ' ', 3, 3, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287612, 1308287612, 1334287612, 0, '', 'Tâm Lý - Giáo Dục', 'Tam-Ly-Giao-Duc', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (4, 0, ' ', ' ', 4, 4, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287623, 1308287623, 1334287623, 0, '', 'Thiếu Nhi', 'Thieu-Nhi', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (5, 0, ' ', ' ', 5, 5, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287634, 1308287634, 1334287634, 0, '', 'Y Khoa', 'Y-Khoa', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (6, 0, ' ', ' ', 6, 6, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287645, 1308287645, 1334287645, 0, '', 'Nghệ Thuật', 'Nghe-Thuat', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (7, 0, ' ', ' ', 7, 7, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287659, 1308287659, 1334287659, 0, '', 'Ẩm Thực', 'Am-Thuc', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (8, 0, ' ', ' ', 8, 8, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287669, 1308287669, 1334287669, 0, '', 'Văn Hoá - Du Lịch', 'Van-Hoa-Du-Lich', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (9, 0, ' ', ' ', 9, 9, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287684, 1308287684, 1334287684, 0, '', 'Khoa Học Kỹ Thuật', 'Khoa-Hoc-Ky-Thuat', '', '');
INSERT INTO `nv3_sach_tieng_anh_catalogs` VALUES (10, 0, ' ', ' ', 10, 10, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308287708, 1308287708, 1334287708, 0, '', 'Kho Sách Giảm Giá', 'Kho-Sach-Giam-Gia', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_comments_vi`
-- 

CREATE TABLE `nv3_sach_tieng_anh_comments_vi` (
  `cid` mediumint(8) unsigned NOT NULL auto_increment,
  `id` mediumint(8) unsigned NOT NULL default '0',
  `post_time` int(11) unsigned NOT NULL default '0',
  `post_name` varchar(100) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL default '0',
  `photo` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_comments_vi`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_group`
-- 

CREATE TABLE `nv3_sach_tieng_anh_group` (
  `groupid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewgroup` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL default '0',
  `subgroupid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`groupid`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_group`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_money_vi`
-- 

CREATE TABLE `nv3_sach_tieng_anh_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_money_vi`
-- 

INSERT INTO `nv3_sach_tieng_anh_money_vi` VALUES (840, 'USD', 'US Dollar', 1);
INSERT INTO `nv3_sach_tieng_anh_money_vi` VALUES (704, 'VND', 'Vietnam Dong', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_orders`
-- 

CREATE TABLE `nv3_sach_tieng_anh_orders` (
  `order_id` int(11) unsigned NOT NULL auto_increment,
  `order_code` varchar(30) NOT NULL default '',
  `lang` char(2) NOT NULL default 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_address` text NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_note` text NOT NULL,
  `listid` text NOT NULL,
  `listnum` text NOT NULL,
  `listprice` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL default '0',
  `admin_id` int(11) unsigned NOT NULL default '0',
  `shop_id` int(11) unsigned NOT NULL default '0',
  `who_is` int(2) unsigned NOT NULL default '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL default '0',
  `order_time` int(11) unsigned NOT NULL default '0',
  `postip` varchar(100) NOT NULL,
  `view` tinyint(2) NOT NULL default '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL default '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY  (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_orders`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_payment`
-- 

CREATE TABLE `nv3_sach_tieng_anh_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY  (`payment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_payment`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_rows`
-- 

CREATE TABLE `nv3_sach_tieng_anh_rows` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` int(11) NOT NULL default '0',
  `topic_id` mediumint(8) NOT NULL default '0',
  `group_id` varchar(255) NOT NULL,
  `com_id` mediumint(8) NOT NULL default '0',
  `shopcat_id` mediumint(8) NOT NULL default '0',
  `user_id` mediumint(8) NOT NULL default '0',
  `source_id` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `product_number` int(11) NOT NULL default '0',
  `product_price` double NOT NULL default '0',
  `product_discounts` int(11) NOT NULL default '0',
  `money_unit` char(3) NOT NULL,
  `product_unit` int(11) NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL,
  `imgposition` tinyint(1) NOT NULL default '1',
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `ratingdetail` varchar(255) NOT NULL default '',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `hitslm` mediumint(8) unsigned NOT NULL default '0',
  `showprice` tinyint(2) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  `vi_note` text NOT NULL,
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_address` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `listcatid` (`listcatid`),
  KEY `topic_id` (`topic_id`),
  KEY `com_id` (`com_id`),
  KEY `shopcat_id` (`shopcat_id`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_rows`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_sources`
-- 

CREATE TABLE `nv3_sach_tieng_anh_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL auto_increment,
  `link` varchar(255) NOT NULL default '',
  `logo` varchar(255) NOT NULL default '',
  `weight` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  `vi_title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`sourceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_sources`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_topics`
-- 

CREATE TABLE `nv3_sach_tieng_anh_topics` (
  `topicid` mediumint(8) unsigned NOT NULL auto_increment,
  `catid` int(8) NOT NULL default '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`topicid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_topics`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_transaction`
-- 

CREATE TABLE `nv3_sach_tieng_anh_transaction` (
  `transaction_id` int(11) NOT NULL auto_increment,
  `transaction_time` int(11) NOT NULL default '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `payment` varchar(22) NOT NULL default '0',
  `payment_id` varchar(22) NOT NULL default '0',
  `payment_time` int(11) NOT NULL default '0',
  `payment_amount` int(11) NOT NULL default '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY  (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_transaction`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sach_tieng_anh_units`
-- 

CREATE TABLE `nv3_sach_tieng_anh_units` (
  `id` int(11) NOT NULL auto_increment,
  `vi_title` varchar(255) NOT NULL default '',
  `vi_note` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_sach_tieng_anh_units`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_sessions`
-- 

CREATE TABLE `nv3_sessions` (
  `session_id` varchar(50) default NULL,
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL default '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_sessions`
-- 

INSERT INTO `nv3_sessions` VALUES ('8e38d793ccddea83ec1d7e0221544aa21963077357', 0, 'guest', 1308295112);
INSERT INTO `nv3_sessions` VALUES ('e5f922d1e266ebe5917e82aaf5c50a671963077357', 0, 'guest', 1308294760);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_setup`
-- 

CREATE TABLE `nv3_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL default '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_setup`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_setup_language`
-- 

CREATE TABLE `nv3_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_setup_language`
-- 

INSERT INTO `nv3_setup_language` VALUES ('vi', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_setup_modules`
-- 

CREATE TABLE `nv3_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL default '0',
  `virtual` tinyint(1) NOT NULL default '0',
  `module_file` varchar(50) NOT NULL default '',
  `module_data` varchar(55) NOT NULL default '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL default '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_setup_modules`
-- 

INSERT INTO `nv3_setup_modules` VALUES ('about', 0, 1, 'about', 'about', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('banners', 1, 0, 'banners', 'banners', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('contact', 0, 1, 'contact', 'contact', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('news', 0, 1, 'news', 'news', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('voting', 0, 0, 'voting', 'voting', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('forum', 0, 0, 'forum', 'forum', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('search', 1, 0, 'search', 'search', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('users', 1, 0, 'users', 'users', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('download', 0, 1, 'download', 'download', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('statistics', 0, 0, 'statistics', 'statistics', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('faq', 0, 1, 'faq', 'faq', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('menu', 0, 1, 'menu', 'menu', '3.1.00 1273225635', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('rss', 1, 0, 'rss', 'rss', '3.0.01 1287532800', 1308229805, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('shops', 0, 1, 'shops', 'shops', '3.0.01 1273830435', 1308230174, 'VINADES (contact@vinades.vn)', '');
INSERT INTO `nv3_setup_modules` VALUES ('sach-tieng-anh', 0, 0, 'shops', 'sach_tieng_anh', '', 1308287526, '', '');
INSERT INTO `nv3_setup_modules` VALUES ('may-doc-sach', 0, 0, 'shops', 'may_doc_sach', '', 1308287801, '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_block`
-- 

CREATE TABLE `nv3_shops_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_shops_block`
-- 

INSERT INTO `nv3_shops_block` VALUES (1, 3, 0);
INSERT INTO `nv3_shops_block` VALUES (1, 2, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_block_cat`
-- 

CREATE TABLE `nv3_shops_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL auto_increment,
  `adddefault` tinyint(4) NOT NULL default '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `nv3_shops_block_cat`
-- 

INSERT INTO `nv3_shops_block_cat` VALUES (1, 0, '', '', 1, 1308279442, 1308279442, 'Sách Tiếng Việt Mới', 'Sach-Tieng-Viet-Moi', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_catalogs`
-- 

CREATE TABLE `nv3_shops_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewcat` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL default '0',
  `subcatid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

-- 
-- Dumping data for table `nv3_shops_catalogs`
-- 

INSERT INTO `nv3_shops_catalogs` VALUES (1, 0, ' ', ' ', 1, 1, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278039, 1308278039, 1334278039, 0, '', 'Kinh Tế - Kinh Doanh', 'Kinh-Te-Kinh-Doanh', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (2, 0, ' ', ' ', 2, 2, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278068, 1308278068, 1334278068, 0, '', 'Văn Học Việt Nam', 'Van-Hoc-Viet-Nam', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (3, 0, ' ', ' ', 3, 3, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278096, 1308278096, 1334278096, 0, '', 'Văn Học Nước Ngoài', 'Van-Hoc-Nuoc-Ngoai', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (4, 0, ' ', ' ', 4, 4, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278413, 1308278413, 1334278413, 0, '', 'Truyện Kiếm Hiệp', 'Truyen-Kiem-Hiep', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (5, 0, ' ', ' ', 5, 5, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278436, 1308278436, 1334278436, 0, '', 'Tâm Lý - Kỹ Năng Sống', 'Tam-Ly-Ky-Nang-Song', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (6, 0, ' ', ' ', 6, 6, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278449, 1308278449, 1334278449, 0, '', 'Thiếu Nhi', 'Thieu-Nhi', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (7, 0, ' ', ' ', 7, 7, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278462, 1308278462, 1334278462, 0, '', 'Tuổi Mới Lớn', 'Tuoi-Moi-Lon', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (8, 0, ' ', ' ', 8, 8, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278540, 1308278540, 1334278540, 0, '', 'Tin Học', 'Tin-Hoc', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (9, 0, ' ', ' ', 9, 9, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278550, 1308278550, 1334278550, 0, '', 'Học Ngoại Ngữ', 'Hoc-Ngoai-Ngu', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (10, 0, ' ', ' ', 10, 10, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278559, 1308278559, 1334278559, 0, '', 'Từ Điển', 'Tu-Dien', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (11, 0, ' ', ' ', 11, 11, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278580, 1308278580, 1334278580, 0, '', 'Giáo Khoa &#40; Lớp 1-12 &#41;', 'Giao-Khoa-Lop-1-12', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (12, 0, ' ', ' ', 12, 12, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278595, 1308278595, 1334278595, 0, '', 'Giáo Khoa Tham Khảo', 'Giao-Khoa-Tham-Khao', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (13, 0, ' ', ' ', 13, 13, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278620, 1308278620, 1334278620, 0, '', 'Giáo Trình, Dạy Nghề', 'Giao-Trinh-Day-Nghe', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (14, 0, ' ', ' ', 14, 14, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278638, 1308278638, 1334278638, 0, '', 'Thể Dục, Thể Thao, Giải Trí', 'The-Duc-The-Thao-Giai-Tri', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (15, 0, ' ', ' ', 15, 15, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278659, 1308278659, 1334278659, 0, '', 'Văn Hóa, Du Lịch, Nghệ Thuật', 'Van-Hoa-Du-Lich-Nghe-Thuat', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (16, 0, ' ', ' ', 16, 16, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278677, 1308278677, 1334278677, 0, '', 'Y Học, Sức Khỏe', 'Y-Hoc-Suc-Khoe', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (17, 0, ' ', ' ', 17, 17, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278717, 1308278717, 1334278717, 0, '', 'Lịch Sử, Địa Lý, Tư Liệu', 'Lich-Su-Dia-Ly-Tu-Lieu', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (18, 0, ' ', ' ', 18, 18, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278909, 1308278909, 1334278909, 0, '', 'Tâm Linh, Huyền Bí, Phong Thủy', 'Tam-Linh-Huyen-Bi-Phong-Thuy', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (19, 0, ' ', ' ', 19, 19, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278940, 1308278940, 1334278940, 0, '', 'Mỹ Thuật, Thiết Kế', 'My-Thuat-Thiet-Ke', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (20, 0, ' ', ' ', 20, 20, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278956, 1308278956, 1334278956, 0, '', 'Pháp Luật, Thuế', 'Phap-Luat-Thue', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (21, 0, ' ', ' ', 21, 21, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278973, 1308278973, 1334278973, 0, '', 'Tôn Giáo, Tín Ngưỡng', 'Ton-Giao-Tin-Nguong', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (22, 0, ' ', ' ', 22, 22, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308278991, 1308278991, 1334278991, 0, '', 'Chính Trị, Xã Hội, Triết Học', 'Chinh-Tri-Xa-Hoi-Triet-Hoc', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (23, 0, ' ', ' ', 23, 23, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308279012, 1308279012, 1334279012, 0, '', 'Gia Đình, Nuôi Dạy Con', 'Gia-Dinh-Nuoi-Day-Con', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (24, 0, ' ', ' ', 24, 24, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308279028, 1308279028, 1334279028, 0, '', 'Trồng Trọt, Chăn Nuôi', 'Trong-Trot-Chan-Nuoi', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (25, 0, ' ', ' ', 25, 25, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308279041, 1308279041, 1334279041, 0, '', 'Audio Books', 'Audio-Books', '', '');
INSERT INTO `nv3_shops_catalogs` VALUES (26, 0, ' ', ' ', 26, 26, 0, 'viewcat_page_list', 0, '', 1, 4, '', 1308279054, 1308279054, 1334279054, 0, '', 'Kho Sách Giảm Giá', 'Kho-Sach-Giam-Gia', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_comments_vi`
-- 

CREATE TABLE `nv3_shops_comments_vi` (
  `cid` mediumint(8) unsigned NOT NULL auto_increment,
  `id` mediumint(8) unsigned NOT NULL default '0',
  `post_time` int(11) unsigned NOT NULL default '0',
  `post_name` varchar(100) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL default '0',
  `photo` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_shops_comments_vi`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_group`
-- 

CREATE TABLE `nv3_shops_group` (
  `groupid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewgroup` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL default '0',
  `subgroupid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`groupid`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_shops_group`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_money_vi`
-- 

CREATE TABLE `nv3_shops_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_shops_money_vi`
-- 

INSERT INTO `nv3_shops_money_vi` VALUES (840, 'USD', 'US Dollar', 1);
INSERT INTO `nv3_shops_money_vi` VALUES (704, 'VND', 'Vietnam Dong', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_orders`
-- 

CREATE TABLE `nv3_shops_orders` (
  `order_id` int(11) unsigned NOT NULL auto_increment,
  `order_code` varchar(30) NOT NULL default '',
  `lang` char(2) NOT NULL default 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_address` text NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_note` text NOT NULL,
  `listid` text NOT NULL,
  `listnum` text NOT NULL,
  `listprice` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL default '0',
  `admin_id` int(11) unsigned NOT NULL default '0',
  `shop_id` int(11) unsigned NOT NULL default '0',
  `who_is` int(2) unsigned NOT NULL default '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL default '0',
  `order_time` int(11) unsigned NOT NULL default '0',
  `postip` varchar(100) NOT NULL,
  `view` tinyint(2) NOT NULL default '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL default '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY  (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `nv3_shops_orders`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_payment`
-- 

CREATE TABLE `nv3_shops_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY  (`payment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_shops_payment`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_rows`
-- 

CREATE TABLE `nv3_shops_rows` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` int(11) NOT NULL default '0',
  `topic_id` mediumint(8) NOT NULL default '0',
  `group_id` varchar(255) NOT NULL,
  `com_id` mediumint(8) NOT NULL default '0',
  `shopcat_id` mediumint(8) NOT NULL default '0',
  `user_id` mediumint(8) NOT NULL default '0',
  `source_id` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `product_number` int(11) NOT NULL default '0',
  `product_price` double NOT NULL default '0',
  `product_discounts` int(11) NOT NULL default '0',
  `money_unit` char(3) NOT NULL,
  `product_unit` int(11) NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL,
  `imgposition` tinyint(1) NOT NULL default '1',
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `ratingdetail` varchar(255) NOT NULL default '',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `hitslm` mediumint(8) unsigned NOT NULL default '0',
  `showprice` tinyint(2) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  `vi_note` text NOT NULL,
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_address` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `listcatid` (`listcatid`),
  KEY `topic_id` (`topic_id`),
  KEY `com_id` (`com_id`),
  KEY `shopcat_id` (`shopcat_id`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

-- 
-- Dumping data for table `nv3_shops_rows`
-- 

INSERT INTO `nv3_shops_rows` VALUES (2, 1, 0, '', 0, 0, 1, 0, 1308280706, 1308284185, 1, 1308280680, 0, 2, 1, 60000, 10, 'VND', 1, '2011_06/dht-nghi_nhu_mot_ty_phu.200x300.w.d10.f300.b.jpg', 'thumb/dht-nghi_nhu_mot_ty_phu.200x300.w.d10.f300.b.jpg|block/dht-nghi_nhu_mot_ty_phu.200x300.w.d10.f300.b.jpg', '', 0, 0, 1, 1, 1, '0', 1, 1, 1, 10, 0, 0, 1, 'Nghĩ Như Một Tỷ Phú - Mọi Thứ Bạn Cần Biết Về Thành Công, Bất Động Sản Và Cuộc Sống &#40;Tái bản&#41;', 'Nghi-Nhu-Mot-Ty-Phu-Moi-Thu-Ban-Can-Biet-Ve-Thanh-Cong-Bat-Dong-San-Va-Cuoc-Song-Tai-ban', '', 'n&#x002F;a', '', '(Think Like A Billionaire - Everything You Need To Know About Success, Real Estate And Life)', '<p> Tác giả:&nbsp;<a href="http://nhasachphuongnam.com/search/pp/donald-j-trump/">Donald J. Trump</a><br  /> Bìa mềm.&nbsp;Xuất bản&nbsp;tháng 06/2011.&nbsp;<a href="http://nhasachphuongnam.com/search/dp/nxb-tre/">NXB Trẻ</a><br  /> Số trang: 254.&nbsp;Kích thước: 14x20cm.&nbsp;Cân nặng: 270&nbsp;gr</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (3, 2, 0, '', 0, 0, 1, 0, 1308282530, 1308284179, 1, 1308282480, 0, 2, 1, 61000, 10, 'VND', 1, '2011_06/bia-dan_ong_dan_ba_chuyen.205x300.w.d10.f300.b.jpg', 'thumb/bia-dan_ong_dan_ba_chuyen.205x300.w.d10.f300.b.jpg|block/bia-dan_ong_dan_ba_chuyen.205x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Đàn Ông, Đàn Bà Và Chuyện...', 'Dan-Ong-Dan-Ba-Va-Chuyen', '', 'n&#x002F;a', '', 'Tác giả: Nguyễn Lệ Chi\r\nBìa mềm. Xuất bản tháng 06/2011. NXB Thời Đại\r\nSố trang: 340. Kích thước: 14x20.5cm. Cân nặng: 380 gr', '<p> 20 nhân vật nhà văn-nhà báo-nghệ sĩ điện ảnh, truyền hình trong và ngoài nước qua cái nhìn sắc sảo của tác giả - nhà báo Nguyễn Lệ Chi. Với họ, chị vừa là một đồng nghiệp, vừa là một người bạn thâm giao. Một góc nhìn khác về những con người trí thức, nổi tiếng trong xã hội hiện đại luôn chuyển động và vươn mình ra thế giới.</p><p> &nbsp;</p><p> Nguyễn Lệ Chi không ngần ngại đưa vào tập sách này những lời các văn nghệ sĩ nói về chị. Người trả lời phỏng vấn đã quay lại nói về người đi phỏng vấn. Không phân vân, mà còn rất quả quyết, đó chính là bản tính của dịch giả Nguyễn Lệ Chi. Khởi đầu từ dịch tiếng Trung, khi cần chị cũng xông thẳng vào tiếng Anh. Khởi đầu là một dịch giả, chị cũng hăm hở bước vào làm báo, rồi làm sách. Mê sách đến mức tự đứng ra mua bản quyền, tổ chức bản thảo, rồi làm đủ các công đoạn in ấn để được cầm cuốn sách thơm mùi giấy mùi mực trong tay. Sự can đảm, hồn nhiên, muốn được làm những gì mình thích quả thật đã đem lại niềm vui, trước hết là cho Nguyễn Lệ Chi, sau nữa là cho những người đã thành bạn bè của chị, sau nữa là những người đọc có khả năng chia sẻ…</p><p> -&nbsp; Hồ Anh Thái</p><p> &nbsp;</p><p> Nghề báo đã giúp tôi gặp gỡ rất nhiều người, có những người thú vị, có những người không. Có những người mang lại cho tôi sự kính trọng, khâm phục, nhưng cũng có những người khiến tôi mất đi những cảm nhận đẹp đẽ trước khi gặp. Có những người mà sau những cuộc phỏng vấn, tôi không bao giờ gặp lại, nhưng cũng có những người đã trở thành bạn bè của tôi, thành những đồng nghiệp mãi gắn bó, luôn có tinh thần chăm sóc và hỗ trợ cho nhau. Tôi coi những nhân vật mà tôi đã phỏng vấn như cơ duyên gặp được nhau trong đời…</p><p align="right"> &nbsp;</p><p> Nhiều lúc tôi cũng lẩn thẩn nghĩ rằng việc tập hợp lại các nhân vật của mình, cưỡng ép họ phải ngồi chung trong một cuốn sách, cùng nhìn lại quá khứ, nhìn lại công việc mà họ đã từng làm như thế này, phải chăng là một việc rất nhàm chán và cũ kĩ? Thế nhưng tôi vẫn không tài nào cưỡng lại nổi ý tưởng này. Dường như có một tiếng gọi từ bên trong tôi cần phải hoàn thành công việc này cho xong, phải dũng cảm tự đứng riêng ra, cùng nhìn lại quá khứ, nhìn lại những việc mình đã làm, dẫu tốt, dẫu xấu, dẫu không có nhiều tiếng vang lẫn ảnh hưởng gì tới các nhân vật. Có lẽ việc bắt mình đối diện với công việc của mình vẫn là điều mà tôi mong muốn hơn cả.</p><p> -&nbsp; Nguyễn Lệ Chi</p><p> &nbsp;</p><p> <span style="text-decoration: underline;">Về tác giả:</span></p><p> <strong>Nguyễn Lệ Chi</strong> tuổi Thìn, chòm sao Hổ Cáp, sinh ra và lớn lên tại Hà Nội. Sống tại TP.HCM từ năm 2004-nay. Người sáng lập và chủ sở hữu sách Chibooks. Hiện làm Biên tập viên tại báo Thanh Niên.</p><p> Đã xuất bản hơn 40 tác phẩm dịch, phần lớn là tiểu thuyết và sách điện ảnh: <em>Nghiên cứu tâm lí diễn xuất điện ảnh,</em><strong> </strong><em>Đối thoại với Trương Nghệ Mưu</em>, <em>Đối thoại với Củng Lợi</em>, <em>Nghệ thuật quay phim điện ảnh</em><strong>, </strong><em>Kim chỉ nam giải quyết các vấn đề khó cho các nhà biên kịch điện</em>, <em>Đối thoại với Trần Khải Ca</em>, <em>Co Giật</em><strong>, </strong><em>Anh có biết nói yêu không</em><strong>, </strong><em>Tối nay có việc không về nhà</em><strong>,</strong> <em>Hoa bên bờ,</em><strong> </strong><em>Đảo Tường Vy</em><strong>, </strong><em>Ôi đàn ông</em><strong>, </strong><em>Thiền của tôi</em>, <em>Tuyển tập Vệ Tuệ,</em><strong> </strong><em>Chuyện tình một đêm</em>, <em>Baby Thượng Hải</em>, <em>Gia đình ngọt ngào của tôi</em>, <em>Gái Trinh</em>, <em>Ai là kẻ thứ ba</em>, <em>Biển quái vật…</em></p>', '');
INSERT INTO `nv3_shops_rows` VALUES (4, 3, 0, '', 0, 0, 1, 0, 1308284368, 1308284368, 1, 1308284368, 0, 2, 1, 30000, 10, 'VND', 1, '2011_06/c113077665084df2eeec514cb.193x300.w.d10.f300.b.jpg', 'thumb/c113077665084df2eeec514cb.193x300.w.d10.f300.b.jpg|block/c113077665084df2eeec514cb.193x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Phút Im Lặng Phút Im Lặng', 'Phut-Im-Lang-Phut-Im-Lang', '', 'n/a', '', 'Tác giả: Siegfried Lenz. Dịch giả: Nguyễn Thị Tâm Tình\r\nBìa mềm. Xuất bản tháng 07/2011. NXB Phụ Nữ\r\nSố trang: 155. Kích thước: 13x20.5x0.8cm. Cân nặng: 150 gr', '<div class="p-description" style="zoom: 1;"> <p> <strong>Phút im lặng</strong> ra mắt độc giả Đức năm 2008. Trước đó, Siegfried Lenz đã ngừng sáng tác một thời gian, khi người vợ đã cùng ông chung sống năm mươi bảy năm qua đời.</p> <p> &nbsp;</p> <p> <strong>Phút im lặng</strong> là hoài niệm về mối tình đầu trong trẻo, gợi lên cảm giác dịu dàng về không gian, tâm trạng, và những khoảnh khắc đã qua. Giọng văn có lúc khiến người đọc cảm thấy sự khắc nghiệt hiện sinh như của Hemingway, nhưng rồi lại trở lại với vẻ duyên dáng và toàn vẹn của Lenz - người kể chuyện, người đang kể lại với chúng ta, từ khuôn khổ hữu hạn của tiểu thuyết ngắn, một câu chuyện mang giá trị vĩnh cửu của con người.</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (5, 4, 0, '', 0, 0, 1, 0, 1308284562, 1308284562, 1, 1308284562, 0, 2, 1, 115000, 10, 'VND', 1, '2011_06/phong_than_song_long_10.185x300.w.d10.f300.b.jpg', 'thumb/phong_than_song_long_10.185x300.w.d10.f300.b.jpg|block/phong_than_song_long_10.185x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Phong Thần Song Long &#40;Tập 10&#41;&#x3A; Ngày Tàn Của Thương Trụ', 'Phong-Than-Song-Long-Tap-10-Ngay-Tan-Cua-Thuong-Tru', '', 'n/a', '', 'Tác giả: Long Nhân. Dịch giả: Biên Hoang hiệp khách\r\nBìa mềm. Xuất bản tháng 04/2011. NXB Hội Nhà Văn\r\nSố trang: 468. Kích thước: 13x21cm. Cân nặng: 500 gr', '<p> Xin trân trọng giới thiệu!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (6, 5, 0, '', 0, 0, 1, 0, 1308284697, 1308284697, 1, 1308284697, 0, 2, 1, 178000, 10, 'VND', 1, '2011_06/c113067421744de34d9e1bd10.195x300.w.d10.f300.b.jpg', 'thumb/c113067421744de34d9e1bd10.195x300.w.d10.f300.b.jpg|block/c113067421744de34d9e1bd10.195x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Sách Hướng Dẫn Kỹ Năng Học Tập Theo Phương Pháp Buzan', 'Sach-Huong-Dan-Ky-Nang-Hoc-Tap-Theo-Phuong-Phap-Buzan', '', 'n/a', '', 'Tác giả: Tony Buzan. Dịch giả: Lê Huy Lâm\r\nBìa mềm. Xuất bản tháng 06/2011. NXB Tổng Hợp TP.HCM\r\nSố trang: 219. Kích thước: 15x23x1.6cm. Cân nặng: 420 gr', '<div class="p-description" style="zoom: 1;"> <p> &quot;Bộ não của bạn là một bộ xử lý siêu mạnh có khả năng tạo ra vô số ý tưởng liên kết nhau. Nếu bạn biết cách khai thác nó thì học tập sẽ không còn là công việc đầy lo âu và căng thẳng mà trở nên nhanh chóng, dễ dàng và hiệu quả.&quot; - Tony Buzan</p> <p> &nbsp;</p> <p> Sách hướng dẫn kỹ năng học tập theo phương pháp BUZAN sẽ giúp bạn:</p> <p> - Tìm ra con đường học tập hiệu quả nhất</p> <p> - Có khả năng đọc 1.000 từ mỗi phút</p> <p> - Nâng cao khả năng tập trung và hiểu</p> <p> - Ghi chú hiệu quả hơn khi nghe giảng và đọc</p> <p> - Ghi nhớ và nhớ lại hiệu quả nội dung đã học</p> <p> - Ôn tập một cách khoa học nhưng vẫn có những phút &quot;giải lao&quot; thoải mái</p> <p> - Tự tin chuẩn bị cho việc học, thi cử và kiểm tra</p> <p> &nbsp;</p> <p> Hơn 35 năm qua, Tony Buzan đã hoạt động không mệt mỏi nhằm giúp mọi người ở các độ tuổi khác nhau trên toàn thế giới tận dụng tối đa khả năng tư duy của họ bằng việc áp dụng các kỹ thuật lập Sơ đồ Tư duy, Đọc nhanh và Nhớ. Trong sách hướng dẫn này, tác giả kết hợp những kỹ thuật trên với chương trình BOST độc đáo để giúp người học ở mọi trình độ tiếp cận một phương pháp học mới và hoàn toàn tích cực. Bằng việc thực hành chúng, bạn sẽ tự tin hơn và kỹ năng phát huy năng lực học tập của bản thân qua đó cũng phát triển, dù bạn học môn gì hay ở trình độ nào.</p> <p> &nbsp;</p> <p> Tony Buzan, người phát minh Sơ đồ Tư duy, là chuyên gia hàng đầu thế giới về não bộ và phương pháp học tập.</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (7, 6, 0, '', 0, 0, 1, 0, 1308284795, 1308284795, 1, 1308284795, 0, 2, 1, 54000, 10, 'VND', 1, '2011_06/nam_dua_tre_va_con_tien_cat.191x300.w.d10.f300.b.jpg', 'thumb/nam_dua_tre_va_con_tien_cat.191x300.w.d10.f300.b.jpg|block/nam_dua_tre_va_con_tien_cat.191x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Năm Đứa Trẻ Và Con Tiên Cát', 'Nam-Dua-Tre-Va-Con-Tien-Cat', '', 'n/a', '', 'Tác giả: E. Nesbit. Dịch giả: Nguyễn Thị Huyền\r\nBìa mềm. Xuất bản tháng 06/2011. NXB Văn Hóa - Thông Tin\r\nSố trang: 295. Kích thước: 13x20.5cm. Cân nặng: 250 gr', '<div class="p-description" style="zoom: 1;"> <div id="fragment-1"> <div> <p> Vào một ngày hè, năm đứa trẻ gặp con Tiên cát tên là Psammead, nó có hình hài thật kỳ quặc.</p> <p> Điều đó chẳng quan trọng bởi vì nó có thể cho bọn trẻ mỗi ngày một điều ước. Chúng đã ước mình đẹp như tiên, trở nên giàu có, biết bay trên những đôi cánh, sống trong một lâu đài nguy nga tráng lệ....Những điều ước ấy khiến bọn trẻ vui nhưng cũng làm chúng bao phen khốn đốn, khóc dở mếu dở.</p> <p> Rồi điều ước cuối cùng mới là điều ước tuyệt vời nhất đối với chúng. Các em có biết điều ước cuối cùng của bọn trẻ là gì không... thôi tốt nhất là các em hãy đọc cuốn truyện này nhé, tôi tin là các em không đặt nó xuống khi chưa biết được điều ước đó đâu</p> </div> </div></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (8, 7, 0, '', 0, 0, 1, 0, 1308284884, 1308284884, 1, 1308284884, 0, 2, 1, 54000, 10, 'VND', 1, '2011_06/bong_hong_chua_kip_gui.160x250.w.d10.f250.b.jpg', 'thumb/bong_hong_chua_kip_gui.160x250.w.d10.f250.b.jpg|block/bong_hong_chua_kip_gui.160x250.w.d10.f250.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Bông Hồng Chưa Kịp Gửi', 'Bong-Hong-Chua-Kip-Gui', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa mềm. Xuất bản tháng 06/2011. NXB Văn Học\r\nSố trang: 269. Kích thước: 14x20cm. Cân nặng: 280 gr', '<p> Nhớ, để nghe thoáng một chút buồn, một chút vui, một chút ngờ nghệch vụng về của những ngày mới lớn. Nhớ, để mong những năm còn lại giữa chúng mình trái đất sẽ tròn.</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (9, 8, 0, '', 0, 0, 1, 0, 1308285060, 1308285079, 1, 1308285060, 0, 2, 1, 56000, 0, 'VND', 1, '2011_06/c113012817764d8ffbf0471ec.200x300.w.f300.b.jpg', 'thumb/c113012817764d8ffbf0471ec.200x300.w.f300.b.jpg|block/c113012817764d8ffbf0471ec.200x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Chế Bản Điện Tử Với Illustrator CS5 Dành Cho Người Tự Học', 'Che-Ban-Dien-Tu-Voi-Illustrator-CS5-Danh-Cho-Nguoi-Tu-Hoc', '', 'n&#x002F;a', '', 'Tác giả: Quang Huy, Thanh Tâm, Lê Thuận\r\nBìa mềm. Xuất bản tháng 04/2011. NXB Giao Thông Vận Tải\r\nSố trang: 271. Kích thước: 16x24x1.3cm. Cân nặng: 310 gr', '<p> &quot;CHẾ BẢN ĐIỆN TỬ VỚI ILLUSTRATOR CS5” được biên soạn với tiêu chí “Dành cho người tự học - Học tới đâu thực hành tới đó”. Nội dung sách gồm 6 chương, trong đó có 5 chương lý thuyết và 1 chương bài tập tổng hợp, các bài tập được sắp xếp xen kẽ từ đơn giản đến phức tạp. Riêng mỗi chương lý thuyết sẽ kèm theo một bài tập minh họa. Sau khi thực hành vẽ sản phẩm trong mỗi bài tập, các bạn sẽ có những kinh nghiệm để thực hiện tiếp một số sản phẩm khác.</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (10, 9, 0, '', 0, 0, 1, 0, 1308285159, 1308285159, 1, 1308285159, 0, 2, 1, 40000, 0, 'VND', 1, '2011_06/c113051033394dca4beb55fa6.201x300.w.f300.b.jpg', 'thumb/c113051033394dca4beb55fa6.201x300.w.f300.b.jpg|block/c113051033394dca4beb55fa6.201x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Giáo Trình Hán Ngữ Cải Tiến &#40;Tập 1 - Quyển 2&#41;', 'Giao-Trinh-Han-Ngu-Cai-Tien-Tap-1-Quyen-2', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả. Dịch giả: Lê Khắc Kiều Lục, Trương Văn Giới\r\nBìa mềm. Xuất bản tháng 12/2040. NXB Tổng Hợp TP.HCM\r\nSố trang: 246. Kích thước: 16x24x1.6cm. Cân nặng: 300 gr', '<p> Xin trân trọng giới thiệu!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (11, 10, 0, '', 0, 0, 1, 0, 1308285287, 1308285287, 1, 1308285287, 0, 2, 1, 290000, 10, 'VND', 1, '2011_06/c113070033434de749cfe0f8f.215x300.w.d10.f300.b.jpg', 'thumb/c113070033434de749cfe0f8f.215x300.w.d10.f300.b.jpg|block/c113070033434de749cfe0f8f.215x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Từ Điển Tiếng Việt 2011', 'Tu-Dien-Tieng-Viet-2011', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa cứng. Xuất bản tháng 04/2011. NXB Đà Nẵng\r\nSố trang: 1562. Kích thước: 14.5x20.5x7.5cm. Cân nặng: 1620 gr', '<p> Xin trân trọng giới thiệu!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (12, 11, 0, '', 0, 0, 1, 0, 1308285372, 1308285372, 1, 1308285372, 0, 2, 1, 136000, 5, 'USD', 1, '2011_06/59369_12803791014c5108dddc7f6.207x300.w.d5.f300.b.jpg', 'thumb/59369_12803791014c5108dddc7f6.207x300.w.d5.f300.b.jpg|block/59369_12803791014c5108dddc7f6.207x300.w.d5.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Bộ Sách Giáo Khoa Lớp 12 - Ban Cơ Bản &#40;13 cuốn&#41;', 'Bo-Sach-Giao-Khoa-Lop-12-Ban-Co-Ban-13-cuon', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa mềm. Xuất bản tháng 05/2011. NXB Giáo Dục\r\nKích thước: 17x24x12cm. Cân nặng: 2900 gr', '<p> ﻿Bộ SGK lớp 12 - ban cơ bản:<br  /> <br  /> 1. Công dân 12<br  /> 2. Công nghệ 12<br  /> 3. Tin học 12<br  /> 4. Giải tích 12<br  /> 5. Hình học 12<br  /> 6. Vật lý 12<br  /> 7. Hóa học 12<br  /> 8. Sinh học 12<br  /> 9. Ngữ văn 12 (tập 1)<br  /> 10. Ngữ văn 12 (tập 2)<br  /> 11. Lịch sử 12<br  /> 12. Địa lý 12<br  /> 13. Tiếng Anh 12</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (13, 12, 0, '', 0, 0, 1, 0, 1308285513, 1308285513, 1, 1308285513, 0, 2, 1, 49000, 0, 'VND', 1, '2011_06/c113047440584dc4d07a8124c.200x300.w.f300.b.jpg', 'thumb/c113047440584dc4d07a8124c.200x300.w.f300.b.jpg|block/c113047440584dc4d07a8124c.200x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Tóm Tắt Lý Thuyết Và Phương Pháp Giải Nhanh Bài Tập Trắc Nghiệm Sinh Học 12', 'Tom-Tat-Ly-Thuyet-Va-Phuong-Phap-Giai-Nhanh-Bai-Tap-Trac-Nghiem-Sinh-Hoc-12', '', 'n/a', '', 'Tác giả: Đỗ Thị Kim Huê\r\nBìa mềm. Xuất bản tháng 10/2011. NXB Đại Học Quốc Gia TP.HCM\r\nSố trang: 320. Kích thước: 16x24x1.4cm. Cân nặng: 330 gr', '<p> Xin trân trọng giới thiệu!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (14, 13, 0, '', 0, 0, 1, 0, 1308285592, 1308285592, 1, 1308285592, 0, 2, 1, 100000, 10, 'USD', 1, '2011_06/dht-tin_tuc_trai_dat_phang.197x300.w.d10.f300.b.jpg', 'thumb/dht-tin_tuc_trai_dat_phang.197x300.w.d10.f300.b.jpg|block/dht-tin_tuc_trai_dat_phang.197x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Tin Tức Trái Đất Phẳng', 'Tin-Tuc-Trai-Dat-Phang', '', 'n/a', '', 'Tác giả: Nick Davies. Dịch giả: Nguyễn Thị Hiền Thảo\r\nBìa mềm. Xuất bản tháng 06/2011. NXB Dân Trí\r\nSố trang: 482. Kích thước: 16x24cm. Cân nặng: 540 gr', '<div class="p-description" style="zoom: 1;"> <p> “<em>Tin tức Trái đất phẳng</em>” - tác phẩm để đời của Nick Davies, nhà báo kỳ cựu với hơn 30 năm làm việc trong gần như tất cả những tờ báo lớn ở Anh - phơi bày báo chí theo đúng cái cách mà báo chí vẫn dùng để “soi” các chính trị gia, thành viên hoàng tộc và vô số mục tiêu khác: khắc nghiệt, tàn nhẫn và không nể nang bất cứ thế lực nào khác. Và cuốn sách đã gây ra một cơn chấn động trong giới báo chí toàn cầu, có thể thay đổi vĩnh viễn cách bạn nhìn nhận báo chí nói riêng và tất cả các phương tiện truyền thông khác nói chung!</p> <p> &nbsp;</p> <p> <span style="text-decoration: underline;"><em>Về tác giả:</em></span></p> <p> Nick Davies sinh năm 1953 tại Anh. Ông lấy bằng cử nhân Triết học, Chính trị và Kinh tế của trường đại học Oxford năm 1974 và bắt đầu nghiệp báo năm 1976 với tư cách là phóng viên tập sự cho tập đoàn&nbsp;<em>The Mirror</em>. Sau đó, ông lần lượt làm việc cho&nbsp;<em>Sunday People</em>,&nbsp;<em>The Evening Standard</em>,&nbsp;<em>The Guardian</em>,&nbsp;<em>The Observer</em>,&nbsp;<em>London Daily News</em>, chương trình&nbsp;<em>World In Action</em>. Kể từ năm 1989, Davies trở thành phóng viên tự do của&nbsp;<em>The Guardian</em> cho đến năm 2009.</p> <p> Nick Davies đã từng được nhận giải thưởng&nbsp;<em>Nhà báo của năm</em>,&nbsp;<em>Phóng viên của năm</em> và&nbsp;<em>Biên tập viên của năm</em> cho những phóng sự điều tra của ông về tội phạm, ma túy, nạn đói nghèo và các vấn đề xã hội khác.</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (15, 14, 0, '', 0, 0, 1, 0, 1308285718, 1308285718, 1, 1308285718, 0, 2, 1, 52000, 10, 'USD', 1, '2011_06/c113067218714de2fe4f049ab.211x300.w.d10.f300.b.jpg', 'thumb/c113067218714de2fe4f049ab.211x300.w.d10.f300.b.jpg|block/c113067218714de2fe4f049ab.211x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Các Trò Chơi Vật Lý Hấp Dẫn', 'Cac-Tro-Choi-Vat-Ly-Hap-Dan', '', 'n/a', '', 'Tác giả: Khánh Linh\r\nBìa mềm. Xuất bản tháng 04/2011. NXB Thời Đại\r\nSố trang: 327. Kích thước: 14.5x20.5x1.3cm. Cân nặng: 300 gr', '<div class="p-description" style="zoom: 1;"> <p> Hiện nay phần lớn trẻ đều cho rằng các môn học toán, lý, hóa đều phải học thuộc lòng, đòi hỏi trí nhớ, dưới cơ chế lấy việc lên lớp làm mục tiêu. Nhưng từ mấy năm trước ở Nhật Bản, cùng với sự kêu gọi và giúp đỡ của rất nhiều giáo viên, ngành giáo dục đưa ra chương trình &quot;Hoạt động khoa học cho thanh thiếu niên&quot;. Ở Tokyo đã có gần 1 vạn phụ huynh và trẻ em tham gia hoạt động này trong vòng 1 ngày. Có thể thấy đây là việc được rất nhiều người quan tâm và coi trọng.</p> <p> &nbsp;</p> <p> Thực tế cho thấy phương pháp giáo dục bằng trực quan mang lại hiệu quả vượt trội và mang tính thực tiễn cao. Ở phương pháp này, trẻ được phát huy tối đa khả năng sáng tạo, kích thích trí tưởng tượng và phát triển tất cả các giác quan. Đối với trẻ em, yếu tố quan trọng là phải kích thích vào sự hứng thú, say mê. Vì vậy việc học tập cần thiết cũng phải là một trò chơi hấp dẫn.</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (16, 15, 0, '', 0, 0, 1, 0, 1308285814, 1308285814, 1, 1308285814, 0, 2, 1, 54000, 10, 'VND', 1, '2011_06/c113059462384dd7287e11bf2.192x300.w.d10.f300.b.jpg', 'thumb/c113059462384dd7287e11bf2.192x300.w.d10.f300.b.jpg|block/c113059462384dd7287e11bf2.192x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Talmud - Tinh Hoa Trí Tuệ Do Thái', 'Talmud-Tinh-Hoa-Tri-Tue-Do-Thai', '', 'n/a', '', 'Tác giả: Từ Quang Á. Dịch giả: Tiến Thành, Kiến Văn\r\nBìa mềm. Xuất bản tháng 07/2011. NXB Lao Động\r\nSố trang: 277. Kích thước: 13.5x21x1.2cm. Cân nặng: 270 gr', '<div class="p-description" style="zoom: 1;"> <p> Talmud - suối nguồn của trí tuệ Do Thái, là tác phẩm được lưu truyền rộng rãi và được đánh giá rất cao vì nó kết tinh trí tuệ của một dân tộc mà định mệnh ngặt nghèo cũng như năng lực sáng tạo đã trở thành huyền thoại.<br  /> Trong lịch sử nhân loại, có thể nói không một dân tộc nào nhiều khổ nạn phải lìa bỏ quê hương xứ sở phiêu bạt khắp nơi ... mà vẫn viết nên những trang sử văn minh rực rỡ như dân tộc Do Thái.<br  /> Cuốn sách này, đề cập đến những khía cạnh tinh hoa của Talmud, qua những câu chuyện sinh động ở mọi lĩnh vực: văn hóa, khoa học, nghệ thuật, kinh doanh, giáo dục, đối nhân xử thế...</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (17, 16, 0, '', 0, 0, 1, 0, 1308285960, 1308285960, 1, 1308285960, 0, 2, 1, 18000, 0, 'VND', 1, '2011_06/c113002458274d802d43a9e0f.204x300.w.f300.b.jpg', 'thumb/c113002458274d802d43a9e0f.204x300.w.f300.b.jpg|block/c113002458274d802d43a9e0f.204x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Diện Chẩn Điều Khiển Liệu Pháp Và Xoa Bóp Việt Nam', 'Dien-Chan-Dieu-Khien-Lieu-Phap-Va-Xoa-Bop-Viet-Nam', '', 'n/a', '', 'Tác giả: Bùi Quốc Châu\r\nBìa mềm. Xuất bản tháng 07/2011. NXB Đà Nẵng\r\nSố trang: 36. Kích thước: 13x19x0.2cm. Cân nặng: 50 gr', '<p> Mời bạn đón đọc!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (18, 17, 0, '', 0, 0, 1, 0, 1308286076, 1308286076, 1, 1308286076, 0, 2, 1, 160000, 10, 'USD', 1, '2011_06/dht-viet_nam_dep_nhat_co_ten_bac_ho.253x300.w.d10.f300.b.jpg', 'thumb/dht-viet_nam_dep_nhat_co_ten_bac_ho.253x300.w.d10.f300.b.jpg|block/dht-viet_nam_dep_nhat_co_ten_bac_ho.253x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Việt Nam Đẹp Nhất Có Tên Bác Hồ &#40;Tập Ảnh Và Tư Liệu&#41;', 'Viet-Nam-Dep-Nhat-Co-Ten-Bac-Ho-Tap-Anh-Va-Tu-Lieu', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa cứng. Xuất bản tháng 06/2011. NXB Trẻ\r\nSố trang: 186. Kích thước: 24x19cm. Cân nặng: 500 gr', '<div class="p-description" style="zoom: 1;"> <p> Sách nói về vị lãnh tụ kính yêu của dân tộc dưới góc nhìn gần gũi, thân thương. Mặc dù bám theo trình tự biên niên, sách vẫn cố gắng tổ chức theo các lĩnh vực hoạt động và các sự kiện lớn trong cuộc đời Bác, cũng như theo dòng lịch sử của dân tộc để bố cục được chặt chẽ, rõ ràng. Để làm được điều này, sách sử dụng các trích dẫn lời phát biểu của Bác như những tiêu đề để phân ra thành các mục.</p> <p> Sách còn sử dụng một số hình ảnh trong các phim tài liệu và các kỷ vật trưng bày tại Bảo tàng Hồ Chí Minh (chi nhánh Hồ Chí Minh). Độc giả sẽ cảm nhận được rất rõ tình cảm nhân dân dành cho Người qua những hình ảnh về lễ tang của Người. Nỗi đau kìm nén của người thống lĩnh muôn vạn hùng binh hay vị thủ tướng lừng lẫy trong các bàn hội nghị quốc tế trước cái chết của người thầy, người đồng chí, sự đau đớn khi mất người ông của các em bé, sự thảng thốt của một cô gái hay những lời khóc than của một bà cụ sẽ nói thay những lời hoa mỹ. Độc giả cũng có dịp nhìn thấy những kỷ vật, đôi khi liên quan đến những bức ảnh lịch sử thật thú vị, như mô hình tàu Amiral Latouche Tréville, nhà số 9 ngõ Compoint, chiếc micro Bác dùng đọc Tuyên ngôn độc lập hay chiếc đũa điều khiển Bác dùng bắt nhịp bài “Kết đoàn”…</p> <p> Tuy nhiên, sách không kết thúc ở lễ truy điệu của Bác. “Chủ tịch Hồ Chí Minh sống mãi trong sự nghiệp của chúng ta”. Chủ tịch Hồ Chí Minh đã đi xa nhưng con đường Bác đã chọn, phương hướng mà Bác vạch ra vẫn tiếp tục đem đến những thành quả lớn lao – đất nước đã ngày càng mạnh giàu, to đẹp, ngày càng đạt được vị thế lớn lao hơn trên trường quốc tế, như Bác vẫn hằng mong lúc sinh thời. Sách có cập nhật những thông tin về những cột mốc của đất nước từ sau giải phóng đến nay, trải dài theo các Đại hội Đảng từ Đại hội IV đến Đại hội XI, các thành tựu về kinh tế, văn hóa, quốc phòng, đối ngoại, các công trình lớn làm thay đổi bộ mặt đất nước.</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (19, 18, 0, '', 0, 0, 1, 0, 1308286173, 1308286173, 1, 1308286173, 0, 2, 1, 45000, 0, 'VND', 1, '2011_06/c113037019344db4e9ae6f9de.180x300.w.f300.b.jpg', 'thumb/c113037019344db4e9ae6f9de.180x300.w.f300.b.jpg|block/c113037019344db4e9ae6f9de.180x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Điều Kỳ Diệu Của Ký Ức - Hé Lộ Những Bí Ẩn Tâm Linh Để Hàn Gắn Nỗi Đau', 'Dieu-Ky-Dieu-Cua-Ky-Uc-He-Lo-Nhung-Bi-An-Tam-Linh-De-Han-Gan-Noi-Dau', '', 'n/a', '', 'Tác giả: Sylvia Browne, Lindsay Harrison. Dịch giả: Việt Thư\r\nBìa mềm. Xuất bản tháng 04/2011. NXB Thời Đại\r\nSố trang: 254. Kích thước: 12x20x1.2cm. Cân nặng: 210 gr', '<p> Bạn sẽ bắt gặp những câu chuyện chọn lọc từ hàng ngàn câu chuyện quay về kiếp trước được tác giả thực hiện trong 25 năm nghiên cứu tiền kiếp và tế bào ký ức. Đặc biệt từ những câu chuyện này, nguồn gốc của những vấn đề sâu kín, cũng như tài năng tiềm ẩn lớn lao nhất trong mỗi con người dần dần hé lộ<br  /> Cuốn sách ngoài mục đích giúp bạn vượt qua nỗi ám ảnh của quá khứ, còn khơi dậy từ ký ức một số chi tiết, yếu tố cần thiết để hàn gắn những nỗi đau tinh thần và giải toả mọi vướng mắc trĩu nặng trong lòng nhằm tạo dựng cho mình một cuộc sống tốt đẹp, an lành!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (20, 19, 0, '', 0, 0, 1, 0, 1308286273, 1308286273, 1, 1308286273, 0, 2, 1, 150000, 10, 'VND', 1, '2011_06/dht-sac_mau_to_am_tuyen_tap_thiet_ke_cua_nha_vui_6.216x300.w.d10.f300.b.jpg', 'thumb/dht-sac_mau_to_am_tuyen_tap_thiet_ke_cua_nha_vui_6.216x300.w.d10.f300.b.jpg|block/dht-sac_mau_to_am_tuyen_tap_thiet_ke_cua_nha_vui_6.216x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Sắc Màu Tổ Ấm - Tuyển Tập Thiết Kế Của Nhà Vui &#40;Tập 6&#41;', 'Sac-Mau-To-Am-Tuyen-Tap-Thiet-Ke-Cua-Nha-Vui-Tap-6', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa cứng. Xuất bản tháng 05/2011. NXB Trẻ\r\nSố trang: 120. Kích thước: 21x29.5x1.5cm. Cân nặng: 840 gr', '<p> Xin trân trọng giới thiệu!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (21, 20, 0, '', 0, 0, 1, 0, 1308286385, 1308286385, 1, 1308286385, 0, 2, 1, 88000, 10, 'VND', 1, '2011_06/c113063833344dddd3e607b0e.218x300.w.d10.f300.b.jpg', 'thumb/c113063833344dddd3e607b0e.218x300.w.d10.f300.b.jpg|block/c113063833344dddd3e607b0e.218x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Hỏi - Đáp Những Quy Định Của Tư Pháp Quốc Tế Việt Nam Về Người Nước Ngoài, Người Việt Nam Định Cư Ở Nước Ngoài Hỏi - Đáp Những Quy Định Của Tư Pháp Quốc Tế Việt Nam Về Người Nước Ngoài,', 'Hoi-Dap-Nhung-Quy-Dinh-Cua-Tu-Phap-Quoc-Te-Viet-Nam-Ve-Nguoi-Nuoc-Ngoai-Nguoi-Viet-Nam-Dinh-Cu-O-Nuoc-Ngoai-Hoi-Dap-Nhung-Quy-Dinh-Cua-Tu-Phap-Quoc-Te-Viet-Nam-Ve-Nguoi-Nuoc-Ngoai', '', 'n/a', '', 'Tác giả: Nguyễn Hồng Bắc\r\nBìa mềm. Xuất bản tháng 04/2011. NXB Tư Pháp\r\nSố trang: 641. Kích thước: 14.5x20.5x2.8cm. Cân nặng: 570 gr', '<p> Xin trân trọng giới thiệu!</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (22, 21, 0, '', 0, 0, 1, 0, 1308286474, 1308286474, 1, 1308286474, 0, 2, 1, 65000, 0, 'VND', 1, '2011_06/c113049108704dc75c16609f2.211x300.w.f300.b.jpg', 'thumb/c113049108704dc75c16609f2.211x300.w.f300.b.jpg|block/c113049108704dc75c16609f2.211x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Theo Chân Đạo Sư Tây Tạng', 'Theo-Chan-Dao-Su-Tay-Tang', '', 'n/a', '', 'Tác giả: Lama Ole Nydahl. Dịch giả: Tâm Huệ Nguyễn Thị Tú Oanh\r\nBìa mềm. Xuất bản tháng 05/2011. NXB Phương Đông\r\nSố trang: 331. Kích thước: 14.5x20.5x1.7cm. Cân nặng: 310 gr', '<div class="p-description" style="zoom: 1;"> <p> <strong><em>Theo chân đạo sư Tây Tạng</em></strong> là câu chuyện cảm động và chân thực về hành trình tìm kiếm tâm linh của Ole và Hannah Nydahl. Vào năm 1968, họ đã trở thành những đệ tử phương Tây đầu tiên của người đứng đầu dòng Kagyu nổi tiếng, Pháp Vương Gyalwa Karmapa đời thứ 16. Cuộc hành trình đầy gian nan dẫn họ tới gặp những vị thầy Tây Tạng và quá trình tiếp xúc với những giáo lý tuyệt vời đã chuyển hóa cuộc sống của họ thành một cuộc sống đầy ánh sáng và niềm an lạc. Tuy nhiên, mục tiêu thực sự của cuốn sách là &quot;tạo một cây cầu giữa hai thế giới và đặc biệt chia sẻ với tất cả những ai đang mong muốn kiếm tìm bản thể đích thực của chính mình... một phương cách chân thực để giác ngộ.&quot;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (23, 22, 0, '', 0, 0, 1, 0, 1308286553, 1308286553, 1, 1308286553, 0, 2, 1, 80000, 10, 'VND', 1, '2011_06/c113061204564dd9d1083a0e6.203x300.w.d10.f300.b.jpg', 'thumb/c113061204564dd9d1083a0e6.203x300.w.d10.f300.b.jpg|block/c113061204564dd9d1083a0e6.203x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Tuệ Trung Thượng Sĩ Với Thiền Tông Việt Nam', 'Tue-Trung-Thuong-Si-Voi-Thien-Tong-Viet-Nam', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa mềm. Xuất bản tháng 05/2011. NXB Đà Nẵng\r\nSố trang: 311. Kích thước: 16x24x1.5cm. Cân nặng: 400 gr', '<div class="p-description" style="zoom: 1;"> <p> Các bạn đang cầm trên tay một tập hợp những ý kiến giống nhau và khác nhau về một hiện tượng độc đáo của lịch sử Việt Nam: Tuệ Trung Thượng sĩ Trần Tung (1230 - 1291).</p> <p> &nbsp;</p> <p> Ông là người được ít người biết đến nhưng thực chất ông là một danh nhân lịch sử vì chính ông đã góp phần quan trọng để tạo ra một giai đoạn lịch sử lừng lẫy của Việt Nam và nhân loại: Đại Việt 3 lần chiến thắng đế quốc Nguyên Mông thế kỷ 13. Nhưng điều đáng chú ý nhất ông là một nhà triết học mà tư tưởng của ông đã ảnh hưởng sâu sắc đối với đệ nhất tổ phái Thiền Trúc Lâm Yên Tử mà Điều Ngự Giác Hoàng đệ nhất tổ Trần Nhân Tông lại chính là một trong những lãnh tụ tư tưởng của cuộc kháng chiến vĩ đại đó.</p> <p> &nbsp;</p> <p> Phần lớn những tham luận này đã được đọc tại hội thảo khoa học &quot;Tuệ Trung Thượng sĩ với Thiền tông Việt Nam&quot; - một hội thảo tranh luận sôi nổi trong hai ngày và đã được G.S Trần Văn Giàu nhận xét: &quot;Đây là một trong vài ba hội thảo có nội dung khoa học thực sự! Chúng ta đáng tự hào vì Việt Nam chúng ta cũng có tư tưởng triết học hẳn hoi.&quot;</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (24, 23, 0, '', 0, 0, 1, 0, 1308286624, 1308286624, 1, 1308286624, 0, 2, 1, 30000, 10, 'VND', 1, '2011_06/c113067230334de302d96a121.210x300.w.d10.f300.b.jpg', 'thumb/c113067230334de302d96a121.210x300.w.d10.f300.b.jpg|block/c113067230334de302d96a121.210x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Thần Đồng Nổi Tiếng Thế Giới', 'Than-Dong-Noi-Tieng-The-Gioi', '', 'n/a', '', 'Bìa mềm. Xuất bản tháng 04/2011. NXB Quân Đội Nhân Dân\r\nSố trang: 187. Kích thước: 14.5x20.5x0.9cm. Cân nặng: 180 gr', '<div class="p-description" style="zoom: 1;"> <p> Hiện nay trên thế giới ghi nhận danh sách 121 thần trong các lĩnh vực: Toán học, Vật lý, Tin học, Văn học, Điện ảnh, Âm, Ngôn ngữ, Luật pháp, Nghệ thuật, Thể thao, Nhân quyền... Sự vinh danh của các thần đồng này đã mang lại niềm tự hào cho gia đình và vinh quang cho dân tộc.</p> <p> &nbsp;</p> <p> Đến nay, chúng ta đã nói nhiều về thần đồng và hiện tượng thần đồng, nhưng tiêu chí thần đồng vẫn có nhiều ý kiến khác nhau. Theo các nhà nghiên cứu thì thần đồng biết sớm hơn các bạn cùng lứa mà thần đồng còn có nghĩa là không học hay không được chỉ bảo mà biết. Theo thống kế của các nhà khoa học trên thế giới, qua so sánh bằng chỉ số IQ thì có khoảng 3% trẻ có IQ trên 130, tuy nhiên người ta vẫn châm chước (độ sai lệch) cho những trẻ có IQ trên 110 vẫn nằm trong danh sách &quot;năng khiếu&quot; qua những trường hợp đặc biệt. Do vậy, để được thế giới ghi nhận là thần đồng, một đứa trẻ phải hội tụ được các yếu tố trên.</p> <p> &nbsp;</p> <p> Cuốn sách <strong>&quot;Thần đồng nổi tiếng thế giới&quot;</strong> sẽ giới thiệu với bạn đọc những thần đồng ở khắp các châu lục, về khả năng đặc biệt, những phát minh và những cống hiến của họ; về cuộc sống của các thần đồng khi vinh danh và cả những áp lực, kỳ vọng mà chúng ta đã tạo cho các thần đồng.</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (25, 24, 0, '', 0, 0, 1, 0, 1308286694, 1308286694, 1, 1308286694, 0, 2, 1, 25000, 10, 'VND', 1, '2011_06/c113063087884ddcb0b472409.207x300.w.d10.f300.b.jpg', 'thumb/c113063087884ddcb0b472409.207x300.w.d10.f300.b.jpg|block/c113063087884ddcb0b472409.207x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Chim Yến &#40;Tập 2&#41;&#x3A; Biện Pháp Kỹ Thuật Giúp Nhà Nuôi Chim Yến Thành Công', 'Chim-Yen-Tap-2-Bien-Phap-Ky-Thuat-Giup-Nha-Nuoi-Chim-Yen-Thanh-Cong', '', 'n/a', '', 'Tác giả: Nguyễn Chung\r\nBìa mềm. Xuất bản tháng 04/2011. NXB Nông Nghiệp\r\nSố trang: 106. Kích thước: 13x19x0.5cm. Cân nặng: 90 gr', '<div class="p-description" style="zoom: 1;"> <p> Đi sau Indonesia hơn 40 năm nhưng không rút ra được bài học từ nước này là tỷ lệ nhà yến thất bại gần 60% do lượng nhà yến bùng phát quá nhanh hơn số chim tăng đàn mỗi năm, ở Việt Nam chỉ vài năm mà tỷ lệ nhà yến kém hiệu quả gần 30-35%.</p> <p> &nbsp;</p> <p> Nghề yến Việt Nam nên tìm hiểu cách tổ chức ở Philippines có nghề nuôi chim yến phát triển bền vững với gần 20.000 nhà yến.</p> <p> &nbsp;</p> <p> Con số 2.000 nhà yến, có gần 30-35% kém hiệu quả gây thiệt hại gần 500-600 tỷ đồng cho nhà đầu tư chỉ mới xây dựng trong năm 2009-2010, thật là lớn.</p> <p> &nbsp;</p> <p> Qui lỗi thất bại do số chim yến tăng đàn không đáp ứng kịp tốc độ nhà yến xây mới, nhưng đi sâu vào là có rất nhều lý do để đi đến thất bại: thiết kế sai, vật tư thiết bị kém chất lượng, vận hành sai, tính kỹ thuật không còn đang bị thương mại hóa cung cấp vật tư-lắp đặt.</p> <p> &nbsp;</p> <p> Ở Đồng Xoài Bình Phước, huyện Đất Đỏ Bà Rịa-Vũng Tàu và thị xã Bạc Liêu có nhiều nhà yến bị mạt gỗ, bị nấm mốc phá hoại, ở thị xã Bà Rịa, Cửa Cạn Phú Quốc có nhà yến chim bay về nhưng không vô nhà... đã minh chứng điều này.</p> <p> &nbsp;</p> <p> Biện pháp nào để phòng tránh thất bại, tiếp theo tập sách &quot;Chim yến - Đầu tư &amp; Kỹ thuật xây dựng nhà khai thác tổ yến&quot;, chúng tôi xin trình bày tiếp tập sách &quot;Chim yến - Biện pháp kỹ thuật giúp nhà nuôi chim yến thành công&quot;.</p> <p> &nbsp;</p> <p> Các ý kiến trong tập sách là tổng hợp của các công trình nghiên cứu của các nhà khoa học trong nước và ngoài nước, các chủ nhà yến, các chuyên viên và các kỹ thuật viên nhiều kinh nghiệm trong kỹ thuật nuôi chim yến trong nhà.</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (26, 25, 0, '', 0, 0, 1, 0, 1308286759, 1308286759, 1, 1308286759, 0, 2, 1, 38000, 0, 'VND', 1, '2011_06/c113008551954d89799bee0ec.212x300.w.f300.b.jpg', 'thumb/c113008551954d89799bee0ec.212x300.w.f300.b.jpg|block/c113008551954d89799bee0ec.212x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 0, 0, 0, 1, 'Audiobook - Các Giá Trị Dạy Con Nên Người &#40;CD&#41;', 'Audiobook-Cac-Gia-Tri-Day-Con-Nen-Nguoi-CD', '', 'n/a', '', 'Bìa mềm. Xuất bản tháng 03/2011. \r\nKích thước: 13.5x19x0.8cm. Cân nặng: 80 gr', '<div class="p-description" style="zoom: 1;"> <p> Mục lục</p> <p> 1.&nbsp; Ngựa vằn Zanzibar mơ mộng</p> <p> 2.&nbsp; Gấu Baffin hung hăng</p> <p> 3.&nbsp; Chuyến rong chơi của tê tê Alice</p> <p> 4.&nbsp; Cá heo Darwin anh dũng</p> <p> 5.&nbsp; Gấu túi Kimberley nhõng nhẽo</p> <p> 6.&nbsp; Đười ươi Odessa siêng năng</p> <p> 7.&nbsp; Giấc mơ của lạc đà Cairo</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (27, 26, 0, '', 0, 0, 1, 0, 1308286822, 1308286822, 1, 1308286822, 0, 2, 1, 200000, 20, 'VND', 1, '2011_06/12872097644cb943246b678.219x300.w.d20.f300.b.jpg', 'thumb/12872097644cb943246b678.219x300.w.d20.f300.b.jpg|block/12872097644cb943246b678.219x300.w.d20.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Độc Đáo Ẩm Thực Thăng Long - Hà Nội', 'Doc-Dao-Am-Thuc-Thang-Long-Ha-Noi', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa mềm. Xuất bản tháng 09/2010. NXB Thông Tấn\r\nSố trang: 188. Kích thước: 25.5x29.5x1.1cm. Cân nặng: 700 gr', '<p> Người Thăng Long - Hà Nội có nền ẩm thực với hương vị riêng đậm đà bản sắc dân tộc, thể hiện rõ trong việc dùng nước mắm và những hương vị tự nhiên như gừng, tỏi, hành, nghệ, rau thơm... để làm gia vị. Không như người Tàu hay dùng nước tương, tàu vị yểu để tra nồi hay chấm, khẩu vị thiên về chua ngọt hay thích xào nhiều dầu mỡ, thức ăn ướp ngũ vị hương hoặc thêm chất bột sền sệt...<br  /> Nói đến ẩm thực Việt và ẩm thực Hà Nội nói riêng, chúng ta không thể không nói tới một nền văn hóa ẩm thực hình thành và phát triển trong khung của nền văn minh lúa gạo. Lúa gạo là một sản vật chủ đạo nghìn năm của người Việt, cho đến tận hôm nay và cả mai sau, lúa gạo vẫn là gốc rễ của văn hóa ẩm thực Việt Nam.<br  /> Cuốn sách Độc đáo ẩm thực Thăng Long - Hà Nội là một nổ lực góp phần về mặt lý luận trong chương trình Cùng nhau xây dựng bếp Việt cho thế giới. Đồng thời, là hành trình tìm lại những giá trị bản sắc từng một thời vang bóng mà hiện đang có nguy cơ mai một, nhằm lên kế hoạch cho công cuộc giữ gìn, phát huy giá trị văn hóa Việt.</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (28, 1, 0, '', 0, 0, 1, 0, 1308286955, 1308286955, 1, 1308286955, 0, 2, 1, 59000, 10, 'VND', 1, '2011_06/201010100423-10_loi_khuyen_khoi_nghiep.192x300.w.d10.f300.b.jpg', 'thumb/201010100423-10_loi_khuyen_khoi_nghiep.192x300.w.d10.f300.b.jpg|block/201010100423-10_loi_khuyen_khoi_nghiep.192x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, '10 Lời Khuyên Khởi Nghiệp - Các Bước Cơ Bản Để Xây Dựng Thành Công Một Doanh Nghiệp', '10-Loi-Khuyen-Khoi-Nghiep-Cac-Buoc-Co-Ban-De-Xay-Dung-Thanh-Cong-Mot-Doanh-Nghiep', '', 'n/a', '', 'Tác giả: Caspian Woods. Dịch giả: Thanh Hằng\r\nBìa mềm. Xuất bản tháng 05/2011. NXB Lao Động - Xã Hội\r\nSố trang: 254. Kích thước: 13x20.5cm. Cân nặng: 270 gr', '<p> Bạn đang nghĩ đến việc khởi nghiệp? Bạn cảm thấy hứng khởi với ý tưởng của mình nhưng lại thoái chí khi nghĩ đến những khó khăn, rủi ro có thể xảy ra. Bạn cần những bí quyết thực tế, sự khôn ngoan và cảm hứng từ hàng trăm doanh nhân để có thể tiếp tục biến ước mơ đó thành hiện thực.<br  /> <strong>10 lời khuyên khởi nghiệp</strong> chính là cuốn sách đơn giản và tinh gọn duy nhất hướng dẫn chính xác những điều bạn cần:<br  /> - 10 lời khuyên doanh nhân<br  /> - 11 cách để đưa ra ý tưởng kinh doanh hay<br  /> - 3 bài tập giúp bạn trở thành doanh nhân thành công<br  /> - Cách tiếp thị thương hiệu<br  /> - Bí quyết tiêu diệt rồng - làm thế nào để thành công trong mọi buổi thuyết trình chào hàng<br  /> - Bí quyết hãy hỏi cô dâu khiêu vũ - làm thế nào để tìm được người cố vấn.<br  /> Khi mới khởi nghiệp, bạn thường cảm thấy mình chỉ như một hạt sồi, còi cọc nhỏ bé dưới cái bóng khổng lồ của những cây sồi trưởng thành xung quanh. Nhưng bạn cần biết rằng, những công ty hàng đầu thế giới đã bắt đầu từ phòng ngủ, những quầy hàng trong chợ hay trên xe tải. Hàng triệu người ngày ngày đang lặng lẽ theo đuổi giấc mơ của mình mới chính là những câu chuyện về thành công bạn cần học hỏi.</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (29, 2, 0, '', 0, 0, 1, 0, 1308287016, 1308287016, 1, 1308287016, 0, 2, 1, 28000, 10, 'VND', 1, '2011_06/c113055207554dd0aa73caee2.180x300.w.d10.f300.b.jpg', 'thumb/c113055207554dd0aa73caee2.180x300.w.d10.f300.b.jpg|block/c113055207554dd0aa73caee2.180x300.w.d10.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Chuyện Tình Nàng Bình Khương &#40;Tập Truyện Ngắn&#41;', 'Chuyen-Tinh-Nang-Binh-Khuong-Tap-Truyen-Ngan', '', 'n/a', '', 'Tác giả: Vũ Ngọc Khánh\r\nBìa mềm. Xuất bản tháng 05/2011. NXB Lao Động\r\nSố trang: 195. Kích thước: 12x20x0.9cm. Cân nặng: 160 gr', '<div class="p-description" style="zoom: 1;"> <p> Nàng là người con gái có sắc đẹp làm cho thác dữ cũng êm ả, nhẹ nhàng trôi, sắc đẹp của nàng khuynh đảo cả Thiên Hương trấn. Các tiểu thư khuê các, quận chúa cao sang đều lu mờ trước dung nhan nàng. Nàng là Bình Khương. Nhưng với vẻ đẹp ấy, cuộc đời nàng gặp bao nhiêu bất trắc...</p> <p> &nbsp;</p> <p> Tập truyện ngắn này kể cho chúng ta nghe những câu chuyện về tình người, về cuộc đời. Đó là những câu chuyện của một thời gian khó, loạn lạc... đã xa. Tác giả đã thổi hơi ấm tình thương yêu của mình vào mỗi câu chuyện, vào mỗi nhân vật để cho họ trong hoàn cảnh khó khăn nhất vẫn có một niềm tin ở phía trước mà sống, sống thật có ý nghĩa với bản thân mình, với người thân, làng xóm.</p> <p> &nbsp;</p> <p> Xin trân trọng giới thiệu!</p></div>', '');
INSERT INTO `nv3_shops_rows` VALUES (30, 4, 0, '', 0, 0, 1, 0, 1308287072, 1308287072, 1, 1308287072, 0, 2, 1, 634000, 0, 'VND', 1, '2011_06/c112873842854cbbecdd7e34c.300x173.w.f300.b.jpg', 'thumb/c112873842854cbbecdd7e34c.300x173.w.f300.b.jpg|block/c112873842854cbbecdd7e34c.300x173.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 1, 0, 0, 1, 'Diệt Tần &#40;Bộ 9 Cuốn&#41;', 'Diet-Tan-Bo-9-Cuon', '', 'n/a', '', 'Tác giả: Long Nhân. Dịch giả: Lê Thanh Dũng, Trần Trung Hỷ\r\nBìa mềm. Xuất bản tháng 07/2010. NXB Văn Học, Phương Nam Book\r\nSố trang: 3755. Kích thước: 13x21x18.6cm. Cân nặng: 3300 gr', '<p> Những năm cuối đời Tần, đất Thần châu quần hùng nổi dậy, ngọn lửa hung tàn thời loạn bùng cháy khắp nơi.<br  /> Chàng thiếu niên Kỷ Không Thủ nổi lên, truyền kỳ gió bụi của chàng lật ra trang sử hào hùng thời cuối Tần đầu Hán.<br  /> Đế quốc đại Tần sụp đổ dưới chân chàng, Sở Hán tranh hùng dậy sóng dưới tay chàng...<br  /> Vì chàng mới có chiến dịch kinh điển “Thập diện mai phục” lưu truyền ngàn năm...<br  /> Vì chàng mới có điển cố “Hồng nhan tri kỷ” của mối tình lãng mạn...<br  /> Tất cả, tất cả những câu chuyện truyền kỳ đó đều bắt nguồn từ mưu trí và võ công của chàng...<br  /> <br  /> Mục lục:<br  /> <br  /> 1. Tập 1: Diệt Tần<br  /> 2. Tập 2: Thần bếp của giang hồ<br  /> 3. Tập 3: Ngạo nghễ phá vây<br  /> 4. Tập 4: Long ngự trâm<br  /> 5. Tập 5: Anh tài xuất thế<br  /> 6. Tập 6: Hán Vương lưu bang<br  /> 7. Tập 7: Vương đạo vô thường<br  /> 8. Tập 8: Cuộc chiến Vương Tướng<br  /> 9. Tập 9: Đao kiếm tranh tài</p>', '');
INSERT INTO `nv3_shops_rows` VALUES (31, 7, 0, '', 0, 0, 1, 0, 1308287124, 1308287124, 1, 1308287124, 0, 2, 1, 45000, 0, 'VND', 1, '2011_06/c113032803614dae7ae90c926.189x300.w.f300.b.jpg', 'thumb/c113032803614dae7ae90c926.189x300.w.f300.b.jpg|block/c113032803614dae7ae90c926.189x300.w.f300.b.jpg', '', 0, 0, 1, 0, 1, '0', 1, 1, 1, 2, 0, 0, 1, 'Hãy Nói Yêu Thôi, Đừng Nói Yêu Mãi Mãi &#40;Đặc San Kỷ Niệm 20 Năm Hoa Học Trò &amp; 10 Năm 2&#33;&#41;', 'Hay-Noi-Yeu-Thoi-Dung-Noi-Yeu-Mai-Mai-Dac-San-Ky-Niem-20-Nam-Hoa-Hoc-Tro-10-Nam-2', '', 'n/a', '', 'Tác giả: Nhiều Tác Giả\r\nBìa mềm. Xuất bản tháng 04/2011. Báo Sinh Viên Việt Nam\r\nSố trang: 249. Kích thước: 15x24x1.4cm. Cân nặng: 310 gr', '<p> Sáng nay, trong khi sắp xếp những chồng thư cũ, tôi tình cờ đọc lại một bài thơ ngắn của Jacques Prévert mà cô bạn cũ nắn nót chép tặng trên một tờ thư có in hoa rất đẹp…<br  /> <br  /> Bài thơ vỏn vẹn năm câu được cô đặt vắt qua hai trang giấy một cách đầy ngụ ý.<br  /> <br  /> Trang thứ nhất:<br  /> <br  /> Tôi sung sướng và tự do<br  /> Như ánh sáng<br  /> Bởi hôm qua anh ấy nói với tôi rằng anh ấy yêu tôi<br  /> <br  /> Hai câu cuối bị đẩy qua trang sau:<br  /> <br  /> Anh ấy đã không nói thêm<br  /> rằng anh ấy sẽ yêu tôi mãi mãi…<br  /> <br  /> Khi đọc bài thơ này cách nay hai mươi năm, tôi đã cảm nhận nó bằng một tâm hồn tươi trẻ. Bây giờ, cuộc sống giúp tôi nhìn có lẽ đã khác đi về bài thơ trên trang giấy đã ố vàng này.<br  /> <br  /> Cô gái trong thơ nhạy cảm và tinh tế, vì đã không đợi đến khi người mình yêu quay lưng mới xót xa nhận ra rằng tự do “như ánh sáng” chỉ là một thứ tự do mong manh. Hạnh phúc “như ánh sáng” là một hạnh phúc có thể vụt tắt bất cứ lúc nào.<br  /> <br  /> Nhưng giả sử chàng trai có nói thêm rằng “sẽ yêu mãi mãi”, hoặc có thề hứa trăm năm đi nữa… ai dám khẳng định trái tim chàng sẽ không đổi thay? Nếu từng đọc Ruồi Trâu, hẳn bạn còn nhớ đọan văn này: “Ràng buộc con người không phải là lời thề. Chỉ cần mình tự cảm thấy thiết tha với một điều nào đó, thế là đủ rồi.”<br  /> <br  /> Ngoài sự “thiết tha tự nguyện” đó ra, chẳng có gì ràng buộc được trái tim con người, nên đừng tin chắc rằng ai đó sẽ mãi không đổi thay. Cũng không thể buộc ai đó không được đổi thay.<br  /> <br  /> Trên đời không có thứ vũ khí hay quyền lực tuyệt đối nào có thể níu giữ trái tim một khi nó đã quyết tâm rẽ lối. Cho dù đó là nhan sắc, một tình yêu sâu đậm, những kỷ niệm sâu sắc đắm say. Càng không phải là sự yếu đuối, sự khéo léo sắc sảo hay vẻ thông minh dịu dàng, sự giàu có hay thương hại…Những thứ đó có thể níu kéo một thân xác, một trí óc…nhưng không thể níu kéo một trái tim.<br  /> <br  /> Trái tim vốn là một tạo vật mong manh và thiếu kiên định. Vì vậy, hãy tin vào điều thiện, lòng tốt, vào nhân cách và năng lực…nhưng đừng tin vào sự bất biến của nhận thức và tình cảm nơi con người. Hãy tin là mình được yêu trong khoảnh khắc này, nhưng đừng chắc rằng mình sẽ được yêu mãi mãi. Nếu chịu chừa chỗ cho sự đổi thay, ta sẽ tránh được không ít tổn thương sâu sắc.<br  /> <br  /> Tôi không cho niềm tin là món quà vô giá mà ta dành cho người khác. Bởi đôi khi, sự tin tưởng hoá ra là một việc rất… đơn phương và vô trách nhiệm. Nó có nghĩa bắt người kia vào rọ, không tính đến khả năng thay đổi của trái tim con người.<br  /> <br  /> Tin tưởng là trút gánh nặng sang vai người khác, bất kể người ta có chịu nhận nó hay không. Việc nhận định hay quyết định vấn đề không còn dựa vào sự thận trọng, tỉnh táo, sáng suốt hay sự nhạy cảm, bao dung của ta mà hoàn toàn giao phó cho người khác.<br  /> <br  /> Và nếu khi họ thay đổi, ta thường nhân danh sự tin tưởng tuyệt đối mà mình đã tự nguyện gửi gắm để cho phép mình cái quyền được ghép tội họ.<br  /> <br  /> Nhưng, bất cứ ai cũng có thể có lúc đổi thay.<br  /> <br  /> Sự thay đổi của người khác, nhất là ở người ta vô cùng yêu quý, chắc chắn khiến ta tổn thương. Nhưng hãy nhớ rằng người quân tử khi đã hết tình cảm thì thường tỏ ra lạnh nhạt. Như ẩn sĩ Urabe Kenkô trong tập Đồ Nhiên Thảo đã viết: “Khi người sáng chiều hết sức thân quen, không có gì ngăn cách bỗng một hôm lại làm mặt lạ và có cử chỉ khác thường, chắc hẳn sẽ có kẻ bảo: “Sao xưa thế kia mà bây giờ lại thế khác?” Theo ta, thái độ lạnh lùng đó chứng tỏ người ấy hết sức đàng hoàng và thành thật.”<br  /> <br  /> Cuối cùng đó mới chính là cốt lõi của tình yêu, tình bạn và những mối quan hệ thân sơ khác. Sự thành thật, chứ không phải là lời hứa vĩnh viễn thủy chung. Bạn có thể yêu hay ghét. Thích hay không còn thích nữa. Chỉ cần thành thật, bạn sẽ luôn luôn thanh thản.<br  /> <br  /> Tôi đọc lại lần nữa bài thơ ngắn ngủi trên tờ thư cũ, và cảm nhận một cách rõ rệt vẻ trách móc đắng cay dịu dàng rất đỗi con gái. Nhưng ít nhất cô gái trong bài thơ kia cũng biết rằng người yêu cô đã rất thành thật, khi không hứa một điều mà anh không tin chắc. Cô cũng biết trái tim con người là một tạo vật hoàn toàn tự do, và một khoảnh khắc đắm say hạnh phúc không hề là lời hứa hẹn vĩnh cửu.<br  /> <br  /> Cô bạn yêu quý của tôi chắc cũng nhận ra điều đó, nên đã viết thêm một dòng chữ xinh xinh vào cuối trang thư, một dòng ngắn mà tôi không bao giờ quên được:<br  /> <br  /> “Hãy nói yêu thôi, đừng nói yêu mãi mãi”</p>', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_sources`
-- 

CREATE TABLE `nv3_shops_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL auto_increment,
  `link` varchar(255) NOT NULL default '',
  `logo` varchar(255) NOT NULL default '',
  `weight` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  `vi_title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`sourceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_shops_sources`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_topics`
-- 

CREATE TABLE `nv3_shops_topics` (
  `topicid` mediumint(8) unsigned NOT NULL auto_increment,
  `catid` int(8) NOT NULL default '0',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `vi_title` varchar(255) NOT NULL default '',
  `vi_alias` varchar(255) NOT NULL default '',
  `vi_description` varchar(255) NOT NULL default '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY  (`topicid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_shops_topics`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_transaction`
-- 

CREATE TABLE `nv3_shops_transaction` (
  `transaction_id` int(11) NOT NULL auto_increment,
  `transaction_time` int(11) NOT NULL default '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `payment` varchar(22) NOT NULL default '0',
  `payment_id` varchar(22) NOT NULL default '0',
  `payment_time` int(11) NOT NULL default '0',
  `payment_amount` int(11) NOT NULL default '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY  (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_shops_transaction`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_shops_units`
-- 

CREATE TABLE `nv3_shops_units` (
  `id` int(11) NOT NULL auto_increment,
  `vi_title` varchar(255) NOT NULL default '',
  `vi_note` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `nv3_shops_units`
-- 

INSERT INTO `nv3_shops_units` VALUES (1, 'cuốn', 'cuốn');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_users`
-- 

CREATE TABLE `nv3_users` (
  `userid` mediumint(8) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `md5username` char(32) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `full_name` varchar(255) NOT NULL default '',
  `gender` char(1) NOT NULL,
  `photo` varchar(255) NOT NULL default '',
  `birthday` int(11) unsigned NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL default '0',
  `website` varchar(255) NOT NULL default '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL default '',
  `telephone` varchar(100) NOT NULL default '',
  `fax` varchar(100) NOT NULL default '',
  `mobile` varchar(100) NOT NULL default '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL default '',
  `passlostkey` varchar(40) NOT NULL default '',
  `view_mail` tinyint(1) unsigned NOT NULL default '0',
  `remember` tinyint(1) unsigned NOT NULL default '0',
  `in_groups` varchar(255) NOT NULL default '',
  `active` tinyint(1) unsigned NOT NULL default '0',
  `checknum` varchar(40) NOT NULL default '',
  `last_login` int(11) unsigned NOT NULL default '0',
  `last_ip` varchar(45) NOT NULL default '',
  `last_agent` varchar(255) NOT NULL default '',
  `last_openid` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `nv3_users`
-- 

INSERT INTO `nv3_users` VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'e10adc3949ba59abbe56e057f20f883e', 'admin@cunghoanhip.net', 'admin', '', '', 0, NULL, 1308229868, '', '', '', '', '', '', 'admin', 'huynhphico', '', 0, 1, '', 1, 'caf53472a0c017320990caeea9ae6643723b5bf7', 1308294572, '117.2.46.237', 'Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_users_config`
-- 

CREATE TABLE `nv3_users_config` (
  `config` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`config`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_users_config`
-- 

INSERT INTO `nv3_users_config` VALUES ('registertype', '1', 1308229805);
INSERT INTO `nv3_users_config` VALUES ('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1308229805);
INSERT INTO `nv3_users_config` VALUES ('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1308229805);
INSERT INTO `nv3_users_config` VALUES ('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br  /> <br  /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br  /> <br  /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br  /> <br  /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_users_openid`
-- 

CREATE TABLE `nv3_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL default '0',
  `openid` varchar(255) NOT NULL default '',
  `opid` varchar(50) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_users_openid`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_users_question`
-- 

CREATE TABLE `nv3_users_question` (
  `qid` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `lang` char(2) NOT NULL default '',
  `weight` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `nv3_users_question`
-- 

INSERT INTO `nv3_users_question` VALUES (1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238);
INSERT INTO `nv3_users_question` VALUES (2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250);
INSERT INTO `nv3_users_question` VALUES (3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257);
INSERT INTO `nv3_users_question` VALUES (4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264);
INSERT INTO `nv3_users_question` VALUES (5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270);
INSERT INTO `nv3_users_question` VALUES (6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278);
INSERT INTO `nv3_users_question` VALUES (7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_users_reg`
-- 

CREATE TABLE `nv3_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `md5username` char(32) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `full_name` varchar(255) NOT NULL default '',
  `regdate` int(11) unsigned NOT NULL default '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL default '',
  `checknum` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_users_reg`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_about`
-- 

CREATE TABLE `nv3_vi_about` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  `status` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `nv3_vi_about`
-- 

INSERT INTO `nv3_vi_about` VALUES (2, 'Giới thiệu về cửa hàng bán sách trực tuyến', 'Gioi-thieu', '<p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> ........................................................................................................</p><p style="text-align: center;"> &nbsp;</p>', 'giới,thiệu,về,cửa,hàng,bán,sách,trực,tuyến', 2, 1, 1275320224, 1308277735, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_blocks_groups`
-- 

CREATE TABLE `nv3_vi_blocks_groups` (
  `bid` int(11) unsigned NOT NULL auto_increment,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) default NULL,
  `title` varchar(255) default NULL,
  `link` varchar(255) default NULL,
  `template` varchar(55) default NULL,
  `position` varchar(55) default NULL,
  `exp_time` int(11) default '0',
  `active` tinyint(4) default '0',
  `groups_view` varchar(255) default '',
  `all_func` tinyint(4) NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  `config` text,
  PRIMARY KEY  (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

-- 
-- Dumping data for table `nv3_vi_blocks_groups`
-- 

INSERT INTO `nv3_vi_blocks_groups` VALUES (1, 'default', 'news', 'global.block_category.php', 'Menu', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:"title_length";i:25;}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (3, 'default', 'shops', 'module.block_catalogs.php', 'Sách Tiếng Việt', '', '', '[LEFT]', 0, 1, '0', 0, 2, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (7, 'default', 'news', 'module.block_headline.php', 'Tin nổi bật', '', 'no_title', '[TOP]', 0, 1, '0', 0, 1, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (8, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, 1, '0', 1, 2, 'a:1:{s:12:"idplanbanner";i:1;}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 1, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '0', 1, 1, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '0', 0, 5, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '0', 1, 1, 'a:1:{s:12:"idplanbanner";i:1;}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (16, 'modern', 'menu', 'global.menu_theme_modern.php', 'global menu theme modern', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (17, 'default', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (18, 'modern', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:"htmlcontent";s:216:"<p> © Copyright NukeViet 3. All right reserved.</p><p> Powered by <a href="http://nukeviet.vn/" title="NukeViet CMS">NukeViet CMS</a>. Design by <a href="http://vinades.vn/" title="VINADES.,JSC">VINADES.,JSC</a></p>";}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (19, 'default', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:"htmlcontent";s:231:"<p class="footer"> © Copyright NukeViet 3. All right reserved.</p><p> Powered by <a href="http://nukeviet.vn/" title="NukeViet CMS">NukeViet CMS</a>. Design by <a href="http://vinades.vn/" title="VINADES.,JSC">VINADES.,JSC</a></p>";}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (23, 'default', 'shops', 'global.block_cart.php', 'Giỏ Hàng', '', '', '[RIGHT]', 0, 1, '0', 1, 1, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (31, 'default', 'sach-tieng-anh', 'module.block_catalogs.php', 'Sách Tiếng Anh', '', '', '[LEFT]', 0, 1, '0', 0, 3, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (32, 'default', 'may-doc-sach', 'module.block_catalogs.php', 'Máy Đọc Sách', '', '', '[LEFT]', 0, 1, '0', 0, 4, '');
INSERT INTO `nv3_vi_blocks_groups` VALUES (34, 'default', 'global', 'global.html.php', 'Hỗ Trợ Trực Tuyến', '', '', '[RIGHT]', 0, 1, '0', 1, 2, 'a:1:{s:11:"htmlcontent";s:1787:"<p style="text-align: center;"> <strong>WEBMASTER</strong></p><p style="text-align: center;"> <span style="color: rgb(128, 0, 128);">(Huỳnh Phi Cơ)</span></p><p style="text-align: center;"> <a href="ymsgr:sendim?huynhphico&amp;m=Xin Chào ! Tôi liên lạc với bạn từ wWw.LeXuanDuan.Net"><img height="70" src="http://opi.yahoo.com/online?u=huynhphico&amp;m=g&amp;t=14" width="90" /></a></p><p style="text-align: center;"> &nbsp;</p><p style="text-align: center;"> <b>SUPPORT</b></p><p style="text-align: center;"> <span style="color: rgb(255, 0, 0);">(Nhóm Hỗ Trợ</span>)</p><p style="text-align: center;"> <a href="ymsgr:sendim?dacsanhue.net30&amp;m=Xin Chào ! Tôi liên lạc với bạn từ wWw.LeXuanDuan.Net"><img height="70" src="http://opi.yahoo.com/online?u=dacsanhue.net30&amp;m=g&amp;t=14" width="90" /></a></p><p style="text-align: center;"> <span style="font-size:12px;"><span style="color: rgb(255, 0, 0);"><span style="font-family: comic sans ms,cursive;"><u>Email:</u> <a href="mailto:admin@dacsanhue.net?subject=Nhap%20tieu%20de%20o%20day%20-%20wWw.DacSanHue.Net&amp;body=Nhap%20noi%20dung%20can%20lien%20he%0A%0AwWw.DacSanHue.Net">admin@dacsanhue.net</a></span></span></span></p><p style="text-align: center;"> <span style="font-size:10px;"><strong><span style="color: rgb(255, 0, 0);"><span style="font-family: courier new,courier,monospace;"><u>Điện Thoại:</u> 09 05 04 12 21</span></span></strong></span></p><p style="text-align: center;"> <span style="font-size:9px;"><span style="color: rgb(0, 0, 255);"><span style="font-family: tahoma,geneva,sans-serif;"><strong><u>Yahoo Messenger :</u> <a href="ymsgr:sendim?huynhphico&amp;m=Xin Chào ! Tôi liên lạc với bạn từ wWw.DacSanHue.Net">huynhphico</a></strong></span></span></span></p>";}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (35, 'default', 'global', 'global.html.php', 'Links Liên Kết', '', '', '[RIGHT]', 0, 1, '0', 1, 3, 'a:1:{s:11:"htmlcontent";s:3287:"<p style="text-align: center;"> <strong><strong><a href="http://dacsanhue.net/tivionline/tivionline/index.php"><span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>Xem TiVi Online </strong></span></span></span></a></strong></strong></p><p style="text-align: center;"> <span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>----------</strong></span></span></span></p><p style="text-align: center;"> <strong><strong><a href="http://dacsanhue.net"><span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>Thiết kế website giá rẻ</strong></span></span></span></a></strong></strong></p><p style="text-align: center;"> <span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>----------</strong></span></span></span></p><p style="text-align: center;"> <strong><a href="http://www.google.com.vn/#hl=vi&amp;source=hp&amp;biw=1024&amp;bih=602&amp;q=dacsanhue.net&amp;aq=f&amp;aqi=&amp;aql=f&amp;oq=&amp;fp=6748074bf4c743f9"><span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>Tìm kiếm với Google</strong></span></span></span></a></strong></p><p style="text-align: center;"> <span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>----------</strong></span></span></span></p><p style="text-align: center;"> <strong><a href="http://khanhcafe.com/qlr42"><span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>Upload ảnh miễn phí</strong></span></span></span></a></strong></p><p style="text-align: center;"> <span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>----------</strong></span></span></span></p><p style="text-align: center;"> <a href="http://dantri.vn"><span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>Báo điện tử Dân Trí</strong></span></span></span></a></p><p style="text-align: center;"> <span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>----------</strong></span></span></span></p><p style="text-align: center;"> <a href="http://thamhue.com"><span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>Diễn đàn Thăm Huế</strong></span></span></span></a></p><p style="text-align: center;"> <span style="color:rgb(255, 140, 0);"><span style="font-size: 16px;"><span style="font-family: times new roman,times,serif;"><strong>----------</strong></span></span></span></p><p style="text-align: center;"> &nbsp;</p><p style="text-align: center;"> &nbsp;</p><div id="cke_pastebin" style="position: absolute; top: 204.5px; width: 1px; height: 1px; overflow: hidden; left: -1000px;"> &nbsp;</div>";}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (36, 'default', 'banners', 'global.banners.php', 'Intro - footer', '', 'no_title', '[BOTTOM]', 0, 1, '0', 0, 1, 'a:1:{s:12:"idplanbanner";i:3;}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (37, 'default', 'banners', 'global.banners.php', 'intro-dacsanhue', '', 'no_title', '[HEADER]', 0, 1, '0', 1, 1, 'a:1:{s:12:"idplanbanner";i:4;}');
INSERT INTO `nv3_vi_blocks_groups` VALUES (38, 'default', 'banners', 'global.banners.php', 'qcd', '', 'no_title', '[FOOTER]', 0, 1, '0', 1, 1, 'a:1:{s:12:"idplanbanner";i:5;}');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_blocks_weight`
-- 

CREATE TABLE `nv3_vi_blocks_weight` (
  `bid` int(11) NOT NULL default '0',
  `func_id` int(11) NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_blocks_weight`
-- 

INSERT INTO `nv3_vi_blocks_weight` VALUES (1, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (1, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (1, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (1, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (1, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (1, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (7, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 7, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (9, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 2, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 36, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 39, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 42, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 43, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 27, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 5, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 6, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 7, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 13, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 15, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 16, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 47, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 46, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 28, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 29, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 30, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 31, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 32, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 33, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 34, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 17, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 25, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 24, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 23, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 22, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 21, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 20, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 19, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 18, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 26, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 2, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 36, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 39, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 42, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 43, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 27, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 5, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 6, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 7, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 13, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 15, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 16, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 47, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 46, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 28, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 29, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 30, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 31, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 32, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 33, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 34, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 17, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 25, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 24, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 23, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 22, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 21, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 20, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 19, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 18, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 26, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 2, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 36, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 39, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 42, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 43, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 27, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 5, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 6, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 7, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 13, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 15, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 16, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 47, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 46, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 28, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 29, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 30, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 31, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 32, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 33, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 34, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 17, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 25, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 24, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 23, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 22, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 21, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 20, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 19, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 18, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 26, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (14, 5, 5);
INSERT INTO `nv3_vi_blocks_weight` VALUES (14, 6, 5);
INSERT INTO `nv3_vi_blocks_weight` VALUES (14, 7, 5);
INSERT INTO `nv3_vi_blocks_weight` VALUES (14, 13, 5);
INSERT INTO `nv3_vi_blocks_weight` VALUES (14, 15, 5);
INSERT INTO `nv3_vi_blocks_weight` VALUES (14, 16, 5);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 48, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 48, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (3, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 54, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 56, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 55, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 50, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 65, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 67, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 69, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 57, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 73, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 71, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 54, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 56, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 55, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 50, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 65, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 67, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 69, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 57, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 73, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 71, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 54, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 56, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 55, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 50, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 65, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 67, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 69, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 57, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 73, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 71, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 48, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 81, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 83, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 82, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 77, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 92, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 94, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 96, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 84, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 100, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 98, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 81, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 83, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 82, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 77, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 92, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 94, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 96, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 84, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 100, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 98, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 81, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 83, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 82, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 77, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 92, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 94, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 96, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 84, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 100, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 98, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (31, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (19, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (17, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (23, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (8, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (18, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (16, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (10, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 108, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 110, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 109, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 104, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 119, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 121, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 123, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 111, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 127, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (11, 125, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 108, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 110, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 109, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 104, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 119, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 121, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 123, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 111, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 127, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (12, 125, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 108, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 110, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 109, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 104, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 119, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 121, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 123, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 111, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 127, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (13, 125, 4);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (15, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (32, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 2, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 36, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 39, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 42, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 43, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 27, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 108, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 110, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 109, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 104, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 119, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 121, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 123, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 111, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 127, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 125, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 48, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 5, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 6, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 7, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 13, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 15, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 16, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 47, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 81, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 83, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 82, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 77, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 92, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 94, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 96, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 84, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 100, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 98, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 46, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 54, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 56, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 55, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 50, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 65, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 67, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 69, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 57, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 73, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 71, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 33, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 32, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 30, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 29, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 31, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 28, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 34, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 24, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 20, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 21, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 26, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 23, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 18, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 25, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 17, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 22, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (34, 19, 2);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 2, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 36, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 39, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 42, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 43, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 27, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 108, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 110, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 109, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 104, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 119, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 121, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 123, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 111, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 127, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 125, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 48, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 5, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 6, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 7, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 13, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 15, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 16, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 47, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 81, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 83, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 82, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 77, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 92, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 94, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 96, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 84, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 100, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 98, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 46, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 54, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 56, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 55, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 50, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 65, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 67, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 69, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 57, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 73, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 71, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 33, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 32, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 30, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 29, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 31, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 28, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 34, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 24, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 20, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 21, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 26, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 23, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 18, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 25, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 17, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 22, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (35, 19, 3);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 48, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (36, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 48, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (37, 19, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 2, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 36, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 39, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 42, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 43, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 27, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 108, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 110, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 109, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 104, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 119, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 121, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 123, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 111, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 127, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 125, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 48, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 5, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 6, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 7, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 13, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 15, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 16, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 47, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 81, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 83, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 82, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 77, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 92, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 94, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 96, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 84, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 100, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 98, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 46, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 54, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 56, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 55, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 50, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 65, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 67, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 69, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 57, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 73, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 71, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 33, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 32, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 30, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 29, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 31, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 28, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 34, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 24, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 20, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 21, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 26, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 23, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 18, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 25, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 17, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 22, 1);
INSERT INTO `nv3_vi_blocks_weight` VALUES (38, 19, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_contact_rows`
-- 

CREATE TABLE `nv3_vi_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `nv3_vi_contact_rows`
-- 

INSERT INTO `nv3_vi_contact_rows` VALUES (1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_contact_send`
-- 

CREATE TABLE `nv3_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `cid` mediumint(8) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL default '0',
  `sender_id` mediumint(8) unsigned NOT NULL default '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL default '0',
  `is_reply` tinyint(1) unsigned NOT NULL default '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL default '0',
  `reply_aid` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_vi_contact_send`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_counter`
-- 

CREATE TABLE `nv3_vi_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL default '0',
  `last_update` int(11) NOT NULL default '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_counter`
-- 

INSERT INTO `nv3_vi_counter` VALUES ('c_time', 'start', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('c_time', 'last', 1308294819, 0);
INSERT INTO `nv3_vi_counter` VALUES ('total', 'hits', 18, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2009', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2010', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2011', 18, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2012', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2013', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2014', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2015', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2016', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2017', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2018', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2019', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('year', '2020', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Jan', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Feb', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Mar', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Apr', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'May', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Jun', 18, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Jul', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Aug', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Sep', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Oct', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Nov', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('month', 'Dec', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '01', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '02', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '03', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '04', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '05', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '06', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '07', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '08', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '09', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '10', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '11', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '12', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '13', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '14', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '15', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '16', 1, 1308230204);
INSERT INTO `nv3_vi_counter` VALUES ('day', '17', 17, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('day', '18', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '19', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '20', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '21', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '22', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '23', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '24', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '25', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '26', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '27', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '28', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '29', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '30', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('day', '31', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Sunday', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Monday', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Tuesday', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Wednesday', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Thursday', 1, 1308230204);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Friday', 17, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('dayofweek', 'Saturday', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '00', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '01', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '02', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '03', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '04', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '05', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '06', 1, 1308268660);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '07', 1, 1308271885);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '08', 2, 1308275720);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '09', 1, 1308276520);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '10', 4, 1308281985);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '11', 1, 1308283483);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '12', 3, 1308290029);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '13', 3, 1308293447);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '14', 1, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '15', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '16', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '17', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '18', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '19', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '20', 0, 1308230204);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '21', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '22', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('hour', '23', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Alexa', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'AltaVista Scooter', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Altavista Mercator', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Altavista Search', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Aport.ru Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Ask Jeeves', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Baidu', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Exabot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'FAST Enterprise', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'FAST WebCrawler', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Francis', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Gigablast', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Google AdsBot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Google Adsense', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Google Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Google Desktop', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Google Feedfetcher', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Heise IT-Markt', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Heritrix', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'IBM Research', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'ICCrawler - ICjobs', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Ichiro', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'InfoSeek Spider', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Lycos.com Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'MSN Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'MSN Bot Media', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'MSN Bot News', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'MSN NewsBlogs', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Majestic-12', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Metager', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'NG-Search', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Nutch Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'NutchCVS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'OmniExplorer', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Online Link Validator', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Open-source Web Search', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Psbot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Rambler', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'SEO Crawler', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'SEOSearch', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Seekport', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Sensis', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Seoma', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Snappy', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Steeler', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Synoo', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Telekom', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'TurnitinBot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Vietnamese Search', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Voyager', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'W3 Sitesearch', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'W3C Linkcheck', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'W3C Validator', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'WiseNut', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'YaCy', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yahoo Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yahoo MMCrawler', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yahoo Slurp', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'YahooSeeker', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yandex', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yandex Blog', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yandex Direct Bot', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('bot', 'Yandex Something', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'netcaptor', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'opera', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'aol', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'aol2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'mosaic', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'k-meleon', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'konqueror', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'avantbrowser', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'avantgo', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'proxomitron', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'chrome', 3, 1308281985);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'safari', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'lynx', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'links', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'galeon', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'abrowse', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'amaya', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'ant', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'aweb', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'beonex', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'blazer', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'camino', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'chimera', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'columbus', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'crazybrowser', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'curl', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'deepnet', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'dillo', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'doris', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'elinks', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'epiphany', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'ibrowse', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'icab', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'ice', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'isilox', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'lotus', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'lunascape', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'maxthon', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'mbrowser', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'multibrowser', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'nautilus', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'netfront', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'netpositive', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'omniweb', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'oregano', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'phaseout', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'plink', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'phoenix', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'shiira', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'sleipnir', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'slimbrowser', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'staroffice', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'sunrise', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'voyager', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'w3m', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'webtv', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'xiino', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'explorer', 4, 1308293447);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'firefox', 11, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'netscape', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'netscape2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'mozilla', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'mozilla2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'firebird', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'Mobile', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('browser', 'Unknown', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windows7', 10, 1308289582);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsvista', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windows2003', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsxp', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsxp2', 8, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windows2k', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windows95', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsce', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsme', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsme2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsnt', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windowsnt2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windows98', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'windows', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'linux', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'linux2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'linux3', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'macosx', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'macppc', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'mac', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'amiga', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'beos', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'freebsd', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'freebsd2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'irix', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'netbsd', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'netbsd2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'os2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'os22', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'openbsd', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'openbsd2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'palm', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'palm2', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('os', 'Unspecified', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AQ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'AZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BB', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BJ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'BZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CV', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'CZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'DE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'DJ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'DK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'DM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'DO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'DZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'EC', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'EE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'EG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ER', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ES', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ET', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'EU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'FI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'FJ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'FK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'FM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'FO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'FR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GB', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GP', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GQ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'GY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'HK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'HN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'HR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'HT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'HU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ID', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IQ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'IT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'JM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'JO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'JP', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'KZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LB', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LC', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LV', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'LY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MC', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ML', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MP', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MQ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MV', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MX', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'MZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NC', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NP', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'NZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'OM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'PY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'QA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'RE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'RO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'RU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'RW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SB', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SC', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ST', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SV', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'SZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TD', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TF', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TH', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TJ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TK', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TL', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TN', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TO', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TR', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TV', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'TZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'UA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'UG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'US', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'UY', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'UZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VC', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VG', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VI', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VN', 18, 1308294819);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'VU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'WS', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'YE', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'YT', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'YU', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ZA', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ZM', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ZW', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'ZZ', 0, 0);
INSERT INTO `nv3_vi_counter` VALUES ('country', 'unkown', 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_modfuncs`
-- 

CREATE TABLE `nv3_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL auto_increment,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL default '0',
  `in_submenu` tinyint(1) unsigned NOT NULL default '0',
  `subweight` smallint(2) unsigned NOT NULL default '1',
  `layout` varchar(50) NOT NULL default 'leftbodyright',
  `setting` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=130 ;

-- 
-- Dumping data for table `nv3_vi_modfuncs`
-- 

INSERT INTO `nv3_vi_modfuncs` VALUES (1, 'Sitemap', 'Sitemap', 'about', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (2, 'main', 'Main', 'about', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (3, 'Sitemap', 'Sitemap', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (4, 'comment', 'Comment', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (5, 'content', 'Content', 'news', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (6, 'detail', 'Detail', 'news', 1, 0, 2, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (7, 'main', 'Main', 'news', 1, 0, 3, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (8, 'postcomment', 'Postcomment', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (9, 'print', 'Print', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (10, 'rating', 'Rating', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (11, 'rss', 'Rss', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (12, 'savefile', 'Savefile', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (13, 'search', 'Search', 'news', 1, 0, 4, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (14, 'sendmail', 'Sendmail', 'news', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (15, 'topic', 'Topic', 'news', 1, 0, 5, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (16, 'viewcat', 'Viewcat', 'news', 1, 0, 6, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (17, 'active', 'Active', 'users', 1, 0, 8, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (18, 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (19, 'editinfo', 'Editinfo', 'users', 1, 0, 10, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (20, 'login', 'Đăng nhập', 'users', 1, 1, 2, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (21, 'logout', 'Logout', 'users', 1, 1, 3, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (22, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (23, 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (24, 'main', 'Main', 'users', 1, 1, 1, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (25, 'openid', 'Openid', 'users', 1, 1, 7, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (26, 'register', 'Đăng ký', 'users', 1, 1, 4, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (27, 'main', 'Main', 'contact', 1, 0, 1, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (28, 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (29, 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (30, 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (31, 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (32, 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (33, 'main', 'Main', 'statistics', 1, 0, 1, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (34, 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, 'left-body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (35, 'main', 'Main', 'voting', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (36, 'addads', 'Addads', 'banners', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (37, 'cledit', 'Cledit', 'banners', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (38, 'click', 'Click', 'banners', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (39, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (40, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (41, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (42, 'main', 'Main', 'banners', 1, 0, 3, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (43, 'stats', 'Stats', 'banners', 1, 0, 4, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (44, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (45, 'adv', 'Adv', 'search', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (46, 'main', 'Main', 'search', 1, 0, 1, 'body', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (47, 'main', 'Main', 'rss', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (48, 'main', 'Main', 'menu', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (49, 'service', 'Service', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (50, 'search', 'Search', 'shops', 1, 0, 4, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (51, 'delhis', 'Delhis', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (52, 'loadcart', 'Loadcart', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (53, 'sendmail', 'Sendmail', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (54, 'main', 'Main', 'shops', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (55, 'detail', 'Detail', 'shops', 1, 0, 3, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (56, 'viewcat', 'Viewcat', 'shops', 1, 0, 2, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (57, 'complete', 'Complete', 'shops', 1, 0, 8, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (58, 'print_pro', 'Print_pro', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (59, 'myproduct', 'Myproduct', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (60, 'profile', 'Profile', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (61, 'checkorder', 'Checkorder', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (62, 'rate', 'Rate', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (63, 'post', 'Post', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (64, 'print', 'Print', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (65, 'cart', 'Cart', 'shops', 1, 0, 5, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (66, 'addcomment', 'Addcomment', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (67, 'order', 'Order', 'shops', 1, 0, 6, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (68, 'delpro', 'Delpro', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (69, 'payment', 'Payment', 'shops', 1, 0, 7, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (70, 'myinfo', 'Myinfo', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (71, 'group', 'Group', 'shops', 1, 0, 10, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (72, 'setcart', 'Setcart', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (73, 'history', 'History', 'shops', 1, 0, 9, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (74, 'rss', 'Rss', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (75, 'remove', 'Remove', 'shops', 0, 0, 0, 'body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (76, 'service', 'Service', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (77, 'search', 'Search', 'sach-tieng-anh', 1, 0, 4, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (78, 'delhis', 'Delhis', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (79, 'loadcart', 'Loadcart', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (80, 'sendmail', 'Sendmail', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (81, 'main', 'Main', 'sach-tieng-anh', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (82, 'detail', 'Detail', 'sach-tieng-anh', 1, 0, 3, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (83, 'viewcat', 'Viewcat', 'sach-tieng-anh', 1, 0, 2, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (84, 'complete', 'Complete', 'sach-tieng-anh', 1, 0, 8, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (85, 'print_pro', 'Print_pro', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (86, 'myproduct', 'Myproduct', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (87, 'profile', 'Profile', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (88, 'checkorder', 'Checkorder', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (89, 'rate', 'Rate', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (90, 'post', 'Post', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (91, 'print', 'Print', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (92, 'cart', 'Cart', 'sach-tieng-anh', 1, 0, 5, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (93, 'addcomment', 'Addcomment', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (94, 'order', 'Order', 'sach-tieng-anh', 1, 0, 6, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (95, 'delpro', 'Delpro', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (96, 'payment', 'Payment', 'sach-tieng-anh', 1, 0, 7, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (97, 'myinfo', 'Myinfo', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (98, 'group', 'Group', 'sach-tieng-anh', 1, 0, 10, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (99, 'setcart', 'Setcart', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (100, 'history', 'History', 'sach-tieng-anh', 1, 0, 9, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (101, 'rss', 'Rss', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (102, 'remove', 'Remove', 'sach-tieng-anh', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (103, 'service', 'Service', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (104, 'search', 'Search', 'may-doc-sach', 1, 0, 4, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (105, 'delhis', 'Delhis', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (106, 'loadcart', 'Loadcart', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (107, 'sendmail', 'Sendmail', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (108, 'main', 'Main', 'may-doc-sach', 1, 0, 1, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (109, 'detail', 'Detail', 'may-doc-sach', 1, 0, 3, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (110, 'viewcat', 'Viewcat', 'may-doc-sach', 1, 0, 2, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (111, 'complete', 'Complete', 'may-doc-sach', 1, 0, 8, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (112, 'print_pro', 'Print_pro', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (113, 'myproduct', 'Myproduct', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (114, 'profile', 'Profile', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (115, 'checkorder', 'Checkorder', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (116, 'rate', 'Rate', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (117, 'post', 'Post', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (118, 'print', 'Print', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (119, 'cart', 'Cart', 'may-doc-sach', 1, 0, 5, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (120, 'addcomment', 'Addcomment', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (121, 'order', 'Order', 'may-doc-sach', 1, 0, 6, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (122, 'delpro', 'Delpro', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (123, 'payment', 'Payment', 'may-doc-sach', 1, 0, 7, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (124, 'myinfo', 'Myinfo', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (125, 'group', 'Group', 'may-doc-sach', 1, 0, 10, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (126, 'setcart', 'Setcart', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (127, 'history', 'History', 'may-doc-sach', 1, 0, 9, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (128, 'rss', 'Rss', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');
INSERT INTO `nv3_vi_modfuncs` VALUES (129, 'remove', 'Remove', 'may-doc-sach', 0, 0, 0, 'left-body-right', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_modthemes`
-- 

CREATE TABLE `nv3_vi_modthemes` (
  `func_id` int(11) default NULL,
  `layout` varchar(100) default NULL,
  `theme` varchar(100) default NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_modthemes`
-- 

INSERT INTO `nv3_vi_modthemes` VALUES (0, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (0, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (2, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (2, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (5, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (5, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (6, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (6, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (7, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (7, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (13, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (13, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (15, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (15, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (16, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (16, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (17, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (17, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (18, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (18, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (19, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (19, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (20, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (20, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (21, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (21, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (22, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (22, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (23, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (23, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (24, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (24, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (25, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (25, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (26, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (26, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (27, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (27, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (28, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (28, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (29, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (29, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (30, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (30, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (31, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (31, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (32, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (32, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (33, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (33, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (34, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (34, 'left-body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (36, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (36, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (39, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (39, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (42, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (42, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (43, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (43, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (46, 'body', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (46, 'body-right', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (47, 'body', 'modern');
INSERT INTO `nv3_vi_modthemes` VALUES (47, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (48, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (50, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (54, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (55, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (56, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (57, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (65, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (67, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (69, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (71, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (73, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (77, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (81, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (82, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (83, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (84, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (92, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (94, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (96, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (98, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (100, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (104, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (108, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (109, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (110, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (111, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (119, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (121, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (123, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (125, 'left-body-right', 'default');
INSERT INTO `nv3_vi_modthemes` VALUES (127, 'left-body-right', 'default');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_modules`
-- 

CREATE TABLE `nv3_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL default '',
  `module_data` varchar(55) NOT NULL default '',
  `custom_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL default '0',
  `admin_file` tinyint(1) unsigned NOT NULL default '0',
  `theme` varchar(100) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL default '0',
  `weight` tinyint(3) unsigned NOT NULL default '1',
  `submenu` tinyint(1) unsigned NOT NULL default '0',
  `act` tinyint(1) unsigned NOT NULL default '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_modules`
-- 

INSERT INTO `nv3_vi_modules` VALUES ('about', 'about', 'about', 'Giới thiệu', 1276333182, 1, '', '', '0', 1, 1, 1, 0, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('news', 'news', 'news', 'Tin Tức', 1270400000, 1, '', '', '0', 0, 6, 0, 0, '', 1);
INSERT INTO `nv3_vi_modules` VALUES ('users', 'users', 'users', 'THÀNH VIÊN', 1274080277, 1, '', '', '0', 1, 7, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('contact', 'contact', 'contact', 'LIÊN HỆ', 1275351337, 1, '', '', '0', 1, 4, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('statistics', 'statistics', 'statistics', 'Thống kê', 1276520928, 0, '', 'truy cập, online, statistics', '0', 0, 8, 0, 0, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('voting', 'voting', 'voting', 'Thăm dò ý kiến', 1275315261, 1, '', '', '0', 0, 9, 1, 0, '', 1);
INSERT INTO `nv3_vi_modules` VALUES ('banners', 'banners', 'banners', 'Quảng cáo', 1270400000, 1, '', '', '0', 0, 10, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('search', 'search', 'search', 'TÌM KIẾM SÁCH', 1273474173, 0, '', '', '0', 1, 5, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('menu', 'menu', 'menu', 'Menu Site', 1295287334, 0, '', '', '0', 0, 11, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('rss', 'rss', 'rss', 'Rss', 1279366705, 1, '', '', '0', 0, 12, 0, 0, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('shops', 'shops', 'shops', 'SÁCH TIẾNG VIỆT', 1308230177, 1, '', '', '0', 1, 2, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('sach-tieng-anh', 'shops', 'sach_tieng_anh', 'SÁCH TIẾNG ANH', 1308287526, 1, '', '', '0', 1, 3, 1, 1, '', 0);
INSERT INTO `nv3_vi_modules` VALUES ('may-doc-sach', 'shops', 'may_doc_sach', 'Máy Đọc Sách', 1308287802, 1, '', '', '0', 1, 13, 1, 0, '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_1`
-- 

CREATE TABLE `nv3_vi_news_1` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_1`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_2`
-- 

CREATE TABLE `nv3_vi_news_2` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_2`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_8`
-- 

CREATE TABLE `nv3_vi_news_8` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_8`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_9`
-- 

CREATE TABLE `nv3_vi_news_9` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_9`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_10`
-- 

CREATE TABLE `nv3_vi_news_10` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_10`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_11`
-- 

CREATE TABLE `nv3_vi_news_11` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_11`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_12`
-- 

CREATE TABLE `nv3_vi_news_12` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_12`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_admins`
-- 

CREATE TABLE `nv3_vi_news_admins` (
  `userid` int(11) NOT NULL default '0',
  `catid` int(11) NOT NULL default '0',
  `admin` tinyint(4) NOT NULL default '0',
  `add_content` tinyint(4) NOT NULL default '0',
  `pub_content` tinyint(4) NOT NULL default '0',
  `edit_content` tinyint(4) NOT NULL default '0',
  `del_content` tinyint(4) NOT NULL default '0',
  `comment` tinyint(4) NOT NULL default '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_news_admins`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_block`
-- 

CREATE TABLE `nv3_vi_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_news_block`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_block_cat`
-- 

CREATE TABLE `nv3_vi_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL auto_increment,
  `adddefault` tinyint(4) NOT NULL default '0',
  `number` mediumint(4) NOT NULL default '10',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `nv3_vi_news_block_cat`
-- 

INSERT INTO `nv3_vi_news_block_cat` VALUES (1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943);
INSERT INTO `nv3_vi_news_block_cat` VALUES (2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', '', 'Tin tiêu điểm', 2, '', 1279945725, 1279956445);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_cat`
-- 

CREATE TABLE `nv3_vi_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL auto_increment,
  `parentid` mediumint(8) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL default '',
  `thumbnail` varchar(255) NOT NULL default '',
  `weight` smallint(4) unsigned NOT NULL default '0',
  `order` mediumint(8) NOT NULL default '0',
  `lev` smallint(4) NOT NULL default '0',
  `viewcat` varchar(50) NOT NULL default 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL default '0',
  `subcatid` varchar(255) NOT NULL default '',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `numlinks` tinyint(2) unsigned NOT NULL default '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL default '0',
  `edit_time` int(11) unsigned NOT NULL default '0',
  `del_cache_time` int(11) NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `nv3_vi_news_cat`
-- 

INSERT INTO `nv3_vi_news_cat` VALUES (1, 0, 'Tin tức', 'Tin-tuc', '', '', '', 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 3, '', '', 1274986690, 1274986690, 1334230204, 0, '');
INSERT INTO `nv3_vi_news_cat` VALUES (2, 0, 'Sản phẩm', 'San-pham', '', '', '', 2, 5, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274986705, 1274986705, 1334230204, 0, '');
INSERT INTO `nv3_vi_news_cat` VALUES (8, 1, 'Thông cáo báo chí', 'thong-cao-bao-chi', '', '', '', 1, 2, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987105, 1274987244, 1334230204, 0, '');
INSERT INTO `nv3_vi_news_cat` VALUES (9, 1, 'Tin công nghệ', 'Tin-cong-nghe', '', '', '', 3, 4, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987212, 1274987212, 1334230204, 0, '');
INSERT INTO `nv3_vi_news_cat` VALUES (10, 0, 'Đối tác', 'Doi-tac', '', '', '', 3, 9, 0, 'viewcat_main_right', 0, '', 1, 3, '', '', 1274987460, 1274987460, 1334230204, 0, '');
INSERT INTO `nv3_vi_news_cat` VALUES (11, 0, 'Tuyển dụng', 'Tuyen-dung', '', '', '', 4, 12, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987538, 1274987538, 1334230204, 0, '');
INSERT INTO `nv3_vi_news_cat` VALUES (12, 1, 'Bản tin nội bộ', 'Ban-tin-noi-bo', '', '', '', 2, 3, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1274987902, 1274987902, 1334230204, 0, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_comments`
-- 

CREATE TABLE `nv3_vi_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL auto_increment,
  `id` mediumint(8) unsigned NOT NULL default '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_vi_news_comments`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_config_post`
-- 

CREATE TABLE `nv3_vi_news_config_post` (
  `pid` mediumint(9) NOT NULL auto_increment,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY  (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `nv3_vi_news_config_post`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_log`
-- 

CREATE TABLE `nv3_vi_news_log` (
  `log_id` int(11) unsigned NOT NULL auto_increment,
  `log_time` int(11) NOT NULL default '0',
  `log_admin` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL default '0',
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `id` (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `nv3_vi_news_log`
-- 

INSERT INTO `nv3_vi_news_log` VALUES (1, 1308277753, 1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 'thumb/nangly.jpg|block/nangly.jpg', 1, '<p style="text-align: justify;"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại 67B/35 Khương Hạ, Khương Đình, Thanh Xuân, Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br  /> <br  /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br  /> <br  /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br  /> <br  /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style="text-align: justify;"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href="http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm" target="_blank">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href="http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov" target="_blank">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 0, 1, 2, 1, 1, 1, 1, 97, 0, 0, 0, 'nguồn mở, quen thuộc, cộng đồng, việt nam, hoạt động, gần đây, phổ biến, áp dụng, hầu hết, hết các, lĩnh vực, tin tức, thương mại điện, điện tử, cá nhân, hệ thống');
INSERT INTO `nv3_vi_news_log` VALUES (2, 1308277753, 1, 2, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 'thumb/nukeviet3.jpg|block/nukeviet3.jpg', 1, '<p style="font-weight: bold;"> <span style="font-size: 14pt;">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style="font-weight: bold;"> Từ một trăn trở</p><p style="text-align: justify;"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style="font-weight: bold;">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style="font-weight: bold;">Một mô hình - một lối đi</span></p><p style="text-align: justify;"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br  /> <span style="font-weight: bold;">Triển khai thực hiện</span></p><p style="text-align: justify;"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style="text-align: center;"> <img alt="Anh Tú phát biểu khai trương VINADES.,JSC " height="332" src="http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg" style="border: 0px solid;" width="500" /></div><div style="text-align: center;"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br  /> <img alt="" border="0" src="http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg" style="width: 500px;" width="500" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br  /> <img alt="" border="0" height="332" src="http://nukeviet.vn/uploads/spaw2/images/nangly.jpg" style="width: 500px; height: 332px;" width="500" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style="font-weight: bold;"> ... và lời cảm ơn gửi tới cộng đồng</p><p style="text-align: justify;"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style="text-align: center;"> <img alt="" border="0" height="375" src="http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg" style="width: 500px; height: 375px;" width="500" /></div><p>  </p><p style="text-align: center;"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style="text-align: center;"> <img alt="" border="0" height="375" src="http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg" style="width: 500px; height: 375px;" width="500" /></div><p>  </p><p style="text-align: center;"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style="font-weight: bold;"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style="text-align: justify;"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style="text-align: justify;"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href="http://nukeviet.vn/phpbb/viewforum.php?f=99" target="_blank">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 0, 1, 2, 1, 1, 1, 1, 91, 0, 0, 0, 'nền tảng, xây dựng, hoàn toàn, với những, công nghệ, tiên tiến, hiện nay, hứa hẹn, cách mạng, nguồn mở, việt nam, món quà, cảm ơn, chân thành, thành nhất, cộng đồng');
INSERT INTO `nv3_vi_news_log` VALUES (3, 1308277753, 1, 5, '2', 1, 1, '', 0, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', 'screenshot.jpg', '', 'thumb/screenshot.jpg|block/screenshot.jpg', 1, '<p> <strong><span style="font-size: 14px;">THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET</span></strong></p><p style="font-weight: bold;"> I. Giới thiệu chung:</p><p> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web.</p><p> NukeViet có 2 dòng phiên bản chính:</p><p> Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke.</p><p> Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt.</p><p> NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &amp;quản trị các nội dung của họ lên Internet hoặc Intranet.</p><p> NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng.</p><p style="text-align: justify;"> NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt.</p><p>  </p><p> Thông tin chi tiết về NukeViet có thể tìm thấy ở bách khoa toàn thư mở Wikipedia: <a href="http://vi.wikipedia.org/wiki/NukeViet">http://vi.wikipedia.org/wiki/NukeViet</a></p><p style="font-weight: bold;"> II. Thông tin về diễn đàn NukeViet:</p><p> Diễn đàn NukeViet hoạt động trên website: <a href="http://nukeviet.vn/"><span style="font-weight: bold;">http://nukeviet.vn</span></a> hiện có trên 13.000 thành viên thực gồm học sinh, sinh viên &amp; nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước.</p><p> Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an...</p><p> Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.</p>', 0, 1, 2, 1, 1, 1, 1, 90, 0, 0, 0, 'quản trị, nội dung, sử dụng, khả năng, tích hợp, ứng dụng');
INSERT INTO `nv3_vi_news_log` VALUES (4, 1308277753, 1, 6, '1,8,10', 0, 1, '', 0, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 'thumb/hoptac.jpg|block/hoptac.jpg', 1, '<div style="text-align: center;"> <h2 style="color: rgb(255, 69, 0);"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style="text-align: justify; line-height: 130%; font-weight: bold;">  </p> <p style="text-align: justify; line-height: 130%; font-weight: bold;"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style="text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style="text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style="text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style="text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style="text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;"> Phương thức hợp tác nhưsau:</p> <p style="text-align: justify; line-height: 130%; font-weight: bold;"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style="text-align: justify; line-height: 130%;"> a. Mô tả hình thức:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style="text-align: justify; line-height: 130%;"> b, Lợi ích:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style="text-align: justify; line-height: 130%;"> c, Trách nhiệm:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style="text-align: justify; line-height: 130%; font-weight: bold;"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style="text-align: justify; line-height: 130%;"> a. Mô tả hình thức:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style="text-align: justify; line-height: 130%;"> b. Lợi ích:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style="text-align: justify; line-height: 130%;"> c. Trách nhiệm:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style="text-align: justify; line-height: 130%; font-weight: bold;"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style="text-align: justify; line-height: 130%;"> a, Mô tả hình thức:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style="text-align: justify; line-height: 130%;"> b, Lợi ích:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style="text-align: justify; line-height: 130%;"> c, Trách nhiệm:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này.</p> <p style="text-align: justify; line-height: 130%; font-weight: bold;"> 4. Các hình thức khác:</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style="text-align: justify; line-height: 130%; text-indent: 1cm;"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style="text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style="font-weight: bold;">Thông tin liên hệ:</span> <p style="text-align: justify;"> CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style="text-align: justify; text-indent: 1cm;"> Trụ sở chính: 67B (ngõ 35) phố Khương Hạ, Khương Đình, Thanh Xuân, Hà Nội.</p> <p style="text-align: justify; text-indent: 1cm;"> Điện thoại: (84-4) 85 872007</p> <p style="text-align: justify; text-indent: 1cm;"> Fax: (84-4) 35 500 914</p> <p style="text-align: justify; text-indent: 1cm;"> Website: <a href="http://www.vinades.vn/">www.vinades.vn</a> – <a href="http://www.nukeviet.vn/">www.nukeviet.vn</a></p> <p style="text-align: justify; text-indent: 1cm;"> Email: <a href="mailto:contact@vinades.vn">contact@vinades.vn</a></p>', 0, 1, 2, 1, 1, 1, 1, 73, 0, 0, 0, 'hiện tại, tiến hành, phát triển, phiên bản, thế hệ, hoàn toàn, tính năng, ưu việt, kinh phí, thiện chí, hợp tác, trân trọng, mời hợp tác, đối tác, các công ty, công ty, cung cấp, tên miền, các doanh, doanh nghiệp, quan tâm');

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_rows`
-- 

CREATE TABLE `nv3_vi_news_rows` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `listcatid` varchar(255) NOT NULL default '',
  `topicid` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `author` varchar(255) NOT NULL default '',
  `sourceid` mediumint(8) NOT NULL default '0',
  `addtime` int(11) unsigned NOT NULL default '0',
  `edittime` int(11) unsigned NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '1',
  `publtime` int(11) unsigned NOT NULL default '0',
  `exptime` int(11) unsigned NOT NULL default '0',
  `archive` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL default '',
  `homeimgalt` varchar(255) NOT NULL default '',
  `homeimgthumb` varchar(255) NOT NULL default '',
  `imgposition` tinyint(1) NOT NULL default '1',
  `bodytext` mediumtext NOT NULL,
  `copyright` tinyint(1) unsigned NOT NULL default '0',
  `inhome` tinyint(1) unsigned NOT NULL default '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL default '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL default '0',
  `allowed_send` tinyint(1) unsigned NOT NULL default '0',
  `allowed_print` tinyint(1) unsigned NOT NULL default '0',
  `allowed_save` tinyint(1) unsigned NOT NULL default '0',
  `hitstotal` mediumint(8) unsigned NOT NULL default '0',
  `hitscm` mediumint(8) unsigned NOT NULL default '0',
  `total_rating` int(11) NOT NULL default '0',
  `click_rating` int(11) NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `listcatid` (`listcatid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `nv3_vi_news_rows`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_sources`
-- 

CREATE TABLE `nv3_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `link` varchar(255) NOT NULL default '',
  `logo` varchar(255) NOT NULL default '',
  `weight` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `nv3_vi_news_sources`
-- 

INSERT INTO `nv3_vi_news_sources` VALUES (1, 'Hanoimoi.com.vn', '', '', 1, 1274989177, 1274989177);
INSERT INTO `nv3_vi_news_sources` VALUES (2, 'nukeviet.vn', '', '', 2, 1274989787, 1274989787);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_news_topics`
-- 

CREATE TABLE `nv3_vi_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL default '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL default '0',
  `edit_time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `nv3_vi_news_topics`
-- 

INSERT INTO `nv3_vi_news_topics` VALUES (1, 'NukeViet 3', 'NukeViet-3', '', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);

-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_referer_stats`
-- 

CREATE TABLE `nv3_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL default '0',
  `month01` int(11) NOT NULL default '0',
  `month02` int(11) NOT NULL default '0',
  `month03` int(11) NOT NULL default '0',
  `month04` int(11) NOT NULL default '0',
  `month05` int(11) NOT NULL default '0',
  `month06` int(11) NOT NULL default '0',
  `month07` int(11) NOT NULL default '0',
  `month08` int(11) NOT NULL default '0',
  `month09` int(11) NOT NULL default '0',
  `month10` int(11) NOT NULL default '0',
  `month11` int(11) NOT NULL default '0',
  `month12` int(11) NOT NULL default '0',
  `last_update` int(11) NOT NULL default '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_referer_stats`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_searchkeys`
-- 

CREATE TABLE `nv3_vi_searchkeys` (
  `id` varchar(32) NOT NULL default '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL default '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `nv3_vi_searchkeys`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_voting`
-- 

CREATE TABLE `nv3_vi_voting` (
  `vid` mediumint(8) unsigned NOT NULL auto_increment,
  `question` varchar(255) NOT NULL,
  `acceptcm` int(2) NOT NULL default '1',
  `admin_id` mediumint(8) unsigned NOT NULL default '0',
  `who_view` tinyint(2) unsigned NOT NULL default '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL default '0',
  `exp_time` int(11) unsigned NOT NULL default '0',
  `act` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `nv3_vi_voting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `nv3_vi_voting_rows`
-- 

CREATE TABLE `nv3_vi_voting_rows` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL default '',
  `hitstotal` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `nv3_vi_voting_rows`
-- 

