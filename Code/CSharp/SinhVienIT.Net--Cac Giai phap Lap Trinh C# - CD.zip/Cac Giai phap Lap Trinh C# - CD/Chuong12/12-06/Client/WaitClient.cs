using System;
using System.Threading;

namespace Client
{
	public class WaitClient
	{
		[MTAThread]
		private static void Main()
		{
			localhost.WaitService proxy = new localhost.WaitService();

			DateTime startDate = DateTime.Now;

			IAsyncResult handle1 = proxy.BeginWait(null, null);
			IAsyncResult handle2 = proxy.BeginWait(null, null);
			IAsyncResult handle3 = proxy.BeginWait(null, null);

			WaitHandle[] waitHandle = {handle1.AsyncWaitHandle,
										  handle2.AsyncWaitHandle, handle3.AsyncWaitHandle};

			WaitHandle.WaitAll(waitHandle);

			int totalDelay = proxy.EndWait(handle1) + proxy.EndWait(handle2) +
				proxy.EndWait(handle3);
			TimeSpan elapsedTime = DateTime.Now - startDate;

			Console.WriteLine("Completed after " + elapsedTime.ToString());
			Console.WriteLine("Total delay time: " + totalDelay.ToString());

			Console.ReadLine();
		}

	/*	[MTAThread]
		private static void Main()
		{
			localhost.WaitService proxy = new localhost.WaitService();

			AsyncCallback callback = new AsyncCallback(Callback);

			// Start the method asynchronously, with the callback. 
			proxy.BeginWait(callback, proxy);

			Console.ReadLine();
		}
	*/
		public static void Callback(IAsyncResult handle) 
		{

			localhost.WaitService proxy = (localhost.WaitService)handle.AsyncState;
			int result = proxy.EndWait(handle);
			Console.WriteLine("Waited " + result.ToString());
		}
	}
}