using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

public class SpriteTest : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SpriteTest()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		// 
		// SpriteTest
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Name = "SpriteTest";
		this.Text = "Sprite Test";
		this.Load += new System.EventHandler(this.SpriteTest_Load);
		

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new SpriteTest());
	}

	
	private bool isDraggingA = false;
	private bool isDraggingB = false;

	private EllipseShape ellipseA, ellipseB;

	private void SpriteTest_Load(object sender, System.EventArgs e)
	{
		ellipseA = new EllipseShape();
		ellipseA.Width = ellipseA.Height = 100;
		ellipseA.Top = ellipseA.Left = 30;
		ellipseA.BackColor = Color.Red;
		this.Controls.Add(ellipseA);

		ellipseB = new EllipseShape();
		ellipseB.Width = ellipseB.Height = 100;
		ellipseB.Top = ellipseB.Left = 130;
		ellipseB.BackColor = Color.Azure;
		this.Controls.Add(ellipseB);

		ellipseA.MouseDown += new MouseEventHandler(Ellipse_MouseDown);
		ellipseA.MouseUp += new MouseEventHandler(Ellipse_MouseUp);
		ellipseA.MouseMove += new MouseEventHandler(Ellipse_MouseMove);

		ellipseB.MouseDown += new MouseEventHandler(Ellipse_MouseDown);
		ellipseB.MouseUp += new MouseEventHandler(Ellipse_MouseUp);
		ellipseB.MouseMove += new MouseEventHandler(Ellipse_MouseMove);
	}

	private void Ellipse_MouseDown(object sender, MouseEventArgs e)
	{
		Control control = (Control)sender;

		if (e.Button == MouseButtons.Left)
		{
			control.Tag = new Point(e.X, e.Y);
			if (control == ellipseA)
			{
				isDraggingA = true;
			}
			else
			{
				isDraggingB = true;
			}
		}
	}

	private void Ellipse_MouseUp(object sender, MouseEventArgs e)
	{		
		isDraggingA = false;	
		isDraggingB = false;
	}

	private void Ellipse_MouseMove(object sender, MouseEventArgs e)
	{
		Control control = (Control)sender;
		
		if ((isDraggingA && control == ellipseA) ||
			(isDraggingB && control == ellipseB))
		{
			Point point = (Point)control.Tag;

			control.Left = e.X + control.Left - point.X;
			control.Top = e.Y + control.Top - point.Y;
		}
	}

}

public class EllipseShape : System.Windows.Forms.Control
{
	private GraphicsPath path = null;

	private void RefreshPath()
	{
		path = new GraphicsPath();
		path.AddEllipse(this.ClientRectangle);
		this.Region = new Region(path);
	}

	protected override void OnResize(System.EventArgs e)
	{
		base.OnResize(e);
		RefreshPath();
		this.Invalidate();
	}

	protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
	{
		base.OnPaint(e);
		if (path != null)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.FillPath(new SolidBrush(this.BackColor), path);
			e.Graphics.DrawPath(new Pen(this.ForeColor, 4), path);
		}
	}

}