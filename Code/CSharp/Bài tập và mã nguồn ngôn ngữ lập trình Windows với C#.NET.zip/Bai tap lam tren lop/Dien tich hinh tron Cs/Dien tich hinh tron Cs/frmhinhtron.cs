using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Dien_tich_hinh_tron_Cs
{
    public partial class frmhinhtron : Form
    {
        public frmhinhtron()
        {
            InitializeComponent();
        }

        private void btnthoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btntinh_Click(object sender, EventArgs e)
        {
            double decr, deccv, decdt;
            decr = Convert.ToDouble(txtbk.Text);
            decdt = decr * decr * 3.14;
            deccv = 2 * decr;
            txtcv.Text = deccv.ToString();
            txtdt.Text = decdt.ToString();
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            txtbk.Text = null;
            txtcv.Text = null;
            txtdt.Text = null;
        }
    }
}