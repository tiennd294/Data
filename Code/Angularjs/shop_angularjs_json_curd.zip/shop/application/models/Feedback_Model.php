<?php
Class Feedback_Model extends MY_Model
{
    var $table = 'feedback';
    var $key = 'Idf';
}