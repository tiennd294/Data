﻿using System;
using System.Windows.Forms;
using System.IO;

namespace FileCopier
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Hàm copy file
        /// </summary>
        /// <param name="Source">File nguồn</param>
        /// <param name="Destination">File đích</param>
        /// <param name="BufferSize">Kích cỡ buffer</param>
        /// <returns>Trả về true nếu copy thành công, ngược lại là thất bại</returns>
        private bool Copy(string Source, string Destination, long BufferSize)
        {
            //Lấy kích cỡ file nguồn
            long TotalSize = new FileInfo(Source).Length;
            long CopiedSize = 0;
            //Mảng byte chứa buff
            byte[] Buffer;
            //Mở luồng để đọc, ghi
            FileStream fsi = new FileStream(Source, FileMode.Open);
            FileStream fso = new FileStream(Destination, FileMode.Create);
            BinaryReader br = new BinaryReader(fsi);
            BinaryWriter bw = new BinaryWriter(fso);
            //Bắt đầu copy
            while (TotalSize > 0)
            {
                //Điều chỉnh buffer size
                if (TotalSize < BufferSize) BufferSize = TotalSize;
                try
                {
                    //Đọc và ghi thông qua Buffer
                    Buffer = br.ReadBytes((int)BufferSize);
                    bw.Write(Buffer);
                    TotalSize -= BufferSize;
                }
                catch (Exception Ex)
                {
                    //Đóng luồng
                    fsi.Close();
                    fso.Close();
                    return false;
                }
                //Tính số byte đã copy
                CopiedSize += BufferSize;
                //Xử lý tiến trình ở đây
                lblCopiedSize.Text = CopiedSize.ToString() + " bytes";
                prbCopy.Value = (int)(((float)CopiedSize / (CopiedSize + TotalSize)) * 100.0);
                lblPercent.Text = prbCopy.Value.ToString() + " %";
                Application.DoEvents();
            }
            //Đóng luồng
            fsi.Close();
            fso.Close();
            return true;
        }

        private void cmdFindSource_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgFile = new OpenFileDialog();
            dlgFile.Title = "Chọn file nguồn";
            dlgFile.Filter = "Tất cả file (*.*)|*.*";
            dlgFile.FilterIndex = 0;
            dlgFile.CheckFileExists = true;
            if (dlgFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtSource.Text = dlgFile.FileName;
                lblFileSize.Text = new FileInfo(txtSource.Text).Length.ToString() + " bytes";
            }
        }

        private void cmdFindDes_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlgFolder = new FolderBrowserDialog();
            dlgFolder.Description = "Chọn thư mục đích :";
            if (dlgFolder.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                txtDes.Text = dlgFolder.SelectedPath;
        }

        private void cmdCopy_Click(object sender, EventArgs e)
        {
            string Source = txtSource.Text;
            string Des = (txtDes.Text + Path.GetFileName(Source)).Replace(@"\\",@"\");
            if (File.Exists(Des))
            {
                if (MessageBox.Show("Tập tin " + Des + " đã tồn tại. Bạn có muốn ghi đè ?","Có ghi đè ?",MessageBoxButtons.YesNo,MessageBoxIcon.Question)== System.Windows.Forms.DialogResult.No)
                    return;
            }
            long BufferSize = (long)nudBufferSize.Value*1024;
            if (BufferSize >= new FileInfo(Source).Length)
            {
                MessageBox.Show("Buffer size phải nhỏ hơn kích cỡ tập tin nguồn.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            bool Result = Copy(Source, Des, BufferSize);
            if (Result)
                MessageBox.Show("Copy file thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Lỗi trong quá trình copy. Copy thất bại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            prbCopy.Value = 0;
            lblCopiedSize.Text = "0 bytes";
            lblPercent.Text = "0 %";
        }
    }
}
