using System;
using System.Collections.Generic;
using System.Text;

namespace bai_tap_ven_nha
{
    class congtru
    {
        int ts;

    public int Ts
    {
        get { return ts; }
        set { ts = value; }
    }
        int ms;

    public int Ms
    {
        get { return ms; }
        set { ms = value; }
    }
        public congtru()
        {
            ts = 0;
            ms =1;
        }
        public congtru(int tu, int mau )
        {
            ts = tu;
            ms = mau;
        }
        
        public int us(int a, int b)
        {
            int us = 1;
            int min = (a < b) ? a : b;
            for (int i = 2; i <= min; i++)
                if (a % i == 0 && b % i == 0)
                    us = i;
            return us;
        }
        public congtru rutgon()
        {
            congtru ct=null;
            if(this.ts==this.ms)
                ct=new congtru(1,1);
            int ucln=us(this.ts,this.ms);
            ct = new congtru(this.ts / ucln, this.ms / ucln);
            return ct;
        }
        public override string  ToString()
        {
 	        string str="";
            congtru ct=new congtru();
            if(ct.ms==1)
                str=ct.ts.ToString();
            else
                str=ct.ts.ToString()+"/"+ct.ms.ToString();
            return str;
        }
        public congtru cong(congtru a)
        {
            congtru tong = new congtru();
            tong.ts = (this.ts * a.ms + this.ms * a.ts);
            tong.ms = (this.ms * a.ms);
            return tong;
        }
        public congtru tru(congtru a)
        {
            congtru tong = new congtru();
            tong.ts = this.ts * a.ms - this.ms * a.ts;
            tong.ms = this.ms * a.ms;
            return tong;
        }
      
    }
}
