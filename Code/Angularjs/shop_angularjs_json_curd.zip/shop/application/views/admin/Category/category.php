
<script type='text/javascript'>
      
     function AddCategory($Parentid)
     {

        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Classify:$('.aClassify'+$Parentid).val(),
            Parentid:$('.aParentid'+$Parentid).val(),
            Name:$('.aName'+$Parentid).val(),
            Linkurl:$('.aLinkurl'+$Parentid).val(),
            Display:$('.aDisplay'+$Parentid).val(),
            Startus:$('#aStartus'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '<?php echo admin_url();?>/Category/Add',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                              $('#result').html(result);
                              window.location.reload();
                              //alert('Successfuly!');
                         }
                    });
     }


      function Add2Category($Parentid)
     {
        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Classify:$('.a2Classify'+$Parentid).val(),
            Parentid:$('.a2Parentid'+$Parentid).val(),
            Name:$('.a2Name'+$Parentid).val(),
            Linkurl:$('.a2Linkurl'+$Parentid).val(),
            Display:$('.a2Display'+$Parentid).val(),
            Startus:$('#a2Startus'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '<?php echo admin_url();?>/Category/Add',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                              $('#result').html(result);
                              window.location.reload();
                              //alert('Successfuly!');
                         }
                    });
     }

    function EditCategory($Parentid)
    {
        
        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        $('.successfuly'+$Parentid).hide();
        var data={
            Idc:$('.eIdc'+$Parentid).val(),
            Name:$('.eName'+$Parentid).val(),
            Linkurl:$('.eLinkurl'+$Parentid).val(),
            Display:$('.eDisplay'+$Parentid).val(),
            Startus:$('#eStartus'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '<?php echo admin_url();?>/Category/Edit',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                            if (result=='true') {
                                loading.fadeOut(500);
                                if ($('#eStartus'+$Parentid).val()=='on') {
                                    if($(".itemstartuslock"+$Parentid).length>0){
                                        $(".itemstartuslock"+$Parentid).removeClass('icon-lock').removeClass('itemstartuslock'+$Parentid).addClass('itemstartusok'+$Parentid).addClass('icon-ok');
                                    }
                                }
                                //alert($('#eStartus'+$Parentid).val());
                                if ($('#eStartus'+$Parentid).val()=='') {
                                    if($(".itemstartusok"+$Parentid).length>0){
                                        $(".itemstartusok"+$Parentid).removeClass('icon-ok').removeClass('itemstartusok'+$Parentid).addClass('itemstartuslock'+$Parentid).addClass('icon-lock');
                                    }
                                }
                                
                                btnadd.fadeIn(300);
                                $('.successfuly'+$Parentid).fadeIn(300);
                            };
                         }
                    });
        


    }

    function DeleteCategory($Parentid)
    {
        var loading = $('.reload'+$Parentid);
        var btnadd = $('.btnadd'+$Parentid); 
        btnadd.fadeOut(300);
        loading.fadeIn(500);
        var data={
            Idc:$('.dIdc'+$Parentid).val()
        };
        
                    $.ajax({
                         url : '<?php echo admin_url();?>/Category/delete',
                         type : "post",
                         dateType:"text",
                         data : data,
                         success : function (result)
                         {
                            if (result=='true') {
                                $('.items'+$Parentid).remove();
                            };
                              //$('#result').html(result);
                              //window.location.reload();
                         }
                    });
    }


</script> 

<?php
echo $category;
?>
    
