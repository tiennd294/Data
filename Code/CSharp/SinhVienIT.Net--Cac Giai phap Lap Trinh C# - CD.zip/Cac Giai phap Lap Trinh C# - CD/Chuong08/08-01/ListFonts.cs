using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Text;

public class ListFonts : System.Windows.Forms.Form
{
	private System.Windows.Forms.Panel pnlFonts;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ListFonts()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.pnlFonts = new System.Windows.Forms.Panel();
		this.SuspendLayout();
		// 
		// pnlFonts
		// 
		this.pnlFonts.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.pnlFonts.AutoScroll = true;
		this.pnlFonts.BackColor = System.Drawing.Color.White;
		this.pnlFonts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.pnlFonts.Location = new System.Drawing.Point(12, 12);
		this.pnlFonts.Name = "pnlFonts";
		this.pnlFonts.Size = new System.Drawing.Size(268, 244);
		this.pnlFonts.TabIndex = 0;
		// 
		// ListFonts
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.pnlFonts});
		this.Name = "ListFonts";
		this.Text = "List Fonts";
		this.Load += new System.EventHandler(this.ListFonts_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new ListFonts());
	}

	private void ListFonts_Load(object sender, System.EventArgs e)
	{
		InstalledFontCollection fontFamilies = new InstalledFontCollection();
        
		int offset = 10;
		foreach (FontFamily family in fontFamilies.Families)
		{
			try
			{
				Label fontLabel = new Label();
				fontLabel.Text = family.Name;
				fontLabel.Font = new Font(family, 14);
				fontLabel.Left = 10;
				fontLabel.Width = pnlFonts.Width;
				fontLabel.Top = offset;
				
				pnlFonts.Controls.Add(fontLabel);
				offset += 30;
			}
			catch
			{
			}

		}
	}
}