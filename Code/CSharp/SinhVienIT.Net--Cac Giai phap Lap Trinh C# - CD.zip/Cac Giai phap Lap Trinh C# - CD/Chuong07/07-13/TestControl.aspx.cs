using System;
using System.Web;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Drawing.Drawing2D;

/// <summary>
/// Summary description for DynamicControlTest.
/// </summary>
public class DynamicControlTest : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.Panel pnl;

	private void Page_Load(object sender, System.EventArgs e)
	{			
		DynamicGraphicControl ctrl;
		ctrl = (DynamicGraphicControl)Page.LoadControl("DynamicGraphicControl.ascx");
		
		ctrl.ImageText = "This is a new banner test";
		ctrl.ImageSize = new Size(300, 200);
		ctrl.TextFont = new Font("Verdana", 24, FontStyle.Bold);
		ctrl.BackColor = Color.Olive;
		ctrl.ForeColor = Color.LightYellow;
		ctrl.BorderColor = Color.OrangeRed;

        pnl.Controls.Add(ctrl);

	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion
}