using System;
using System.IO;
using System.Threading;

public class AsynchronousIO
{
	public static void Main()
	{
		FileStream fs = new FileStream("test.txt", FileMode.Create);
		fs.SetLength(1000000);
		fs.Close();

		AsyncProcessor asyncIO = new AsyncProcessor("test.txt");
		asyncIO.StartProcess();

		DateTime startTime = DateTime.Now;
		while (DateTime.Now.Subtract(startTime).TotalSeconds < 10)
		{
			Console.WriteLine("[MAIN THREAD]: Doing some work.");

			Thread.Sleep(TimeSpan.FromMilliseconds(100));
		}
		
		Console.WriteLine("[MAIN THREAD]: Complete.");
		Console.ReadLine();

		File.Delete("test.txt");
	}

}

public class AsyncProcessor
{
	private Stream inputStream;   

	private int bufferSize = 2048;

	public int BufferSize
	{
		get {return bufferSize;}
		set {bufferSize = value;}
	}

	private byte[] buffer;

	public AsyncProcessor(string fileName)
	{
		buffer = new byte[bufferSize];

		inputStream = new FileStream(fileName, FileMode.Open,
			FileAccess.Read, FileShare.Read, bufferSize, true);
	}

	public void StartProcess()
	{
		inputStream.BeginRead(buffer, 0, buffer.Length,
			new AsyncCallback(OnCompletedRead), null);
	}

	private void OnCompletedRead(IAsyncResult asyncResult)
	{
		int bytesRead = inputStream.EndRead(asyncResult);

		if (bytesRead > 0)
		{
			Console.WriteLine("\t[ASYNC READER]: Read one block.");
			Thread.Sleep(TimeSpan.FromMilliseconds(20));

			inputStream.BeginRead(
				buffer, 0, buffer.Length, new AsyncCallback(OnCompletedRead), null);
		}
		else
		{
			Console.WriteLine("\t[ASYNC READER]: Complete.");
			inputStream.Close();
		}
	}
}