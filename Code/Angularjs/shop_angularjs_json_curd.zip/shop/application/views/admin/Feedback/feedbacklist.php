<script type='text/javascript'>
$(document).ready(function () {
	var frmadd = $('.frmadd');
    var datatable = $('#datatable');

	$(".btndatail").click(function (e) {

    
       
        var $td = $(this).closest('tr').children('td');
        

		var Idfe = $td.eq(0).text(); $(".Idfe").val(Idfe);
		var Name = $td.eq(1).text(); $(".Name").text(Name);
		var Phone = $td.eq(2).text(); $(".Phone").text(Phone);
		var Email = $td.eq(3).text(); $(".Email").text(Email);
		var Address = $td.eq(4).text(); $(".Address").text(Address);
		var Detail = $td.eq(5).text(); $(".Detail").text(Detail);
		if ($td.eq(6).text()=='on'){
			$(".Startus").text('Đã xử lý');
			$(".Startus").removeClass('btn-danger').addClass('btn-success');
		}
		else {
			$(".Startus").text('Đang chờ');
			$(".Startus").removeClass('btn-success').addClass('btn-danger');
		}

	    e.preventDefault();
	   	datatable.hide(500);
	    frmadd.fadeIn(500);
    });

   
});







function Update_feedback(id)
    {

    	var Items = $('.Items'+id);
    	var reload = $('.reload'+id);
    	    
    	Items.hide(500);
    	reload.fadeIn(500);
        var data={
            Idf:id,
            Startus:$('.Startus'+id).text()
        };

        

                    $.ajax({
                       type: 'post',
                       url: '<?php echo admin_url();?>/Feedbacklist/Update',
                       data: data,
                       success: function (response) {
                        reload.hide(500);
                        if ($('.Startus'+id).text()=='on') {
				            $('.Startus'+id).text('');
				            Items.removeClass('icon-ok').addClass('icon-remove');
				            
				        }else
				        if($('.Startus'+id).text()!='on') {
				            $('.Startus'+id).text('on');
				            Items.removeClass('icon-remove').addClass('icon-ok');
				            
				        };

                        Items.fadeIn(500);
                       }
                     });
                    
    }
</script> 
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã ID</th>  
                                    <th>Tên</th>  
                                    <th>Điện thoại</th>  
                                    <th>Email</th>  
                                    <th>Địa chỉ</th>  
                                    <th>Nội dung</th>  
                                    <th>Ngày tạo</th> 
                                    <th></th> 
                                    <th>Tình trạng</th>  
                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                $i=0;
                                foreach ($tblfeedback as $row):
                                    $i++;
                            ?>
                                <tr class='gradeU items_' id='<?php echo $row->Idf; ?>'>
                                    <td><?php echo $row->Idf; ?></td>
                                    <td><?php echo $row->Name; ?></td>
                                    <td><?php echo $row->Phone; ?></td>
                                    <td><?php echo $row->Email; ?></td>
                                    <td><?php echo $row->Address; ?></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Content; ?></div></td>
                                    <td><?php echo $row->Createdate; ?></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><label class='Startus<?php echo $row->Idf; ?>'><?php echo $row->Startus; ?></label></div></td>
                                    <td style='text-align: center;'>
                                        
                                    <i class='reload reload<?php echo $row->Idf; ?>' style='display:none;'></i>
                                    <?php
                                     if($row->Startus=='on')
                                     	echo "<label class='Items".$row->Idf." icon-ok' onclick='Update_feedback(".$row->Idf.")'></label>" ; 
                                     	else echo "<label class='Items".$row->Idf." icon-remove' onclick='Update_feedback(".$row->Idf.")'></label>" ;
                                     ?>

                                     </td>
                                    <td style='text-align: center;'><a href='#' class='btn btndatail btn-mini tip-top btnedit btn-primary' data-original-title='Chi tiết'>Chi tiết</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:75%;text-align: center; margin-left: 12%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Khách hàng góp ý</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='?c=feedbacklist&a=update'>


							
                            <div class="widget-content tab-content">
                                <div id="tab1" class="tab-pane active" style="margin-left:5%;margin-top:5%;margin-bottom:15%;margin-right:5%;">
                                	<p><h5>Tên khách hàng: </h5></p><p><h4><label id="Name" class="Name"></label></h4></p>
                  					<p><h5>Số điện thoại: </h5></p><p><h4><label id="Phone" class="Phone"></label></h4></p>
                  					<p><h5>Email: </h5></p><h4><label id="Email" class="Email"></label></h4></p>
                  					<p><h5>Địa chỉ: </h5></p><p><h4><label id="Address" class="Address"></label> </h4></p>
                  					<p><h5>Nội dung: </h5></p><p><h4><label id="Detail" class="Detail"></label></h4></p>
                  					
                                </div>
                               
                            </div>                            
                        
								

								
									<div class='form-actions'   align='center'>
									<button type='button' class='btn btn-success Startus'> </button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	






	
</div>
