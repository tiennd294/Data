Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient

Namespace TestQuanbLyBanHang
	Public Partial Class Form7
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub
		Public Them As Boolean
		Public Sub loaddata2()
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM NhanVien", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				' Đưa dữ liệu lên DataGridView
				dataGridView1.DataSource = dt
				' Thay đổi độ rộng cột
				dataGridView1.AutoResizeColumns()
				' Xóa trống các đối tượng trong Panel
				Me.textBox1.ResetText()
				Me.textBox2.ResetText()
				Me.textBox3.ResetText()
				Me.textBox4.ResetText()
				Me.textBox5.ResetText()
				Me.comboBox1.ResetText()
				Me.maskedTextBox1.ResetText()
				' Không cho thao tác trên các nút Lưu / Hủy
				Me.btnLuu.Enabled = False
				Me.btnHuyBo.Enabled = False

				' Cho thao tác trên các nút Thêm / Sửa / Xóa /Thoát
				Me.btnThem.Enabled = True
				Me.btnSua.Enabled = True
				Me.btnXoa.Enabled = True
				Me.btnTroVe.Enabled = True

				' Không cho thao tác trên Panel

				Me.groupBox1.Enabled = False
			Catch
			End Try
		End Sub

		Private Sub Form7_Load(sender As Object, e As EventArgs)
			loaddata2()
		End Sub

		Private Sub btnReLoad_Click(sender As Object, e As EventArgs)
			loaddata2()
		End Sub

		Private Sub btnThem_Click(sender As Object, e As EventArgs)
			' Kich hoạt biến Them
			Them = True
			' Xóa trống các đối tượng trong Panel
			Me.textBox1.ResetText()
			Me.textBox2.ResetText()
			Me.textBox3.ResetText()
			Me.textBox4.ResetText()
			Me.textBox5.ResetText()
			Me.comboBox1.ResetText()
			Me.maskedTextBox1.ResetText()
			' Cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = True
			Me.btnHuyBo.Enabled = True
			Me.groupBox1.Enabled = True

			' Không cho thao tác trên các nút Thêm / Xóa / Thoát
			Me.btnThem.Enabled = False
			Me.btnSua.Enabled = False
			Me.btnXoa.Enabled = False
			Me.btnTroVe.Enabled = False
			' Đưa con trỏ đến TextField txtThanhPho
			Me.textBox1.Focus()
		End Sub

		Private Sub btnSua_Click(sender As Object, e As EventArgs)
			Try
				Them = False
				' Cho phép thao tác trên Panel this.panel.Enabled = true;
				' Thứ tự dòng hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Chuyển thông tin lên panel 
				Me.textBox1.Text = dataGridView1.Rows(r).Cells(0).Value.ToString()
				Me.textBox2.Text = dataGridView1.Rows(r).Cells(1).Value.ToString()
				Me.textBox3.Text = dataGridView1.Rows(r).Cells(2).Value.ToString()
				Me.textBox4.Text = dataGridView1.Rows(r).Cells(5).Value.ToString()
				Me.textBox5.Text = dataGridView1.Rows(r).Cells(6).Value.ToString()
				Me.comboBox1.Text = dataGridView1.Rows(r).Cells(3).Value.ToString()
				Me.maskedTextBox1.Text = dataGridView1.Rows(r).Cells(4).Value.ToString()
				' Cho thao tác trên các nút Lưu / Hủy / Panel
				Me.btnLuu.Enabled = True
				Me.btnHuyBo.Enabled = True
				Me.groupBox1.Enabled = True
				' Không cho thao tác trên các nút Thêm / Xóa / Thoát
				Me.btnThem.Enabled = False
				Me.btnSua.Enabled = False
				Me.btnXoa.Enabled = False
				Me.btnTroVe.Enabled = False
				' Đưa con trỏ đến TextField txtMaKH
				Me.textBox1.Focus()
			Catch
			End Try
		End Sub

		Private Sub btnLuu_Click(sender As Object, e As EventArgs)
			Dim cmd As New SqlCommand()
			Dim kn As New ketnoi()
			kn.ket_noi()
			cmd.Connection = kn.con
			If Them Then
				Try
					' Thực hiện lệnh
					Dim tg As String = maskedTextBox1.Text.ToString()
					'DateTime ctg = Convert.ToDateTime(tg);
					cmd.CommandType = CommandType.Text
					' Lệnh Insert InTo
					cmd.CommandText = System.[String].Concat("Insert Into NhanVien(MaNV, Ho, Ten, Nu, NgayNV, DiaChi, DienThoai) Values(" & "'" & Me.textBox1.Text.ToString() & "','" & Me.textBox2.Text.ToString() & "','" & Me.textBox3.Text.ToString() & "','" & Me.comboBox1.Text.ToString() & "','" & Convert.ToDateTime(tg) & "','" & Me.textBox4.Text.ToString() & "','" & Me.textBox5.Text.ToString() & "')")
					cmd.CommandType = CommandType.Text
					cmd.ExecuteNonQuery()
					' Load lại dữ liệu trên DataGridView
					loaddata2()
					' Thông báo
					MessageBox.Show("Đã thêm xong!")

				Catch
				End Try
			End If
			If Not Them Then
				Try
					' Thực hiện lệnh
					Dim tg As String = maskedTextBox1.Text.ToString()
					cmd.CommandType = CommandType.Text
					' Thứ tự dòng hiện hành
					Dim r As Integer = dataGridView1.CurrentCell.RowIndex
					' MaKH hiện hành 
					Dim str As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
					' Câu lệnh SQL
					cmd.CommandText = System.[String].Concat("Update NhanVien Set Ho='" & Me.textBox2.Text.ToString() & "',Ten='" & Me.textBox3.Text.ToString() & "', Nu='" & Me.comboBox1.Text.ToString() & "', NgayNV='" & Convert.ToDateTime(tg) & "', DiaChi= '" & Me.textBox4.Text.ToString() & "', DienThoai= '" & Me.textBox5.Text.ToString() & "'  Where MaNV='" & str & "'")
					' Cập nhật

					cmd.CommandType = CommandType.Text
					cmd.ExecuteNonQuery()
					' Load lại dữ liệu trên DataGridView
					loaddata2()
					' Thông báo
					MessageBox.Show("Đã sửa xong!")
				Catch
				End Try
			End If
			' Đóng kết nối
			kn.con.Close()
		End Sub

		Private Sub btnHuyBo_Click(sender As Object, e As EventArgs)
			Me.btnThem.Enabled = True
			Me.btnSua.Enabled = True
			Me.btnXoa.Enabled = True
			Me.btnTroVe.Enabled = True
			' Không cho thao tác trên các nút Lưu / Hủy / Panel
			Me.btnLuu.Enabled = False
			Me.btnHuyBo.Enabled = False
			Me.groupBox1.Enabled = False
		End Sub

		Private Sub btnXoa_Click(sender As Object, e As EventArgs)
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con
				cmd.CommandType = CommandType.Text
				' Lấy thứ tự record hiện hành
				Dim r As Integer = dataGridView1.CurrentCell.RowIndex
				' Lấy MaKH của record hiện hành 
				Dim str As String = dataGridView1.Rows(r).Cells(0).Value.ToString()
				' Viết câu lệnh SQL
				cmd.CommandText = System.[String].Concat("Delete From NhanVien Where MaNV='" & str & "'")
				cmd.CommandType = CommandType.Text
				' Thực hiện câu lệnh SQL
				cmd.ExecuteNonQuery()
				' Cập nhật lại DataGridView
				loaddata2()
				' Thông báo

				MessageBox.Show("Đã xóa xong!")
			Catch
			End Try
		End Sub

		Private Sub btnTroVe_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub
	End Class
End Namespace
