using System;
using System.Text;
using System.Reflection;
using System.Collections;

public class CreateObjectExample {

    public static StringBuilder CreateStringBuilder() {

        Type type = typeof(System.Text.StringBuilder);

        Type[] argTypes = new Type[] {typeof(System.String), typeof(System.Int32)};

        ConstructorInfo cInfo = type.GetConstructor(argTypes);

        object[] argVals = new object[] {"Some string", 30};

        StringBuilder sb = (StringBuilder)cInfo.Invoke(argVals);

        return sb;
    }

	public static void Main(string[] args) {

        StringBuilder sb = CreateStringBuilder();

        IPlugin plugin = PluginFactory.CreatePlugin(
            "CreateObjectExample",  
            "SimplePlugin",         
            "A Simple Plugin" 
        );
 
        plugin.Start();
        plugin.Stop();

        Console.ReadLine();
    }
}
