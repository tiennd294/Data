﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RichTextBoxExample
{
    public partial class frmMain : Form
    {
        int selectedID = 0;
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            BindingData();
        }

        private void BindingData()
        {
            gvRecords.DataSource = DBConnector.GetAllRecords();
        }

        private void gvRecords_SelectionChanged(object sender, EventArgs e)
        {
            if (gvRecords.SelectedRows.Count > 0)
            {
                Record selectedRec = gvRecords.SelectedRows[0].DataBoundItem as Record;
                selectedID = selectedRec.ID;
                rtxtValue.Rtf = selectedRec.Content;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Record rec = new Record { ID = selectedID, Content = rtxtValue.Rtf };
            DBConnector.Save(rec);
            BindingData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Record selectedRec = gvRecords.SelectedRows[0].DataBoundItem as Record;
            selectedID = selectedRec.ID;
            DBConnector.Delete(selectedRec);
            BindingData();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            selectedID = 0;
            gvRecords.ClearSelection();
            rtxtValue.Rtf = string.Empty;
        }
    }

    public class DBConnector
    {
        private static string ConnectionString = 
                ConfigurationManager.ConnectionStrings["RichTextBoxExample.Properties.Settings.RichTextBoxExampleConnectionString"].ToString();
        public static List<Record> GetAllRecords()
        {
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = ConnectionString;
                    con.Open();
                    SqlCommand selectCommand = new SqlCommand();
                    selectCommand.CommandText = "SELECT * FROM RECORDS";
                    selectCommand.Connection = con;

                    SqlDataReader reader = selectCommand.ExecuteReader();
                    List<Record> lstRecords = new List<Record>();
                    while (reader.Read())
                    {
                        lstRecords.Add(new Record
                        {
                            ID = Convert.ToInt32(reader[0])
                          ,
                            Content = reader[1].ToString()
                        });
                    }
                    return lstRecords;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static void Save(Record rec)
        {
            string strInsertCommand = "INSERT INTO RECORDS VALUES (@content)";
            string strUpdateCommand = "UPDATE RECORDS SET CONTENT = @content WHERE ID = {0}";
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = ConnectionString;
                    con.Open();
                    SqlCommand comm = new SqlCommand();
                    comm.Connection = con;
                    comm.CommandText = rec.ID == 0
                                     ? string.Format(strInsertCommand)
                                     : string.Format(strUpdateCommand, rec.ID);
                    comm.Parameters.Add(new SqlParameter("content", rec.Content));
                    comm.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public static void Delete(Record rec)
        {
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = ConnectionString;
                    con.Open();
                    SqlCommand comm = new SqlCommand();
                    comm.Connection = con;
                    comm.CommandText = string.Format("DELETE RECORDS WHERE ID = {0}", rec.ID);
                    comm.ExecuteNonQuery();
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }

    public class Record
    {
        private int _id;
        private string _content;


        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Content
        {
            get { return _content; }
            set { _content = value; }
        }

        public Record()
        { }
    }
}
