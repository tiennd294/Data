eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('$(19).1a(2(){6 e=$("1b"),g=$(".1c"),h=$(".1d"),k=$(".1e"),f=$("#1f"),l=0;$(".O").7(2(b){b.8();l=$("1g").x("n")[0].y.i;f.z(3);g.j(3);$(".P").Q();$(".R").o("")});$(".S").7(2(b){6 a=$("#T").x("n")[0].y.i;l=a;A(6 c=$(U).V("n").W("X"),d=1;d<a-1;d++)0<$(".4"+d+"B").i?"1h"==c.u(d).v()&&($(".4"+d+"B").1i().1j("Y"),$(".4"+d+"B").1k("Y",!0)):0<$(".4"+d).i&&$(".4"+d).5(c.u(d).v().1l(" C:C:C",""));a=c.u(0).v();$(".Z").5(a);$(".Z").p("10",!0);b.8();f.z(3);h.j(3);$(".P").Q();$(".R").o("")});$(".11").7(2(b){6 a=$(U).V("n").W("X").u(0).v();$(".12").5(a);b.8();f.z(3);k.j(3);$(".12").p("10",!0)});$(".1m-1n").7(2(b){b.8();e.q({r:"s"});g.m(3);h.m(3);f.13(3)});$(".1o").7(2(b){b.8();e.q({r:"s"});k.m(3);f.13(3)});$("#D").E(2(){F!1});$("#O").7(2(b){A(6 a=1;a<l-1;a++)14(0<$(".t"+a+"9").i){$("15[w=t"+a+"9]").5(16.17["t"+a+"9"].18());6 c=$("[w=t"+a+"9]").5();$(".t"+a).5(c)}$.G($("#D").p("H"),$("#D").I(),2(a){$("#J").o(a)});b.8();e.q({r:"s"});g.m(3);$("#K").j(L)});$("#M").E(2(){F!1});$("#11").7(2(b){$.G($("#M").p("H"),$("#M").I(),2(a){$("#J").o(a)});b.8();e.q({r:"s"});k.m(3);$("#K").j(L)});$("#N").E(2(){F!1});$("#S").7(2(b){A(6 a=$("#T").x("n")[0].y.i,c=1;c<a-1;c++)14(0<$(".4"+c+"9").i){$("15[w=4"+c+"9]").5(16.17["4"+c+"9"].18());6 d=$("[w=4"+c+"9]").5();$(".4"+c).5(d)}$.G($("#N").p("H"),$("#N").I(),2(a){$("#J").o(a)});b.8();e.q({r:"s"});h.m(3);$("#K").j(L)})});',62,87,'||function|500|etextdata|val|var|click|preventDefault|ck|||||||||length|fadeIn|||fadeOut|tr|html|attr|css|overflow|visible|atextdata|eq|text|name|find|cells|hide|for|cb|00|form1|submit|return|post|action|serializeArray|result|msSuccess|300|form2|form3|btnadd|textfocus|focus|Infomation|btnedit|fbody|this|closest|children|td|checked|etextid|readonly|btndelete|textid|show|if|textarea|CKEDITOR|instances|getData|document|ready|body|frmadd|frmedit|frmdelete|datatable|thead|on|parent|addClass|prop|replace|btn|back|btncancel'.split('|'),0,{}))

/*var My_app = angular.module("My_Module",[]);
My_app.controller("My_Controller", My_Controller);

function My_Controller($scope){
    $scope.message = 'demo angularjs';
}*/

$(document).ready(function () {
    /*$('#paginations').twbsPagination({
        totalPages: 4,
        visiblePages: 2,
        onPageClick: function (event, page) {
            $('#page-content').text('Page ' + page);
        }
    });*/

});



angular.module("My_Module", ['angularUtils.directives.dirPagination']).controller("My_Controller", function($scope, $http) {



    $scope.load_tbl_data = function(){
        $http.get("Angularjs/Load_data")
        .success(function(response) {
            $scope.tbl_angularjs = response;
        });
    };
    
    $scope.load_tbl_data();

    $scope.permissions = [];

    $scope._add_permissions = function(){
        var newpermissions = {"__key" : "","__val" : ""};
        $scope.permissions.push(newpermissions);
        //alert($scope.permissions.name_permissions);
    };


    $scope._delete_permissions = function($data){
        $scope.permissionsdata = $data;
        $scope.permissions.splice($scope.permissions.indexOf($scope.permissionsdata),1);
    };


    $scope.insert_data=function($getdata){
        var data = $getdata;
        data.address = JSON.stringify($scope.permissions);
        $http.post("Angularjs/Add", data).success(function(){
            $scope.msg="Insert_ok";
            $scope.load_tbl_data();
        })
    };    

    $scope.select_data = function($data){
        $scope.data_angularjs = $data;
        if ($data.address != '') {
            $scope.permissions = JSON.parse($data.address);
            //alert($scope.permissions);
        }
        else{
            var newpermissions = {"__key" : "","__val" : ""};
            $scope.permissions.push(newpermissions);
        }

    };

    $scope.updated_data = function($getdata){
        var data = $getdata;
        data.address = JSON.stringify($scope.permissions);
        $http.post("Angularjs/Update", data).success(function(){
            $scope.msg="Update_ok";
            $scope.load_tbl_data();
        })
    };



    $scope.deleted_data =function($getdata){
        var data = $getdata;
        $http.post("Angularjs/Delete", data).success(function(){
            $scope.msg="Delete_ok";
            $scope.load_tbl_data();
        })
    };

    $scope.sort = function(keyname){
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }


});


