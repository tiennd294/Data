namespace BT7
{
    partial class frmxy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtdisplay = new System.Windows.Forms.TextBox();
            this.txty = new System.Windows.Forms.TextBox();
            this.txtx = new System.Windows.Forms.TextBox();
            this.lblx = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnycy = new System.Windows.Forms.Button();
            this.btnx2 = new System.Windows.Forms.Button();
            this.btnxty = new System.Windows.Forms.Button();
            this.btnx3 = new System.Windows.Forms.Button();
            this.btnxny = new System.Windows.Forms.Button();
            this.btnx12 = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtdisplay
            // 
            this.txtdisplay.Location = new System.Drawing.Point(35, 31);
            this.txtdisplay.Name = "txtdisplay";
            this.txtdisplay.Size = new System.Drawing.Size(260, 20);
            this.txtdisplay.TabIndex = 0;
            // 
            // txty
            // 
            this.txty.Location = new System.Drawing.Point(116, 104);
            this.txty.Name = "txty";
            this.txty.Size = new System.Drawing.Size(179, 20);
            this.txty.TabIndex = 0;
            // 
            // txtx
            // 
            this.txtx.Location = new System.Drawing.Point(116, 78);
            this.txtx.Name = "txtx";
            this.txtx.Size = new System.Drawing.Size(179, 20);
            this.txtx.TabIndex = 0;
            // 
            // lblx
            // 
            this.lblx.AutoSize = true;
            this.lblx.Location = new System.Drawing.Point(67, 81);
            this.lblx.Name = "lblx";
            this.lblx.Size = new System.Drawing.Size(14, 13);
            this.lblx.TabIndex = 1;
            this.lblx.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Y";
            // 
            // btnycy
            // 
            this.btnycy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnycy.Location = new System.Drawing.Point(48, 148);
            this.btnycy.Name = "btnycy";
            this.btnycy.Size = new System.Drawing.Size(75, 23);
            this.btnycy.TabIndex = 2;
            this.btnycy.Text = "Y+Y";
            this.btnycy.UseVisualStyleBackColor = true;
            // 
            // btnx2
            // 
            this.btnx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnx2.Location = new System.Drawing.Point(48, 177);
            this.btnx2.Name = "btnx2";
            this.btnx2.Size = new System.Drawing.Size(75, 23);
            this.btnx2.TabIndex = 2;
            this.btnx2.Text = "X^2";
            this.btnx2.UseVisualStyleBackColor = true;
            // 
            // btnxty
            // 
            this.btnxty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxty.Location = new System.Drawing.Point(129, 148);
            this.btnxty.Name = "btnxty";
            this.btnxty.Size = new System.Drawing.Size(75, 23);
            this.btnxty.TabIndex = 2;
            this.btnxty.Text = "X-Y";
            this.btnxty.UseVisualStyleBackColor = true;
            // 
            // btnx3
            // 
            this.btnx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnx3.Location = new System.Drawing.Point(129, 177);
            this.btnx3.Name = "btnx3";
            this.btnx3.Size = new System.Drawing.Size(75, 23);
            this.btnx3.TabIndex = 2;
            this.btnx3.Text = "X^3";
            this.btnx3.UseVisualStyleBackColor = true;
            // 
            // btnxny
            // 
            this.btnxny.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxny.Location = new System.Drawing.Point(210, 148);
            this.btnxny.Name = "btnxny";
            this.btnxny.Size = new System.Drawing.Size(75, 23);
            this.btnxny.TabIndex = 2;
            this.btnxny.Text = "X*Y";
            this.btnxny.UseVisualStyleBackColor = true;
            // 
            // btnx12
            // 
            this.btnx12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnx12.Location = new System.Drawing.Point(210, 177);
            this.btnx12.Name = "btnx12";
            this.btnx12.Size = new System.Drawing.Size(75, 23);
            this.btnx12.TabIndex = 2;
            this.btnx12.Text = "X^1/2";
            this.btnx12.UseVisualStyleBackColor = true;
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(98, 216);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(131, 38);
            this.btnexit.TabIndex = 2;
            this.btnexit.Text = "&Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // frmxy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 283);
            this.Controls.Add(this.btnx12);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnx3);
            this.Controls.Add(this.btnx2);
            this.Controls.Add(this.btnxny);
            this.Controls.Add(this.btnxty);
            this.Controls.Add(this.btnycy);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblx);
            this.Controls.Add(this.txtx);
            this.Controls.Add(this.txty);
            this.Controls.Add(this.txtdisplay);
            this.Name = "frmxy";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtdisplay;
        private System.Windows.Forms.TextBox txty;
        private System.Windows.Forms.TextBox txtx;
        private System.Windows.Forms.Label lblx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnycy;
        private System.Windows.Forms.Button btnx2;
        private System.Windows.Forms.Button btnxty;
        private System.Windows.Forms.Button btnx3;
        private System.Windows.Forms.Button btnxny;
        private System.Windows.Forms.Button btnx12;
        private System.Windows.Forms.Button btnexit;
    }
}

