Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SqlClient


Namespace TestQuanbLyBanHang
	Public Partial Class Form13
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub button2_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		Private Sub button1_Click(sender As Object, e As EventArgs)
			Try
				Dim cmd As New SqlCommand()
				Dim kn As New ketnoi()
				kn.ket_noi()
				cmd.Connection = kn.con

				Dim da As New SqlDataAdapter("SELECT * FROM DangNhap ", kn.con)
				Dim dt As New DataTable()
				dt.Clear()
				da.Fill(dt)
				' Đưa dữ liệu lên textbox1
				'textBox1.Text = dt.Rows[0][0].ToString();

				If (Me.textBox1.Text = dt.Rows(0)(1).ToString()) Then
					If textBox2.Text.ToString() = textBox3.Text.ToString() Then
						Dim dt2 As New DataTable()
						cmd.CommandText = System.[String].Concat("UPDATE DangNhap SET Pass='" & textBox2.Text.ToString() & "'")
						cmd.CommandType = CommandType.Text
						cmd.ExecuteNonQuery()

						Me.Close()
						MessageBox.Show("Thay Doi Mat Khau Thanh Cong!", "Chuc Mung Ban..")
					Else
						MessageBox.Show("Mat Khau Moi Khong Trung Khop!", "Nhap Lai!")
					End If
				Else

					MessageBox.Show("Sai Mat Khau!", "Thông báo")
					Me.textBox1.Focus()
				End If
			Catch
			End Try
		End Sub
	End Class
End Namespace
