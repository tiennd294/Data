/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package vidukethua;

//lớp tính giai thừa
class GT{
    int n;
    int TinhGT(int n){
        int s=1;
        for(int i=1;i<=n;i++)
            s=s*i;
        return s;
    }
}

//lớp tính s kế thứ lớp GT
class TinhS extends GT{
    long S(int n){
        long t=0;
        for (int i=1;i<=n;i++)
            t=t+TinhGT(i);
        return t;
    }
}

public class Main {
    public static void main(String[] args) {
        int n;

        n=5;
        GT cha=new GT(); //khai bao doi tuong cha
        TinhS con=new TinhS();//Khai bao doi tuong con

        System.out.println(" n! = "+cha.TinhGT(n));
        System.out.println(" 1!+2!+...+ n! = "+con.S(n));
    }

}
