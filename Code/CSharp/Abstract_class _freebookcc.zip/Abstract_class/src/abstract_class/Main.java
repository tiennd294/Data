package abstract_class;
// Lớp trừu tượng
abstract class A{
    int x,y;
    String phepTinh;
    public A(int x,int y){
        this.x=x;
        this.y=y;

    }
    abstract float Tinh();
    void InKQ(){
        System.out.println(" ********* VI DU LOP TRUU TUONG ***********\n\n");
        System.out.println(" + Ket qua phep tinh "+phepTinh+" la: "+Tinh());
    }
}

// Lớp đẫn xuất
class B extends A{
    public B(int x,int y, String pt){
    super(x,y);
        phepTinh=pt;
    }
    float Tinh(){
        return (x+y);
    }
}

class C extends A{
    public C(int x,int y,String phepTinh){
    super(x,y);
        this.phepTinh=phepTinh;
    }
    float Tinh(){
        return (x-y);
    }
}
class D extends A{
    public D(int x,int y){
    super(x,y);
        phepTinh="*";
    }
    float Tinh(){
        return (x*y);
    }

}
class E extends A{
    public E(int x,int y){
        super(x,y);
        phepTinh="/";
    }
    float Tinh(){
        return ((float)x/y);
    }

}
public class Main {

    public static void main(String[] args) {
       A t,t1,t2,t3;
       t=new B(3,4," Cong ");  t.InKQ();
       t1=new C(3,4," Tru "); t1.InKQ();
       t2=new D(3,4); t2.InKQ();
       t3=new E(3,4); t3.InKQ();
    }

}
