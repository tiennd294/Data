

<?php
    $this->load->view('site/access/template/slideheader');
    //echo "<pre>";
    //print_r($tblproduct);echo "<pre>";
?>

<div class="container productsp">
<?php 
foreach ($tblcatagory as $row): 
	if($row->Parentid==0 &&  $row->Startus=='on' &&  $row->Classify==1){ 
?>
	<div class="featured">
			<div class="box_head">
				<h3><?php echo $row->Name; ?></h3>
				<div class="pagers center">
					<a href="#prev" class="prev unlinka featuredPrev<?php echo $row->Idc; ?>">Prev</a>
					<a href="#nxt" class="nxt unlinka featuredNxt<?php echo $row->Idc; ?>">Next</a>
				</div>
			</div><!--end box_head -->
		

			<div data-cycle-next="div.pagers a.featuredNxt<?php echo $row->Idc; ?>" data-cycle-prev="div.pagers a.featuredPrev<?php echo $row->Idc; ?>" data-cycle-slides="&gt; ul" data-cycle-timeout="0" data-cycle-fx="scrollHorz" class="cycle-slideshow" style="position: relative; overflow: hidden;">
			
				<?php 
				foreach ($tblcatagory as $row2): 
					if($row2->Parentid==$row->Idc &&  $row2->Startus=='on' &&  $row2->Classify==1){ 
						$testidc=0;
						foreach ($tblproduct as $rowp): 
						if((int)$rowp->Idc == (int)$row2->Idc){
							
							if ($testidc!=$row2->Idc) {
								$testidc=$row2->Idc;

							
				?>
					
				<ul class="product_show cycle-slide " style="position: absolute; top: 0px; left: 0px; z-index: 99; opacity: 1; display: block;">
					<?php 
					$i=0;
					foreach ($tblproduct as $rowp): 
						if ($i>3) {
							break;
						}
						
						if((int)$rowp->Idc == (int)$row2->Idc){
							$i++;
							
					?>
					
							<li class="column">
								<div class="img">
									<?php if($rowp->Promotion>0) echo "<div class='offer_icon'></div>"; ?>
									<div class="hover_over" style="opacity: 0;">
										<a href="<?php echo base_url().'defaults/ShowProductid/'.$rowp->Idp; ?>" class="link" style="left: 0px;">link</a>
										<a href="#" class="cart unlinka" onclick="Set_cart('<?php echo $rowp->Idp; ?>','<?php echo $rowp->Name; ?>','<?php echo $rowp->Code; ?>','<?php if($rowp->Promotion>0) echo $rowp->Promotion;else echo $rowp->Price; ?>','<?php echo base_url().$rowp->Images; ?>')" style="right: 0px;">cart</a>

									</div>
									<a href="#">
										<img alt="product" src="<?php echo base_url().$rowp->Images; ?>" style="overflow: hidden; width: 100%; height: 100%; left: 0px; top: 0px;">
									</a>
								</div>
								<h6><a href="<?php echo $rowp->Idp; ?>"><?php echo $rowp->Name; ?></a></h6>
								<h5>
								<?php if($rowp->Promotion>0) {
								?>
								<span class="sale_offer"><?php echo $rowp->Price; ?>.đ</span><br/>
								<?php echo $rowp->Promotion;?>.đ
								<?php } else echo "<br/>".$rowp->Price;?>
								</h5>
							</li>
					
					
					<?php 
						}
					endforeach;
					?>
				</ul>

				<?php
							}
							
						}
						endforeach;
					}
				endforeach;
				?>
				
			</div>
	</div>



<?php
	}
endforeach;
?>
</div>
<?php
    $this->load->view('site/defaults/cart');
?>