using System;
using System.Threading;

public class MessageInfo {

    private int iterations;
    private string message;

    public MessageInfo(int iterations, string message) {

        this.iterations = iterations;
        this.message = message;
    }

    public int Iterations { get { return iterations; } }
    public string Message { get { return message; } }
}

public class ThreadPoolExample {

    public static void DisplayMessage(object state) {

        MessageInfo config = state as MessageInfo;

        if (config == null) {

            for (int count = 0; count < 3; count++) {

                Console.WriteLine("A thread-pool example.");

                Thread.Sleep(1000);
            }

        } else {

            for (int count = 0; count < config.Iterations; count++) {

                Console.WriteLine(config.Message);

                Thread.Sleep(1000);
            }
        }
    }

    public static void Main() {

        WaitCallback workMethod = 
            new WaitCallback(ThreadPoolExample.DisplayMessage);

        ThreadPool.QueueUserWorkItem(workMethod);

        MessageInfo info = 
            new MessageInfo(5, "A thread-pool example with arguments.");

        ThreadPool.QueueUserWorkItem(workMethod, info);

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}