$(document).ready(function () {
pagination();
function pagination(){
		var req_num_row=10;
		var $tr=jQuery('#fbody tr.items_');
		var total_num_row=$tr.length;
		var num_pages=0;
		var curentpages=1;
		var maxpages=5;
        var getpage=1;//_______________________________________________________________
            
            //$('.'+myclass).removeClass( myclass ).addClass( newclass );
        
        function update_num_page(curentpage, maxpage, num_pages){
                    if(curentpage>3)
            			if(curentpage+2<=num_pages){ //6+2=8!=16     12+2=14<=16
							for(var i=curentpage+2; i>=curentpage-2; i--){
                                var newclass=i;
                                var myclass=i-1;
									if(i==curentpage){
  						                $('.'+myclass).removeClass( myclass ).addClass( newclass ).addClass( 'btn-info' );
                                        jQuery('#pagination').append("<label for='male'>" + myclass + "</label>");
                                    }
                                    else 
                                    {
                                        jQuery('#pagination').append("<label for='male'>" + myclass + "</label>");
                                        //$('.'+myclass).removeClass( myclass ).addClass( newclass );
                                    }
                            }
						}
						else if(curentpage==num_pages){
								for(var i=curentpage-4; i<=num_pages; i++){
										if(i==curentpage)
                						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                                        else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
                								}
							} 
							else if(curentpage+2>num_pages)
								for(var i=curentpage-3; i<=num_pages; i++){
										if(i==curentpage)
                						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                                        else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
								}
        }
		
		function load_num_page(curentpage, maxpage, num_pages){
		//$( ".btnpg" ).hide();
			if(curentpage<=3) //1 2 3
				{
					if(num_pages <= maxpage)//4<5   5=5
					maxpage=num_pages;
					for(var i=1; i<=maxpage; i++){// 1234  12345
                        if(i==curentpage)
						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                        else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
					}
				}
				else if(num_pages<=maxpage)// 4 5     4<5   5=5
					{
						for(var i=1; i<=num_pages; i++){//4 1234    5 12345
							if(i==curentpage)
    						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                            else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
						}
						
					}
					else
						if(curentpage+2<=num_pages){ //6+2=8!=16     12+2=14<=16
							for(var i=curentpage-2; i<=curentpage+2; i++){
									if(i==curentpage)
            						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                                    else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
							}
						}
						else if(curentpage==num_pages){
								for(var i=curentpage-4; i<=num_pages; i++){
										if(i==curentpage)
                						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                                        else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
                								}
							} 
							else if(curentpage+2>num_pages)
								for(var i=curentpage-3; i<=num_pages; i++){
										if(i==curentpage)
                						  jQuery('#pagination').append("<label for='male' class='btnpg btn btn-info btnpg2 "+i+"'>" + i + "</label>");
                                        else jQuery('#pagination').append("<label for='male' class='btnpg btn btnpg2 "+i+"'>" + i + "</label>");
								}
			//jQuery('#pagination').append("<label for='male' class='btnpg btnpgNext btn'> Next</label>");
			//jQuery('#pagination').append("<label for='male' class='btnpg btnpgLast btn'> Last</label>");
            jQuery('#pagination').append("<label for='male' class='btnpg btnpgNext btn'> Next</label>");
			jQuery('#pagination').append("<label for='male' class='btnpg btnpgLast btn'> Last</label>");
		}
	
	
				
		
		if(total_num_row % req_num_row ==0){
			num_pages=total_num_row / req_num_row;
            maxpages=num_pages;//________________________________________________________________
		}
		if(total_num_row % req_num_row >=1){
			num_pages=total_num_row / req_num_row;
			num_pages++;
			num_pages=Math.floor(num_pages++);
            maxpages=num_pages;//_______________________________________________________________________
		}
		//_______________________________________________________________________
		
		//jQuery('#pagination').append("<label for='male' class='btnFirst btn'> First</label>");
		//jQuery('#pagination').append("<label for='male' class='btnPrevious btn'> Previous</label>");
        jQuery('#pagination').append("<label for='male' class='btnFirst btn'> First</label>");
		jQuery('#pagination').append("<label for='male' class='btnPrevious btn'> Previous</label>");
		load_num_page(curentpages, maxpages, num_pages);
		
		
		$tr.each(function(a){
			jQuery(this).hide();
			if(a+1 <= req_num_row){
			
				$tr.eq(a).show();
			}
		
		});
		
		
		
		
		jQuery('#pagination .btnpg2').click(function(e){
            
			e.preventDefault();
			$tr.hide();
            
			var page=jQuery(this).text();
            //set page_______________________________________________________________________
            //if(curentpages!=page)
            //getpage=curentpages;
            
			curentpages=page;
			var temp=page-1;
			var start=temp*req_num_row;
			//alert(start);
			//jQuery('#pagination').append("<label for='male'> "+ curentpages + "</label>");
			for(var i=0; i< req_num_row; i++){
				
				$tr.eq(start+i).show();
			
			}
            
            $('.btn-info').removeClass('btn-info');
            jQuery(this).addClass( "btn-info" );
            /*if(curentpages<=3 || parseInt(curentpages) +2>=num_pages){//_____________________________________________________________________
            jQuery(this).addClass( "btn-info" );//set btn true
            }
			//update_num_page(curentpages, maxpage, num_pages);
            if(curentpages>3 && parseInt(curentpages) +2<num_pages)//_______________________________________________________________________
            {
                 //curentpages=parseInt(curentpages)+2;
                 //$('.4').text(curentpages);
                 if(getpage<curentpages){
            			if(parseInt(curentpages) +2<=num_pages){ //6+2=8!=16     12+2=14<=16
                        //$('.4').text(curentpages.parseInt()+2332);
							for(var i=parseInt(curentpages)+2; i>=parseInt(curentpages)-2; i--){
							 
                                var newclass=i;
                                var myclass=i-1;
                                if(getpage<=3)
                                {
                                    if(parseInt(curentpages)-3==1)
                                    myclass=i-1;
                                    if(parseInt(curentpages)-3==2)
                                    myclass=i-2;
                                }else{
                                    
                                    myclass=i-(parseInt(curentpages)-parseInt(getpage));
                                    //jQuery('#pagination').append("<label for='male' style=' color: red;'>" + getpage + "</label>");
                                }
                                
									if(i==curentpages){
									   
  						                $('.'+myclass).removeClass('btn-info' ).removeClass( myclass.toString() ).addClass( newclass.toString() ).addClass( 'btn-info' ).text( newclass.toString());
                                        //jQuery('#pagination').append("<label for='male'>" + newclass + "</label>");
                                    }
                                    else 
                                    {
                                        //jQuery('#pagination').append("<label for='male'>" + newclass + "</label>");
                                        $('.'+myclass).removeClass( myclass.toString() ).addClass(newclass.toString()).text( newclass.toString());
                                        //$('.'+myclass).text( newclass.toString());
                                    }
                            }
						}
                    }else if(getpage>curentpages)
                    {
                     if(parseInt(curentpages) -2 >= 1 ){ //6+2=8!=16     12+2=14<=16
                            //$('.4').text(curentpages.parseInt()+2332);
                            //jQuery('#pagination').append("<label for='male' style=' color: red;'>" + getpage + "</label>");
                            for(var j=parseInt(curentpages)-2; j<=parseInt(curentpages)+2; j++){
                                var newclassp=j;//2  ->6  23456  edit name class
                                var myclassp=parseInt(j)+1;//3 
                                if(getpage>=num_pages-2)
                                {
                                    if(parseInt(curentpages)+1==parseInt(getpage))
                                    myclassp=j+1;
                                    if(parseInt(curentpages)+2==parseInt(getpage))
                                    myclassp=j+2;
                                }else{
                                    
                                    myclassp=j+(parseInt(getpage)-parseInt(curentpages));
                                    
                                }jQuery('#pagination').append("<label for='male' style=' color: red;'>" + myclassp + "</label>");
                                if(j==curentpages){
									   
  						                $('.'+myclassp).removeClass('btn-info' ).removeClass( myclassp.toString() ).addClass( newclassp.toString() ).addClass( 'btn-info' ).text( newclassp.toString());
                                        //jQuery('#pagination').append("<label for='male' style=' color: red;'>" + myclassp + "</label>");
                                    }
                                    else 
                                    {
                                        //jQuery('#pagination').append("<label for='male'>" + newclassp + "</label>");
                                        $('.'+myclassp).removeClass( myclassp.toString() ).addClass(newclassp.toString()).text( newclassp.toString());
                                        //$('.'+myclass).text( newclass.toString());
                                    }
                                
                                
                            }
    							
						}       
                    }
                        
            }*/
		});
		
		
		
		
		jQuery('.btnPrevious').click(function(e){
			e.preventDefault();
			$tr.hide();
			var page=curentpages;
            getpage=page;
			var temp=page-1;
			curentpages=temp;
			var start=(temp-1)*req_num_row;
			if(temp<=0){
			temp=1;
			start=(temp-1)*req_num_row;
			curentpages=temp;
			}
			//alert(start);
			//jQuery('#pagination').append("<label for='male'> "+ temp + "</label>");
			for(var i=0; i< req_num_row; i++){
				
				$tr.eq(start+i).show();
			
			}
            $('.btn-info').removeClass('btn-info');
            $('.'+temp).addClass('btn-info');
			//load_num_page(page, maxpages, num_pages);
		});
		
		jQuery('.btnpgNext').click(function(e){
			e.preventDefault();
			$tr.hide();
			var page=curentpages;
            getpage=page;
			var temp2=page-1;
			var temp=temp2+2;
			curentpages=temp;
			var start=(temp-1)*req_num_row;
			if(temp>num_pages){
				temp=num_pages;
				curentpages=temp;
				start=(temp-1)*req_num_row;
			}
			//alert(start);
			//jQuery('#pagination').append("<label for='male' class='btn'> "+ temp + "</label>");
			for(var i=0; i< req_num_row; i++){
				
				$tr.eq(start+i).show();
			
			}
            $('.btn-info').removeClass('btn-info');
            $('.'+temp).addClass('btn-info');
			//load_num_page(page, maxpages, num_pages);
		});
		
		
		
		
		
		
		
		
		
		
		jQuery('.btnFirst').click(function(e){
			e.preventDefault();
			$tr.hide();
			curentpages=1;
            //getpage=curentpage;
			var temp=curentpages;
			var start=temp*req_num_row;
			//alert(start);
			//jQuery('#pagination').append("<label for='male' class='btn'> "+ temp + "</label>");
			for(var i=0; i< req_num_row; i++){
				
				$tr.eq(i).show();
			
			}
            $('.btn-info').removeClass('btn-info');
            $('.'+temp).addClass('btn-info');
			//load_num_page(page, maxpages, num_pages);
		});
		
		
		
		jQuery('.btnpgLast').click(function(e){
			e.preventDefault();
			$tr.hide();
			var page=num_pages;
            getpage=page;
			curentpages=page;
			var temp=page-1;
			var start=temp*req_num_row;
			//alert(start);
			//jQuery('#pagination').append("<label for='male'> "+ curentpages + "</label>");
			for(var i=0; i< req_num_row; i++){
				
				$tr.eq(start+i).show();
			
			}
            $('.btn-info').removeClass('btn-info');
            $('.'+curentpages).addClass('btn-info');
			//load_num_page(page, maxpages, num_pages);
		});
		
		
		
		
	}
	
});