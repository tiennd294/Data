<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES.,JSC. All rights reserved
 * @Createdate 1-28-2010 14:21
 */

if (! defined('NV_WYSIWYG') or ! defined('NV_MAINFILE'))
	die('Stop!!!');

?>