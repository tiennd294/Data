using System.Security;
using System.Security.Permissions;

[PublisherIdentityPermission(SecurityAction.InheritanceDemand, 
    CertFile = @"I:\CSharp\Chuong13\pubcert.cer")]
public class InheritanceDemandExample {

    public static void Main() {
    }
    
    [PermissionSet(SecurityAction.InheritanceDemand, Name="FullTrust")]
    public void SomeProtectedMethod () {
    }
}