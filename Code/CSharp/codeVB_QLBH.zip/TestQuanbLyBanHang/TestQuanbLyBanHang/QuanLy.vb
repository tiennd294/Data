Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.SqlClient
Imports System.Data

Namespace TestQuanbLyBanHang
	Class QuanLy
		Public Sub XuLy(chon As Integer)
			Dim cmd As New SqlCommand()
			Dim kn As New ketnoi()
			kn.ket_noi()
			cmd.Connection = kn.con

			Dim da As New SqlDataAdapter("SELECT * FROM DangNhap ", kn.con)
			Dim dt As New DataTable()
			dt.Clear()
			da.Fill(dt)

			If dt.Rows(0)(2).ToString() = "dung" Then
				Select Case chon
					Case 1
						If True Then
							Dim frm As New Form4()
							frm.Text = "Quan Ly Danh Muc Thanh Pho"
							frm.ShowDialog()
							Exit Select
						End If
					Case 2
						If True Then
							Dim frm As New Form5()
							frm.Text = "Quan Ly Danh Muc Khach Hang"
							frm.ShowDialog()
							Exit Select
						End If
					Case 3
						If True Then
							Dim frm As New Form6()
							frm.Text = "Quan Ly Danh Muc Hoa Don"
							frm.ShowDialog()
							Exit Select
						End If
					Case 4
						If True Then
							Dim frm As New Form7()
							frm.Text = "Quan Ly Danh Muc Nhan Vien"
							frm.ShowDialog()
							Exit Select
						End If
					Case 5
						If True Then
							Dim frm As New Form8()
							frm.Text = "Quan Ly Danh Muc San Pham"
							frm.ShowDialog()
							Exit Select
						End If
					Case 6
						If True Then
							Dim frm As New Form9()
							frm.Text = "Quan Ly Danh Muc Chi Tiet Hoa Don"
							frm.ShowDialog()
							Exit Select
						End If
					Case 7
						If True Then
							Dim frm As New Form13()
							frm.Text = "Doi Mat Khau"
							frm.ShowDialog()
							Exit Select
						End If
					Case Else
						Exit Select
				End Select
			Else
				Dim frm As New Form2()
				frm.Text = "Dang Nhap"
				frm.ShowDialog()
			End If
		End Sub
		Public Sub Huy()
			Dim cmd As New SqlCommand()
			Dim kn As New ketnoi()
			kn.ket_noi()
			cmd.Connection = kn.con
			cmd.CommandText = System.[String].Concat("UPDATE DangNhap SET TG='sai'")
			cmd.CommandType = CommandType.Text
			cmd.ExecuteNonQuery()
		End Sub
	End Class
End Namespace
