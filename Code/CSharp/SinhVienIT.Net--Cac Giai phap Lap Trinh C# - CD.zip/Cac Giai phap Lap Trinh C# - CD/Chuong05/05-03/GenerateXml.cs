using System;
using System.Xml;

public class GenerateXml
{
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	private static void Main()
	{
		XmlDocument doc = new XmlDocument();
		XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
		doc.AppendChild(docNode);
		XmlNode products = doc.CreateElement("products");
		doc.AppendChild(products);

		XmlNode product = XmlHelper.AddElement("product", null, products);
		XmlHelper.AddAttribute("id", "1001", product);
		XmlHelper.AddElement("productName", "Gourmet Coffee", product);
		XmlHelper.AddElement("productPrice", "0.99", product);
		
		product = XmlHelper.AddElement("product", null, products);
		XmlHelper.AddAttribute("id", "1002", product);
		XmlHelper.AddElement("productName", "Blue China Tea Pot", product);
		XmlHelper.AddElement("productPrice", "102.99", product);
		
		doc.Save(Console.Out);
		Console.ReadLine();
	}
}
public class XmlHelper
{
	public static XmlNode AddElement(string tagName, string textContent, XmlNode parent)
	{
		XmlNode node = parent.OwnerDocument.CreateElement(tagName);
		parent.AppendChild(node);

		if (textContent != null)
		{
			XmlNode content;
			content = parent.OwnerDocument.CreateTextNode(textContent);
			node.AppendChild(content);
		}

		return node;
	}

	public static XmlNode AddAttribute(string attributeName, string textContent, XmlNode parent)
	{
		XmlAttribute attribute;
		attribute = parent.OwnerDocument.CreateAttribute(attributeName);
		attribute.Value = textContent;
		parent.Attributes.Append(attribute);

		return attribute;
	}
}