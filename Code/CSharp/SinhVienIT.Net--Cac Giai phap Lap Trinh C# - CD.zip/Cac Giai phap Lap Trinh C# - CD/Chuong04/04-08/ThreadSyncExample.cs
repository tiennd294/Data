using System;
using System.Threading;

public class ThreadSyncExample {

    private static object consoleGate = new Object();

    private static void DisplayMessage() {

        Console.WriteLine("{0} : Thread started, acquiring lock...",
            DateTime.Now.ToString("HH:mm:ss.ffff"));

        try {

            Monitor.Enter(consoleGate);

            Console.WriteLine("{0} : {1}",
                DateTime.Now.ToString("HH:mm:ss.ffff"),
                "Acquired consoleGate lock, waiting...");

            Monitor.Wait(consoleGate);

            Console.WriteLine("{0} : Thread pulsed, terminating.",
                DateTime.Now.ToString("HH:mm:ss.ffff"));

        } finally {

            Monitor.Exit(consoleGate);
        }
    }

    public static void Main() {

        lock (consoleGate) {

            for (int count = 0; count < 3; count++) {

                (new Thread(new ThreadStart(DisplayMessage))).Start();
            }
        }

        Thread.Sleep(1000);

        Console.WriteLine("{0} : {1}", 
            DateTime.Now.ToString("HH:mm:ss.ffff"),
            "Press Enter to pulse one waiting thread.");

        Console.ReadLine();

        lock (consoleGate) {
            
            Monitor.Pulse(consoleGate);
        }

        Console.WriteLine("{0} : {1}",  
            DateTime.Now.ToString("HH:mm:ss.ffff"),
            "Press Enter to pulse all waiting threads.");

        Console.ReadLine();

        lock (consoleGate) {
            
            Monitor.PulseAll(consoleGate);
        }

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}