using System;
using System.Data.SqlClient;

public class PoolingExample {
    
    public static void Main() {

        using (SqlConnection con = new SqlConnection()) {

            con.ConnectionString = 
                "Data Source = localhost;" + 
                "Database = Northwind;" + 
                "Integrated Security = SSPI;" +
                "Min Pool Size = 5;" +
                "Max Pool Size = 15;" +
                "Connection Reset = True;" +
                "Connection Lifetime = 600";

            con.Open();

        }

        using (SqlConnection con = new SqlConnection()) {

            con.ConnectionString = 
                "Data Source = localhost;" +
                "Database = Northwind;" + 
                "Integrated Security = SSPI;" +
                "Pooling = False";

            con.Open();

        }

        Console.ReadLine();
    }
}
