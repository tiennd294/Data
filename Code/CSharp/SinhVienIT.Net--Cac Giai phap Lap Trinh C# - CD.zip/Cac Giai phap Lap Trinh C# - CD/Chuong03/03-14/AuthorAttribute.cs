using System;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Assembly,
     AllowMultiple = true, Inherited = false)]
public class AuthorAttribute : System.Attribute {
	
    private string company;
    private string name; 

    public AuthorAttribute(string name) {
        this.name = name;
        company = "";
    }

    public string Company {
        get { return company; }
        set { company = value; }
    }

    public string Name{
        get { return name;}
    }
}