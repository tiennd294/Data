//////////////
// CREDITS: //
//////////////

// @elrumordelaluz - Provided scaling fix/improvement
// @faddee - Provided fix for Edge support