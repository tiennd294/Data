using System;
using System.Drawing;
using System.Windows.Forms;

public class DragForm : System.Windows.Forms.Form
{
	internal System.Windows.Forms.Button cmdClose;
	internal System.Windows.Forms.Label lblDrag;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DragForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.cmdClose = new System.Windows.Forms.Button();
		this.lblDrag = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// cmdClose
		// 
		this.cmdClose.Location = new System.Drawing.Point(102, 215);
		this.cmdClose.Name = "cmdClose";
		this.cmdClose.Size = new System.Drawing.Size(76, 20);
		this.cmdClose.TabIndex = 5;
		this.cmdClose.Text = "Close";
		this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
		// 
		// lblDrag
		// 
		this.lblDrag.BackColor = System.Drawing.Color.Navy;
		this.lblDrag.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.lblDrag.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.lblDrag.ForeColor = System.Drawing.Color.White;
		this.lblDrag.Location = new System.Drawing.Point(12, 8);
		this.lblDrag.Name = "lblDrag";
		this.lblDrag.Size = new System.Drawing.Size(268, 36);
		this.lblDrag.TabIndex = 4;
		this.lblDrag.Text = "Click vào đây để di chuyển form!";
		this.lblDrag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.lblDrag.MouseUp += new System.Windows.Forms.MouseEventHandler(this.lblDrag_MouseUp);
		this.lblDrag.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lblDrag_MouseMove);
		this.lblDrag.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblDrag_MouseDown);
		// 
		// DragForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.ControlBox = false;
		this.Controls.Add(this.cmdClose);
		this.Controls.Add(this.lblDrag);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		this.Name = "DragForm";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new DragForm());
	}

	private bool dragging;
	
	private Point pointClicked;
	
	private void lblDrag_MouseDown(object sender,
		System.Windows.Forms.MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			dragging = true;
			pointClicked = new Point(e.X, e.Y);
		}
		else
		{
			dragging = false;
		}
	}

	private void lblDrag_MouseMove(object sender,
		System.Windows.Forms.MouseEventArgs e)
	{
		if (dragging)
		{
			Point pointMoveTo;
			
			pointMoveTo = this.PointToScreen(new Point(e.X, e.Y));
			
			pointMoveTo.Offset(-pointClicked.X, -pointClicked.Y);
			
			this.Location = pointMoveTo;
		}   
	}
	
	private void lblDrag_MouseUp(object sender,
		System.Windows.Forms.MouseEventArgs e) 
	{
		dragging = false;
	}

	private void cmdClose_Click(object sender, System.EventArgs e)
	{
		this.Close();
	}
}