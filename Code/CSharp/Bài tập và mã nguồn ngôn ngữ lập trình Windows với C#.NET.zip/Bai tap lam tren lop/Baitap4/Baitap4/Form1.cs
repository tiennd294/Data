using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Baitap4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        decimal mdectongtien;
        private void button1_Click(object sender, EventArgs e)
        {
            decimal dectong, decsoluong, decdongia;
            decsoluong = Convert.ToDecimal(txtquantity.Text);
            decdongia = Convert.ToDecimal(txtprice.Text);
            dectong = decsoluong * decdongia+mdectongtien;
            txtdollar.Text = "$" + dectong.ToString();
            mdectongtien +=dectong;
            groupBox1.Enabled = false;
            txtdescription.Text = null;
            txtquantity.Text = null;
            txtweight.Text = null;
            txtprice.Text = null;
            btnupdate.Enabled = true;
        }
    }
}