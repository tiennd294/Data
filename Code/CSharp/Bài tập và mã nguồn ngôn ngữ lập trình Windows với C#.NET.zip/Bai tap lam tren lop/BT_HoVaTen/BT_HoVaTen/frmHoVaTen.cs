using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT_HoVaTen
{
    public partial class frmHoVaTen : Form
    {
        public frmHoVaTen()
        {
            InitializeComponent();
        }
        private void txtholot_TextChanged(object sender, EventArgs e)
        {
            lblholot.Text = txtholot.Text;
        }

        private void txtten_TextChanged(object sender, EventArgs e)
        {
            lblten.Text = txtten.Text;
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnholot_Click(object sender, EventArgs e)
        {
            lblhoten.Text = txtholot.Text;
        }

        private void btnten_Click(object sender, EventArgs e)
        {
            lblhoten.Text = txtten.Text;
        }

        private void btnhoten_Click(object sender, EventArgs e)
        {
            lblhoten.Text = txtholot.Text + " " + txtten.Text;
        }
    }
}