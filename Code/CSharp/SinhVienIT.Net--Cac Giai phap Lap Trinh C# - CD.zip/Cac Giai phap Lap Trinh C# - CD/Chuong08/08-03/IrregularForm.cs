using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

public class IrregularForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button cmdClose;
	private System.Windows.Forms.Label label1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public IrregularForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.cmdClose = new System.Windows.Forms.Button();
		this.label1 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// cmdClose
		// 
		this.cmdClose.Location = new System.Drawing.Point(100, 204);
		this.cmdClose.Name = "cmdClose";
		this.cmdClose.Size = new System.Drawing.Size(100, 32);
		this.cmdClose.TabIndex = 0;
		this.cmdClose.Text = "Close";
		this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
		// 
		// label1
		// 
		this.label1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.label1.Location = new System.Drawing.Point(16, 36);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(232, 136);
		this.label1.TabIndex = 1;
		this.label1.Text = "An Irregular Form";
		this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		// 
		// IrregularForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.label1,
																		this.cmdClose});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "IrregularForm";
		this.Text = "Irregular Form";
		this.Load += new System.EventHandler(this.IrregularForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new IrregularForm());
	}

	private void IrregularForm_Load(object sender, System.EventArgs e)
	{
		GraphicsPath path = new GraphicsPath();
		Point[] pointsA = new Point[] {new Point(0, 0),
			new Point(40, 60), new Point(this.Width - 100, 10)};
		path.AddCurve(pointsA);
		
		Point[] pointsB = new Point[]
            {new Point(this.Width - 40, this.Height - 60), 
			new Point(this.Width, this.Height),
			new Point(10, this.Height)};
		path.AddCurve(pointsB);
		
		path.CloseAllFigures();
		this.Region = new Region(path);
	}

	private void cmdClose_Click(object sender, System.EventArgs e)
	{
		this.Close();
	}
}