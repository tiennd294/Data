using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

/// <summary>
/// Summary description for DynamicControls.
/// </summary>
public class DynamicControls : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.Label Label1;
	protected System.Web.UI.WebControls.Label lblMessage;
	protected System.Web.UI.WebControls.Panel pnl;

	private void Page_Load(object sender, System.EventArgs e)
	{
		Button dynamicButton = new Button();
		dynamicButton.Text = "Dynamic Button A";
		
		dynamicButton.Click += new EventHandler(cmdDynamicA_Click);

		pnl.Controls.Add(dynamicButton);
        
		pnl.Controls.Add(new LiteralControl("<br>"));
		
		dynamicButton = new Button();
		dynamicButton.Text = "Dynamic Button B";
		dynamicButton.Click += new EventHandler(cmdDynamicB_Click);
		pnl.Controls.Add(dynamicButton);
		
		pnl.Controls.Add(new LiteralControl("<br><br>"));
		
		TextBox dynamicText = new TextBox();
		pnl.Controls.Add(dynamicText);
		
		dynamicText.ID = "DynamicText";
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

		

	private void cmdDynamicA_Click(object sender, System.EventArgs e)
	{
		lblMessage.Text = "Clicked A";
		GetText();
	}

	private void cmdDynamicB_Click(object sender, System.EventArgs e)
	{
		lblMessage.Text = "Clicked B";
		GetText();
	}

	private void GetText()
	{
		lblMessage.Text += "<br><br>";
		
		foreach (Control ctrl in pnl.Controls)
		{
			if (ctrl.ID == "DynamicText")
			{
				lblMessage.Text += "TextBox contains: " +
					((TextBox)ctrl).Text;
			}
		}
	}

}