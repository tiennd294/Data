using System;
using System.Collections;

public class SortExample
{
	public static void Main() {

        int[] array = {4, 2, 9, 3};

        Array.Sort(array);

        foreach (int i in array) { Console.WriteLine(i);}

        ArrayList list = new ArrayList(4);
        list.Add("Phuong");
        list.Add("Phong");
        list.Add("Nam");
        list.Add("Tam");

        list.Sort();

        foreach (string s in list) { Console.WriteLine(s);}

		Console.ReadLine();
    }
}
