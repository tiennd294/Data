using System;
using System.Security.Cryptography;

public class DerivedKeyExample {

    public static void Main(string[] args) {
        
        byte[] salt = new byte[8];
        RandomNumberGenerator.Create().GetBytes(salt);

        PasswordDeriveBytes pdb = 
            new PasswordDeriveBytes(args[1], salt);

        pdb.HashName = args[0];

        pdb.IterationCount = 200;
        
        byte[] key = pdb.GetBytes(8);
        
        Console.WriteLine("Key  = {0}", BitConverter.ToString(key));
        Console.WriteLine("Salt = {0}", BitConverter.ToString(salt));

        Console.ReadLine();
    }
}