using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT_Hoten
{
    public partial class BT_Hoten : Form
    {
        public BT_Hoten()
        {
            InitializeComponent();
        }

        private void btnholot_Click(object sender, EventArgs e)
        {
            lblholot.Text=textBox1.Text;
        }

       