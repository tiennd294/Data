<?php

$this->load->view('admin/accessdata/template/header');
$this->load->view($urldata);



$this->load->view('admin/accessdata/template/footer');
?>