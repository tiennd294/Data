<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Footer extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Footer_Model');
    }

    public function Index()
    {
        $input = array();
        $tblfooter=$this->Footer_Model->get_list($input);
        $tblmenu=$this->Footer_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Footer/footer',
            'tblfooter' => $tblfooter,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);
    }

    
    public function Add()
    {
        $data = array(
            'Idft' => $this->input->post('atextdata1'),
            'Content' => $this->input->post('atextdata2'),
            'Startus' => $this->input->post('atextdata3')
        );
       $this->Footer_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Content' => $this->input->post('etextdata1'),
            'Startus' => $this->input->post('etextdata2')
        );
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Footer_Model->update($Id,$data);
        
        }
        
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Footer_Model->delete($Id);
       
        }
    }
}