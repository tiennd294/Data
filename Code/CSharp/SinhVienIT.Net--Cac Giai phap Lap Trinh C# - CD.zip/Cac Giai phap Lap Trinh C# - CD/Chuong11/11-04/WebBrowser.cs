using System;
using System.Drawing;
using System.Windows.Forms;

public class WebBrowser : System.Windows.Forms.Form
{
	private AxSHDocVw.AxWebBrowser explorer;
	private System.Windows.Forms.Button cmdBack;
	private System.Windows.Forms.Button cmdHome;
	private System.Windows.Forms.Button cmdForward;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public WebBrowser()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(WebBrowser));
		this.explorer = new AxSHDocVw.AxWebBrowser();
		this.cmdBack = new System.Windows.Forms.Button();
		this.cmdHome = new System.Windows.Forms.Button();
		this.cmdForward = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.explorer)).BeginInit();
		this.SuspendLayout();
		// 
		// explorer
		// 
		this.explorer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.explorer.Enabled = true;
		this.explorer.Location = new System.Drawing.Point(8, 8);
		this.explorer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("explorer.OcxState")));
		this.explorer.Size = new System.Drawing.Size(348, 208);
		this.explorer.TabIndex = 0;
		// 
		// cmdBack
		// 
		this.cmdBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.cmdBack.Location = new System.Drawing.Point(8, 228);
		this.cmdBack.Name = "cmdBack";
		this.cmdBack.Size = new System.Drawing.Size(104, 28);
		this.cmdBack.TabIndex = 1;
		this.cmdBack.Text = "<<";
		this.cmdBack.Click += new System.EventHandler(this.cmdBack_Click);
		// 
		// cmdHome
		// 
		this.cmdHome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.cmdHome.Location = new System.Drawing.Point(132, 228);
		this.cmdHome.Name = "cmdHome";
		this.cmdHome.Size = new System.Drawing.Size(104, 28);
		this.cmdHome.TabIndex = 2;
		this.cmdHome.Text = "Home";
		this.cmdHome.Click += new System.EventHandler(this.cmdHome_Click);
		// 
		// cmdForward
		// 
		this.cmdForward.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.cmdForward.Location = new System.Drawing.Point(252, 228);
		this.cmdForward.Name = "cmdForward";
		this.cmdForward.Size = new System.Drawing.Size(104, 28);
		this.cmdForward.TabIndex = 3;
		this.cmdForward.Text = ">>";
		this.cmdForward.Click += new System.EventHandler(this.cmdForward_Click);
		// 
		// WebBrowser
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(364, 266);
		this.Controls.Add(this.cmdForward);
		this.Controls.Add(this.cmdHome);
		this.Controls.Add(this.cmdBack);
		this.Controls.Add(this.explorer);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "WebBrowser";
		this.Text = "Web Browser";
		this.Load += new System.EventHandler(this.WebBrowser_Load);
		((System.ComponentModel.ISupportInitialize)(this.explorer)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new WebBrowser());
	}

	private void WebBrowser_Load(object sender, System.EventArgs e)
	{
		object nullObject = null;
		object uri = "http://localhost/iishelp/iis/misc/default.asp";
		explorer.Navigate2(ref uri, ref nullObject, ref nullObject, ref nullObject, ref nullObject);
	}

	private void cmdHome_Click(object sender, System.EventArgs e)
	{
		explorer.GoHome();
	}

	private void cmdForward_Click(object sender, System.EventArgs e)
	{
		try
		{
			explorer.GoForward();
		}
		catch
		{
			MessageBox.Show("Already on last page.");
		}
	}

	private void cmdBack_Click(object sender, System.EventArgs e)
	{
		try
		{
			explorer.GoBack();
		}
		catch
		{
			MessageBox.Show("Already on first page.");
		}
	}
}