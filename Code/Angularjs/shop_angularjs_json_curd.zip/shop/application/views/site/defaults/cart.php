<script type="text/javascript">
	function Set_cart(Idps,Names,Codes,Prices,Imagess)
    {
        var produstsp = $('.productsp');
        var pcart = $('.pcart');
        var cartitems = $('.cartitems');
        var reload = $('.reloading');
        cartitems.hide();
        produstsp.hide(500);
        pcart.fadeIn(500);
        reload.fadeIn(500);
       
        
        var data={
            Idp:Idps,
            Name:Names,
            Code:Codes,
            Price:Prices,
            Images:Imagess
        };
        var qtyc=0;
        if($(".Quantity"+Idps).length>0){
          
          $(".Quantity"+Idps).val(parseInt($(".Quantity"+Idps).val())+1);
          $(".money"+Idps).text(parseInt($(".money"+Idps).text())+parseInt(Prices)+'.đ');
          $(".TOTAL").text(parseInt($(".TOTAL").text())+parseInt(Prices)+'.đ');
          $('.totalcartmoney').text($(".TOTAL").text());
          qtyc=$(".Quantity"+Idps).val();
          $('.qtycart'+Idps).text(qtyc);
          //alert(parseInt($(".money"+Idps).text()));
        }else{
          var numCols = $("#fbody2").find('tr').length;
            var strdata="<tr class='Items"+Idps+"'>"+
          "<td class='first_td Items"+Idps+"'>"+
          "<div class='clearfix'>"+
          "<img style='width:110px;height:110px;' src='"+Imagess+"'>"+
          "<span>"+
          "<strong><a href='#'>"+Names+"</a></strong><br>"+
          "<ul>"+
          "<li><a href='javascript:void(0);'>text</a></li>"+
          "<li><a href='javascript:void(0);'>text</a></li>"+
          "<li><a href='javascript:void(0);'>text</a></li>"+
          "<li><a href='javascript:void(0);'>text</a></li>"+
          "<li><a href='javascript:void(0);'>text</a></li>"+
          "</ul>"+
          Codes+"<br>"+
          ""+
          "</span>"+
          "</div>"+
          "</td>"+
          "<td class='quantity'>"+
          "<form>"+
          "<label>"+
          "<input class='gray_btn' type='button' id='min_qty' class='qty' value='-'  onclick='vinegar("+Idps+")'>"+
          "</label>"+
          "<label>"+
          "<input type='text'  maxlength='12' name='Quantity"+Idps+"' id='Quantity"+Idps+"' class='Quantity"+Idps+"' value='1' size='2' readonly>"+
          "</label>"+
          "<label>"+
          "<input class='gray_btn' type='button' id='max_qty' class='qty' value='+' onclick='donate("+Idps+")'>"+
          "</label>"+
          "</form>"+
          "<label onclick='Update_cart("+Idps+");'><span>Cập Nhật </span></label>"+
          "<i class='reload2 loading"+Idps+"' id='loading"+Idps+"' style='display: none;padding-top:12px;padding-bottom:12px;'></i>"+
          "<i class='icon-okk successok"+Idps+"' id='successok"+Idps+"' name='successok"+Idps+"' style='display: none;'></i>"+
          "</td>"+
          "<td>"+
          "<h5> <div id='Price"+Idps+"' class='Price"+Idps+"' name='Price"+Idps+"'> "+Prices+".đ</div></h5>"+
          "</td>"+
          "<td class='total_price'>"+
          "<h5>"+
          "<div id='money"+Idps+"' class='money"+(numCols+1)+" money"+Idps+"' name='money"+Idps+"'>"+Prices+".đ</div>"+
          "<span>( Đã bao gồm VAT )</span></h5>"+
          "</td>"+
          "<td>"+
          "<i class='reload2 loadingd"+Idps+"' id='loading"+Idps+"' style='display: none;padding-top:12px;padding-bottom:12px;'></i>"+
          "<a class='unlinka delete_item delete_item"+Idps+"' onclick='Remove_cart("+Idps+")'>delete</a>"+
          "</td>"+
          "</tr>";
          //alert(strdata);
          $("#fbody2").append(strdata);

          var strdata2="<li class='clearfix delete_item"+Idps+"'>"+
          "<div class='cart_product_name'>"+
          "<img style='width:65px;height:65px;' src='"+Imagess+"' alt='product image'><span>"+
          "<strong>"+Names+"</strong><br>"+
          "<br></span></div><div class='cart_product_price'><span>"+
          "<strong><label  class='qtycart"+Idps+"'>1</label>x - "+Prices+".đ</strong><br>"+
          "<a class='remove_item unlinka' onclick='Remove_cart("+Idps+")'>Remove</a>"+
          "</span></div><div class='clear'></div></li>";
          $(".cartmenu").append(strdata2);

          $(".TOTAL").text(parseInt($(".TOTAL").text())+parseInt(Prices)+'.đ');
          $('.totalcartmoney').text($(".TOTAL").text());
          
          //alert($('.countitems').text());
        }
                    
                    $.ajax({
                       type: 'post',
                       url: '<?php echo base_url();?>defaults/SetCart',
                       data: data,
                       success: function (response) {
                        var numCols = $("#fbody2").find('tr').length;
                          $('.countitems').text(numCols.toString());
                          reload.hide(500);
                          cartitems.fadeIn(500);
                       }
                     });
                    
    }


    function Update_cart(id)
    {
      //alert($(".Email").val());
      var loading = $('.loading'+id);
      var successok = $('.successok'+id);  
      successok.hide();   
      loading.show(500);

        var data={
            Idp:id,
            Quantity:$(".Quantity"+id).val()
        };

               
                    $.ajax({
                       type: 'post',
                       url: '<?php echo base_url();?>defaults/UpdateCart',
                       dataType:'text',
                       data: data,
                       success: function (response) {
                       	if (response=='true') {
                       		loading.hide(500);
                			successok.fadeIn(500);
                       	};
                        

                       }
                     });
                   
    }

    function Remove_cart(id)
    {
      var loading = $('.loadingd'+id);
      var delete_item = $('.delete_item'+id);  
      delete_item.hide();   
      loading.show(500);
      
      
      

        var data={
            Idp:id
        };

                    $.ajax({
                       type: 'post',
                       url: '<?php echo base_url();?>defaults/RemoveCart',
                       data: data,
                       success: function (response) {
                          $('.Items'+id).hide();
                          $('.Items'+id).remove();
                          var totalmoney=0;
                  var tbl=document.getElementById("fbody2");
                var myrow=tbl.rows.length;
                          for (var i = 0; i < myrow; i++) {
                  var row=tbl.rows[i];
                  var column=row.cells[3].innerHTML;
                  var tg=(column.replace('.đ</div><span>( Đã bao gồm VAT )</span></h5>','')).substr(60);
                      totalmoney+=parseInt(tg);
                };

                          $('.TOTAL').text(totalmoney.toString() + '.đ');
                          $('.totalcartmoney').text(totalmoney.toString() + '.đ');
                          
                          $('.countitems').text(myrow.toString());
                          if (totalmoney==0) {
                            $('.pcart').hide();
                            $('.productsp').fadeIn(500);
                            
                          };
                          /*if ($('.TOTAL').text(totalmoney.toString() + '.đ')=='0.đ') {
                          	window.location="<?php echo base_url();?>defaults";
                          };*/
                       }
                     });
                   
    }


function number_format( number, decimals, dec_point, thousands_sep ) {
    // http://kevin.vanzonneveld.net
    // + original by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // + improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // + bugfix by: Michael White (http://crestidg.com)
    // + bugfix by: Benjamin Lupton
    // + bugfix by: Allan Jensen (http://www.winternet.no)
    // + revised by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // * example 1: number_format(1234.5678, 2, '.', '');
    // * returns 1: 1234.57
                              
    var n = number, c = isNaN(decimals = Math.abs(decimals)) ? 2 : decimals;
    var d = dec_point == undefined ? "," : dec_point;
    var t = thousands_sep == undefined ? "." : thousands_sep, s = n < 0 ? "-" : "";
    var i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", j = (j = i.length) > 3 ? j % 3 : 0;
                              
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
}

    
</script>

<?php 
if ($this->uri->rsegment(2)=='showcart')
	$this->load->view('site/access/template/slideheader');
?>
<div class="pcart" style="<?php if ($this->uri->rsegment(2)!='showcart') echo "display:none"; ?>">
<?php 
	if ($this->uri->rsegment(2)!='showcart') { 

?>
<div class="reloading" style="display:none; padding-left:48%;padding-right:35%;padding-top:20%;padding-bottom:20%;background-color:#ffffff;">
	<i class='reload2'></i>
</div>
<?php
	}
?>
<div class="container cartitems"  style="<?php if ($this->uri->rsegment(2)!='showcart') echo "display:none"; ?>">
<?php //if($total_items>0) { ?>
		<div class="sixteen columns">
			
			<div class="box_head">
				<h3>Giỏ hàng</h3>
			</div><!--end box_head -->

			<table class="cart_table">
				<thead>
					<tr>
						<th class="first_td"><h4>Sản phẩm</h4></th>
						<th><h4>Số lượng</h4></th>
						<th><h4>Đơn giá</h4></th>
						<th><h4>Thành tiền</h4></th>
						<th><h4>Hủy</h4></th>
					</tr>
				</thead>
				<tbody id="fbody2">
					<?php
		                if (isset($carts)) {
		                  $TOTAL=0;
		                  
		                  //$count=count($_SESSION['product_cart']);
		                  //echo "Ban co".$count." san pham :";
		                  $idmoney=1;
		                  foreach ($carts as $row):
		                  	
		            ?>
		                <li class="clearfix">
		                  <div class="cart_product_name">
		            <?php
		                    
		                    //$money=$row['qty']*$row['price'];
		                    $TOTAL=$TOTAL+$row['subtotal'];
		                    

		                    					echo "<tr class='Items".$row['id']."'>";
													echo "<td class='first_td'>";
														echo "<div class='clearfix'>";
															echo "<img style='width:110px;height:110px;' src='".base_url().$row['image_link']."'>";
															echo "<span>";
																echo "<strong><a class='unlinka' href='#'>".$row['name']."</a></strong><br>";
																echo "<ul>";
																	echo "<li><a href='javascript:void(0);'>text</a></li>";
																	echo "<li><a href='javascript:void(0);'>text</a></li>";
																	echo "<li><a href='javascript:void(0);'>text</a></li>";
																	echo "<li><a href='javascript:void(0);'>text</a></li>";
																	echo "<li><a href='javascript:void(0);'>text</a></li>";
																echo "</ul>";
																echo "<br>";
																
															echo "</span>";
														echo "</div>";
													echo "</td>";
													echo "<td class='quantity'>";
														echo "<form>";
														echo "<label>";
															echo "<input class='gray_btn' type='button' id='min_qty' class='qty' value='-'  onclick='vinegar(".$row['id'].")'>";
														echo "</label>";
														echo "<label>";
															echo "<input type='text'  maxlength='12' name='Quantity".$row['id']."' id='Quantity".$row['id']."' class='Quantity".$row['id']."' value='".$row['qty']."' size='2' readonly>";
														echo "</label>";
														echo "<label>";
															echo "<input class='gray_btn' type='button' id='max_qty' class='qty' value='+' onclick='donate(".$row['id'].")'>";
														echo "</label>";
														echo "</form>";
														echo "<label onclick='Update_cart(".$row['id'].");'><span>Cập Nhật </span></label>";
														echo "<i class='reload2 loading".$row['id']."' id='loading".$row['id']."' style='display: none;padding-top:12px;padding-bottom:12px;'></i>";
														echo "<i class='icon-okk successok".$row['id']."' id='successok".$row['id']."' name='successok".$row['id']."' style='display: none;'></i>";
														echo "";
													echo "</td>";
													echo "<td>";
														echo "<h5> <div id='Price".$row['id']."' class='Price".$row['id']."' name='Price".$row['id']."'> ".$row['price'].".đ</div></h5>";
													echo "</td>";
													echo "<td class='total_price'>";
														echo "<h5>";
														if (isset($row['subtotal'])) {
															echo "<div id='money".$row['id']."' class='money".$idmoney." money".$row['id']."' name='money".$row['id']."'>".$row['subtotal'].".đ</div>";
														}
														echo "<span>( Đã bao gồm VAT )</span></h5>";
													echo "</td>";
													echo "<td>";
														echo "<i class='reload2 loadingd".$row['id']."' id='loading".$row['id']."' style='display: none;padding-top:12px;padding-bottom:12px;'></i>";
														echo "<a class='delete_item unlinka delete_item".$row['id']."' href='#' onclick='Remove_cart(".$row['id'].")'>delete</a>";
													echo "</td>";
												echo "</tr>";
												$idmoney++;
		                  
		                  endforeach;
		                }
		            ?>

					
					
				</tbody>
			</table><!--end cart_table-->

		</div><!--end sixteen-->


		


		<div class="" align="center" style="width:98%; padding-left: 1%;">

			<table class="receipt">
				<tbody>
					
					
				</tbody>
				<tfoot>
					<tr>
					
						<td class="last_td">
						<?php 
							
								
						?>
						<a class="gray_btn <?php if ($this->uri->rsegment(2)!='showcart') echo "unlinka Continue"; ?> " href="<?php if ($this->uri->rsegment(2)!='showcart') echo "#"; else echo base_url()."defaults";?>" <?php if ($this->uri->rsegment(2)!='showcart') echo "onclick='Continue()'"; ?> style="padding-right: 3%;">Tiếp tục mua hàng</a> <span style="padding-right: 5%;padding-left: 25%;">
						<span style="color:#ff0099"><strong><span style='font-size:22px'>Tổng tiền : <label class='TOTAL' name='TOTAL' id="TOTAL"> <?php if(isset($TOTAL)) echo $TOTAL.".đ"; else echo "0.đ";?> </label></span></strong></span></span>
							<a class="red_btn" href="<?php if((!isset($_SESSION["User"])) || ($_SESSION["User"]=="")) echo  base_url()."defaults/checkout"; ?>">Tiến hành đặt hàng</a>
						<?php 
						
						?>
						</td>
					</tr>
				</tfoot>
				

			</table>

		</div><!--end six -->

		</div>
<?php //} ?>
	</div><!--end container-->

<?php
/*}
else { /*
	?>

		<div style="padding-left:5%;padding-right:5%;padding-top:20%;padding-bottom:20%;">
			<p style="text-align: center;"><span style="color:#ff0066"><span style="font-size:172px">404</span></span></p>

			<p style="text-align: center;"><span style="color:#ff0066"><span style="font-size:72px">page not found!</span></span></p>
		</div>
	<?php */
//}
?>