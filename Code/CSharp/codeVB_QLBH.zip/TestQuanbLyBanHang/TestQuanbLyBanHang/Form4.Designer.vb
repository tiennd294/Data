Namespace TestQuanbLyBanHang
	Partial Class Form4
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.textBox2 = New System.Windows.Forms.TextBox()
			Me.textBox1 = New System.Windows.Forms.TextBox()
			Me.label2 = New System.Windows.Forms.Label()
			Me.label1 = New System.Windows.Forms.Label()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.btnReLoad = New System.Windows.Forms.Button()
			Me.btnThem = New System.Windows.Forms.Button()
			Me.btnSua = New System.Windows.Forms.Button()
			Me.btnLuu = New System.Windows.Forms.Button()
			Me.btnHuyBo = New System.Windows.Forms.Button()
			Me.btnXoa = New System.Windows.Forms.Button()
			Me.btnTroVe = New System.Windows.Forms.Button()
			Me.groupBox1.SuspendLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me.textBox2)
			Me.groupBox1.Controls.Add(Me.textBox1)
			Me.groupBox1.Controls.Add(Me.label2)
			Me.groupBox1.Controls.Add(Me.label1)
			Me.groupBox1.Location = New System.Drawing.Point(12, 7)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(229, 67)
			Me.groupBox1.TabIndex = 0
			Me.groupBox1.TabStop = False
			' 
			' textBox2
			' 
			Me.textBox2.Location = New System.Drawing.Point(94, 39)
			Me.textBox2.Name = "textBox2"
			Me.textBox2.Size = New System.Drawing.Size(124, 20)
			Me.textBox2.TabIndex = 3
			' 
			' textBox1
			' 
			Me.textBox1.Location = New System.Drawing.Point(94, 13)
			Me.textBox1.Name = "textBox1"
			Me.textBox1.Size = New System.Drawing.Size(124, 20)
			Me.textBox1.TabIndex = 2
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New System.Drawing.Point(6, 42)
			Me.label2.Name = "label2"
			Me.label2.Size = New System.Drawing.Size(82, 13)
			Me.label2.TabIndex = 1
			Me.label2.Text = "Ten Thanh Pho"
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New System.Drawing.Point(6, 16)
			Me.label1.Name = "label1"
			Me.label1.Size = New System.Drawing.Size(60, 13)
			Me.label1.TabIndex = 0
			Me.label1.Text = "Thanh Pho"
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(12, 85)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(229, 177)
			Me.dataGridView1.TabIndex = 1
			' 
			' btnReLoad
			' 
			Me.btnReLoad.Location = New System.Drawing.Point(12, 268)
			Me.btnReLoad.Name = "btnReLoad"
			Me.btnReLoad.Size = New System.Drawing.Size(57, 35)
			Me.btnReLoad.TabIndex = 2
			Me.btnReLoad.Text = "Reload"
			Me.btnReLoad.UseVisualStyleBackColor = True
			AddHandler Me.btnReLoad.Click, New System.EventHandler(Me.btnReLoad_Click)
			' 
			' btnThem
			' 
			Me.btnThem.AccessibleDescription = ""
			Me.btnThem.Location = New System.Drawing.Point(75, 268)
			Me.btnThem.Name = "btnThem"
			Me.btnThem.Size = New System.Drawing.Size(57, 35)
			Me.btnThem.TabIndex = 3
			Me.btnThem.Text = "Them"
			Me.btnThem.UseVisualStyleBackColor = True
			AddHandler Me.btnThem.Click, New System.EventHandler(Me.btnThem_Click)
			' 
			' btnSua
			' 
			Me.btnSua.Location = New System.Drawing.Point(138, 268)
			Me.btnSua.Name = "btnSua"
			Me.btnSua.Size = New System.Drawing.Size(55, 35)
			Me.btnSua.TabIndex = 4
			Me.btnSua.Text = "Sua"
			Me.btnSua.UseVisualStyleBackColor = True
			AddHandler Me.btnSua.Click, New System.EventHandler(Me.btnSua_Click)
			' 
			' btnLuu
			' 
			Me.btnLuu.Location = New System.Drawing.Point(12, 309)
			Me.btnLuu.Name = "btnLuu"
			Me.btnLuu.Size = New System.Drawing.Size(57, 35)
			Me.btnLuu.TabIndex = 5
			Me.btnLuu.Text = "Luu"
			Me.btnLuu.UseVisualStyleBackColor = True
			AddHandler Me.btnLuu.Click, New System.EventHandler(Me.btnLuu_Click)
			' 
			' btnHuyBo
			' 
			Me.btnHuyBo.Location = New System.Drawing.Point(75, 309)
			Me.btnHuyBo.Name = "btnHuyBo"
			Me.btnHuyBo.Size = New System.Drawing.Size(57, 35)
			Me.btnHuyBo.TabIndex = 7
			Me.btnHuyBo.Text = "Huy Bo"
			Me.btnHuyBo.UseVisualStyleBackColor = True
			AddHandler Me.btnHuyBo.Click, New System.EventHandler(Me.btnHuyBo_Click)
			' 
			' btnXoa
			' 
			Me.btnXoa.Location = New System.Drawing.Point(138, 309)
			Me.btnXoa.Name = "btnXoa"
			Me.btnXoa.Size = New System.Drawing.Size(55, 35)
			Me.btnXoa.TabIndex = 8
			Me.btnXoa.Text = "Xoa"
			Me.btnXoa.UseVisualStyleBackColor = True
			AddHandler Me.btnXoa.Click, New System.EventHandler(Me.btnXoa_Click)
			' 
			' btnTroVe
			' 
			Me.btnTroVe.Font = New System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(0))
			Me.btnTroVe.Location = New System.Drawing.Point(199, 269)
			Me.btnTroVe.Name = "btnTroVe"
			Me.btnTroVe.Size = New System.Drawing.Size(42, 75)
			Me.btnTroVe.TabIndex = 9
			Me.btnTroVe.Text = "  Tro   Ve"
			Me.btnTroVe.TextAlign = System.Drawing.ContentAlignment.TopLeft
			Me.btnTroVe.UseVisualStyleBackColor = True
			AddHandler Me.btnTroVe.Click, New System.EventHandler(Me.btnTroVe_Click)
			' 
			' Form4
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(252, 354)
			Me.Controls.Add(Me.btnTroVe)
			Me.Controls.Add(Me.btnXoa)
			Me.Controls.Add(Me.btnHuyBo)
			Me.Controls.Add(Me.btnLuu)
			Me.Controls.Add(Me.btnSua)
			Me.Controls.Add(Me.btnThem)
			Me.Controls.Add(Me.btnReLoad)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.groupBox1)
			Me.Name = "Form4"
			Me.Text = "Danh Muc Thanh Pho"
			Me.FormClosing += New System.Windows.Forms.FormClosingEventHandler(Me.Form4_FormClosing)
			Me.Load += New System.EventHandler(Me.Form4_Load)
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private groupBox1 As System.Windows.Forms.GroupBox
		Private textBox2 As System.Windows.Forms.TextBox
		Private textBox1 As System.Windows.Forms.TextBox
		Private label2 As System.Windows.Forms.Label
		Private label1 As System.Windows.Forms.Label
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private btnReLoad As System.Windows.Forms.Button
		Private btnThem As System.Windows.Forms.Button
		Private btnSua As System.Windows.Forms.Button
		Private btnLuu As System.Windows.Forms.Button
		Private btnHuyBo As System.Windows.Forms.Button
		Private btnXoa As System.Windows.Forms.Button
		Private btnTroVe As System.Windows.Forms.Button
	End Class
End Namespace
