using System;

public class TypeInfoExample {

    public static void Main() {

        Type t1 = typeof(System.Text.StringBuilder);

        Type t2 = Type.GetType("System.String");
        Type t3 = Type.GetType("System.String", true);
        Type t4 = Type.GetType("system.string", true, true);
        Type t5 = Type.GetType("System.Data.DataSet,System.Data," +
            "Version=1.0.5000.0,Culture=neutral,PublicKeyToken=b77a5c561934e089");

        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        Type t6 = sb.GetType();

        Console.ReadLine();
    }
}
