<?php
Class Productsima_Model extends MY_Model
{
    var $table = 'productsima';
    var $key = 'Idi';
}