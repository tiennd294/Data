using System;

public class Person : IFormattable {

    private string title;
    private string[] names;

    public Person(string title, params string[] names) {

        this.title = title;
        this.names = names;
    }

    public override string ToString() {
        return ToString("G", null);
    }

    public string ToString(string format, IFormatProvider formatProvider) {

        string result = null;

        if (format == null) format = "G";

        switch (format.ToUpper()[0]) {

            case 'S':
                result = names[0][0] + ". " + names[names.Length-1];
                break;

            case 'P':
                if (title != null && title.Length != 0) {
                    result = title + ". ";
                }
                for (int count = 0; count < names.Length; count++) {
                    
                    if ( count != (names.Length - 1)) {
                        result += names[count][0] + ". ";
                    } else {
                        result += names[count];
                    }
                }
                break;

            case 'I':
                result = names[0];
                break;

            case 'G':
            default:
                result = names[0] + " " + names[names.Length-1];
                break;
        }
        return result;
    }

    public static void Main() {

        Person person = 
            new Person("Mr", "Richard", "Glen", "David", "Peters");

        System.Console.WriteLine("Dear {0:G},", person);
        System.Console.WriteLine("Dear {0:P},", person);
        System.Console.WriteLine("Dear {0:I},", person);
        System.Console.WriteLine("Dear {0},", person);
        System.Console.WriteLine("Dear {0:S},", person);

		Console.ReadLine();
    }
}