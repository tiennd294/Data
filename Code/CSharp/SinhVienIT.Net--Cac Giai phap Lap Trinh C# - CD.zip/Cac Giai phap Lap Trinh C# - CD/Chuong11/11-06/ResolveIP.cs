using System;
using System.Net;

public class ResolveIP
{
	private static void Main()
	{
		foreach (IPAddress ip in Dns.GetHostByName("www.microsoft.com").AddressList)
		{
			Console.Write(ip.AddressFamily.ToString() + ": ");
			Console.WriteLine(ip.ToString());
		}

		Console.ReadLine();
	}
}