using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;

namespace SimpleMAPITest
{
	using SimpleMAPI;

	/// <summary>
	/// MyMAPIForm Sample illustrates calling Simple MAPI functions from C#.
	/// Microsoft provides programming examples for illustration only, without warranty either 
	/// expressed or implied, including, but not limited to, the implied warranties of merchantability 
	/// and/or fitness for a particular purpose. This article assumes that you are familiar with the 
	/// programming language being demonstrated and the tools used to create and debug 
	/// procedures. Microsoft support professionals can help explain the functionality of a 
	/// particular procedure, but they will not modify these examples to provide added functionality 
	/// or construct procedures to meet your specific needs. If you have limited programming 
	/// experience, you may want to contact a Microsoft Certified Partner or the Microsoft fee-
	/// based consulting line at (800) 936-5200. For more information about Microsoft Certified 
	/// Partners, please see the following page on the World Wide Web: 

	/// 	http://www.microsoft.com/partner/referral/
	/// For more information about the support options available from Microsoft, please see the 
	/// following page on the World Wide Web: 
	/// 	http://support.microsoft.com/directory/overview.asp	/// </summary>
	public class MyMAPIForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox Output;
		private System.Windows.Forms.Button ResolveName;
		private System.Windows.Forms.Button Address;
		private System.Windows.Forms.Button ReadAllMail;
		private System.Windows.Forms.Button Details;
		private System.Windows.Forms.Button Logon;
		private System.Windows.Forms.Button ReadMail;
		private System.Windows.Forms.Button Logoff;
		private System.Windows.Forms.Button SaveMail;
		private System.Windows.Forms.Button SendDocuments;
		private System.Windows.Forms.Button SendMail;
		private System.Windows.Forms.Button DeleteMail;
		private System.Windows.Forms.Panel panel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MyMAPIForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			m_MAPISession = 0;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Output = new System.Windows.Forms.RichTextBox();
			this.ResolveName = new System.Windows.Forms.Button();
			this.Address = new System.Windows.Forms.Button();
			this.ReadAllMail = new System.Windows.Forms.Button();
			this.Details = new System.Windows.Forms.Button();
			this.Logon = new System.Windows.Forms.Button();
			this.ReadMail = new System.Windows.Forms.Button();
			this.Logoff = new System.Windows.Forms.Button();
			this.SaveMail = new System.Windows.Forms.Button();
			this.SendDocuments = new System.Windows.Forms.Button();
			this.SendMail = new System.Windows.Forms.Button();
			this.DeleteMail = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// Output
			// 
			this.Output.Dock = System.Windows.Forms.DockStyle.Fill;
			this.Output.Location = new System.Drawing.Point(0, 112);
			this.Output.Name = "Output";
			this.Output.Size = new System.Drawing.Size(448, 269);
			this.Output.TabIndex = 11;
			this.Output.Text = "";
			// 
			// ResolveName
			// 
			this.ResolveName.Location = new System.Drawing.Point(120, 40);
			this.ResolveName.Name = "ResolveName";
			this.ResolveName.Size = new System.Drawing.Size(96, 23);
			this.ResolveName.TabIndex = 9;
			this.ResolveName.Text = "ResolveName";
			this.ResolveName.Click += new System.EventHandler(this.ResolveName_Click);
			// 
			// Address
			// 
			this.Address.Location = new System.Drawing.Point(120, 8);
			this.Address.Name = "Address";
			this.Address.Size = new System.Drawing.Size(96, 23);
			this.Address.TabIndex = 8;
			this.Address.Text = "Address";
			this.Address.Click += new System.EventHandler(this.Address_Click);
			// 
			// ReadAllMail
			// 
			this.ReadAllMail.Location = new System.Drawing.Point(232, 72);
			this.ReadAllMail.Name = "ReadAllMail";
			this.ReadAllMail.Size = new System.Drawing.Size(96, 23);
			this.ReadAllMail.TabIndex = 10;
			this.ReadAllMail.Text = "ReadAllMail";
			this.ReadAllMail.Click += new System.EventHandler(this.ReadAllMail_Click);
			// 
			// Details
			// 
			this.Details.Location = new System.Drawing.Point(120, 72);
			this.Details.Name = "Details";
			this.Details.Size = new System.Drawing.Size(96, 23);
			this.Details.TabIndex = 3;
			this.Details.Text = "Details";
			this.Details.Click += new System.EventHandler(this.Details_Click);
			// 
			// Logon
			// 
			this.Logon.Location = new System.Drawing.Point(8, 8);
			this.Logon.Name = "Logon";
			this.Logon.Size = new System.Drawing.Size(96, 23);
			this.Logon.TabIndex = 0;
			this.Logon.Text = "Logon";
			this.Logon.Click += new System.EventHandler(this.Logon_Click);
			// 
			// ReadMail
			// 
			this.ReadMail.Location = new System.Drawing.Point(232, 40);
			this.ReadMail.Name = "ReadMail";
			this.ReadMail.Size = new System.Drawing.Size(96, 23);
			this.ReadMail.TabIndex = 4;
			this.ReadMail.Text = "ReadMail";
			this.ReadMail.Click += new System.EventHandler(this.ReadMail_Click);
			// 
			// Logoff
			// 
			this.Logoff.Location = new System.Drawing.Point(8, 40);
			this.Logoff.Name = "Logoff";
			this.Logoff.Size = new System.Drawing.Size(96, 23);
			this.Logoff.TabIndex = 1;
			this.Logoff.Text = "Logoff";
			this.Logoff.Click += new System.EventHandler(this.Logoff_Click);
			// 
			// SaveMail
			// 
			this.SaveMail.Location = new System.Drawing.Point(344, 40);
			this.SaveMail.Name = "SaveMail";
			this.SaveMail.Size = new System.Drawing.Size(96, 23);
			this.SaveMail.TabIndex = 7;
			this.SaveMail.Text = "SaveMail";
			this.SaveMail.Click += new System.EventHandler(this.SaveMail_Click);
			// 
			// SendDocuments
			// 
			this.SendDocuments.Location = new System.Drawing.Point(344, 8);
			this.SendDocuments.Name = "SendDocuments";
			this.SendDocuments.Size = new System.Drawing.Size(96, 23);
			this.SendDocuments.TabIndex = 5;
			this.SendDocuments.Text = "SendDocuments";
			this.SendDocuments.Click += new System.EventHandler(this.SendDocuments_Click);
			// 
			// SendMail
			// 
			this.SendMail.Location = new System.Drawing.Point(232, 8);
			this.SendMail.Name = "SendMail";
			this.SendMail.Size = new System.Drawing.Size(96, 23);
			this.SendMail.TabIndex = 2;
			this.SendMail.Text = "SendMail";
			this.SendMail.Click += new System.EventHandler(this.SendMail_Click);
			// 
			// DeleteMail
			// 
			this.DeleteMail.Location = new System.Drawing.Point(344, 72);
			this.DeleteMail.Name = "DeleteMail";
			this.DeleteMail.Size = new System.Drawing.Size(96, 23);
			this.DeleteMail.TabIndex = 6;
			this.DeleteMail.Text = "DeleteMail";
			this.DeleteMail.Click += new System.EventHandler(this.DeleteMail_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.DeleteMail,
																				 this.ReadAllMail,
																				 this.Logoff,
																				 this.SendDocuments,
																				 this.Logon,
																				 this.Address,
																				 this.ReadMail,
																				 this.SaveMail,
																				 this.SendMail,
																				 this.Details,
																				 this.ResolveName});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(448, 112);
			this.panel1.TabIndex = 14;
			// 
			// MyMAPIForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(448, 381);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Output,
																		  this.panel1});
			this.Name = "MyMAPIForm";
			this.Text = "MAPITest";
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		int m_MAPISession;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MyMAPIForm());
		}

		private void ClearLog()
		{
			Output.Text = "";
		}

		private void Log(string szOutput)
		{
			Output.Text = Output.Text + szOutput;
		}

		private void Check(int iRet,string szOutput)
		{
			Output.Text += "\n";
			Output.Text += szOutput;
			Output.Text += "\nReturn val: " + iRet.ToString() + " = " + iRet.ToString("x");
		}

		private void LogMessage(SimpleMAPI.MapiMessage MyMessage)
		{
			Log("\nSubject = " + MyMessage.szSubject);
			Log("\nDate = " + MyMessage.szDateReceived);
			if (MyMessage.nRecipCount > 0)
			{
				SimpleMAPI.MapiRecipDesc[] MyRecips = MyMessage.lpRecips;
				foreach (SimpleMAPI.MapiRecipDesc Recipient in MyRecips)
				{
					Log("\nRecipient = " + Recipient.szName + " : " + Recipient.szAddress);
					Log("\nType = " + Recipient.RecipClass.ToString());

//					int iRet = 0;
//					iRet = SimpleMAPI.MAPIDetails(
//						m_MAPISession,
//						0,
//						Recipient,
//						SimpleMAPI.MAPI_LOGON_UI,
//						0);
				}
			}
			Log("\nBody = " + MyMessage.szNoteText);
		}

		private void Logon_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			if (m_MAPISession == 0)
			{
				iRet = SimpleMAPI.MAPILogon(
					0, 
					"", //TODO: Specifiy a profile name if desired
					"", //Most MAPI providers will ignore this parameter 
					SimpleMAPI.MAPI_LOGON_UI, 
					0, 
					out m_MAPISession);
				Check(iRet,"MAPILogon");
			}
		}

		private void Logoff_Click(object sender, System.EventArgs e)
		{
			if (m_MAPISession != 0)
			{
				int iRet = 0;
				iRet = SimpleMAPI.MAPILogoff(
					m_MAPISession,
					0,
					SimpleMAPI.MAPI_LOGON_UI,
					0);
				Check(iRet,"MAPILogoff");
				m_MAPISession = 0;
			}
		}

		private void SendMail_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			SimpleMAPI.MapiMessage MyMessage;
			SimpleMAPI.MapiRecipDesc[] MyRecips = new SimpleMAPI.MapiRecipDesc[2];
			SimpleMAPI.MapiFileDesc[] MyFiles = new SimpleMAPI.MapiFileDesc[2];
		
			MyRecips[0].lpEID = null;
			// Important: If sending through Hotmail,
			// note that Hotmail only looks at szName, not szAddress
			MyRecips[0].szAddress = "SMTP:jdoe@fake.microsoft.com";
			MyRecips[0].szName = "John Doe";
			MyRecips[0].cbEID = 0;
			MyRecips[0].RecipClass = SimpleMAPI.MAPI_TO;
			MyRecips[0].Reserved = 0;

			MyRecips[1].lpEID = null;
			// Important: If sending through Hotmail,
			// note that Hotmail only looks at szName, not szAddress
			MyRecips[1].szAddress = "SMTP:jadoe@fake.microsoft.com";
			MyRecips[1].szName = "Jane Doe";
			MyRecips[1].cbEID = 0;
			MyRecips[1].RecipClass = SimpleMAPI.MAPI_CC;
			MyRecips[1].Reserved = 0;

			MyFiles[0].Flags = 0;
			MyFiles[0].lpFileType = null;
//These statements are bogus. They exist to test some allocation and marshalling routines
//			MyFiles[0].lpFileType = new SimpleMAPI.MapiFileTagExt[1];
//			MyFiles[0].lpFileType[0].cbEncoding = 7;
//			MyFiles[0].lpFileType[0].cbTag = 5;
//			MyFiles[0].lpFileType[0].Reserved = 0;
//			MyFiles[0].lpFileType[0].szEncoding = "1234567";
//			MyFiles[0].lpFileType[0].szTag = "12345";
			MyFiles[0].szFileName = "boot.ini";
			MyFiles[0].szPathName = @"c:\boot.ini";
			MyFiles[0].nPosition = 1;
			MyFiles[0].Reserved = 0;
		
			MyFiles[1].Flags = 0;
			MyFiles[1].lpFileType = null;
			MyFiles[1].szFileName = "io.sys";
			MyFiles[1].szPathName = @"c:\io.sys";
			MyFiles[1].nPosition = 3;
			MyFiles[1].Reserved = 0;

			MyMessage.Flags = 0;
			MyMessage.nFileCount = 2;
			MyMessage.lpFiles = MyFiles;
			MyMessage.lpOriginator = null;
			MyMessage.nRecipCount = 2;
			MyMessage.lpRecips = MyRecips;
			MyMessage.szConversationID = "";
			MyMessage.szDateReceived = "";
			//If we write instead
			//MyMessage.szMessageType = "";
			//this call will fail against Outlook with an error code of 2 and the dialog "Object not Found"
			MyMessage.szMessageType = null;
			MyMessage.szNoteText = "This is my body";
			MyMessage.szSubject = "This is my subject";
			MyMessage.Reserved = 0;

			iRet = SimpleMAPI.MAPISendMail(
				m_MAPISession,
				0,
				MyMessage,
				SimpleMAPI.MAPI_DIALOG,//pass 0 to send without UI
				0);
			Check(iRet,"MAPISendMail");
		}

		private void Details_Click(object sender, System.EventArgs e)
		{
				int iRet = 0;
				SimpleMAPI.MapiRecipDesc Recipient;
		
				Recipient.lpEID = null;
				Recipient.szAddress = "";
				Recipient.szName = "John Doe <jdoe@fake.microsoft.com>";
				Recipient.cbEID = 0;
				Recipient.RecipClass = 0;
				Recipient.Reserved = 0;

				iRet = SimpleMAPI.MAPIDetails(
					m_MAPISession,
					0,
					Recipient,
					SimpleMAPI.MAPI_LOGON_UI,
					0);
				Check(iRet,"MAPIDetails");
				if (2 == iRet) Log("\nSome providers require that the recipient be fully resolved. Try MAPIResolveName instead.");
		}

		private string FindNext()
		{
			int iRet = 0;
			string szMsgID;
			iRet = SimpleMAPI.MAPIFindNext(
				m_MAPISession,
				0,
				"",//Message class or empty for default
				"",//Starting message ID or empty for default
				SimpleMAPI.MAPI_LONG_MSGID,//Flags
				0,//Reserved,
				out szMsgID);
			Check(iRet,"MAPIFindNext");
			return szMsgID;
		}

		private void ReadMail_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;

			SimpleMAPI.MapiMessage MyMessage;

			iRet = SimpleMAPI.MAPIReadMail(
				m_MAPISession,
				0,
				FindNext(),
				SimpleMAPI.MAPI_PEEK,
				0,
				out MyMessage);
			Check(iRet,"MAPIReadMail");

			if (iRet == 0)
				LogMessage(MyMessage);
		}

		private void SendDocuments_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			iRet = SimpleMAPI.MAPISendDocuments(
				0,
				";",
				@"c:\boot.ini;c:\io.sys",
				"boot.ini;io.sys",
				0);
			Check(iRet,"MAPISendDocuments");
		}

		private void DeleteMail_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			iRet = SimpleMAPI.MAPIDeleteMail(
				m_MAPISession,
				0,
				FindNext(),
				0,
				0);
			Check(iRet,"MAPIDeleteMail");
		}

		private void SaveMail_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;

			SimpleMAPI.MapiMessage MyMessage;
			SimpleMAPI.MapiRecipDesc[] MyRecips = new SimpleMAPI.MapiRecipDesc[2];
			SimpleMAPI.MapiFileDesc[] MyFiles = new SimpleMAPI.MapiFileDesc[2];
		
			MyRecips[0].lpEID = null;
			// Important: If sending through Hotmail,
			// note that Hotmail only looks at szName, not szAddress
			MyRecips[0].szAddress = "SMTP:jdoe@fake.microsoft.com";
			MyRecips[0].szName = "John Doe";
			MyRecips[0].cbEID = 0;
			MyRecips[0].RecipClass = SimpleMAPI.MAPI_TO;
			MyRecips[0].Reserved = 0;

			MyRecips[1].lpEID = null;
			// Important: If sending through Hotmail,
			// note that Hotmail only looks at szName, not szAddress
			MyRecips[1].szAddress = "SMTP:jadoe@fake.microsoft.com";
			MyRecips[1].szName = "Jane Doe";
			MyRecips[1].cbEID = 0;
			MyRecips[1].RecipClass = SimpleMAPI.MAPI_CC;
			MyRecips[1].Reserved = 0;

			MyFiles[0].Flags = 0;
			MyFiles[0].lpFileType = null;
//These statements are bogus. They exist to test some allocation and marshalling routines
//				MyFiles[0].lpFileType = new SimpleMAPI.MapiFileTagExt[1];
//				MyFiles[0].lpFileType[0].cbEncoding = 7;
//				MyFiles[0].lpFileType[0].cbTag = 5;
//				MyFiles[0].lpFileType[0].Reserved = 0;
//				MyFiles[0].lpFileType[0].szEncoding = "1234567";
//				MyFiles[0].lpFileType[0].szTag = "12345";
			MyFiles[0].szFileName = "boot.ini";
			MyFiles[0].szPathName = @"c:\boot.ini";
			MyFiles[0].nPosition = 1;
			MyFiles[0].Reserved = 0;
		
			MyFiles[1].Flags = 0;
			MyFiles[1].lpFileType = null;
			MyFiles[1].szFileName = "io.sys";
			MyFiles[1].szPathName = @"c:\io.sys";
			MyFiles[1].nPosition = 3;
			MyFiles[1].Reserved = 0;

			MyMessage.Flags = 0;
			MyMessage.nFileCount = 2;
			MyMessage.lpFiles = MyFiles;
			MyMessage.lpOriginator = null;
			MyMessage.nRecipCount = 2;
			MyMessage.lpRecips = MyRecips;
			MyMessage.szConversationID = "";
			MyMessage.szDateReceived = "";
			//Outlook does not object to this here as it does in MAPISendMail
			//MyMessage.szMessageType = "";
			MyMessage.szMessageType = null;
			MyMessage.szNoteText = "This is my body";
			MyMessage.szSubject = "This is my subject";
			MyMessage.Reserved = 0;

			string szMsgID;

			iRet = SimpleMAPI.MAPISaveMail(
				m_MAPISession,
				0,
				MyMessage,
				SimpleMAPI.MAPI_LONG_MSGID,//pass 0 to send without UI
				0,
				out szMsgID);
			Check(iRet,"MAPISaveMail");

			if (iRet == 0)
			{
				Log("\nNew message ID = " + szMsgID.ToString());
				LogMessage(MyMessage);
			}
		}

		private void Address_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			SimpleMAPI.MapiRecipDesc[] MyRecips = new SimpleMAPI.MapiRecipDesc[1];
			int iNewRecips;
			SimpleMAPI.MapiRecipDesc[] NewRecips;
		
			MyRecips[0].lpEID = null;
			MyRecips[0].szAddress = "jdoe@fake.microsoft.com";
			MyRecips[0].szName = "John Doe";
			MyRecips[0].cbEID = 0;
			MyRecips[0].RecipClass = SimpleMAPI.MAPI_TO;
			MyRecips[0].Reserved = 0;

			iRet = SimpleMAPI.MAPIAddress(
				m_MAPISession,
				0,
				"My Caption",
				4,
				"To String",
				MyRecips.Length,
				MyRecips,
				SimpleMAPI.MAPI_LOGON_UI,
				0,
				out iNewRecips,
				out NewRecips);
			Check(iRet,"MAPIAddress");

			if (NewRecips != null)
			{
				foreach (SimpleMAPI.MapiRecipDesc Recipient in NewRecips)
				{
					Log("\nRecipient = " + Recipient.szName + " : " + Recipient.szAddress);
					Log("\nType = " + Recipient.RecipClass.ToString());

					iRet = SimpleMAPI.MAPIDetails(
						m_MAPISession,
						0,
						Recipient,
						SimpleMAPI.MAPI_LOGON_UI,
						0);
				}
			}
		}

		private void ResolveName_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			SimpleMAPI.MapiRecipDesc Recipient;

			iRet = SimpleMAPI.MAPIResolveName(
				m_MAPISession,
				0,
				"John Doe <jdoe@fake.microsoft.com>",
				SimpleMAPI.MAPI_DIALOG,//pass 0 to send without UI
				0,
				out Recipient);
			Check(iRet,"MAPIResolveName");

			iRet = SimpleMAPI.MAPIDetails(
				m_MAPISession,
				0,
				Recipient,
				SimpleMAPI.MAPI_LOGON_UI,
				0);
		}

		private void ReadAllMail_Click(object sender, System.EventArgs e)
		{
			int iRet = 0;
			string szCurEID = "";
			string szNextEID;
			SimpleMAPI.MapiMessage MyMessage;

			while(SimpleMAPI.MAPIFindNext(
				m_MAPISession,
				0,
				"",
				szCurEID,
				0,
				0,
				out szNextEID) == 0)
			{
				szCurEID = szNextEID;

				iRet = SimpleMAPI.MAPIReadMail(
					m_MAPISession,
					0,
					szCurEID,
					SimpleMAPI.MAPI_PEEK,
					0,
					out MyMessage);
				Check(iRet,"MAPIReadMail");

				LogMessage(MyMessage);
			}
		}
	}
}
