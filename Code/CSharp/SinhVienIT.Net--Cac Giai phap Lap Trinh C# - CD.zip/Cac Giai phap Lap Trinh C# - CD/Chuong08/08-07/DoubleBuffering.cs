using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public class DoubleBuffering : System.Windows.Forms.Form
{
	private System.Windows.Forms.CheckBox chkUseDoubleBuffering;
	private System.Windows.Forms.Timer tmrRefresh;
	private System.ComponentModel.IContainer components;

	public DoubleBuffering()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		this.chkUseDoubleBuffering = new System.Windows.Forms.CheckBox();
		this.tmrRefresh = new System.Windows.Forms.Timer(this.components);
		this.SuspendLayout();
		// 
		// chkUseDoubleBuffering
		// 
		this.chkUseDoubleBuffering.BackColor = System.Drawing.Color.Yellow;
		this.chkUseDoubleBuffering.Location = new System.Drawing.Point(8, 8);
		this.chkUseDoubleBuffering.Name = "chkUseDoubleBuffering";
		this.chkUseDoubleBuffering.Size = new System.Drawing.Size(336, 16);
		this.chkUseDoubleBuffering.TabIndex = 1;
		this.chkUseDoubleBuffering.Text = "Use Double Buffering";
		// 
		// tmrRefresh
		// 
		this.tmrRefresh.Interval = 10;
		this.tmrRefresh.Tick += new System.EventHandler(this.tmrRefresh_Tick);
		// 
		// DoubleBuffering
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(376, 354);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.chkUseDoubleBuffering});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "DoubleBuffering";
		this.Text = "DoubleBuffering";
		this.Load += new System.EventHandler(this.DoubleBuffering_Load);
		this.Paint += new System.Windows.Forms.PaintEventHandler(this.DoubleBuffering_Paint);
		this.ResumeLayout(false);

	}
	#endregion


	[STAThread]
	static void Main() 
	{
		Application.Run(new DoubleBuffering());
	}

	private bool isShrinking = false;
	private int imageSize = 0;

	private Image image;

	private void DoubleBuffering_Load(object sender, System.EventArgs e)
	{
		image = Image.FromFile("image.bmp");

		tmrRefresh.Start();
	}

	private void tmrRefresh_Tick(object sender, System.EventArgs e)
	{
		if (isShrinking)
		{
			imageSize--;
		}
		else
		{
			imageSize++;
		}
		
		if (imageSize > (this.Width - 150))
		{
			isShrinking = true;
		}
		else if (imageSize < 1)
		{
			isShrinking = false;
		}
		
		this.Invalidate();
	}
	
	private void DoubleBuffering_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
	{
		Graphics g;

		Bitmap drawing = null;
		if (chkUseDoubleBuffering.Checked)
		{
			drawing = new Bitmap(this.Width, this.Height, e.Graphics);
			g = Graphics.FromImage(drawing);
		}
		else
		{
			g = e.Graphics;
		}

		g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

		g.FillRectangle(Brushes.Yellow, new Rectangle(new Point(0, 0),
			this.ClientSize));

		g.DrawImage(image, 50, 50, 50 + imageSize, 50 + imageSize);

		if (chkUseDoubleBuffering.Checked)
		{
			e.Graphics.DrawImageUnscaled(drawing, 0, 0);
			g.Dispose();
		}
	}

	protected override void OnPaintBackground(
		System.Windows.Forms.PaintEventArgs pevent)
	{
	}

}