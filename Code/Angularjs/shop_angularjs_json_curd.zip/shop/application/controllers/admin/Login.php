<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {

	public function Index()
    {
        $this->load->library('form_validation');
        $this->load->helper('form');
        if($this->input->post())
        {
            $this->form_validation->set_rules('login' ,'login', 'callback_check_login');
            if($this->form_validation->run())
            {
                $this->session->set_userdata('Administrator',$this->input->post('username') );
                
                redirect(admin_url('Defaults'));
            }
        }
        
        $this->load->view('admin/Login/Index');
    }
    
    /*
     * Kiem tra username va password co chinh xac khong
     */
    public function check_login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $password = md5(md5($password));
        
        $this->load->model('Users_Model');
        $where = array('Usersnames' => $username , 'Passwords' => $password, 'Startus' => 'on');
        if($this->Users_Model->check_exists($where))
        {
            return true;
        }
        $this->form_validation->set_message(__FUNCTION__, 'Sai tên đăng nhập hoặc mật khẩu!');
        return false;
    }

    
	
}
