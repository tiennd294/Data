using System;
using System.Security;
using System.Security.Policy;
using System.Security.Cryptography.X509Certificates;

public class AppDomainPolicyExample {

    public static void Main() {
        
        AppDomain domain = AppDomain.CreateDomain("modules");
        
        // ...
        
        SetDomainPolicy(domain);
        
        // ...
    }

    private static void SetDomainPolicy(AppDomain domain) {
    	
        PolicyLevel policy = PolicyLevel.CreateAppDomainLevel();
    
        policy.RootCodeGroup = new FirstMatchCodeGroup(
            new AllMembershipCondition(),
            new PolicyStatement(policy.GetNamedPermissionSet("Nothing"))
        );
            
        X509Certificate microsoftCert = 
            X509Certificate.CreateFromCertFile("microsoft.cer");
        
        policy.RootCodeGroup.AddChild(new UnionCodeGroup(
            new PublisherMembershipCondition(microsoftCert),
            new PolicyStatement(policy.GetNamedPermissionSet("FullTrust"),
            PolicyStatementAttribute.Exclusive)
        ));

        X509Certificate litwareCert = 
            X509Certificate.CreateFromCertFile("litware.cer");
    
        policy.RootCodeGroup.AddChild(new UnionCodeGroup(
            new PublisherMembershipCondition(litwareCert),
            new PolicyStatement(policy.GetNamedPermissionSet("Internet"),
            PolicyStatementAttribute.Exclusive)
        ));

        X509Certificate fabrikamCert = 
            X509Certificate.CreateFromCertFile("fabrikam.cer");
    
        policy.RootCodeGroup.AddChild(new UnionCodeGroup(
            new PublisherMembershipCondition(fabrikamCert),
            new PolicyStatement(policy.GetNamedPermissionSet("Execution"),
            PolicyStatementAttribute.Exclusive)
        ));

        policy.RootCodeGroup.AddChild(new UnionCodeGroup(
            new AllMembershipCondition(),
            new PolicyStatement(policy.GetNamedPermissionSet("Nothing"),
            PolicyStatementAttribute.Exclusive)
        ));
 
        domain.SetAppDomainPolicy(policy);
    }
}