using System;
using System.Xml;
using System.IO;
using System.Text;


public class ReadWriteXml
{
	private static void Main()
	{
		FileStream fs = new FileStream("products.xml", FileMode.Create);
		XmlTextWriter w = new XmlTextWriter(fs, Encoding.UTF8);

		w.WriteStartDocument();
		w.WriteStartElement("products");

		w.WriteStartElement("product");
		w.WriteAttributeString("id", "1001");	
		w.WriteElementString("productName", "Gourmet Coffee");
		w.WriteElementString("productPrice", "0.99");
		w.WriteEndElement();

		w.WriteStartElement("product");
		w.WriteAttributeString("id", "1002");	
		w.WriteElementString("productName", "Blue China Tea Pot");
		w.WriteElementString("productPrice", "102.99");
		w.WriteEndElement();

		w.WriteEndElement();
		w.WriteEndDocument();
		w.Flush();
		fs.Close();
			
		Console.WriteLine("Document created. " + 
            "Press Enter to read the document.");
		Console.ReadLine();

		fs = new FileStream("products.xml", FileMode.Open);
		XmlTextReader r = new XmlTextReader(fs);
		
		while (r.Read())
		{
			if (r.NodeType == XmlNodeType.Element)
			{
				Console.WriteLine();
				Console.WriteLine("<" + r.Name + ">");
				if (r.HasAttributes)
				{
					for (int i = 0; i < r.AttributeCount; i++)
					{
						Console.WriteLine("\tATTRIBUTE: " + r.GetAttribute(i));
                    }
				}
			}
			else if (r.NodeType == XmlNodeType.Text)
			{
				Console.WriteLine("\tVALUE: " + r.Value);
			}
		}
		Console.ReadLine();
	}
}
