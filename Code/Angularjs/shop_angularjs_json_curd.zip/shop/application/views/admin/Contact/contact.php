<script type='text/javascript'>
    $(function(){
    });
</script> 
<?php
        $this->load->view('admin/accessdata/template/messenger');
?>
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>

                        <div class='table-action'>
                            <a href='#' class='btnadd tip-top' data-original-title='Add'><i class='icon-plus'></i> Thêm mới</a>
                        </div>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã ID</th>  
                                    <th>Tên</th>  
                                    <th>Điện thoại</th>  
                                    <th>Email</th>  
                                    <th>Địa chỉ</th>  
                                    <th>Mã nhúng google map</th>  
                                    <th>Nội dung</th>  
                                    <th>Trạng thái</th>  
                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                $i=0;
                                foreach ($tblcontact as $row):
                                    $i++;
                            ?>
                                <tr class='gradeU items_' id='<?php echo $row->Idct; ?>'>
                                    <td><?php echo $row->Idct; ?></td>
                                    <td><?php echo $row->Name; ?></td>
                                    <td><?php echo $row->Phone; ?></td>
                                    <td><?php echo $row->Email; ?></td>
                                    <td><?php echo $row->Address; ?></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Addressmap; ?></div></td>
                                    <td><div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;"><?php echo $row->Content; ?></div></td>
                                    <td><?php echo $row->Startus; ?></td>
                                    <td style='text-align: center;'><a href='#' class='btn btn-mini tip-top btnedit btn-primary' data-original-title='Edit'>Sửa</a> <a href='#' class='btn btn-mini tip-top btndelete btn-danger' data-original-title='Delete'>Xóa</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>




	<div class='frmadd' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Thêm mới</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='<?php echo admin_url();?>/contact/Add'>


								<div class='control-group'>
									<label class='control-label'>Tên :</label>
									<div class='controls'>
										<input  name='atextdata1' type='text' class='span20 atextdata1' placeholder='Tên' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Điện thoại :</label>
									<div class='controls'>
										<input  name='atextdata2' type='text' class='span20 atextdata2' placeholder='Điện thoại' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Email :</label>
									<div class='controls'>
										<input  name='atextdata3' type='text' class='span20 atextdata3' placeholder='Email' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Địa chỉ :</label>
									<div class='controls'>
										<input  name='atextdata4' type='text' class='span20 atextdata4' placeholder='Địa chỉ' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mã nhúng google map :</label>
									<div class='controls'>
										<input  name='atextdata5' type='text' class='span20 atextdata5' placeholder='Mã nhúng google map' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Nội dung :</label>
									<div class='controls'>
									</div>
								</div>

								<div class='control-group' style='margin-right: 1.5%; '>
										<textarea  name='atextdata6ck' class='span20 atextdata6ck ckeditor' rows='5' ></textarea>
                                        <div class='setingck' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>
                                        <input  name='atextdata6' type='text' class='span20 atextdata6' placeholder='data' />
                                        </div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='atextdata7' class='atextdata7 atextdata7cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnadd' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>






	<div class='frmedit' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-pencil'></i>
									</span>
									<h5>Cập nhật</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form3' class='form-horizontal' name='form3' method='post' action='<?php echo admin_url();?>/contact/Edit'>
								<div class='control-group'>
										<label class='control-label'>Mã ID :</label>
										<div class='controls'><input id='etextid' name='etextid' type='text' class='span20 etextid'/></div>
								</div>
								<div class='control-group'>
									<label class='control-label'>Tên :</label>
									<div class='controls'>
										<input  name='etextdata1' type='text' class='span20 etextdata1' placeholder='Tên' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Điện thoại :</label>
									<div class='controls'>
										<input  name='etextdata2' type='text' class='span20 etextdata2' placeholder='Điện thoại' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Email :</label>
									<div class='controls'>
										<input  name='etextdata3' type='text' class='span20 etextdata3' placeholder='Email' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Địa chỉ :</label>
									<div class='controls'>
										<input  name='etextdata4' type='text' class='span20 etextdata4' placeholder='Địa chỉ' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Mã nhúng google map :</label>
									<div class='controls'>
										<input  name='etextdata5' type='text' class='span20 etextdata5' placeholder='Mã nhúng google map' />
									</div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Nội dung :</label>
									<div class='controls'>
									</div>
								</div>

								<div class='control-group' style='margin-right: 1.5%; '>
										<textarea  name='etextdata6ck' class='span20 etextdata6ck ckeditor' rows='5' ></textarea>
                                        <div class='setingck' style='color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;'>
                                        <input  name='etextdata6' type='text' class='span20 etextdata6' placeholder='data' />
                                        </div>
								</div>

								<div class='control-group'>
									<label class='control-label'>Trạng thái</label>
									<div class='controls'>
										<label><input type='checkbox' name='etextdata7' class='etextdata7 etextdata7cb' />On/Off</label>
									</div>
								</div>
									<div class='form-actions'   align='center'>
									<button id='btnedit' class='btn btn-success'>Save</button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>







	<div class='frmdelete' style='width:50%;text-align: center; margin-left: 24%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-trash'></i>
									</span>
									<h5>Xóa</h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form2' class='form-horizontal' name='form2' method='post' action='<?php echo admin_url();?>/contact/Delete'>
								<div class='controls'>                                   <label id='Label2' class='control-label'> Bạn có chắc chắn muốn xóa không?</label>                               </div>                               <div class='control-group' style='padding-left:5px; padding-top:5px;'>                                    <div style='color:#fff;background:rgba(0,0,0,0.0);width:13px;height:13px;overflow:auto;'>                                        <div class='control-group'>                                               <label class='control-label'>ID dstaikhoan:</label>                                           <div class='controls'>                                               <input id='textid' class='textid' name='textid' type='text' class='span20' />                                           </div>                                       </div>                                   </div>                               </div>								<div class='form-actions  txtc'   align='center'>
									<button id='btndelete' class='btn btnyes btn-success'>Có</button>
									<button id='btnhuy'  class='btn btn-success btncancel' style='margin-left:10px'> Không</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
