<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Contact_Model');
    }

    public function Index()
    {

        $input = array();
        $tblcontact=$this->Contact_Model->get_list($input);
        $tblmenu=$this->Contact_Model->loadmenu();
        $data = array(
            'urldata' => 'admin/Contact/contact',
            'tblcontact' => $tblcontact,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);

    }

    public function Add()
    {
        $data = array(
            'Name' => $this->input->post('atextdata1'),
            'Phone' => $this->input->post('atextdata2'),
            'Email' => $this->input->post('atextdata3'),
            'Address' => $this->input->post('atextdata4'),
            'Addressmap' => $this->input->post('atextdata5'),
            'Content' => $this->input->post('atextdata6'),
            'Startus' => $this->input->post('atextdata7')
        );
        $this->Contact_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Phone' => $this->input->post('etextdata2'),
            'Email' => $this->input->post('etextdata3'),
            'Address' => $this->input->post('etextdata4'),
            'Addressmap' => $this->input->post('etextdata5'),
            'Content' => $this->input->post('etextdata6'),
            'Startus' => $this->input->post('etextdata7')
        );
         if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Contact_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
       if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Contact_Model->delete($Id);
       
        }
    }
}