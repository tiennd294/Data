(function(exports){
	$.ripple.init();
})(window);