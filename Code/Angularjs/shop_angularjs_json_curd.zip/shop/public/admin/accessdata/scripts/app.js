// var My_app = angular.module('myModule',[]);
// My_app.controller(myController, 'myController');

// function myController($scope){
// 	$scope.message = 'demo angularjs';
// }

// angular.module("myapp", []).controller("HeaderController", function($scope) {
 
//     $scope.data = {
//         title : 'các bạn',
//         website : 'freetuts.net'
//     };
// });