﻿namespace MyLanChat
{
    partial class Frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox16 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox17 = new FontAwesome.Sharp.IconPictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.iconPictureBox15 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox18 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox19 = new FontAwesome.Sharp.IconPictureBox();
            this.iconPictureBox20 = new FontAwesome.Sharp.IconPictureBox();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox17)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox20)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumPurple;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(374, 23);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.BlueViolet;
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(374, 83);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.iconPictureBox20);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(91, 83);
            this.panel3.TabIndex = 0;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Users;
            this.iconPictureBox1.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox1.IconSize = 46;
            this.iconPictureBox1.Location = new System.Drawing.Point(14, 227);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox1.TabIndex = 2;
            this.iconPictureBox1.TabStop = false;
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            this.iconPictureBox2.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox2.IconSize = 46;
            this.iconPictureBox2.Location = new System.Drawing.Point(67, 123);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox2.TabIndex = 3;
            this.iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox3
            // 
            this.iconPictureBox3.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.UserTimes;
            this.iconPictureBox3.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox3.IconSize = 46;
            this.iconPictureBox3.Location = new System.Drawing.Point(120, 123);
            this.iconPictureBox3.Name = "iconPictureBox3";
            this.iconPictureBox3.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox3.TabIndex = 4;
            this.iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox4
            // 
            this.iconPictureBox4.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.UserCheck;
            this.iconPictureBox4.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox4.IconSize = 46;
            this.iconPictureBox4.Location = new System.Drawing.Point(14, 123);
            this.iconPictureBox4.Name = "iconPictureBox4";
            this.iconPictureBox4.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox4.TabIndex = 5;
            this.iconPictureBox4.TabStop = false;
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.UserCog;
            this.iconPictureBox5.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox5.IconSize = 46;
            this.iconPictureBox5.Location = new System.Drawing.Point(279, 123);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox5.TabIndex = 6;
            this.iconPictureBox5.TabStop = false;
            // 
            // iconPictureBox6
            // 
            this.iconPictureBox6.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.UserLock;
            this.iconPictureBox6.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox6.IconSize = 46;
            this.iconPictureBox6.Location = new System.Drawing.Point(120, 175);
            this.iconPictureBox6.Name = "iconPictureBox6";
            this.iconPictureBox6.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox6.TabIndex = 7;
            this.iconPictureBox6.TabStop = false;
            // 
            // iconPictureBox7
            // 
            this.iconPictureBox7.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.UserMinus;
            this.iconPictureBox7.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox7.IconSize = 46;
            this.iconPictureBox7.Location = new System.Drawing.Point(173, 123);
            this.iconPictureBox7.Name = "iconPictureBox7";
            this.iconPictureBox7.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox7.TabIndex = 8;
            this.iconPictureBox7.TabStop = false;
            // 
            // iconPictureBox8
            // 
            this.iconPictureBox8.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.UserShield;
            this.iconPictureBox8.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox8.IconSize = 46;
            this.iconPictureBox8.Location = new System.Drawing.Point(173, 175);
            this.iconPictureBox8.Name = "iconPictureBox8";
            this.iconPictureBox8.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox8.TabIndex = 9;
            this.iconPictureBox8.TabStop = false;
            // 
            // iconPictureBox9
            // 
            this.iconPictureBox9.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.UserSlash;
            this.iconPictureBox9.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox9.IconSize = 46;
            this.iconPictureBox9.Location = new System.Drawing.Point(226, 123);
            this.iconPictureBox9.Name = "iconPictureBox9";
            this.iconPictureBox9.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox9.TabIndex = 10;
            this.iconPictureBox9.TabStop = false;
            // 
            // iconPictureBox10
            // 
            this.iconPictureBox10.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.UserTag;
            this.iconPictureBox10.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox10.IconSize = 46;
            this.iconPictureBox10.Location = new System.Drawing.Point(226, 175);
            this.iconPictureBox10.Name = "iconPictureBox10";
            this.iconPictureBox10.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox10.TabIndex = 11;
            this.iconPictureBox10.TabStop = false;
            // 
            // iconPictureBox11
            // 
            this.iconPictureBox11.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.UsersCog;
            this.iconPictureBox11.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox11.IconSize = 46;
            this.iconPictureBox11.Location = new System.Drawing.Point(120, 227);
            this.iconPictureBox11.Name = "iconPictureBox11";
            this.iconPictureBox11.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox11.TabIndex = 12;
            this.iconPictureBox11.TabStop = false;
            // 
            // iconPictureBox12
            // 
            this.iconPictureBox12.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.User;
            this.iconPictureBox12.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox12.IconSize = 46;
            this.iconPictureBox12.Location = new System.Drawing.Point(279, 175);
            this.iconPictureBox12.Name = "iconPictureBox12";
            this.iconPictureBox12.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox12.TabIndex = 13;
            this.iconPictureBox12.TabStop = false;
            // 
            // iconPictureBox13
            // 
            this.iconPictureBox13.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.UserClock;
            this.iconPictureBox13.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox13.IconSize = 46;
            this.iconPictureBox13.Location = new System.Drawing.Point(67, 175);
            this.iconPictureBox13.Name = "iconPictureBox13";
            this.iconPictureBox13.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox13.TabIndex = 14;
            this.iconPictureBox13.TabStop = false;
            // 
            // iconPictureBox14
            // 
            this.iconPictureBox14.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            this.iconPictureBox14.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox14.IconSize = 46;
            this.iconPictureBox14.Location = new System.Drawing.Point(14, 175);
            this.iconPictureBox14.Name = "iconPictureBox14";
            this.iconPictureBox14.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox14.TabIndex = 15;
            this.iconPictureBox14.TabStop = false;
            // 
            // iconPictureBox16
            // 
            this.iconPictureBox16.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox16.IconChar = FontAwesome.Sharp.IconChar.UserFriends;
            this.iconPictureBox16.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox16.IconSize = 46;
            this.iconPictureBox16.Location = new System.Drawing.Point(67, 227);
            this.iconPictureBox16.Name = "iconPictureBox16";
            this.iconPictureBox16.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox16.TabIndex = 17;
            this.iconPictureBox16.TabStop = false;
            // 
            // iconPictureBox17
            // 
            this.iconPictureBox17.BackColor = System.Drawing.SystemColors.Control;
            this.iconPictureBox17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox17.IconChar = FontAwesome.Sharp.IconChar.UserCircle;
            this.iconPictureBox17.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPictureBox17.IconSize = 46;
            this.iconPictureBox17.Location = new System.Drawing.Point(173, 227);
            this.iconPictureBox17.Name = "iconPictureBox17";
            this.iconPictureBox17.Size = new System.Drawing.Size(47, 46);
            this.iconPictureBox17.TabIndex = 18;
            this.iconPictureBox17.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.iconPictureBox19);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(91, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(95, 83);
            this.panel4.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.iconPictureBox15);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(186, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(95, 83);
            this.panel5.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.iconPictureBox18);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(281, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(93, 83);
            this.panel6.TabIndex = 3;
            // 
            // iconPictureBox15
            // 
            this.iconPictureBox15.BackColor = System.Drawing.Color.BlueViolet;
            this.iconPictureBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.iconPictureBox15.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox15.IconChar = FontAwesome.Sharp.IconChar.Users;
            this.iconPictureBox15.IconColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox15.IconSize = 83;
            this.iconPictureBox15.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox15.Name = "iconPictureBox15";
            this.iconPictureBox15.Size = new System.Drawing.Size(95, 83);
            this.iconPictureBox15.TabIndex = 19;
            this.iconPictureBox15.TabStop = false;
            // 
            // iconPictureBox18
            // 
            this.iconPictureBox18.BackColor = System.Drawing.Color.BlueViolet;
            this.iconPictureBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.iconPictureBox18.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox18.IconChar = FontAwesome.Sharp.IconChar.UserCog;
            this.iconPictureBox18.IconColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox18.IconSize = 83;
            this.iconPictureBox18.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox18.Name = "iconPictureBox18";
            this.iconPictureBox18.Size = new System.Drawing.Size(93, 83);
            this.iconPictureBox18.TabIndex = 19;
            this.iconPictureBox18.TabStop = false;
            // 
            // iconPictureBox19
            // 
            this.iconPictureBox19.BackColor = System.Drawing.Color.BlueViolet;
            this.iconPictureBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.iconPictureBox19.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox19.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            this.iconPictureBox19.IconColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox19.IconSize = 83;
            this.iconPictureBox19.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox19.Name = "iconPictureBox19";
            this.iconPictureBox19.Size = new System.Drawing.Size(95, 83);
            this.iconPictureBox19.TabIndex = 19;
            this.iconPictureBox19.TabStop = false;
            // 
            // iconPictureBox20
            // 
            this.iconPictureBox20.BackColor = System.Drawing.Color.BlueViolet;
            this.iconPictureBox20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.iconPictureBox20.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox20.IconChar = FontAwesome.Sharp.IconChar.UserCheck;
            this.iconPictureBox20.IconColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.iconPictureBox20.IconSize = 83;
            this.iconPictureBox20.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox20.Name = "iconPictureBox20";
            this.iconPictureBox20.Size = new System.Drawing.Size(91, 83);
            this.iconPictureBox20.TabIndex = 19;
            this.iconPictureBox20.TabStop = false;
            // 
            // Frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 471);
            this.Controls.Add(this.iconPictureBox17);
            this.Controls.Add(this.iconPictureBox16);
            this.Controls.Add(this.iconPictureBox14);
            this.Controls.Add(this.iconPictureBox13);
            this.Controls.Add(this.iconPictureBox12);
            this.Controls.Add(this.iconPictureBox11);
            this.Controls.Add(this.iconPictureBox10);
            this.Controls.Add(this.iconPictureBox9);
            this.Controls.Add(this.iconPictureBox8);
            this.Controls.Add(this.iconPictureBox7);
            this.Controls.Add(this.iconPictureBox6);
            this.Controls.Add(this.iconPictureBox5);
            this.Controls.Add(this.iconPictureBox4);
            this.Controls.Add(this.iconPictureBox3);
            this.Controls.Add(this.iconPictureBox2);
            this.Controls.Add(this.iconPictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Frm_Main";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox17)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox20)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox16;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox17;
        private System.Windows.Forms.Panel panel6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox18;
        private System.Windows.Forms.Panel panel5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox15;
        private System.Windows.Forms.Panel panel4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox19;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox20;
    }
}

