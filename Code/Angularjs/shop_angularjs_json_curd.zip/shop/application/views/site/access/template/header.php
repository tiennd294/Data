<!DOCTYPE html>

<html lang="en"> 
<head>

  <!-- Basic Page Needs
  ================================================== -->
  <meta charset="utf-8">
  <title>Test web shop</title>
  <meta name="description" content="">
  <meta name="author" content="Ahmed Saeed">

  <!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  
  <!-- CSS
  ================================================== -->
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/main.css">
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/home.css">
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/home2.css">
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/blog.css">
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/responsive.css">
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/cart.css">

  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/about.css">
  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/account.css">
  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/checkout.css">
  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/contact.css">
  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/user_log.css">
  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/css/wish_list.css">
  <link rel="stylesheet" href="<?php echo public_url();?>/site/access/css/style.css">

  <link type="image/x-icon" href="<?php echo public_url();?>/site/access/template/images/favicon2.ico" rel="shortcut icon" />
  <link rel="shortcut icon" href="<?php echo public_url();?>/site/access/template/images/favicon2.ico">
  <link rel="apple-touch-icon" href="/site/access/template/images/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="<?php echo public_url();?>/site/access/template/images/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="<?php echo public_url();?>/site/access/template/images/apple-touch-icon-114x114.png">

   <!-- JS
  ================================================== -->
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.min.js"></script>

    <!-- jQuery.dropKick plug-in -->
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/js/dropKick/dropkick.css">
    <script src="<?php echo public_url();?>/site/access/template/js/dropKick/jquery.dropkick-1.0.0.js"></script>
    <!-- jQuery.nicescroll plug-in -->
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.nicescroll.js"></script>
    <!-- jQuery.tweet plug-in -->
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.tweet.js"></script>
    <!-- jQuery.cycle2 plug-in -->
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.cycle2.min.js"></script>
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.cycle2.tile.min.js"></script>
    <!-- jQuery.jcarousellite plug-in -->
    <script src="<?php echo public_url();?>/site/access/template/js/jcarousellite_1.0.1.min.js"></script>
    <!-- jQuery.fancybox plug-in -->
    <link rel="stylesheet" href="<?php echo public_url();?>/site/access/template/js/fancybox/jquery.fancybox-1.3.4.css">
    <script src="<?php echo public_url();?>/site/access/template/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <!-- jQuery.etalage plug-in -->
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.etalage.min.js"></script>
    <!-- jQuery.cookie plug-in -->
    <script src="<?php echo public_url();?>/site/access/template/js/jquery.cookie.js"></script>
    <!--my custom code--> 
    <script src="<?php echo public_url();?>/site/access/template/js/main.js"></script>
    <script src="<?php echo public_url();?>/site/access/js/productscart.js"></script>

<!-- End Document
================================================== -->
<style type="text/css">
    
</style>
<script type="text/javascript">
  function __test()
  {
    alert('Chức năng đang được xây dựng!');
  }
</script> 
</head>
<body>

  <!--start header-->
  <header>

    <div id="topHeader">
      <div class="container">
        <div class="sixteen columns">
          
          
          <ul id="topNav">
            <li><a class="unlinka" onclick="__test()" href="">Tài khoản</a></li>
            <li><a href="<?php echo base_url().'defaults/About'; ?>">Giới thiệu</a></li>
            <li><a href="<?php echo base_url().'defaults/Blog'; ?>">Sự kiện</a></li>
            <li><a href="<?php echo base_url(); ?>">Cửa hàng</a></li>
            <li><a href="<?php echo base_url().'defaults/Contact'; ?>">Liên hệ</a></li>
          </ul>

        </div><!--end sixteen-->
      </div><!--end container-->
    </div><!--end topHeader-->


    <div id="middleHeader">
      <div class="container">
        <div class="sixteen columns">
          <div id="logo">
            <h1><a href=""></a></h1>
          </div><!--end logo-->

          <form action="#" method="post" accept-charset="utf-8">
            <label>
              <input type="text" name="search" placeholder="Tìm kiếm" value="">
            </label>
            
            <div class="submit">
              <input class="unlinka" onclick="__test()" type="submit" name="submit">
            </div>
          </form><!--end form-->

        </div><!--end sixteen-->
      </div><!--end container-->
    </div><!--end middleHeader-->

    <?php
      $this->load->view('site/access/template/category');
    ?>

  </header>
  <!--end header-->

  <?php
    /*if (!isset($_GET['id'])) 
    {
      include_once PATH_PUBLIC . '/access/template/slideheader.php';
      //if (!isset($_GET['a']) {
        //include_once PATH_PUBLIC . '/access/template/slideheader.php';
      //}else{
        //if ($_GET['a']!='contact' || $_GET['a']!='about') {
          //include_once PATH_PUBLIC . '/access/template/slideheader.php';
        //}
      //}
      
    } 
      */
    //if (isset($_SESSION['product_cart'])) echo $_SESSION['product_cart'][0]['Name'];



  ?>


  


  <!-- strat the main content area -->
  
  <div class="container">

    
   

    


   