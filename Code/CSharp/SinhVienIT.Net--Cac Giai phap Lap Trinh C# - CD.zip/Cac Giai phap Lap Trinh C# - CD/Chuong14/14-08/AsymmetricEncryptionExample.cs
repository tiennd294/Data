using System;
using System.Text;
using System.Security.Cryptography;

public class AsymmetricEncryptionExample {

    public static void Main(string[] args) {

        RSAParameters recipientsPublicKey;

        CspParameters cspParams = new CspParameters();
        cspParams.KeyContainerName = "MyKeys";
        
        using (RSACryptoServiceProvider rsaAlg = 
            new RSACryptoServiceProvider(cspParams)) {

            rsaAlg.PersistKeyInCsp = true;
            
            recipientsPublicKey = rsaAlg.ExportParameters(false);
        }
        
        Console.WriteLine("Original message = {0}", args[0]);

        byte[] plaintext = Encoding.Unicode.GetBytes(args[0]);
                
        byte[] ciphertext = EncryptMessage(plaintext, recipientsPublicKey);
        
        Console.WriteLine("Formatted Ciphertext = {0}", 
            BitConverter.ToString(ciphertext));
        
        byte[] decData = DecryptMessage(ciphertext, cspParams);
        
        Console.WriteLine("Decrypted message = {0}", 
            Encoding.Unicode.GetString(decData));

        Console.ReadLine();
    }

    private static byte[] EncryptMessage(byte[] plaintext, 
        RSAParameters rsaParams) {
        
        byte[] ciphertext = null;
        
        using (RSACryptoServiceProvider rsaAlg = 
            new RSACryptoServiceProvider()) {
        
            rsaAlg.ImportParameters(rsaParams);

            ciphertext = rsaAlg.Encrypt(plaintext, true);
        }
        
        Array.Clear(plaintext, 0, plaintext.Length);
        
        return ciphertext;
    }

    private static byte[] DecryptMessage(byte[] ciphertext, 
        CspParameters cspParams ) {

        byte[] plaintext = null;
        
        using (RSACryptoServiceProvider rsaAlg = 
            new RSACryptoServiceProvider(cspParams)) {

            plaintext = rsaAlg.Decrypt(ciphertext, true);
        }
        
        return plaintext;
    }
}        