using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bansachnangcao
{
    public partial class frmbansachnc : Form
    {
        public frmbansachnc()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            double doublesl, doubledg, doublett, double15per, doubletra;
            doublesl = Convert.ToDouble(txtquantity.Text);
            doubledg = Convert.ToDouble(txtprice.Text);
            doublett = doublesl * doubledg;
            double15per = 0.15 * doublett;
            doubletra = doublett - double15per;
            txtextended.Text = '$' + doublett.ToString();
            txtdiscount.Text = '$' + double15per.ToString();
            txtdiscounted.Text = '$' + doubletra.ToString();
        }

        private void btnclearsale_Click(object sender, EventArgs e)
        {
            txtquantity.Text = null;
            txttitle.Text = null;
            txtprice.Text = null;
            txtextended.Text = null;
            txtdiscount.Text = null;
            txtdiscounted.Text = null;
            txttnob.Text = null;
            txttda.Text = null;
            txttdg.Text = null;
            txtad.Text = null;
        }
    }
}