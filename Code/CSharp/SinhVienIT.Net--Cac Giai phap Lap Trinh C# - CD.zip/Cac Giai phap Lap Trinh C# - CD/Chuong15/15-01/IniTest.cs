using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class IniTest
{
	private static void Main()
	{
		IniFileWrapper ini = new IniFileWrapper(Application.StartupPath + "\\initest.ini");
		string val = ini.GetIniValue("SampleSection", "Key1");
		Console.WriteLine("Value of Key1 in [SampleSection] is: " + val);
		ini.WriteIniValue("SampleSection", "Key1", "New Value");
		val = ini.GetIniValue("SampleSection", "Key1");
		Console.WriteLine("Value of Key1 in [SampleSection] is now: " + val);
		//ini.WriteIniValue("SampleSection", "Key1", "Value1");
		Console.ReadLine();
	}
}
public class IniFileWrapper
{

	private string filename;

	public string Filename
	{
		get {return filename;}
	}

	public IniFileWrapper(string filename)
	{
		this.filename = filename;
	}

	[DllImport("kernel32.dll", EntryPoint="GetPrivateProfileString")]
	private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName);

	[DllImport("kernel32.dll", EntryPoint="WritePrivateProfileString")]
	private static extern bool WritePrivateProfileString(string lpAppName, string lpKeyName, string lpString, string lpFileName);

	[DllImport("kernel32.dll", EntryPoint="WritePrivateProfileInt")]
	private static extern int GetPrivateProfileInt(string lpAppName, string lpKeyName, int iDefault, string lpFileName) ;

	[DllImport("kernel32.dll", EntryPoint="GetPrivateProfileSection")]
	private static extern int GetPrivateProfileSection(string lpAppName, byte[] lpReturnedString, int nSize, string lpFileName);

	[DllImport("kernel32.dll", EntryPoint="WritePrivateProfileSection")]
	private static extern bool WritePrivateProfileSection(string lpAppName, byte[] data, string lpFileName);

	[DllImport("kernel32.dll", EntryPoint="GetPrivateProfileSectionNames")]
	private static extern int GetPrivateProfileSectionNames(byte[] lpReturnedString, int nSize, string lpFileName);


	public string GetIniValue(string section, string key)
	{
		StringBuilder buffer = new StringBuilder();
		string sDefault = "";
		if (GetPrivateProfileString(section, key, sDefault, buffer, buffer.Capacity, filename) != 0 )
		{
			return buffer.ToString();
		}
		else
		{
			return null;
		}
	}

	public bool WriteIniValue(string section, string key, string value)
	{
		return WritePrivateProfileString(section, key, value, filename);
	}
    
}