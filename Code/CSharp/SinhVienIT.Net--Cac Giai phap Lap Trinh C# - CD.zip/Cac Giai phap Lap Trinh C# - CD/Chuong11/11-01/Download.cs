using System;
using System.Net;
using System.IO;

public class Download
{
	private static void Main()
	{
		string remoteUri = "http://localhost/winXP.gif";
		string localFileName = "winXP.gif";
		
		WebClient client = new WebClient();
		Console.WriteLine("Downloading file " + 
			remoteUri + " to " + Path.GetFullPath(localFileName));
		
		client.DownloadFile(remoteUri, localFileName);        
		Console.WriteLine("Download complete.");

		Console.ReadLine();
	}
}
