using System;
using System.Xml;
using System.Data;
using System.Data.SqlClient;

public class DisconnectedXmlQueryExample {

    public static void Main() {

		XmlDocument doc = new XmlDocument();

		using (SqlConnection con = new SqlConnection()) {

			con.ConnectionString = "Data Source = localhost;" + 
				"Database = Northwind; Integrated Security=SSPI";

			SqlCommand com = con.CreateCommand();
			com.CommandType = CommandType.Text;
			com.CommandText = 
				"SELECT CustomerID, CompanyName FROM Customers FOR XML AUTO";

			con.Open();

			XmlReader reader = com.ExecuteXmlReader();
			doc.LoadXml("<results></results>");

			XmlNode newNode = doc.ReadNode(reader);

			while (newNode != null) {

				doc.DocumentElement.AppendChild(newNode);
				newNode = doc.ReadNode(reader);
			}
		}

		Console.WriteLine(doc.OuterXml);

        Console.ReadLine();
    }
}
