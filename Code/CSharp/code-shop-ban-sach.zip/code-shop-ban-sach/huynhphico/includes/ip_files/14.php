<?php
//234881024-251658239
$ranges=Array(
);
?>