using System;

public class ExecuteAssemblyExample {

	public static void Main(string[] args) {

        if (AppDomain.CurrentDomain.FriendlyName != "NewAppDomain") {

            AppDomain domain = AppDomain.CreateDomain("NewAppDomain");

            domain.ExecuteAssembly("ExecuteAssemblyExample.exe", 
                null, args);
        }

        foreach (string s in args) {

            Console.WriteLine(AppDomain.CurrentDomain.FriendlyName + 
                " : " + s);
        }

        if (AppDomain.CurrentDomain.FriendlyName != "NewAppDomain") {
            Console.ReadLine();
        }
    }
}
