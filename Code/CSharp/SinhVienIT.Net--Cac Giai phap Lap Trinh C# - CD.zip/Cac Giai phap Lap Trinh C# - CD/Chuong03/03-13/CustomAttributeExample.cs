[assembly:Author("Square Nguyen", Company = "Goldsoft Ltd.")]

[Author("Square Nguyen", Company = "Goldsoft Ltd.")]
public class SomeClass {
    // Hiện thực lớp.
}

[Author("Bluewind Thai")]
public class SomeOtherClass {
    // Hiện thực lớp.
}
