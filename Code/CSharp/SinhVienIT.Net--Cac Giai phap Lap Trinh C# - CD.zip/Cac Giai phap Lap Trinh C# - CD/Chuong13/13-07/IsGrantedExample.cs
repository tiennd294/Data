public class IsGrantedExample {

    public static void Main() {
        
        bool canWrite = false;
        
        System.Security.Permissions.FileIOPermission fileIOPerm = 
            new System.Security.Permissions.FileIOPermission(
                System.Security.Permissions.FileIOPermissionAccess.Write, @"C:\Data");
                
        canWrite = System.Security.SecurityManager.IsGranted(fileIOPerm);
        
        System.Console.WriteLine(@"Can write to C:\Data? - {0}", canWrite);

        System.Console.ReadLine();
    }
}