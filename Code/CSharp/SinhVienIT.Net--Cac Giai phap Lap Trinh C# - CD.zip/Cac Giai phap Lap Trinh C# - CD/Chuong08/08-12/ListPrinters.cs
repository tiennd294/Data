using System;
using System.Drawing.Printing;

public class ListPrinters
{
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	private static void Main(string[] args)
	{		
		foreach (string printerName in PrinterSettings.InstalledPrinters)
		{
			Console.WriteLine("Printer: {0}", printerName);

			PrinterSettings printer = new PrinterSettings();
			printer.PrinterName = printerName;
			
			if (printer.IsValid)
			{
				Console.WriteLine("Supported Resolutions:");
			
				foreach (PrinterResolution resolution in printer.PrinterResolutions)
				{
					Console.WriteLine("  {0}", resolution);
				} 
				Console.WriteLine();

				Console.WriteLine("Supported Paper Sizes:");
            
				foreach (PaperSize size in printer.PaperSizes)
				{
					if (Enum.IsDefined(size.Kind.GetType(), size.Kind))
					{
						Console.WriteLine("  {0}", size);
					}
				}
				Console.WriteLine();
			}
		}
		Console.ReadLine();
	}
}