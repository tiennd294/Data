<?php 
$this->load->view('site/access/template/slideheader');

?>
<style type="text/css">
	
</style>
<br/><br/>
<div class="latest productsp">
			
			<div class="box_head">
				<h3>
				<?php 
					foreach ($category as $row): 
						echo $row->Name;
					endforeach;
				?>
				</h3>
				<div class="pagers center">
					
				</div>
			</div><br/><br/>
			<div class="cycle-slideshow" 
					        data-cycle-fx="scrollHorz"
					        data-cycle-timeout=0
					        data-cycle-slides="> ul"
					        data-cycle-prev="div.pagers a.latest_prev"
					        data-cycle-next="div.pagers a.latest_nxt"
					        >
					        <ul class="product_show">
			<?php 
				
				foreach ($tblproduct as $rowp): 
          			
?>
						
<?php
          			
?>
							<li class="column"><br/><br/>
								<div class="img">
								<?php if($rowp->Promotion>0) echo "<div class='offer_icon'></div>"; ?>
									<div class="hover_over">
										<a class="link" href="<?php echo base_url().'defaults/ShowProductid/'.$rowp->Idp; ?>">link</a>
										<a class="cart  unlinka" onclick="Set_cart('<?php echo $rowp->Idp; ?>','<?php echo $rowp->Name; ?>','<?php echo $rowp->Code; ?>','<?php if($rowp->Promotion>0) echo $rowp->Promotion;else echo $rowp->Price; ?>','<?php echo base_url().$rowp->Images; ?>')"  href="#">
										cart</a>
									</div>
									<a href="#">
										<img src="<?php echo base_url().$rowp->Images; ?>" alt="product">
									</a>
								</div>
								<h6><a href="<?php echo $rowp->Idp; ?>"><?php echo $rowp->Name; ?></a></h6>
								<h5>
								<?php if($rowp->Promotion>0) {
								?>
								<span class="sale_offer"><?php echo $rowp->Price; ?>.đ</span><br/>
								<?php echo $rowp->Promotion;?>.đ
								<?php } else echo "<br/>".$rowp->Price;?>
								.đ</h5><br/>
							</li>

						

<?php
    			endforeach;  
    			//echo('<pre>')  ;print_r($tblproduct) 	;echo('<pre>')  ;		
?>
				</ul>			
			</div>
		<br/><br/>
			<div class="pagination">
				<?php echo $this->pagination->create_links()?>
			</div>



</div>
<?php
	$this->load->view('site/defaults/cart');
?>