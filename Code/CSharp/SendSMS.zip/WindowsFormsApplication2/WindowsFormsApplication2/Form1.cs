﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SmsClient;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SendSms sms = new SendSms();

            string status = sms.send(txtName.Text, txtPassword.Text, txtBody.Text, txtReceiveNo.Text);

            if (status == "1")
            {

                MessageBox.Show("Message Send");

            }

            else if (status == "2")
            {

                MessageBox.Show("No Internet Connection");

            }

            else
            {

                MessageBox.Show("Invalid Login Or No Internet Connection");

            }
        }
    }
}
