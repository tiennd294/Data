<?php
Class News_Model extends MY_Model
{
    var $table = 'news';
    var $key = 'Idn';
}