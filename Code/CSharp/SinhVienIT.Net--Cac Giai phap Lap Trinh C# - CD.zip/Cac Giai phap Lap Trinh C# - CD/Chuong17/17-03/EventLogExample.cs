using System;
using System.Diagnostics;

public class EventLogExample {

    public static void Main () {

        if (!EventLog.SourceExists("EventLogExample")) {

            EventLog.CreateEventSource("EventLogExample","Application");
        }

        EventLog.WriteEntry(
            "EventLogExample",
            "A simple test event.", 
            EventLogEntryType.Information,
            1, 
            0,
            new byte[] {10, 55, 200}
        );

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}