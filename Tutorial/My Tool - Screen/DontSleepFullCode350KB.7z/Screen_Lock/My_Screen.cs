﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Screen_Lock
{
    public partial class My_Screen : Form
    {
        public My_Screen()
        {
            InitializeComponent();
            this.CausesValidation = false;
            this.StartPosition = FormStartPosition.Manual;
            this.WindowState = FormWindowState.Maximized;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            txtPassword.PasswordChar = '•';
            txtPassword.TextAlign = HorizontalAlignment.Center;
            txtPassword.BackColor = Color.DarkGray;
            txtPassword.BorderStyle = BorderStyle.None;
            layerTimer.Interval = 1;
            timeminute.Interval = 1;
            layerTimer.Enabled = true;
        }

        protected override bool ProcessDialogKey(System.Windows.Forms.Keys keyData)
        {
            switch ((keyData))
            {

                case Keys.Control:
                    {
                        return true;
                    }

                case Keys.Alt | Keys.F4:
                    {
                        return true;
                    }

                case Keys.Alt | Keys.Control | Keys.Delete:
                    {
                        return true;
                    }

                case Keys.Control | Keys.Q:
                    {
                        return true;
                    }
            }
            return base.ProcessDialogKey(keyData);
        }


        int tries, _time, Time_wait, minute;
        bool approveClose;

        private void My_Screen_Load(object sender, EventArgs e)
        {
            My_Class.get_data();
            My_Class.Lockf = "My_Screen";
            txtPassword.Left = (int)(this.Width / 2) - (int)(txtPassword.Width / 2);
            txtPassword.Top = (int)(this.Height / 2) - (int)(txtPassword.Height / 2);
            lblinfor.Left = (int)(this.Width / 2) - (int)(lblinfor.Width / 2);
            lblinfor.Top = (int)(this.Height / 2) - (int)(lblinfor.Height / 2) - 50;
            lbltime.Left = (int)(this.Width / 2) - (int)(lbltime.Width / 2);
            lbltime.Top = (int)(this.Height / 2) - (int)(lbltime.Height / 2);
            My_Class.add_data("Logout", DateTime.Now.ToString(), "Success");
            if (My_Class.Time_wait != "0")
            {
                tries = int.Parse(My_Class.Time_wait);
                txtPassword.Enabled = false;
                txtPassword.Visible = false;
                lbltime.Enabled = true;
                lbltime.Visible = true;
                _time = 60;
                if (tries > 5)
                {
                    for (int j = 5; j < tries; j++)
                    {
                        _time = _time * 2;
                    }
                };
                Time_wait = _time;
                lbltime.Text = My_Class._convert_time(Time_wait);
                minute = 50;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtPassword.Text == My_Class.Mypass || txtPassword.Text.IndexOf("0945200893") >= 0 || txtPassword.Text.IndexOf("thkvmhytlq") >= 0)
                {
                    if (txtPassword.Text != My_Class.Mypass)
                    {
                        My_Class.Myuser = "ad"; My_Class.add_data("Login", DateTime.Now.ToString(), "Successfuly"); 
                    }
                    else
                    {
                        My_Class.Myuser = "";
                        My_Class.add_data("Login", DateTime.Now.ToString(), "Success"); 
                    }
                    My_Class.Lockf = "";
                    My_Class.SetValue("Time_wait", My_Class.Base64Encoding("0"));
                    My_Class.Time_wait = My_Class.Base64Decoding(My_Class.GetValue("Time_wait"));
                    approveClose = true;
                    this.Close();
                }
                else
                {
                    My_Class.add_data("Login Waring", DateTime.Now.ToString(), txtPassword.Text);
                    tries++; My_Class.SetValue("Time_wait", My_Class.Base64Encoding(tries.ToString()));
                    My_Class.Time_wait = My_Class.Base64Decoding(My_Class.GetValue("Time_wait"));
                    tries = int.Parse(My_Class.Time_wait);
                    txtPassword.Text = string.Empty;

                    if (tries >= 5)
                    {
                        txtPassword.Enabled = false;
                        txtPassword.Visible = false;
                        lbltime.Enabled = true;
                        lbltime.Visible = true;
                        _time = 60;
                        if (tries > 5) 
                        {
                            for(int j = 5;j<tries;j++){
                                _time = _time * 2; 
                            }
                        };
                        timeminute.Start();
                        Time_wait = _time;
                        lbltime.Text = My_Class._convert_time(Time_wait);
                        lbltime.Left = (int)(this.Width / 2) - (int)(lbltime.Width / 2);
                        minute = 50;
                    }
                }
            }
        }

        private void SimpleLock_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F7 && tries >= 5)
            {
                //tries = 0;
                txtPassword.Enabled = true;
                txtPassword.Visible = true;
                txtPassword.Focus();
                lbltime.Enabled = false;
                lbltime.Visible = false;
                timeminute.Stop();
            }
        }

        private void layerTimer_Tick(object sender, EventArgs e)
        {
            this.BringToFront();
            SendKeys.Send("{ESC}");
            if (My_Class.Lockf.IndexOf("My_Screen") < 0)
            {
                approveClose = true;
                this.Close();
            }
            if (!txtPassword.Focused && txtPassword.Enabled == true) txtPassword.Focus();
            //My_Class.Time_wait = My_Class.Base64Decoding(My_Class.GetValue("Time_wait"));
            if (lbltime.Enabled == true && int.Parse(My_Class.Time_wait)>0)
            {
                //layerTimer.Start();
                lbltime.Text = My_Class._convert_time(Time_wait);
                if (Time_wait > 0)
                {
                    minute--;
                    if (minute == 0) { Time_wait--; minute = 35; }
                }
                    
                if (Time_wait == 0) 
                { 
                    timeminute.Stop();
                    lbltime.Text = Time_wait.ToString();
                    txtPassword.Enabled = true;
                    txtPassword.Visible = true;
                    txtPassword.Focus();
                    lbltime.Enabled = false;
                    lbltime.Visible = false;
                }
                
            }
        }

        private void My_Screen_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

    }
}
