using System;
using System.Data;
using System.Data.SqlClient;

public class DataReaderExample {

    public static void Main() {

        using (SqlConnection con = new SqlConnection()) {

            con.ConnectionString = "Data Source = localhost;" + 
                "Database = Northwind; Integrated Security=SSPI";

            SqlCommand com = con.CreateCommand();
            com.CommandType = CommandType.Text;
            com.CommandText = "SELECT BirthDate,FirstName,LastName FROM " +
                "Employees ORDER BY BirthDate;SELECT * FROM Employees";

            con.Open();

            using (SqlDataReader reader = com.ExecuteReader()) {

                Console.WriteLine("Employee Birthdays (By Age).");

                while (reader.Read()) {

                    Console.WriteLine("{0,18:D} - {1} {2}", 
                        reader.GetDateTime(0),
                        reader["FirstName"],
                        reader[2]);
                }

                reader.NextResult();
                Console.WriteLine("Employee Table Metadata.");
                for (int field = 0; field < reader.FieldCount; field++) {

                    Console.WriteLine("  Column Name:{0}  Type:{1}",
                        reader.GetName(field), 
                        reader.GetDataTypeName(field));
                }

            }
        }

        Console.ReadLine();
    }
}
