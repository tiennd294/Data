using System;
using System.IO;
using System.Security.Principal;
using System.Security.Permissions;
using System.Runtime.InteropServices;

[assembly:SecurityPermission(SecurityAction.RequestMinimum,
    UnmanagedCode=true, ControlPrincipal=true)]

public class ImpersonationExample {
	
    const int LOGON32_PROVIDER_DEFAULT = 0;
    const int LOGON32_LOGON_INTERACTIVE = 2;

    [DllImport("advapi32.dll", SetLastError=true)]
    static extern int LogonUser(string userName, string domain, 
        string password, int logonType, int logonProvider,
        ref IntPtr accessToken);

    public static void Main(string[] args) {

        IntPtr accessToken = IntPtr.Zero;
        
        int result = LogonUser(
            args[0],
            ".",
            args[1],
            LOGON32_LOGON_INTERACTIVE,
            LOGON32_PROVIDER_DEFAULT,
            ref accessToken
        );
        
        if (result == 0)  {        	

            Console.WriteLine("LogonUser returned error {0}", 
                Marshal.GetLastWin32Error());
            
        } else {
        	
            WindowsIdentity identity = new WindowsIdentity(accessToken);
    
            Console.WriteLine("Identity before impersonation = {0}",
                WindowsIdentity.GetCurrent().Name);

            WindowsImpersonationContext impContext = 
                identity.Impersonate();

            Console.WriteLine("Identity during impersonation = {0}",
                WindowsIdentity.GetCurrent().Name);

            impContext.Undo();

            Console.WriteLine("Identity after impersonation = {0}",
                WindowsIdentity.GetCurrent().Name);
        }
		Console.ReadLine();
	}
}
