using System;
using System.Windows.Forms;
using System.Threading;
using System.Globalization;

public class Form1 : System.Windows.Forms.Form
{
	private System.Windows.Forms.Label label1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public Form1()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
		this.label1 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.AccessibleDescription = resources.GetString("label1.AccessibleDescription");
		this.label1.AccessibleName = resources.GetString("label1.AccessibleName");
		this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label1.Anchor")));
		this.label1.AutoSize = ((bool)(resources.GetObject("label1.AutoSize")));
		this.label1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label1.Dock")));
		this.label1.Enabled = ((bool)(resources.GetObject("label1.Enabled")));
		this.label1.Font = ((System.Drawing.Font)(resources.GetObject("label1.Font")));
		this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
		this.label1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.ImageAlign")));
		this.label1.ImageIndex = ((int)(resources.GetObject("label1.ImageIndex")));
		this.label1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label1.ImeMode")));
		this.label1.Location = ((System.Drawing.Point)(resources.GetObject("label1.Location")));
		this.label1.Name = "label1";
		this.label1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label1.RightToLeft")));
		this.label1.Size = ((System.Drawing.Size)(resources.GetObject("label1.Size")));
		this.label1.TabIndex = ((int)(resources.GetObject("label1.TabIndex")));
		this.label1.Text = resources.GetString("label1.Text");
		this.label1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.TextAlign")));
		this.label1.Visible = ((bool)(resources.GetObject("label1.Visible")));
		// 
		// Form1
		// 
		this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
		this.AccessibleName = resources.GetString("$this.AccessibleName");
		this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
		this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
		this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
		this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
		this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
		this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
		this.Controls.Add(this.label1);
		this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
		this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
		this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
		this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
		this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
		this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
		this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
		this.Name = "Form1";
		this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
		this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
		this.Text = resources.GetString("$this.Text");
		this.Load += new System.EventHandler(this.Form1_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Thread.CurrentThread.CurrentUICulture = new CultureInfo("vi");
		Application.Run(new Form1());
	}

	private void Form1_Load(object sender, System.EventArgs e)
	{
		
	}
}