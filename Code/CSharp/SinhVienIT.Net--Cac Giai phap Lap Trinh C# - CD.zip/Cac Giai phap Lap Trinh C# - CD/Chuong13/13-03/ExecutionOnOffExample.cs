public class ExecutionOnOffExample {

    public static void Main() {
    
        System.Security.SecurityManager.CheckExecutionRights = false;
        
        System.Security.SecurityManager.SavePolicy();
        
        System.Security.SecurityManager.CheckExecutionRights = true;
        
        System.Security.SecurityManager.SavePolicy();
    }
}
