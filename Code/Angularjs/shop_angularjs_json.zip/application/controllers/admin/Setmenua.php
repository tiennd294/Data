<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Setmenua extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Setmenua_Model');
        $this->load->model('Users_Model');
    }

    public function Index()
    {
        $input = array();
        $tblsetmenua=$this->Setmenua_Model->get_list($input);
        $tblmenu=$this->Setmenua_Model->loadmenu();

        $input['where'] = array('Usersnames' => $this->session->userdata('Administrator'));
        $level=$this->Users_Model->get_list($input);
        $link='admin/Error/error';
        
        foreach ($level as $row) {
            if ($row->Level==10) {
                $link='admin/Setmenua/setmenua';
            }
        }

        $data = array(
            'urldata' => $link,
            'tblsetmenua' => $tblsetmenua,
            'tblmenu' => $tblmenu
         );
        $this->load->view('admin/layout',$data);

        
    }

    public function Add()
    {
        $data = array(
            'Idset' => $this->input->post('atextdata1'),
            'Name' => $this->input->post('atextdata2'),
            'Icon' => $this->input->post('atextdata3'),
            'Classify' => $this->input->post('atextdata5'),
            'Startus' => $this->input->post('atextdata4')
        );
        $this->Setmenua_Model->create($data);
    }


    public function Edit()
    {
        $data = array(
            'Name' => $this->input->post('etextdata1'),
            'Icon' => $this->input->post('etextdata2'),
            'Startus' => $this->input->post('etextdata3')
        );
        if($this->input->post('etextid')){
        
            $Id = $this->input->post('etextid');
            $this->Setmenua_Model->update($Id,$data);
        
        }
    }


   public function Delete()
   {
        if($this->input->post('textid')){
             $Id  = $this->input->post('textid');
             $this->Setmenua_Model->delete($Id);
       
        }
    }
}