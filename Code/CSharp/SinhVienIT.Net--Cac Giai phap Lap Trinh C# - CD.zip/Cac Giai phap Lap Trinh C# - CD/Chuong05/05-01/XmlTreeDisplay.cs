using System;
using System.Windows.Forms;
using System.Xml;

public class XmlTreeDisplay : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button cmdLoad;
	private System.Windows.Forms.TextBox txtXmlFile;
	private System.Windows.Forms.TreeView treeXml;
	private System.Windows.Forms.Label lblFile;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public XmlTreeDisplay()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.treeXml = new System.Windows.Forms.TreeView();
		this.txtXmlFile = new System.Windows.Forms.TextBox();
		this.cmdLoad = new System.Windows.Forms.Button();
		this.lblFile = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// treeXml
		// 
		this.treeXml.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.treeXml.ImageIndex = -1;
		this.treeXml.Location = new System.Drawing.Point(8, 44);
		this.treeXml.Name = "treeXml";
		this.treeXml.SelectedImageIndex = -1;
		this.treeXml.Size = new System.Drawing.Size(348, 264);
		this.treeXml.TabIndex = 0;
		// 
		// txtXmlFile
		// 
		this.txtXmlFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.txtXmlFile.Location = new System.Drawing.Point(44, 12);
		this.txtXmlFile.Name = "txtXmlFile";
		this.txtXmlFile.Size = new System.Drawing.Size(240, 21);
		this.txtXmlFile.TabIndex = 1;
		this.txtXmlFile.Text = "ProductCatalog.xml";
		// 
		// cmdLoad
		// 
		this.cmdLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.cmdLoad.Location = new System.Drawing.Point(300, 12);
		this.cmdLoad.Name = "cmdLoad";
		this.cmdLoad.Size = new System.Drawing.Size(56, 24);
		this.cmdLoad.TabIndex = 2;
		this.cmdLoad.Text = "Load";
		this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
		// 
		// lblFile
		// 
		this.lblFile.Location = new System.Drawing.Point(12, 16);
		this.lblFile.Name = "lblFile";
		this.lblFile.Size = new System.Drawing.Size(28, 16);
		this.lblFile.TabIndex = 3;
		this.lblFile.Text = "File:";
		// 
		// XmlTreeDisplay
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(364, 322);
		this.Controls.Add(this.lblFile);
		this.Controls.Add(this.cmdLoad);
		this.Controls.Add(this.txtXmlFile);
		this.Controls.Add(this.treeXml);
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "XmlTreeDisplay";
		this.Text = "XML Tree";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new XmlTreeDisplay());
	}

	private void cmdLoad_Click(object sender, System.EventArgs e)
	{
		treeXml.Nodes.Clear();

		XmlDocument doc = new XmlDocument();
		try
		{
			doc.Load(txtXmlFile.Text);
		}
		catch (Exception err)
		{
			MessageBox.Show(err.Message);
			return;
		}
		
		ConvertXmlNodeToTreeNode(doc, treeXml.Nodes);
		
		treeXml.Nodes[0].ExpandAll();
		
		XmlElement root=doc.DocumentElement;
		MessageBox.Show(root.InnerText,"InnerText");
		MessageBox.Show(root.InnerXml,"InnerXml");
		MessageBox.Show(root.OuterXml,"OuterXml");
	}

	private void ConvertXmlNodeToTreeNode(XmlNode xmlNode, TreeNodeCollection treeNodes)
	{
		TreeNode newTreeNode = treeNodes.Add(xmlNode.Name);
		
		switch (xmlNode.NodeType)
		{
			case XmlNodeType.ProcessingInstruction:
			case XmlNodeType.XmlDeclaration:
				newTreeNode.Text = "<?" + xmlNode.Name + " " + xmlNode.Value + "?>";
				break;
			case XmlNodeType.Element:
				newTreeNode.Text = "<" + xmlNode.Name + ">";
				break;
			case XmlNodeType.Attribute:
				newTreeNode.Text = "ATTRIBUTE: " + xmlNode.Name;
				break;
			case XmlNodeType.Text:
			case XmlNodeType.CDATA:
				newTreeNode.Text = xmlNode.Value;
				break;
			case XmlNodeType.Comment:
				newTreeNode.Text = "<!--" + xmlNode.Value + "-->";
				break;		
		}

		if (xmlNode.Attributes != null)
		{
			foreach (XmlAttribute attribute in xmlNode.Attributes)
			{
				ConvertXmlNodeToTreeNode(attribute, newTreeNode.Nodes);
			}
		}
		
		foreach (XmlNode childNode in xmlNode.ChildNodes)
		{
			ConvertXmlNodeToTreeNode(childNode, newTreeNode.Nodes);
		}
	}


}