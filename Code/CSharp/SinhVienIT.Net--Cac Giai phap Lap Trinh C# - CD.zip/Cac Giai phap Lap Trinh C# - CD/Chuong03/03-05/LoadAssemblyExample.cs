using System;
using System.Reflection;
using System.Globalization;

public class LoadAssemblyExample
{
	public static void Main() {

        Console.WriteLine("**** BEFORE ****");
        ListAssemblies();

        string name1 = "System.Data,Version=1.0.5000.0," + 
                        "Culture=neutral,PublicKeyToken=b77a5c561934e089";
        Assembly a1 = Assembly.Load(name1);

        AssemblyName name2 = new AssemblyName();
        name2.Name = "System.Xml";
        name2.Version = new Version(1,0,5000,0);
        name2.CultureInfo = new CultureInfo("");
        name2.SetPublicKeyToken(
            new byte[] {0xb7,0x7a,0x5c,0x56,0x19,0x34,0xe0,0x89});
        Assembly a2 = Assembly.Load(name2);

        Assembly a3 = Assembly.Load("SomeAssembly");

        Assembly a4 = Assembly.LoadFrom(@"c:\shared\MySharedAssembly.dll");
    
        Console.WriteLine("**** AFTER ****");
        ListAssemblies();

        Console.ReadLine();
    }

    public static void ListAssemblies () {
     
        Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();

        foreach (Assembly a in assemblies) {

            Console.WriteLine(a.GetName());

        }
    }
}
