<?php
//603979776-620756991
$ranges=Array(
);
?>