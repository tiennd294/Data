using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class ConnectionExample {

    public static void Main() {

        SqlConnectionExample();
        Console.WriteLine(Environment.NewLine);

        OleDbConnectionExample();

        Console.ReadLine();
    }

    public static void SqlConnectionExample() {

        using (SqlConnection con = new SqlConnection()) {

            con.ConnectionString = 
                "Data Source = localhost;"+
                "Database = Northwind;" +
                "Integrated Security=SSPI";

            con.Open();

            if (con.State == ConnectionState.Open) {
                Console.WriteLine("SqlConnection Information:");
                Console.WriteLine("  Connection State = " + con.State);
                Console.WriteLine("  Connection String = " + 
                    con.ConnectionString);
                Console.WriteLine("  Database Source = " + con.DataSource);
                Console.WriteLine("  Database = " + con.Database);
                Console.WriteLine("  Server Version = " + con.ServerVersion);
                Console.WriteLine("  Workstation Id = " + con.WorkstationId);
                Console.WriteLine("  Timeout = " + con.ConnectionTimeout);
                Console.WriteLine("  Packet Size = " + con.PacketSize);
            } else {
                Console.WriteLine("SqlConnection failed to open.");
                Console.WriteLine("  Connection State = " + con.State);
            }
        }
    }

    public static void OleDbConnectionExample() {

        using (OleDbConnection con = new OleDbConnection()) {

            con.ConnectionString = 
                "Provider = SQLOLEDB;" + 
                "Data Source = localhost;" +
                "Initial Catalog = Northwind;" +
                "Integrated Security=SSPI";

            con.Open();

            if (con.State == ConnectionState.Open) {
                Console.WriteLine("OleDbConnection Information:");
                Console.WriteLine("  Connection State = " + con.State);
                Console.WriteLine("  Connection String = " + 
                    con.ConnectionString);
                Console.WriteLine("  Database Source = " + con.DataSource);
                Console.WriteLine("  Database = " + con.Database);
                Console.WriteLine("  Server Version = " + con.ServerVersion);
                Console.WriteLine("  Timeout = " + con.ConnectionTimeout);
            } else {
                Console.WriteLine("OleDbConnection failed to open.");
                Console.WriteLine("  Connection State = " + con.State);
            }
        }
    }
}
