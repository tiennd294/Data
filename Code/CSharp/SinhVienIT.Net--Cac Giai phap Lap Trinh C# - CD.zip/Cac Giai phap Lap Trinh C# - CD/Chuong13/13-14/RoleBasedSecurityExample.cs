using System;
using System.Threading;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Principal;
using System.Security.Permissions;

public class RoleBasedSecurityExample {
    
    public static void Main() {

        AppDomain appDomain = System.AppDomain.CurrentDomain;
        
        appDomain.SetPrincipalPolicy(
            System.Security.Principal.PrincipalPolicy.WindowsPrincipal);
        
        Console.WriteLine(Thread.CurrentPrincipal.Identity.Name);

        try {
            ImperativeExample.ProtectedMethod1();        
        } catch (SecurityException) {
            Console.WriteLine("SecurityException in ImperativeExample.ProtectedMethod1");
        }
        
        try {
            ImperativeExample.ProtectedMethod2();        
        } catch (SecurityException) {
            Console.WriteLine("SecurityException in ImperativeExample.ProtectedMethod2");
        }
        
        try {
            ImperativeExample.ProtectedMethod3();        
        } catch (SecurityException) {
            Console.WriteLine("SecurityException in ImperativeExample.ProtectedMethod3");
        }

        try {
            DeclarativeExample.ProtectedMethod1();        
        } catch (SecurityException) {
            Console.WriteLine("SecurityException in DeclarativeExample.ProtectedMethod1");
        }
        try {
            DeclarativeExample.ProtectedMethod2();        
        } catch (SecurityException) {
            Console.WriteLine("SecurityException in DeclarativeExample.ProtectedMethod2");
        }
        try {
            DeclarativeExample.ProtectedMethod3();        
        } catch (SecurityException) {
            Console.WriteLine("SecurityException in DeclarativeExample.ProtectedMethod3");
        }

        Console.ReadLine();
    }
}

public class ImperativeExample {
    
    public static void ProtectedMethod1() { 
        
        System.Security.Permissions.PrincipalPermission perm = 
            new System.Security.Permissions.PrincipalPermission
            (@"MACHINE\Anya", null);
            
        perm.Demand();
    }
    
    public static void ProtectedMethod2() { 

        System.Security.Permissions.PrincipalPermission perm1 = 
            new System.Security.Permissions.PrincipalPermission
            (null, @"MACHINE\Managers");

        System.Security.Permissions.PrincipalPermission perm2 = 
            new System.Security.Permissions.PrincipalPermission
            (null, @"MACHINE\Developers");

        perm1.Union(perm2).Demand();
    }

    public static void ProtectedMethod3() { 

        System.Security.Permissions.PrincipalPermission perm = 
            new System.Security.Permissions.PrincipalPermission
            (@"MACHINE\Anya", @"MACHINE\Managers");
            
        perm.Demand();
    }
}

public class DeclarativeExample {
    
    [PrincipalPermission(SecurityAction.Demand, Name = @"MACHINE\Anya")]
    public static void ProtectedMethod1() { /*...*/}

    [PrincipalPermission(SecurityAction.Demand, Role = @"MACHINE\Managers")]
    [PrincipalPermission(SecurityAction.Demand, Role = @"MACHINE\Developers")]    
    public static void ProtectedMethod2() { /*...*/}

    [PrincipalPermission(SecurityAction.Demand, Name = @"MACHINE\Anya", 
        Role = @"MACHINE\Managers")]
    public static void ProtectedMethod3() { /*...*/}
}