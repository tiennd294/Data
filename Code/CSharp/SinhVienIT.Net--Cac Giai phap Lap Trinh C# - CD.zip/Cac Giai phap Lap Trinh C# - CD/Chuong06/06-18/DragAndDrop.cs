using System;
using System.Windows.Forms;

public class DragAndDrop : System.Windows.Forms.Form
{
	internal System.Windows.Forms.TextBox TextBox2;
	internal System.Windows.Forms.TextBox TextBox1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DragAndDrop()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.TextBox2 = new System.Windows.Forms.TextBox();
		this.TextBox1 = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// TextBox2
		// 
		this.TextBox2.AllowDrop = true;
		this.TextBox2.Location = new System.Drawing.Point(28, 84);
		this.TextBox2.Name = "TextBox2";
		this.TextBox2.Size = new System.Drawing.Size(196, 20);
		this.TextBox2.TabIndex = 3;
		this.TextBox2.Text = "TextBox2";
		this.TextBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TextBox_MouseDown);
		this.TextBox2.DragDrop += new System.Windows.Forms.DragEventHandler(this.TextBox_DragDrop);
		this.TextBox2.DragEnter += new System.Windows.Forms.DragEventHandler(this.TextBox_DragEnter);
		// 
		// TextBox1
		// 
		this.TextBox1.AllowDrop = true;
		this.TextBox1.Location = new System.Drawing.Point(28, 36);
		this.TextBox1.Name = "TextBox1";
		this.TextBox1.Size = new System.Drawing.Size(196, 20);
		this.TextBox1.TabIndex = 2;
		this.TextBox1.Text = "TextBox1";
		this.TextBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TextBox_MouseDown);
		this.TextBox1.DragDrop += new System.Windows.Forms.DragEventHandler(this.TextBox_DragDrop);
		this.TextBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.TextBox_DragEnter);
		// 
		// DragAndDrop
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.TextBox2,
																		this.TextBox1});
		this.Name = "DragAndDrop";
		this.Text = "Form1";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new DragAndDrop());
	}

	private void TextBox_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
	{
		TextBox txt = (TextBox)sender;
		txt.SelectAll();
		txt.DoDragDrop(txt.Text, DragDropEffects.Copy);
	}

	private void TextBox_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
	{
		if (e.Data.GetDataPresent(DataFormats.Text))
		{
			e.Effect = DragDropEffects.Copy;
		}
		else
		{
			e.Effect = DragDropEffects.None;
		}
	}

	private void TextBox_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
	{
		TextBox txt = (TextBox)sender;
		txt.Text = (string)e.Data.GetData(DataFormats.Text);
	}
}
