using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BT2_Hoten
{
    public partial class BT2_Hoten : Form
    {
        public BT2_Hoten()
        {
            InitializeComponent();
        }

        private void btnHoLot_Click(object sender, EventArgs e)
        {
            lblHoTen.Text = txtHoLot.Text;
        }

        private void btnTen_Click(object sender, EventArgs e)
        {
            lblHoTen.Text = txtTen.Text;
        }

        private void btnHoVaTen_Click(object sender, EventArgs e)
        {
            lblHoTen.Text=txtHoLot.Text+txtTen.Text;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtTen_TextChanged(object sender, EventArgs e)
        {
            lblTen.Text = txtTen.Text;
        }

        private void txtHoLot_TextChanged(object sender, EventArgs e)
        {
            lblHoLot.Text = txtHoLot.Text;
        }

        private void btnHoLot_Click_1(object sender, EventArgs e)
        {
            lblHoTen.Text = txtHoLot.Text;
        }

        

     

       

        
    }
}