<?php
//33554432-50331647
$ranges=Array(
);
?>