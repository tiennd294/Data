======================================================================
�ySoft name�z PDForsell
�yVersion�z 2.1
�yRelease date�z2/25/2011
�yKind of soft�z FreeWare
�yProgram OS�z Windows XP/Vista/7
�yRequired�z .Net Framework 2.0 or newer (Except 4.0)
�yDev. Lang�z Visual Studio 2010
�yCopylight�z Copylight Yomogi Software
�yU  R  L�z http://yomogi.bakufu.org/en/indexen.html
�yE-mail�z yomogi08@gmail.com
======================================================================
��Summary
The PDF becomes the general file format now and can watch a PDF file if Adobe Reader is installed. But we cannot edit a PDF file. If it purchases charged Adobe Acrobat, It's possible, but it's not a so cheap thing.

PDForsell realizes the editing of the PDF file and a preview by using the free PDF editing library.
You can unite plural PDF files if you use PDForsell and separate one file into two and can turn only in the page that there is. In addition, you can decrypt a PDF file and can encrypt it by password.

Functions
	Separate, rotate, merge
	Encrypt and decrypt a file by password 
	Transposition of the file and pages 
	Preview PDF files

��Licence
Base on GPLv3.
http://www.gnu.org/licenses/gpl-3.0.html

For edit PDF files, PDForsell uses iTextSharp.
iText	http://itextpdf.com/
iTextSharp	http://sourceforge.net/projects/itextsharp/

Render PDF files, PDForsell uses cube-pdf modify version of PDFLibNet.
PDFLibNet	http://www.codeproject.com/KB/files/xpdf_csharp.aspx
cube-pdf-PDFLibNet	https://github.com/cube-soft/PDFLibNet

Thanks so much!!

