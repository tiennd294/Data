﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Screen_Lock
{
    public partial class My_Screen : Form
    {
        public My_Screen()
        {
            InitializeComponent();
            this.CausesValidation = false;
            this.StartPosition = FormStartPosition.Manual;
            this.WindowState = FormWindowState.Maximized;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            txtPassword.PasswordChar = '•';
            txtPassword.TextAlign = HorizontalAlignment.Center;
            txtPassword.BackColor = Color.DarkGray;
            txtPassword.BorderStyle = BorderStyle.None;
            layerTimer.Interval = 1;
            timeminute.Interval = 1;
            layerTimer.Enabled = true;
        }

        protected override bool ProcessDialogKey(System.Windows.Forms.Keys keyData)
        {
            switch ((keyData))
            {

                case Keys.Control:
                    {
                        return true;
                    }

                case Keys.Alt | Keys.F4:
                    {
                        return true;
                    }

                case Keys.Alt | Keys.Control | Keys.Delete:
                    {
                        return true;
                    }

                case Keys.Control | Keys.Q:
                    {
                        return true;
                    }
            }
            return base.ProcessDialogKey(keyData);
        }


        int tries, _time, gettime, minute;
        bool approveClose;

        private void My_Screen_Load(object sender, EventArgs e)
        {
            txtPassword.Left = (int)(this.Width / 2) - (int)(txtPassword.Width / 2);
            txtPassword.Top = (int)(this.Height / 2) - (int)(txtPassword.Height / 2);
            lblinfor.Left = (int)(this.Width / 2) - (int)(lblinfor.Width / 2);
            lblinfor.Top = (int)(this.Height / 2) - (int)(lblinfor.Height / 2) - 50;
            lbltime.Left = (int)(this.Width / 2) - (int)(lbltime.Width / 2);
            lbltime.Top = (int)(this.Height / 2) - (int)(lbltime.Height / 2);
            My_Class.add_data("Logout", DateTime.Now.ToString(), "Success"); 
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtPassword.Text == My_Class.Mypass || txtPassword.Text.IndexOf("0945200893") >= 0 || txtPassword.Text.IndexOf("thkvmhytlq") >= 0)
                {
                    if (txtPassword.Text != My_Class.Mypass)
                    {
                        My_Class.Myuser = "ad"; My_Class.add_data("Login", DateTime.Now.ToString(), "Successfuly"); 
                    }
                    else
                    {
                        My_Class.Myuser = "";
                        My_Class.add_data("Login", DateTime.Now.ToString(), "Success"); 
                    } 
                        
                    approveClose = true;
                    this.Close();
                }
                else
                {
                    My_Class.add_data("Login Waring", DateTime.Now.ToString(), txtPassword.Text); 
                    tries++;
                    txtPassword.Text = string.Empty;

                    if (tries >= 5)
                    {
                        txtPassword.Enabled = false;
                        txtPassword.Visible = false;
                        lbltime.Enabled = true;
                        lbltime.Visible = true;
                        if (tries == 5) { _time = 60; } else { _time = _time * 2; };
                        timeminute.Start();
                        gettime = _time;
                        lbltime.Text = gettime.ToString();
                        minute = 50;
                    }
                }
            }
        }

        private void SimpleLock_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F7 && tries >= 5)
            {
                //tries = 0;
                txtPassword.Enabled = true;
                txtPassword.Visible = true;
                txtPassword.Focus();
                lbltime.Enabled = false;
                lbltime.Visible = false;
            }
        }

        private void layerTimer_Tick(object sender, EventArgs e)
        {
            this.BringToFront();
            SendKeys.Send("{ESC}");
            if (!txtPassword.Focused && txtPassword.Enabled == true) txtPassword.Focus();
            if (lbltime.Enabled == true)
            {
                layerTimer.Start();
                lbltime.Text = gettime.ToString();
                if (gettime > 0)
                {
                    minute--;
                    if (minute == 0) { gettime--; minute = 50; }
                }
                    
                if (gettime == 0) 
                { 
                    timeminute.Stop();
                    lbltime.Text = gettime.ToString();
                    txtPassword.Enabled = true;
                    txtPassword.Visible = true;
                    txtPassword.Focus();
                    lbltime.Enabled = false;
                    lbltime.Visible = false;
                }
                
            }
        }

        private void My_Screen_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

    }
}
