<?php
Class Users_Model extends MY_Model
{
    var $table = 'users';
    var $key = 'Idus';
}