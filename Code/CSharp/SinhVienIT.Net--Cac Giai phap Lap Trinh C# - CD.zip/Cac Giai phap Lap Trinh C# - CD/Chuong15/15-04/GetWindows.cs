using System;
using System.Text;
using System.Runtime.InteropServices;

public class GetWindows
{
	public delegate bool CallBack(int hwnd, int lParam);

	[DllImport("user32.dll")]
	public static extern int EnumWindows(CallBack callback, int param); 

	[DllImport("user32.dll")]
	public static extern int GetWindowText(int hWnd, StringBuilder lpString, int nMaxCount);

	private static void Main()
	{
		CallBack callBack = new CallBack(DisplayWindowInfo);

		EnumWindows(callBack, 0);

		Console.ReadLine();
	}

	public static bool DisplayWindowInfo(int hWnd, int lParam) 
	{ 
		int chars = 100;
		StringBuilder buf = new StringBuilder(chars);
		if (GetWindowText(hWnd, buf, chars) != 0)
		{
			Console.WriteLine(buf);
		}
		return true;
	}
}