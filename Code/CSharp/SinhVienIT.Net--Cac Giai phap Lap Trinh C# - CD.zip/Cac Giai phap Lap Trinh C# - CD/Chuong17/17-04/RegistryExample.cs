using System;
using Microsoft.Win32;

public class RegistryExample {

    public static void Main(String[] args) {	
		
        if (args.Length > 0) {

            using(RegistryKey root = Registry.CurrentUser) {

                UpdateUsageCounter(root);

                SearchSubKeys(root, args[0]);
            }
        }				

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
	
    public static void UpdateUsageCounter(RegistryKey root) {

        RegistryKey countKey = root.CreateSubKey("RegistryExample");

        int count = (Int32)countKey.GetValue("UsageCount", 0);

        countKey.SetValue("UsageCount", ++count);
    }

    public static void SearchSubKeys(RegistryKey root, String searchKey) {

        foreach (string keyname in root.GetSubKeyNames()) {

            try {				
                using (RegistryKey key = root.OpenSubKey(keyname)) {	
                    if (keyname == searchKey) PrintKeyValues(key);
                    SearchSubKeys(key, searchKey);
                }
            } catch (System.Security.SecurityException) {
            }
        }											
    }		
		
    public static void PrintKeyValues(RegistryKey key) {	
	
        Console.WriteLine("Registry key found : {0} contains {1} values",
            key.Name, key.ValueCount);

        foreach (string valuename in key.GetValueNames()) {			
            if (key.GetValue(valuename) is String) {			
                Console.WriteLine("  Value : {0} = {1}", 
                    valuename, key.GetValue(valuename));
            }
        }
    } 				
}