<script type='text/javascript'>

$(document).ready(function () {
	var frmadd = $('.frmadd');
    var datatable = $('#datatable');

	$(".btninfocart").click(function (e) {

    
       
        var $td = $(this).closest('tr').children('td');
        

		var code = $td.eq(0).text(); $(".code").text(code);
		var Name = $td.eq(1).text(); $(".Name").text(Name);
		var Email = $td.eq(2).text(); $(".Email").text(Email);
		var Phone = $td.eq(3).text(); $(".Phone").text(Phone);
		var Address = $td.eq(4).text(); $(".Address").text(Address);
		var Createdate = $td.eq(6).text(); $(".Createdate").text(Createdate);
		//var Detail = $td.eq(5).text(); $(".Detail").text(Detail);

		if ($td.eq(7).text().indexOf('on')>0){

			$(".Startuscart").text('Đã xử lý');
			$(".Startuscart").removeClass('btn-danger').addClass('btn-success');
		}
		else {
			$(".Startuscart").text('Đang chờ');
			$(".Startuscart").removeClass('btn-success').addClass('btn-danger');
		}
		
		var tbl=document.getElementById("fbody3");
	    var myrow=tbl.rows.length;
	    $("#fbody2").html('');

	    var total=0;
	    var detail='';
	    for (var i = 0; i < myrow; i++) {
	      	var row=tbl.rows[i];
	      	var mycolumn=row.cells.length;
	      	
	      	if (row.cells[0].innerHTML==code) {
	      		var strdatacart='<tr>';
	      		
		      	for (var ic = 0; ic <mycolumn; ic++) {

			        var column=row.cells[ic].innerHTML;
			        
			        if (ic==1 || ic==2 || ic==3 || ic==4 || ic==5) {
			        	if (ic==1 || ic==2) {
			        		if (ic==1) {
			        			strdatacart +="<td><img style='width: 55px;height: 55px;' src='"+column+"'></img> ";
			        		};
			        		if (ic==2) {
			        			strdatacart +=column+"</td>";
			        		};
			        	};
			        	if (ic==3) {
			        		var pri=parseInt(column);
			        		strdatacart +="<td  style='text-align: center;'>"+column+".đ</td>";
			        	};
			        	if (ic==4) {
			        		var qty=parseInt(column);
			        		strdatacart +="<td  style='text-align: center;'>"+column+"</td>";
			        	};
			        	if (ic==5) {
			        		total += pri*qty;
			        		detail +=column;
			        		strdatacart +="<td  style='text-align: center;'>"+pri*qty+".đ</td>";
			        	};
			        	
			        };
			        

		      	};
		      	strdatacart += '</tr>';
		      	$("#fbody2").append(strdatacart);
	      	};
	      		      	
	    };
	    //alert(detail);
	    $(".allmn").text("Tổng tiền : "+total+".đ");
	    $(".GhiChu").text(detail);

	    e.preventDefault();
	   	datatable.hide(500);
	    frmadd.fadeIn(500);
    });

   
});


function Update_Cart_Startus(id)
    {
    	var Items = $('.Items'+id);
    	var reload = $('.reload'+id);
    	    
    	Items.hide(500);
    	reload.fadeIn(500);
        var data={
            Product_code:id,
            Startus:$('.Startus'+id).text()
        };

        

                    $.ajax({
                       type: 'post',
                       url: '<?php echo admin_url();?>/purchase_order_ok/Purchase_order',
                       data: data,
                       success: function (response) {
                        reload.hide(500);
                        if ($('.Startus'+id).text()=='on') {
				            $('.Startus'+id).text('');
				            Items.removeClass('icon-ok').addClass('icon-remove');
				            
				        }else
				        if($('.Startus'+id).text()!='on') {
				            $('.Startus'+id).text('on');
				            Items.removeClass('icon-remove').addClass('icon-ok');
				            
				        };

                        Items.fadeIn(500);
                       }
                     });
                    
    }


</script> 
<?php

    

           //$conn = @mysqli_connect('localhost','root','', 'testshopweb') or die ('Lỗi kết nối');
            //mysqli_query($conn, "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
      

			
?>
    <div id='datatable' class='container-fluid'>
        <input id='searchInput' value='' placeholder='Key' class='span3 email' style='margin-left: 5%;'/>
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>
                        
                        <span class='icon'><span style="color:#000080"><span style="font-size:14px"><strong>Danh sách đơn đặt hàng</strong></span></span></span>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã đơn hàng</th>  
                                    <th>Khách hàng</th>  
                                    <th>Email</th>  
                                    <th>Điện thoại</th>  
                                    <th>Địa chỉ</th>  
                                    <th>Tổng tiền</th>
                                    <th>Ngày tạo</th>
                                    <th>Giao hàng</th>    
                                    <th>Quản lý</th>
                                </tr>
                            </thead>
                            <tbody id='fbody'>
                            <?php
                                $i=0;
                                foreach ($tbluser->result() as $row):
                                    $i++;
                            ?>
                                <tr class=" items_">
                                    <td><?php echo $row->Product_code; ?></td>
                                    <td><?php echo $row->Name; ?></td>
                                    <td><?php echo $row->Email; ?></td>
                                    <td><?php echo $row->Phone; ?></td>
                                    <td><?php echo $row->Address; ?></td>
                                    <td>
                                    <?php $money=0;
                                    foreach ($tblpurchase_order as $row2):
                                    	
                                    	if ($row->Product_code==$row2->Product_code) {
                                    		$money += $row2->Product_price*$row2->Product_quantity;
                                    	}

                                    endforeach;
                                    echo $money;
                                    
                                    ?>.đ
                                    </td>
                                    <td><?php 
                                    foreach ($tblpurchase_order as $row3):
                                    	if ($row->Product_code==$row3->Product_code) {
                                    		echo $row3->Createdate; break;
                                    	}
                                    endforeach;
                                    ?></td>
                                    <td style='text-align: center;'>
	                                    <div style="color:#fff;background:rgba(0,0,0,0.0);width:1px;height:1px;overflow:auto;">
	                                    	<label class='Startuslv Startus<?php echo $row->Product_code; ?>'><?php echo $row->Startus; ?></label>
	                                    </div>
	                                    <i class='reload reload<?php echo $row->Product_code; ?>' style='display: none;'></i>
	                                    <?php
	                                     	if($row->Startus=='on'){
	                                    ?>
	                                     	<label class="Items<?php echo $row->Product_code; ?> icon-ok" onclick="Update_Cart_Startus('<?php echo $row->Product_code; ?>')"></label>
	                                    <?php }
	                                     	else {
	                                    ?>
	                                		<label class="Items<?php echo $row->Product_code; ?> icon-remove" onclick="Update_Cart_Startus('<?php echo $row->Product_code; ?>')"></label> 
	                                   	<?php
	                                   		}
	                                   	?>
                                    	
                                    </td>
                                    
                                    <td style='text-align: center;'><a href='#' class='btn btninfocart btn-mini tip-top btn-primary' data-original-title='Chi tiết'>Chi tiết</a></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div><div id='pagination' class='' style='text-align: center;'></div>
            </div>
        </div>
    </div>



<div class='frmadd' style='width:75%;text-align: center; margin-left: 12%;'>
		<div class='container-fluid'>
			<div class='row-fluid'>
				<div class='span12'>
					<div class='widget-box'>
						<div class='widget-title'>
									<span class='icon'>
										<i class='icon-list'></i>
									</span>
									<h5>Chi tiết đơn hàng <span id="code" class="code"></span></h5>
						</div>
						<div class='widget-content nopadding'  align='left'>
							<form id='form1' class='form-horizontal' name='form1' method='post' action='?c=feedbacklist&a=update'>


							
	                            <div class="widget-content tab-content">
	                                <div id="tab1" class="tab-pane active" style="margin-left:5%;margin-top:5%;margin-bottom:2%;margin-right:5%;">
	                                	<p><h5>Tên khách hàng: </h5></p><p><h4><label id="Name" class="Name"></label></h4></p>
	                  					<p><h5>Số điện thoại: </h5></p><p><h4><label id="Phone" class="Phone"></label></h4></p>
	                  					<p><h5>Email: </h5></p><h4><label id="Email" class="Email"></label></h4></p>
	                  					<p><h5>Địa chỉ: </h5></p><p><h4><label id="Address" class="Address"></label> </h4></p>
	                  					<p><h5>Đơn hàng : <span id="code" class="code"></span></h5></p>
	                  					<p><h5>Ngày tạo : <span class="Createdate"></span></h5></p>
	                                </div>
	                               
	                            </div>                            
                        		


                        		<div id='datacart' class='container-fluid'>
        
							        <div class='row-fluid'>
							            <div class='span12'>
							                <div class='widget-box'>
							                    <div class='widget-title'>
							                        <span class='icon'><i class='icon-th'></i></span>
							                        
							                        <span class='icon'><span style="color:#000080"><span style="font-size:14px"><strong>Danh sách sản phẩm</strong></span></span></span>
							                    </div>
							                    <div class='widget-content nopadding' style='overflow: auto;'>
							                        <table class='table table-bordered data-table paginated'>
							                            <thead>
							                                <tr>
							                                    <th>Sản phẩm</th>  
							                                    <th>Giá bán</th>  
							                                    <th>Số lượng</th> 
							                                    <th>Thành tiền</th>  
							                                </tr>
							                            </thead>
							                            <tbody id='fbody2'>
							                            
							                                
							                           
							                            </tbody>
							                        </table>


							                    </div>
							                </div>
							            </div>
							            <div style="margin-left:5%;margin-bottom:2%;">
							            	<label class="allmn" style="font-size:20px;"></label>
							            	<label>( Đã bao gồm VAT )</label>
							            </div>
							            <div class="span4" style="margin-bottom:7%;">
											<div class="widget-box">
												<div class="widget-title">
													<span class="icon">
														<i class="icon-th-list"></i>
													</span>
													<h5>Ghi chú</h5>
												</div>
												<div class="widget-content">
													<label class="GhiChu"></label>
												</div>
											</div>
										</div>
							        </div>
							    </div>
								
							    

								
								<div class='form-actions'   align='center'>
									<button type='button' class='btn btn-success Startuscart'> </button>
									<button type='button' class='btn btn-back'> </button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	

	






	 <div id='datatable2' class='container-fluid' style="display:none;">
        
        <div class='row-fluid'>
            <div class='span12'>
                <div class='widget-box'>
                    <div class='widget-title'>
                        <span class='icon'><i class='icon-th'></i></span>
                        
                        <span class='icon'><span style="color:#000080"><span style="font-size:14px"><strong>Danh sách đơn hàng</strong></span></span></span>
                    </div>
                    <div class='widget-content nopadding' style='overflow: auto;'>
                        <table class='table table-bordered data-table paginated'>
                            <thead>
                                <tr>
                                    <th>Mã đơn hàng</th>  
                                    <th>Hình ảnh</th>
                                    <th>Tên sản phẩm</th>    
                                    <th>Giá bán</th>  
                                    <th>Số lượng</th>  
                                    <th>Mô tả</th>
                                    <th>Ngày tạo</th>
                                </tr>
                            </thead>
                            <tbody id='fbody3' class="fbody3">
                            <?php
                                
                                foreach ($tblpurchase_order as $row):
                                    
                            ?>
                                <tr>
                                    <td><?php echo $row->Product_code; ?></td>
                                    <td><?php echo base_url().$row->Product_img; ?></td>
                                    <td><?php echo $row->Product_name; ?></td>
                                    <td><?php echo $row->Product_price; ?></td>
                                    <td><?php echo $row->Product_quantity; ?></td>
                                    <td><?php echo $row->Product_note; ?></td>
                                    <td><?php echo $row->Createdate; ?></td>
                                </tr>
                            <?php
                            endforeach;
                            ?>
                            </tbody>
                        </table>


                    </div>
                </div>
            </div>
        </div>
    </div>






	
</div>
