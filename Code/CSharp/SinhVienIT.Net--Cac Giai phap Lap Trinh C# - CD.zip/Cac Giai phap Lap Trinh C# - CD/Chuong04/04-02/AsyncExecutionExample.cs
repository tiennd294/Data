using System;
using System.Threading;
using System.Collections;

public class AsyncExecutionExample {

    public delegate DateTime AsyncExampleDelegate(int delay, string name);

    public static DateTime LongRunningMethod(int delay, string name) {

        Console.WriteLine("{0} : {1} example - thread starting.", 
            DateTime.Now.ToString("HH:mm:ss.ffff"), name);

        Thread.Sleep(delay);

        Console.WriteLine("{0} : {1} example - thread finishing.", 
            DateTime.Now.ToString("HH:mm:ss.ffff"), name);

        return DateTime.Now;
    }

    public static void BlockingExample() {

        Console.WriteLine(Environment.NewLine + 
            "*** Running Blocking Example ***");

        AsyncExampleDelegate longRunningMethod = 
            new AsyncExampleDelegate(LongRunningMethod);

        IAsyncResult asyncResult = longRunningMethod.BeginInvoke(2000, 
            "Blocking", null, null);

        for (int count = 0; count < 3; count++) {
            Console.WriteLine("{0} : Continue processing until ready " +
                "to block...", DateTime.Now.ToString("HH:mm:ss.ffff"));
            Thread.Sleep(200);
        }

        Console.WriteLine("{0} : Blocking until method is complete...",
            DateTime.Now.ToString("HH:mm:ss.ffff"));
        DateTime completion = longRunningMethod.EndInvoke(asyncResult);

        Console.WriteLine("{0} : Blocking example complete.",
            completion.ToString("HH:mm:ss.ffff"));
    }

    public static void PollingExample() {

        Console.WriteLine(Environment.NewLine + 
            "*** Running Polling Example ***");

        AsyncExampleDelegate longRunningMethod = 
            new AsyncExampleDelegate(LongRunningMethod);

        IAsyncResult asyncResult = longRunningMethod.BeginInvoke(2000, 
            "Polling", null, null);

        Console.WriteLine("{0} : Poll repeatedly until method is " +
            "complete...", DateTime.Now.ToString("HH:mm:ss.ffff"));
        while(!asyncResult.IsCompleted) {
            Console.WriteLine("{0} : Polling...", 
                DateTime.Now.ToString("HH:mm:ss.ffff"));
            Thread.Sleep(300);
        }

        DateTime completion = longRunningMethod.EndInvoke(asyncResult);

        Console.WriteLine("{0} : Polling example complete.",
            completion.ToString("HH:mm:ss.ffff"));
    }

    public static void WaitingExample() {

        Console.WriteLine(Environment.NewLine + 
            "*** Running Waiting Example ***");

        AsyncExampleDelegate longRunningMethod = 
            new AsyncExampleDelegate(LongRunningMethod);

        IAsyncResult asyncResult = longRunningMethod.BeginInvoke(2000, 
            "Waiting", null, null);

        Console.WriteLine("{0} : Waiting until method is complete...", 
            DateTime.Now.ToString("HH:mm:ss.ffff"));
        while(!asyncResult.AsyncWaitHandle.WaitOne(300, false)) {
            Console.WriteLine("{0} : Wait timeout...",
                DateTime.Now.ToString("HH:mm:ss.ffff"));
        }

        DateTime completion = longRunningMethod.EndInvoke(asyncResult);

        Console.WriteLine("{0} : Waiting example complete.",
            completion.ToString("HH:mm:ss.ffff"));
    }

    public static void WaitAllExample() {

        Console.WriteLine(Environment.NewLine + 
            "*** Running WaitAll Example ***");

        ArrayList asyncResults = new ArrayList(3);

        AsyncExampleDelegate longRunningMethod = 
            new AsyncExampleDelegate(LongRunningMethod);

        asyncResults.Add(longRunningMethod.BeginInvoke(3000, 
            "WaitAll 1", null, null));

        asyncResults.Add(longRunningMethod.BeginInvoke(2500, 
            "WaitAll 2", null, null));

        asyncResults.Add(longRunningMethod.BeginInvoke(1500, 
            "WaitAll 3", null, null));

        WaitHandle[] waitHandles = new WaitHandle[3];

        for (int count = 0; count < 3; count++) {

            waitHandles[count] = 
                ((IAsyncResult)asyncResults[count]).AsyncWaitHandle;
        }

        Console.WriteLine("{0} : Waiting until all 3 methods are " + 
            "complete...", DateTime.Now.ToString("HH:mm:ss.ffff"));
        while(!WaitHandle.WaitAll(waitHandles, 300, false)) {
            Console.WriteLine("{0} : WaitAll timeout...", 
                DateTime.Now.ToString("HH:mm:ss.ffff"));
        }

        DateTime completion = DateTime.MinValue;

        foreach (IAsyncResult result in asyncResults) {

            DateTime time = longRunningMethod.EndInvoke(result);
            if ( time > completion) completion = time;
        }

        Console.WriteLine("{0} : WaitAll example complete.",
            completion.ToString("HH:mm:ss.ffff"));
    }

    public static void CallbackExample() {

        Console.WriteLine(Environment.NewLine + 
            "*** Running Callback Example ***");

        AsyncExampleDelegate longRunningMethod = 
            new AsyncExampleDelegate(LongRunningMethod);

        IAsyncResult asyncResult = longRunningMethod.BeginInvoke(2000, 
            "Callback", new AsyncCallback(CallbackHandler), 
            longRunningMethod);

        for (int count = 0; count < 15; count++) {
            Console.WriteLine("{0} : Continue processing...", 
                DateTime.Now.ToString("HH:mm:ss.ffff"));
            Thread.Sleep(200);
        }
    }

    public static void CallbackHandler(IAsyncResult result) {

        AsyncExampleDelegate longRunningMethod = 
            (AsyncExampleDelegate)result.AsyncState;

        DateTime completion = longRunningMethod.EndInvoke(result);

        Console.WriteLine("{0} : Callback example complete.",
            completion.ToString("HH:mm:ss.ffff"));
    }

    public static void Main() {
        
        BlockingExample();
        PollingExample();
        WaitingExample();
        WaitAllExample();
        CallbackExample();

        Console.WriteLine("");
        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}