Namespace TestQuanbLyBanHang
	Partial Class Form3
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.lblDM = New System.Windows.Forms.Label()
			Me.dataGridView1 = New System.Windows.Forms.DataGridView()
			Me.button1 = New System.Windows.Forms.Button()
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' lblDM
			' 
			Me.lblDM.AutoSize = True
			Me.lblDM.Font = New System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(0))
			Me.lblDM.Location = New System.Drawing.Point(89, 20)
			Me.lblDM.Name = "lblDM"
			Me.lblDM.Size = New System.Drawing.Size(323, 36)
			Me.lblDM.TabIndex = 0
			Me.lblDM.Text = "Danh Muc Khach Hang"
			' 
			' dataGridView1
			' 
			Me.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dataGridView1.Location = New System.Drawing.Point(26, 59)
			Me.dataGridView1.Name = "dataGridView1"
			Me.dataGridView1.Size = New System.Drawing.Size(497, 205)
			Me.dataGridView1.TabIndex = 1
			' 
			' button1
			' 
			Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(0))
			Me.button1.Location = New System.Drawing.Point(416, 280)
			Me.button1.Name = "button1"
			Me.button1.Size = New System.Drawing.Size(84, 36)
			Me.button1.TabIndex = 2
			Me.button1.Text = "Tro Ve"
			Me.button1.UseVisualStyleBackColor = True
			AddHandler Me.button1.Click, New System.EventHandler(Me.button1_Click)
			' 
			' Form3
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(548, 337)
			Me.Controls.Add(Me.button1)
			Me.Controls.Add(Me.dataGridView1)
			Me.Controls.Add(Me.lblDM)
			Me.Name = "Form3"
			Me.Text = "Form3"
			Me.Load += New System.EventHandler(Me.Form3_Load)
			DirectCast(Me.dataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private lblDM As System.Windows.Forms.Label
		Private dataGridView1 As System.Windows.Forms.DataGridView
		Private button1 As System.Windows.Forms.Button
	End Class
End Namespace
