<?php
//520093696-536870911
$ranges=Array(
);
?>