﻿namespace FileCopier
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtSource = new System.Windows.Forms.TextBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmdFindSource = new System.Windows.Forms.Button();
            this.cmdFindDes = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.prbCopy = new System.Windows.Forms.ProgressBar();
            this.cmdCopy = new System.Windows.Forms.Button();
            this.nudBufferSize = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.lblCopiedSize = new System.Windows.Forms.Label();
            this.lblFileSize = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudBufferSize)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nguồn";
            // 
            // txtSource
            // 
            this.txtSource.Location = new System.Drawing.Point(76, 9);
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(469, 20);
            this.txtSource.TabIndex = 1;
            // 
            // txtDes
            // 
            this.txtDes.Location = new System.Drawing.Point(76, 56);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(469, 20);
            this.txtDes.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Đích";
            // 
            // cmdFindSource
            // 
            this.cmdFindSource.Location = new System.Drawing.Point(551, 7);
            this.cmdFindSource.Name = "cmdFindSource";
            this.cmdFindSource.Size = new System.Drawing.Size(31, 22);
            this.cmdFindSource.TabIndex = 4;
            this.cmdFindSource.Text = "...";
            this.cmdFindSource.UseVisualStyleBackColor = true;
            this.cmdFindSource.Click += new System.EventHandler(this.cmdFindSource_Click);
            // 
            // cmdFindDes
            // 
            this.cmdFindDes.Location = new System.Drawing.Point(551, 54);
            this.cmdFindDes.Name = "cmdFindDes";
            this.cmdFindDes.Size = new System.Drawing.Size(31, 22);
            this.cmdFindDes.TabIndex = 5;
            this.cmdFindDes.Text = "...";
            this.cmdFindDes.UseVisualStyleBackColor = true;
            this.cmdFindDes.Click += new System.EventHandler(this.cmdFindDes_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Buffer size";
            // 
            // prbCopy
            // 
            this.prbCopy.Location = new System.Drawing.Point(15, 136);
            this.prbCopy.Name = "prbCopy";
            this.prbCopy.Size = new System.Drawing.Size(567, 21);
            this.prbCopy.TabIndex = 9;
            // 
            // cmdCopy
            // 
            this.cmdCopy.Location = new System.Drawing.Point(523, 163);
            this.cmdCopy.Name = "cmdCopy";
            this.cmdCopy.Size = new System.Drawing.Size(59, 30);
            this.cmdCopy.TabIndex = 10;
            this.cmdCopy.Text = "Copy";
            this.cmdCopy.UseVisualStyleBackColor = true;
            this.cmdCopy.Click += new System.EventHandler(this.cmdCopy_Click);
            // 
            // nudBufferSize
            // 
            this.nudBufferSize.Location = new System.Drawing.Point(76, 82);
            this.nudBufferSize.Maximum = new decimal(new int[] {
            20480,
            0,
            0,
            0});
            this.nudBufferSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudBufferSize.Name = "nudBufferSize";
            this.nudBufferSize.Size = new System.Drawing.Size(146, 20);
            this.nudBufferSize.TabIndex = 11;
            this.nudBufferSize.Value = new decimal(new int[] {
            512,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(228, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "KB";
            // 
            // lblPercent
            // 
            this.lblPercent.Location = new System.Drawing.Point(523, 120);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(59, 13);
            this.lblPercent.TabIndex = 13;
            this.lblPercent.Text = "0 %";
            this.lblPercent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCopiedSize
            // 
            this.lblCopiedSize.Location = new System.Drawing.Point(12, 120);
            this.lblCopiedSize.Name = "lblCopiedSize";
            this.lblCopiedSize.Size = new System.Drawing.Size(297, 13);
            this.lblCopiedSize.TabIndex = 14;
            this.lblCopiedSize.Text = "0 bytes of 0 bytes";
            this.lblCopiedSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblFileSize
            // 
            this.lblFileSize.Location = new System.Drawing.Point(74, 35);
            this.lblFileSize.Name = "lblFileSize";
            this.lblFileSize.Size = new System.Drawing.Size(354, 13);
            this.lblFileSize.TabIndex = 15;
            this.lblFileSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 202);
            this.Controls.Add(this.lblFileSize);
            this.Controls.Add(this.lblCopiedSize);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.nudBufferSize);
            this.Controls.Add(this.cmdCopy);
            this.Controls.Add(this.prbCopy);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmdFindDes);
            this.Controls.Add(this.cmdFindSource);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSource);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "csharpviet.tk - Copy file";
            ((System.ComponentModel.ISupportInitialize)(this.nudBufferSize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSource;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button cmdFindSource;
        private System.Windows.Forms.Button cmdFindDes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar prbCopy;
        private System.Windows.Forms.Button cmdCopy;
        private System.Windows.Forms.NumericUpDown nudBufferSize;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.Label lblCopiedSize;
        private System.Windows.Forms.Label lblFileSize;
    }
}

