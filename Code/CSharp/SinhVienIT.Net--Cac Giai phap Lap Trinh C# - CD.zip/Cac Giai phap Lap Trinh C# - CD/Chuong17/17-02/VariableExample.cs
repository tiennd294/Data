using System;
using System.Collections;

public class VariableExample {

    public static void Main () {

        Console.WriteLine("Path = " + 
            Environment.GetEnvironmentVariable("Path"));
		Console.WriteLine();

        Console.WriteLine(Environment.ExpandEnvironmentVariables(
                "The Path on %computername% is %Path%"));
		Console.WriteLine();

        IDictionary vars = Environment.GetEnvironmentVariables();
        foreach (string s in vars.Keys) {
            if (s.ToUpper().StartsWith("P")) {
                Console.WriteLine(s + " = " + vars[s]);
            }
        }
		Console.WriteLine();

        Console.WriteLine("Main method complete. Press Enter.");
        Console.ReadLine();
    }
}