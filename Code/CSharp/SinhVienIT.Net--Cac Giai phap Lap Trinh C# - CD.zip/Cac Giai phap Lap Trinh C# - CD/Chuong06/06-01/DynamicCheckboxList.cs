using System;
using System.Windows.Forms;

public class DynamicCheckBoxForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Panel panel;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DynamicCheckBoxForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if (components != null) 
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.panel = new System.Windows.Forms.Panel();
		this.SuspendLayout();
		// 
		// panel
		// 
		this.panel.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.panel.AutoScroll = true;
		this.panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
		this.panel.Location = new System.Drawing.Point(8, 8);
		this.panel.Name = "panel";
		this.panel.Size = new System.Drawing.Size(276, 248);
		this.panel.TabIndex = 0;
		// 
		// DynamicCheckBoxForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.panel});
		this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.Name = "DynamicCheckBoxForm";
		this.Text = "Dynamic Checkbox List";
		this.Load += new System.EventHandler(this.DynamicChecboxForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new DynamicCheckBoxForm());
	}

	private void DynamicChecboxForm_Load(object sender, System.EventArgs e)
	{
		string[] foods = {"Grain", "Bread", "Beans", "Eggs",
								"Chicken", "Milk", "Fruit", "Vegetables",
								"Pasta", "Rice", "Fish", "Beef"};
		
		int topPosition = 10;
		foreach (string food in foods)
		{
			CheckBox checkBox = new CheckBox();
			checkBox.Left = 10;
			checkBox.Top = topPosition;
			topPosition += 30;
			checkBox.Text = food;

			panel.Controls.Add(checkBox);
		}
	}
}