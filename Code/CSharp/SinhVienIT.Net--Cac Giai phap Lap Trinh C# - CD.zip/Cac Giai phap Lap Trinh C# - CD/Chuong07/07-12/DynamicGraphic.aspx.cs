using System;
using System.Web;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Drawing.Drawing2D;

/// <summary>
/// Summary description for DynamicGraphic.
/// </summary>
public class DynamicGraphic : System.Web.UI.Page
{
	private void Page_Load(object sender, System.EventArgs e)
	{
		string text = "";
		if (Request.QueryString["image"] == null)
		{
			Response.Redirect(Request.Url + "?image=" +
                Server.UrlEncode("This is a test image"));
		}
		else
		{
			text = Server.UrlDecode(Request.QueryString["image"]);
		}
		
		int width = 300, height = 200;
		Bitmap bitmap = new Bitmap(width, height);

		Graphics graphics = Graphics.FromImage(bitmap);

		graphics.Clear(Color.OrangeRed);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;

		graphics.FillRectangle(new SolidBrush(Color.Olive), 5, 5, 
			width - 10, height - 10);

		Font fontBanner = new Font("Verdana", 24, FontStyle.Bold);
		StringFormat stringFormat = new StringFormat();
		stringFormat.Alignment = StringAlignment.Center;
		stringFormat.LineAlignment = StringAlignment.Center;

		graphics.DrawString(text, fontBanner, new 
			SolidBrush(Color.LightYellow), new Rectangle(0, 0, width, height), 
			stringFormat);

		//bitmap.Save(strFilename, ImageFormat.Jpeg);

		bitmap.Save(Response.OutputStream, 
		    System.Drawing.Imaging.ImageFormat.Gif);

		graphics.Dispose();
		bitmap.Dispose();
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.Load += new System.EventHandler(this.Page_Load);
	}
	#endregion
}