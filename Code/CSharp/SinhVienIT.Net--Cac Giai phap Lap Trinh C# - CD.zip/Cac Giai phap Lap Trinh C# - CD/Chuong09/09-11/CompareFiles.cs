using System;
using System.IO;
using System.Security.Cryptography;

public class CompareFiles
{
	private	static void Main(string[] args)
	{
		if (args.Length != 2)
		{
			Console.WriteLine("USAGE:  CompareFiles [fileName] [fileName]");
			Console.ReadLine();
			return;
		}    

        Console.WriteLine("Comparing " + args[0] + " and " + args[1]);

        HashAlgorithm hashAlg = HashAlgorithm.Create();

        FileStream fsA = new FileStream(args[0], FileMode.Open);
        byte[] hashBytesA = hashAlg.ComputeHash(fsA);
		fsA.Close();

		FileStream fsB = new FileStream(args[1], FileMode.Open);
		byte[] hashBytesB = hashAlg.ComputeHash(fsB);
		fsB.Close();

		if (BitConverter.ToString(hashBytesA) ==
			BitConverter.ToString(hashBytesB))
		{
			Console.WriteLine("Files match.");
		}
		else
		{
			Console.WriteLine("No match.");
		}
        
		Console.ReadLine();

	}
}